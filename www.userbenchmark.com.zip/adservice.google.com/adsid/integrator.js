processGoogleToken({
    "newToken": "",
    "validLifetimeSecs": 300,
    "freshLifetimeSecs": 300,
    "1p_jar": "2023-04-09-19",
    "pucrd": ""
});