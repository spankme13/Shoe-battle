apstag.punt({
    "cmp": "https://s.amazon-adsystem.com/iu3?cm3ppd=1&d=dtb-pub&csif=t&dl=n-mediagrid_n-index_n-LoopMe_n-MediaNet_n-Beeswax_ox-db5_smrt_n-smaato_n-sharethrough_pm-db5_ym_rbd_n-vmg_r1u",
    "cb": "0"
})