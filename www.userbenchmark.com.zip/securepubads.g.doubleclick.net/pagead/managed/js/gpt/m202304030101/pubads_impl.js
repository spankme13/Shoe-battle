(function(_) {
    /* 
     
     Copyright The Closure Library Authors. 
     SPDX-License-Identifier: Apache-2.0 
    */
    /* 
     
     SPDX-License-Identifier: Apache-2.0 
    */
    var da, fa, ia, la, ma, qa, sa, va, Aa, xa, Ba, Ca, Ea, Fa, Ga, Ia, Ja, Na, Pa, Qa, Ra, Sa, Ta, Ua, Va, Xa, Wa, Ya, Za, ab, bb, gb, hb, jb, lb, nb, rb, xb, zb, Fb, Mb, Pb, Tb, Vb, Xb, Zb, dc, fc, ac, hc, ic, jc, kc, lc, pc, qc, rc, sc, tc, uc, xc, zc, yc, Ac, Cc, Dc, Ec, Fc, Ic, Mc, Lc, Kc, Qc, Rc, Tc, Uc, Xc, Yc, Zc, $c, dd, gd, kd, md, pd, rd, qd, ud, sd, td, vd, Ad, wd, Sc, Cd, Dd, Ed, Id, Ld, Fd, Gd, Pd, Qd, Td, Ud, Nd, Od, Vd, Zd, $d, be, ce, de, ge, he, ke, pe, qe, se, te, ve, we, xe, ye, Be, De, He, We, Ne, Ye, af, cf, df, ff, kf, lf, mf, pf, qf, tf, Bf, uf, Ff, Gf, Jf, Kf, Qf, Of, Nf, Mf, Vf, eg, fg, gg, tg, Og, yg, Ng, Tg, Xg, Yg, $g, dh, bh, ih, nh, rh, sh, th, ph, qh, uh, vh, Bh, zh, Eh, Kh, Mh, Nh, Oh, Vh, Zh, J, $h, fi, di, qi, Ji, Li, Mi, Oi, Pi, Ri, Ti, Wi, Zi, aj, dj, fj, ej, mj, nj, oj, pj, gj, qj, hj, sj, uj, vj, xj, wj, Cj, Aj, Dj, Mj, Pj, Hj, Ij, Qj, Rj, Tj, Uj, Vj, Wj, ak, gk, ck, Yj, nk, lk, mk, ok, pk, qk, sk, Ek, Fk, Ik, Kk, M, Mk, Nk, Ok, Qk, Sk, Tk, Uk, Xk, Wk, Vk, el, hl, ol, pl, rl, sl, wl, yl, Cl, Il, Kl, Ml, Nl, $l, bm, em, gm, im, jm, lm, nm, om, mm, ta, rm, sm, um, wm, ym, zm, Am, Cm, Dm, Em, Gm, Lm, Pm, Qm, Um, Vm, Wm, Xm, $m, Ym, an, cn, dn, en, fn, gn, kn, ln, nn, rn, pn, tn, un, An, Bn, Dn, In, Jn, Ln, Qn, Vn, Xn, bo, fo, co, eo, ho, ro, po, so, vo, io, Eo, Go, Ho, Io, Jo, Mo, No, Oo, Vo, Xo, Yo, $o, ap, bp, cp, fp, hp, op, ip, jp, ep, sp, tp, wp, Mp, Zp, $p, bq, hq, kq, lq, mq, rq, sq, xq, yq, Bq, Gq, Hq, Iq, zr, Cr, Dr, Lr, Nr, Pr, Sr, Tr, Ur, Vr, Xr, Yr, Zr, $r, as, bs, cs, js, ks, ls, Bb, Db, Eb, ns, qs, os, ps, rs, ss, wa, oa, pa, ws, xs, gf;
    da = function(a) {
        return function() {
            return _.ba[a].apply(this, arguments)
        }
    };
    fa = function(a) {
        return a ? a.passive && ea() ? a : a.capture || !1 : !1
    };
    ia = function(a, b) {
        b = _.ha(a, b);
        var c;
        (c = 0 <= b) && Array.prototype.splice.call(a, b, 1);
        return c
    };
    la = function(a) {
        var b = a.length;
        if (0 < b) {
            for (var c = Array(b), d = 0; d < b; d++) c[d] = a[d];
            return c
        }
        return []
    };
    ma = function(a, b, c) {
        return 2 >= arguments.length ? Array.prototype.slice.call(a, b) : Array.prototype.slice.call(a, b, c)
    };
    qa = function(a) {
        for (var b = 0, c = 0, d = {}; c < a.length;) {
            var e = a[c++],
                f = _.na(e) ? "o" + (Object.prototype.hasOwnProperty.call(e, oa) && e[oa] || (e[oa] = ++pa)) : (typeof e).charAt(0) + e;
            Object.prototype.hasOwnProperty.call(d, f) || (d[f] = !0, a[b++] = e)
        }
        a.length = b
    };
    sa = function(a, b) {
        a.sort(b || _.ra)
    };
    va = function(a) {
        for (var b = ta, c = Array(a.length), d = 0; d < a.length; d++) c[d] = {
            index: d,
            value: a[d]
        };
        var e = b || _.ra;
        sa(c, function(f, g) {
            return e(f.value, g.value) || f.index - g.index
        });
        for (b = 0; b < a.length; b++) a[b] = c[b].value
    };
    Aa = function(a, b) {
        if (!wa(a) || !wa(b) || a.length != b.length) return !1;
        for (var c = a.length, d = xa, e = 0; e < c; e++)
            if (!d(a[e], b[e])) return !1;
        return !0
    };
    _.ra = function(a, b) {
        return a > b ? 1 : a < b ? -1 : 0
    };
    xa = function(a, b) {
        return a === b
    };
    Ba = function(a, b) {
        for (var c = {}, d = 0; d < a.length; d++) {
            var e = a[d],
                f = b.call(void 0, e, d, a);
            void 0 !== f && (c[f] || (c[f] = [])).push(e)
        }
        return c
    };
    Ca = function(a) {
        for (var b = [], c = 0; c < arguments.length; c++) {
            var d = arguments[c];
            if (Array.isArray(d))
                for (var e = 0; e < d.length; e += 8192)
                    for (var f = Ca.apply(null, ma(d, e, e + 8192)), g = 0; g < f.length; g++) b.push(f[g]);
            else b.push(d)
        }
        return b
    };
    Ea = function(a, b) {
        for (var c in a) b.call(void 0, a[c], c, a)
    };
    Fa = function(a) {
        var b = [],
            c = 0,
            d;
        for (d in a) b[c++] = a[d];
        return b
    };
    Ga = function(a, b) {
        for (var c in a)
            if (b.call(void 0, a[c], c, a)) return c
    };
    Ia = function(a, b) {
        for (var c, d, e = 1; e < arguments.length; e++) {
            d = arguments[e];
            for (c in d) a[c] = d[c];
            for (var f = 0; f < Ha.length; f++) c = Ha[f], Object.prototype.hasOwnProperty.call(d, c) && (a[c] = d[c])
        }
    };
    Ja = function() {
        var a = _.q.navigator;
        return a && (a = a.userAgent) ? a : ""
    };
    Na = function(a) {
        return Ka ? La ? La.brands.some(function(b) {
            return (b = b.brand) && Ma(b, a)
        }) : !1 : !1
    };
    Pa = function(a) {
        return Ma(Ja(), a)
    };
    Qa = function(a) {
        for (var b = RegExp("([A-Z][\\w ]+)/([^\\s]+)\\s*(?:\\((.*?)\\))?", "g"), c = [], d; d = b.exec(a);) c.push([d[1], d[2], d[3] || void 0]);
        return c
    };
    Ra = function() {
        return Ka ? !!La && 0 < La.brands.length : !1
    };
    Sa = function() {
        return Ra() ? !1 : Pa("Opera")
    };
    Ta = function() {
        return Ra() ? !1 : Pa("Trident") || Pa("MSIE")
    };
    Ua = function() {
        return Ra() ? Na("Microsoft Edge") : Pa("Edg/")
    };
    Va = function() {
        return Pa("Firefox") || Pa("FxiOS")
    };
    Xa = function() {
        return Pa("Safari") && !(Wa() || (Ra() ? 0 : Pa("Coast")) || Sa() || (Ra() ? 0 : Pa("Edge")) || Ua() || (Ra() ? Na("Opera") : Pa("OPR")) || Va() || Pa("Silk") || Pa("Android"))
    };
    Wa = function() {
        return Ra() ? Na("Chromium") : (Pa("Chrome") || Pa("CriOS")) && !(Ra() ? 0 : Pa("Edge")) || Pa("Silk")
    };
    Ya = function(a) {
        var b = {};
        a.forEach(function(c) {
            b[c[0]] = c[1]
        });
        return function(c) {
            return b[_.u(c, "find").call(c, function(d) {
                return d in b
            })] || ""
        }
    };
    Za = function() {
        var a = Ja();
        if (Ta()) {
            var b = /rv: *([\d\.]*)/.exec(a);
            if (b && b[1]) a = b[1];
            else {
                b = "";
                var c = /MSIE +([\d\.]+)/.exec(a);
                if (c && c[1])
                    if (a = /Trident\/(\d.\d)/.exec(a), "7.0" == c[1])
                        if (a && a[1]) switch (a[1]) {
                            case "4.0":
                                b = "8.0";
                                break;
                            case "5.0":
                                b = "9.0";
                                break;
                            case "6.0":
                                b = "10.0";
                                break;
                            case "7.0":
                                b = "11.0"
                        } else b = "7.0";
                        else b = c[1];
                a = b
            }
            return a
        }
        a = Qa(a);
        b = Ya(a);
        return Sa() ? b(["Version", "Opera"]) : (Ra() ? 0 : Pa("Edge")) ? b(["Edge"]) : Ua() ? b(["Edg"]) : Pa("Silk") ? b(["Silk"]) : Wa() ? b(["Chrome", "CriOS", "HeadlessChrome"]) : (a = a[2]) && a[1] || ""
    };
    ab = function() {
        var a = Qa(Ja());
        Ya(a);
        return Va() ? (a = a[2]) && a[1] || "" : ""
    };
    bb = function() {
        if (Ra()) {
            var a = _.u(La.brands, "find").call(La.brands, function(b) {
                return "Firefox" === b.brand
            });
            if (!a || !a.version) return NaN;
            a = a.version.split(".")
        } else {
            a = ab();
            if ("" === a) return NaN;
            a = a.split(".")
        }
        return 0 === a.length ? NaN : Number(a[0])
    };
    _.fb = function(a) {
        if (a instanceof _.cb) a = _.db(a);
        else {
            b: if (eb) {
                try {
                    var b = new URL(a)
                } catch (c) {
                    b = "https:";
                    break b
                }
                b = b.protocol
            } else c: {
                b = document.createElement("a");
                try {
                    b.href = a
                } catch (c) {
                    b = void 0;
                    break c
                }
                b = b.protocol;b = ":" === b || "" === b ? "https:" : b
            }
            a = "javascript:" !== b ? a : void 0
        }
        return a
    };
    gb = function(a) {
        throw Error("unexpected value " + a + "!");
    };
    hb = function(a) {
        var b, c, d = null == (c = (b = (a.ownerDocument && a.ownerDocument.defaultView || window).document).querySelector) ? void 0 : c.call(b, "script[nonce]");
        (b = d ? d.nonce || d.getAttribute("nonce") || "" : "") && a.setAttribute("nonce", b)
    };
    jb = function(a, b) {
        a.textContent = _.ib(b);
        hb(a)
    };
    lb = function(a, b) {
        a.src = _.kb(b);
        hb(a)
    };
    nb = function(a, b) {
        a.write(_.mb(b))
    };
    rb = function(a) {
        return new qb(function(b) {
            return b.substr(0, a.length + 1).toLowerCase() === a + ":"
        })
    };
    _.vb = function(a) {
        var b = void 0 === b ? sb : b;
        a: {
            b = void 0 === b ? sb : b;
            for (var c = 0; c < b.length; ++c) {
                var d = b[c];
                if (d instanceof qb && d.zh(a)) {
                    a = tb(a);
                    break a
                }
            }
            a = void 0
        }
        return a || _.ub
    };
    xb = function(a) {
        for (var b = _.wb.apply(1, arguments), c = [a[0]], d = 0; d < b.length; d++) c.push(String(b[d])), c.push(a[d + 1]);
        return tb(c.join(""))
    };
    zb = function(a) {
        var b = window,
            c = !0;
        c = void 0 === c ? !1 : c;
        new _.v.Promise(function(d, e) {
            function f() {
                g.onload = null;
                g.onerror = null;
                var h;
                null == (h = g.parentElement) || h.removeChild(g)
            }
            var g = b.document.createElement("script");
            g.onload = function() {
                f();
                d()
            };
            g.onerror = function() {
                f();
                e(void 0)
            };
            g.type = "text/javascript";
            lb(g, a);
            c && "complete" !== b.document.readyState ? _.yb(b, "load", function() {
                b.document.body.appendChild(g)
            }) : b.document.body.appendChild(g)
        })
    };
    Fb = function(a) {
        var b, c, d, e, f, g;
        return _.Ab(function(h) {
            switch (h.j) {
                case 1:
                    return b = "https://pagead2.googlesyndication.com/getconfig/sodar?sv=200&tid=" + a.j + ("&tv=" + a.o + "&st=") + a.ec, c = void 0, h.m = 2, Bb(h, Cb(b), 4);
                case 4:
                    c = h.o;
                    Db(h, 3);
                    break;
                case 2:
                    Eb(h);
                case 3:
                    if (!c) return h.return(void 0);
                    d = a.Ec || c.sodar_query_id;
                    e = void 0 !== c.rc_enable && a.m ? c.rc_enable : "n";
                    f = void 0 === c.bg_snapshot_delay_ms ? "0" : c.bg_snapshot_delay_ms;
                    g = void 0 === c.is_gen_204 ? "1" : c.is_gen_204;
                    return d && c.bg_hash_basename && c.bg_binary ? h.return({
                        context: a.H,
                        Ag: c.bg_hash_basename,
                        zg: c.bg_binary,
                        Fh: a.j + "_" + a.o,
                        Ec: d,
                        ec: a.ec,
                        zd: e,
                        Jd: f,
                        yd: g
                    }) : h.return(void 0)
            }
        })
    };
    Mb = function(a) {
        var b;
        return _.Ab(function(c) {
            if (1 == c.j) return Bb(c, Fb(a), 2);
            if (b = c.o) {
                var d = "sodar2";
                d = void 0 === d ? "sodar2" : d;
                var e = window,
                    f = e.GoogleGcLKhOms;
                f && "function" === typeof f.push || (f = e.GoogleGcLKhOms = []);
                var g = {};
                f.push((g._ctx_ = b.context, g._bgv_ = b.Ag, g._bgp_ = b.zg, g._li_ = b.Fh, g._jk_ = b.Ec, g._st_ = b.ec, g._rc_ = b.zd, g._dl_ = b.Jd, g._g2_ = b.yd, g));
                if (f = e.GoogleDX5YKUSk) e.GoogleDX5YKUSk = void 0, f[1]();
                d = Ib(Lb, {
                    basename: d
                });
                zb(d)
            }
            return c.return(b)
        })
    };
    Pb = function(a) {
        var b = !1;
        b = void 0 === b ? !1 : b;
        if (Nb) {
            if (b && /(?:[^\uD800-\uDBFF]|^)[\uDC00-\uDFFF]|[\uD800-\uDBFF](?![\uDC00-\uDFFF])/.test(a)) throw Error("Found an unpaired surrogate");
            a = (Ob || (Ob = new TextEncoder)).encode(a)
        } else {
            for (var c = 0, d = new Uint8Array(3 * a.length), e = 0; e < a.length; e++) {
                var f = a.charCodeAt(e);
                if (128 > f) d[c++] = f;
                else {
                    if (2048 > f) d[c++] = f >> 6 | 192;
                    else {
                        if (55296 <= f && 57343 >= f) {
                            if (56319 >= f && e < a.length) {
                                var g = a.charCodeAt(++e);
                                if (56320 <= g && 57343 >= g) {
                                    f = 1024 * (f - 55296) + g - 56320 + 65536;
                                    d[c++] = f >> 18 | 240;
                                    d[c++] = f >> 12 & 63 | 128;
                                    d[c++] = f >> 6 & 63 | 128;
                                    d[c++] = f & 63 | 128;
                                    continue
                                } else e--
                            }
                            if (b) throw Error("Found an unpaired surrogate");
                            f = 65533
                        }
                        d[c++] = f >> 12 | 224;
                        d[c++] = f >> 6 & 63 | 128
                    }
                    d[c++] = f & 63 | 128
                }
            }
            a = c === d.length ? d : d.subarray(0, c)
        }
        return a
    };
    Tb = function(a) {
        if (!Qb) return Sb(a);
        for (var b = "", c = 0, d = a.length - 10240; c < d;) b += String.fromCharCode.apply(null, a.subarray(c, c += 10240));
        b += String.fromCharCode.apply(null, c ? a.subarray(c) : a);
        return btoa(b)
    };
    Vb = function(a) {
        return Ub[a] || ""
    };
    Xb = function(a) {
        return Wb && null != a && a instanceof Uint8Array
    };
    Zb = function(a) {
        if (a !== Yb) throw Error("illegal external caller");
    };
    dc = function(a) {
        var b = 0 > a;
        a = Math.abs(a);
        var c = a >>> 0;
        a = Math.floor((a - c) / 4294967296);
        b && (c = _.x(ac(c, a)), b = c.next().value, a = c.next().value, c = b);
        bc = c >>> 0;
        cc = a >>> 0
    };
    fc = function(a) {
        if (16 > a.length) dc(Number(a));
        else if (ec) a = BigInt(a), bc = Number(a & BigInt(4294967295)) >>> 0, cc = Number(a >> BigInt(32) & BigInt(4294967295));
        else {
            var b = +("-" === a[0]);
            cc = bc = 0;
            for (var c = a.length, d = b, e = (c - b) % 6 + b; e <= c; d = e, e += 6) d = Number(a.slice(d, e)), cc *= 1E6, bc = 1E6 * bc + d, 4294967296 <= bc && (cc += bc / 4294967296 | 0, bc %= 4294967296);
            b && (b = _.x(ac(bc, cc)), a = b.next().value, b = b.next().value, bc = a, cc = b)
        }
    };
    ac = function(a, b) {
        b = ~b;
        a ? a = ~a + 1 : b += 1;
        return [a, b]
    };
    hc = function(a, b) {
        if (gc) return a[gc] |= b;
        if (void 0 !== a.Za) return a.Za |= b;
        Object.defineProperties(a, {
            Za: {
                value: b,
                configurable: !0,
                writable: !0,
                enumerable: !1
            }
        });
        return b
    };
    ic = function(a, b) {
        gc ? a[gc] && (a[gc] &= ~b) : void 0 !== a.Za && (a.Za &= ~b)
    };
    jc = function(a) {
        var b;
        gc ? b = a[gc] : b = a.Za;
        return null == b ? 0 : b
    };
    kc = function(a, b) {
        gc ? a[gc] = b : void 0 !== a.Za ? a.Za = b : Object.defineProperties(a, {
            Za: {
                value: b,
                configurable: !0,
                writable: !0,
                enumerable: !1
            }
        });
        return a
    };
    lc = function(a) {
        hc(a, 1);
        return a
    };
    pc = function(a) {
        return !!(jc(a) & 2)
    };
    qc = function(a) {
        hc(a, 18);
        return a
    };
    rc = function(a) {
        hc(a, 16);
        return a
    };
    sc = function(a, b) {
        kc(b, (a | 0) & -51)
    };
    tc = function(a, b) {
        kc(b, (a | 18) & -41)
    };
    uc = function(a) {
        return null !== a && "object" === typeof a && !Array.isArray(a) && a.constructor === Object
    };
    xc = function(a, b, c) {
        if (null != a)
            if ("string" === typeof a) a = a ? new vc(a, Yb) : wc();
            else if (a.constructor !== vc)
            if (Xb(a)) {
                var d;
                c ? d = 0 == a.length ? wc() : new vc(a, Yb) : d = a.length ? new vc(new Uint8Array(a), Yb) : wc();
                a = d
            } else {
                if (!b) throw Error();
                a = void 0
            }
        return a
    };
    zc = function(a) {
        yc(jc(a.ga))
    };
    yc = function(a) {
        if (a & 2) throw Error();
    };
    Ac = function(a) {
        var b = a.length;
        (b = b ? a[b - 1] : void 0) && uc(b) ? b.g = 1 : (b = {}, a.push((b.g = 1, b)))
    };
    _.Bc = function(a) {
        if (null != a && "number" !== typeof a) throw Error("Value of float/double field must be a number|null|undefined, found " + typeof a + ": " + a);
        return a
    };
    Cc = function(a) {
        if (null == a) return a;
        switch (typeof a) {
            case "string":
                return +a;
            case "number":
                return a
        }
    };
    Dc = function(a) {
        return a
    };
    Ec = function(a) {
        return a
    };
    Fc = function(a) {
        return a
    };
    _.Hc = function(a) {
        return a
    };
    Ic = function(a) {
        return a
    };
    Mc = function(a, b, c, d) {
        var e = !1;
        if (null != a && "object" === typeof a && !(e = Array.isArray(a)) && a.Ae === Jc) return a;
        if (!e) return c ? d & 2 ? Kc(b) : new b : void 0;
        Lc(a, d);
        return new b(a)
    };
    Lc = function(a, b) {
        var c = jc(a),
            d = c;
        0 === d && (d |= b & 16);
        d |= b & 2;
        d !== c && kc(a, d)
    };
    Kc = function(a) {
        var b = a[Pc];
        if (b) return b;
        b = new a;
        qc(b.ga);
        return a[Pc] = b
    };
    Qc = function(a) {
        return a
    };
    Rc = function(a, b, c) {
        return "string" === typeof a ? a : c ? "" : void 0
    };
    Tc = function(a, b, c, d, e, f) {
        a = Mc(a, d, c, f);
        e && (a = Sc(a));
        return a
    };
    Uc = function(a) {
        return a
    };
    Xc = function(a, b, c, d, e) {
        var f = y(a, b, d);
        Array.isArray(f) || (f = Vc);
        var g = jc(f);
        g & 1 || lc(f);
        if (e) g & 2 || qc(f), c & 1 || Object.freeze(f);
        else {
            e = !(c & 2);
            var h = g & 2;
            c & 1 || !h ? e && g & 16 && !h && ic(f, 16) : (f = lc(Array.prototype.slice.call(f)), Wc(a, b, f, d))
        }
        return f
    };
    Yc = function(a, b, c, d, e) {
        var f = pc(a.ga),
            g = Xc(a, b, e || 1, d, f),
            h = jc(g);
        if (!(h & 4)) {
            Object.isFrozen(g) && (g = lc(g.slice()), Wc(a, b, g, d));
            for (var k = 0, l = 0; k < g.length; k++) {
                var n = c(g[k]);
                null != n && (g[l++] = n)
            }
            l < k && (g.length = l);
            h |= 5;
            f && (h |= 18);
            kc(g, h);
            h & 2 && Object.freeze(g)
        }
        if (2 === e) return g;
        !f && (h & 2 || Object.isFrozen(g)) && (g = Array.prototype.slice.call(g), hc(g, 5), Wc(a, b, g, d));
        return g
    };
    Zc = function(a) {
        return xc(a, !0, !0)
    };
    $c = function(a) {
        return xc(a, !0, !1)
    };
    dd = function(a, b, c) {
        var d = !1;
        if (null == b) {
            if (c) return ad || (ad = new bd(qc([])));
            b = []
        } else if (b.constructor === bd) {
            if (0 == (b.m & 2) || c) return b;
            b = cd(b)
        } else Array.isArray(b) ? d = pc(b) : b = [];
        if (c) {
            if (!b.length) return ad || (ad = new bd(qc([])));
            d || (d = !0, qc(b))
        } else if (d)
            for (d = !1, b = Array.prototype.slice.call(b), c = 0; c < b.length; c++) {
                var e = b[c] = Array.prototype.slice.call(b[c]);
                Array.isArray(e[1]) && (e[1] = qc(e[1]))
            }
        d || (jc(b) & 32 ? ic(b, 16) : jc(a.ga) & 16 && rc(b));
        d = new bd(b, void 0, Rc, Rc);
        Wc(a, 26, d, !1);
        return d
    };
    _.ed = function(a, b, c, d) {
        if (null == c) return _.z(a, b, Vc);
        var e = jc(c);
        if (!(e & 4)) {
            if (e & 2 || Object.isFrozen(c)) c = Array.prototype.slice.call(c);
            for (var f = 0; f < c.length; f++) c[f] = d(c[f]);
            kc(c, e | 5)
        }
        return _.z(a, b, c)
    };
    _.fd = function(a, b, c, d) {
        zc(a);
        c !== d ? Wc(a, b, c) : Wc(a, b, void 0, !1);
        return a
    };
    gd = function(a, b, c, d, e) {
        var f = !!(e & 2);
        a.j || (a.j = {});
        var g = a.j[c],
            h = Xc(a, c, 3, void 0, f);
        if (!g) {
            var k = h;
            g = [];
            f = !!(e & 2);
            h = !!(jc(k) & 2);
            var l = k;
            !f && h && (k = Array.prototype.slice.call(k));
            var n = e | (h ? 2 : 0);
            e = h;
            for (var m = 0; m < k.length; m++) {
                var p = k[m];
                var r = b;
                Array.isArray(p) ? (Lc(p, n), p = new r(p)) : p = void 0;
                void 0 !== p && (e = e || !!(2 & jc(p.ga)), g.push(p))
            }
            a.j[c] = g;
            n = jc(k);
            b = n | 33;
            b = e ? b & -9 : b | 8;
            n != b && (e = k, Object.isFrozen(e) && (e = Array.prototype.slice.call(e)), kc(e, b), k = e);
            l !== k && Wc(a, c, k);
            (f || 1 === d && h) && qc(g);
            (f || 1 === d) && Object.freeze(g);
            return g
        }
        if (3 === d) return g;
        f || ((f = Object.isFrozen(g), 1 !== d || f) ? 2 === d && f && (g = Array.prototype.slice.call(g), a.j[c] = g) : Object.freeze(g));
        return g
    };
    _.hd = function(a, b, c) {
        return _.fd(a, b, null == c ? c : !!c, !1)
    };
    _.id = function(a, b, c) {
        return _.fd(a, b, c, 0)
    };
    _.jd = function(a, b, c) {
        return _.fd(a, b, c, "")
    };
    kd = function(a, b) {
        return null == a ? b : a
    };
    md = function(a, b) {
        ld = b;
        a = new a(b);
        ld = void 0;
        return a
    };
    pd = function(a) {
        switch (typeof a) {
            case "number":
                return isFinite(a) ? a : String(a);
            case "object":
                if (a)
                    if (Array.isArray(a)) {
                        if (0 !== (jc(a) & 128)) return a = Array.prototype.slice.call(a), Ac(a), a
                    } else {
                        if (Xb(a)) return Tb(a);
                        if (a instanceof vc) return nd(a);
                        if (a instanceof bd) return od(a)
                    }
        }
        return a
    };
    rd = function(a, b, c, d, e, f) {
        if (null != a) {
            if (Array.isArray(a)) a = e && 0 == a.length && jc(a) & 1 ? void 0 : f && jc(a) & 2 ? a : qd(a, b, c, void 0 !== d, e, f);
            else if (uc(a)) {
                var g = {},
                    h;
                for (h in a) Object.prototype.hasOwnProperty.call(a, h) && (g[h] = rd(a[h], b, c, d, e, f));
                a = g
            } else a = b(a, d);
            return a
        }
    };
    qd = function(a, b, c, d, e, f) {
        var g = jc(a);
        d = d ? !!(g & 16) : void 0;
        a = Array.prototype.slice.call(a);
        for (var h = 0; h < a.length; h++) a[h] = rd(a[h], b, c, d, e, f);
        c(g, a);
        return a
    };
    ud = function(a) {
        return rd(a, sd, td, void 0, !1, !1)
    };
    sd = function(a) {
        return a.Ae === Jc ? a.toJSON() : a instanceof bd ? od(a, ud) : pd(a)
    };
    td = function(a, b) {
        a & 128 && Ac(b)
    };
    vd = function(a, b, c) {
        c = void 0 === c ? tc : c;
        if (null != a) {
            if (Wb && a instanceof Uint8Array) return b ? a : new Uint8Array(a);
            if (Array.isArray(a)) {
                var d = jc(a);
                if (d & 2) return a;
                if (b && !(d & 32) && (d & 16 || 0 === d)) return kc(a, d | 18), a;
                a = qd(a, vd, d & 4 ? tc : c, !0, !1, !0);
                b = jc(a);
                b & 4 && b & 2 && Object.freeze(a);
                return a
            }
            a.Ae === Jc ? a = wd(a) : a instanceof bd && (b = qc(cd(a, vd)), a = new bd(b, a.o, a.H, a.B));
            return a
        }
    };
    Ad = function(a, b, c, d, e, f, g) {
        (a = a.j && a.j[c]) ? (d = jc(a), d & 2 ? d = a : (f = _.xd(a, wd), tc(d, f), Object.freeze(f), d = f), _.yd(b, c, d, e)) : _.z(b, c, vd(d, f, g), e)
    };
    wd = function(a) {
        if (pc(a.ga)) return a;
        a = _.Bd(a, !0);
        qc(a.ga);
        return a
    };
    _.Bd = function(a, b) {
        var c = a.ga,
            d = rc([]),
            e = a.constructor.messageId;
        e && d.push(e);
        e = a.Va;
        if (e) {
            d.length = c.length;
            var f = {};
            d[d.length - 1] = f
        }
        0 !== (jc(c) & 128) && Ac(d);
        b = b || pc(a.ga) ? tc : sc;
        d = md(a.constructor, d);
        a.we && (d.we = a.we.slice());
        f = !!(jc(c) & 16);
        for (var g = e ? c.length - 1 : c.length, h = 0; h < g; h++) Ad(a, d, h - a.yb, c[h], !1, f, b);
        if (e)
            for (var k in e) Ad(a, d, +k, e[k], !0, f, b);
        return d
    };
    Sc = function(a) {
        if (!pc(a.ga)) return a;
        var b = _.Bd(a, !1);
        b.B = a;
        return b
    };
    Cd = function(a, b) {
        if (Array.isArray(a)) {
            var c = jc(a),
                d = 1;
            !b || c & 2 || (d |= 16);
            (c & d) !== d && kc(a, c | d)
        }
    };
    Dd = function(a, b) {
        return pd(b)
    };
    Ed = function(a, b) {
        if (!Array.isArray(b)) throw Error("must be an array");
        if (Object.isFrozen(b) || Object.isSealed(b) || !Object.isExtensible(b)) throw Error("arrays passed to jspb constructors must be mutable");
        var c = jc(b);
        if (0 !== c) throw Error();
        kc(b, c | 64);
        return md(a, rc(b))
    };
    Id = function(a, b, c) {
        if (c) {
            var d = {},
                e;
            for (e in c) {
                if (Object.prototype.hasOwnProperty.call(c, e)) {
                    var f = c[e],
                        g = f.Ki;
                    g || (d.mc = f.Uj || f.ck.Ld, f.xg ? (d.Qd = Fd(f.xg), g = function(h) {
                        return function(k, l, n) {
                            return h.mc(k, l, n, h.Qd)
                        }
                    }(d)) : f.Gh ? (d.Pd = Gd(f.Ug.gf, f.Gh), g = function(h) {
                        return function(k, l, n) {
                            return h.mc(k, l, n, h.Pd)
                        }
                    }(d)) : g = d.mc, f.Ki = g);
                    g(b, a, f.Ug)
                }
                d = {
                    mc: d.mc,
                    Qd: d.Qd,
                    Pd: d.Pd
                }
            }
        }
        Hd(b, a)
    };
    Ld = function(a, b) {
        var c = a[b];
        "function" == typeof c && 0 === c.length && (c = c(), a[b] = c);
        return Array.isArray(c) && (Jd in c || Kd in c || 0 < c.length && "function" == typeof c[0]) ? c : void 0
    };
    Fd = function(a) {
        var b = a[Md];
        if (!b) {
            var c = Nd(a);
            b = function(d, e) {
                return Od(d, e, c)
            };
            a[Md] = b
        }
        return b
    };
    Gd = function(a, b) {
        var c = a[Md];
        c || (c = function(d, e) {
            return Id(d, e, b)
        }, a[Md] = c);
        return c
    };
    Pd = function(a, b) {
        a.push(b)
    };
    Qd = function(a, b, c) {
        a.push(b, c.Ld)
    };
    Td = function(a, b, c, d) {
        var e = Fd(d),
            f = Nd(d).gf,
            g = c.Ld;
        a.push(b, function(h, k, l) {
            return g(h, k, l, f, e)
        })
    };
    Ud = function(a, b, c, d, e, f) {
        var g = Gd(d, f),
            h = c.Ld;
        a.push(b, function(k, l, n) {
            return h(k, l, n, d, g)
        })
    };
    Nd = function(a) {
        var b = a[Kd];
        if (b) return b;
        b = a[Kd] = [];
        var c = Pd,
            d = Qd,
            e = Td,
            f = Ud;
        b.gf = a[0];
        var g = 1;
        if (a.length > g && "number" !== typeof a[g]) {
            var h = a[g++];
            c(b, h)
        }
        for (; g < a.length;) {
            c = a[g++];
            for (var k = g + 1; k < a.length && "number" !== typeof a[k];) k++;
            h = a[g++];
            k -= g;
            switch (k) {
                case 0:
                    d(b, c, h);
                    break;
                case 1:
                    (k = Ld(a, g)) ? (g++, e(b, c, h, k)) : d(b, c, h, a[g++]);
                    break;
                case 2:
                    k = b;
                    var l = g++;
                    l = Ld(a, l);
                    e(k, c, h, l, a[g++]);
                    break;
                case 3:
                    f(b, c, h, a[g++], a[g++], a[g++]);
                    break;
                case 4:
                    f(b, c, h, a[g++], a[g++], a[g++], a[g++]);
                    break;
                default:
                    throw Error("unexpected number of binary field arguments: " + k);
            }
        }
        Jd in a && Kd in a && (a.length = 0);
        return b
    };
    Od = function(a, b, c) {
        for (var d = c.length, e = 1 == d % 2, f = e ? 1 : 0; f < d; f += 2)(0, c[f + 1])(b, a, c[f]);
        Id(a, b, e ? c[0] : void 0)
    };
    Vd = function(a, b) {
        return {
            bk: a,
            Ld: b
        }
    };
    Zd = function(a, b, c) {
        b = y(b, c);
        null != b && ("string" === typeof b && Wd(b), null != b && (Xd(a.j, 8 * c), "number" === typeof b ? (a = a.j, dc(b), Yd(a, bc, cc)) : (c = Wd(b), Yd(a.j, c.o, c.j))))
    };
    $d = function(a) {
        return a
    };
    be = function(a, b) {
        var c = ae;
        ae = void 0;
        if (!b(a)) throw b = c ? c() + "\n" : "", Error(b + String(a));
    };
    ce = function(a, b, c) {
        be(a, b, c);
        return a
    };
    de = function(a, b, c) {
        b = ae;
        ae = void 0;
        if (!a) {
            if (b) throw Error(b());
            if (c && 0 < c.length) throw Error("[" + c.map(String).join(",") + "]");
            throw Error(String(a));
        }
    };
    ge = function(a) {
        return function() {
            var b = new ee;
            Od(this, b, Nd(a));
            fe(b, b.j.end());
            for (var c = new Uint8Array(b.o), d = b.m, e = d.length, f = 0, g = 0; g < e; g++) {
                var h = d[g];
                c.set(h, f);
                f += h.length
            }
            b.m = [c];
            return c
        }
    };
    he = function(a) {
        return function(b) {
            if (null == b || "" == b) b = new a;
            else {
                b = JSON.parse(b);
                if (!Array.isArray(b)) throw Error(void 0);
                b = md(a, rc(b))
            }
            return b
        }
    };
    ke = function(a) {
        switch (a) {
            case 1:
                return "gda";
            case 2:
                return "gpt";
            case 3:
                return "ima";
            case 4:
                return "pal";
            case 5:
                return "xfad";
            case 6:
                return "dv3n";
            case 7:
                return "spa";
            default:
                return "unk"
        }
    };
    pe = function(a, b, c, d) {
        d = void 0 === d ? [] : d;
        var e = new a.MutationObserver(function(f) {
            f = _.x(f);
            for (var g = f.next(); !g.done; g = f.next()) {
                g = _.x(g.value.removedNodes);
                for (var h = g.next(); !h.done; h = g.next())
                    if (h = h.value, d && (h === b || le(h, b))) {
                        f = _.x(d);
                        for (g = f.next(); !g.done; g = f.next()) g.value.disconnect();
                        d.length = 0;
                        c();
                        return
                    }
            }
        });
        d.push(e);
        e.observe(a.document.documentElement, {
            childList: !0,
            subtree: !0
        });
        me(function(f) {
            if (!f.parent || !_.ne(f.parent)) return !1;
            for (var g = f.parent.document.getElementsByTagName("iframe"), h = 0; h < g.length; h++) try {
                if (oe(g[h]) == f) {
                    pe(f.parent, g[h], c, d);
                    break
                }
            } catch (k) {}
            return !1
        }, !1, !1, a)
    };
    qe = function(a) {
        a = void 0 === a ? _.q : a;
        var b = a.context || a.AMP_CONTEXT_DATA;
        if (!b) try {
            b = a.parent.context || a.parent.AMP_CONTEXT_DATA
        } catch (e) {}
        var c, d;
        return (null == (c = b) ? 0 : c.pageViewId) && (null == (d = b) ? 0 : d.canonicalUrl) ? b : null
    };
    _.A = function(a) {
        var b = _.wb.apply(1, arguments);
        if (0 === b.length) return re(a[0]);
        for (var c = [a[0]], d = 0; d < b.length; d++) c.push(encodeURIComponent(b[d])), c.push(a[d + 1]);
        return re(c.join(""))
    };
    se = function(a, b) {
        var c = _.kb(a).toString();
        if (/#/.test(c)) throw Error("");
        var d = /\?/.test(c) ? "&" : "?";
        b.forEach(function(e, f) {
            e = e instanceof Array ? e : [e];
            for (var g = 0; g < e.length; g++) {
                var h = e[g];
                null !== h && void 0 !== h && (c += d + encodeURIComponent(f) + "=" + encodeURIComponent(String(h)), d = "&")
            }
        });
        return re(c)
    };
    te = function(a) {
        return JSON.stringify([a.map(function(b) {
            var c = {};
            return [(c[b.Re] = b.message.toJSON(), c)]
        })])
    };
    ve = function(a) {
        a.Oe.apply(a, _.ue(_.wb.apply(1, arguments).map(function(b) {
            return {
                Re: 2,
                message: b
            }
        })))
    };
    we = function(a) {
        a.Oe.apply(a, _.ue(_.wb.apply(1, arguments).map(function(b) {
            return {
                Re: 5,
                message: b
            }
        })))
    };
    xe = function(a) {
        a && "function" == typeof a.Ha && a.Ha()
    };
    ye = function(a) {
        return a[_.u(_.v.Symbol, "iterator")]()
    };
    Be = function(a, b, c, d, e) {
        e = void 0 === e ? !1 : e;
        a.google_image_requests || (a.google_image_requests = []);
        var f = _.ze("IMG", a.document);
        if (c || d) {
            var g = function(h) {
                c && c(h);
                d && ia(a.google_image_requests, f);
                _.Ae(f, "load", g);
                _.Ae(f, "error", g)
            };
            _.yb(f, "load", g);
            _.yb(f, "error", g)
        }
        e && (f.attributionSrc = "");
        f.src = b;
        a.google_image_requests.push(f)
    };
    De = function() {
        var a = Ce;
        return (0, B.te)(function(b) {
            for (var c in a)
                if (b === a[c] && !/^[0-9]+$/.test(c)) return !0;
            return !1
        }, function() {
            return "unknown enum"
        })
    };
    He = function() {
        var a = Ee;
        return (0, B.te)(function(b) {
            return b instanceof a
        }, function() {
            var b = a.name;
            b || (b = (b = /function\s+([^\(]+)/m.exec(String(a))) ? b[1] : "(Anonymous)");
            return b
        })
    };
    We = function(a, b) {
        var c;
        a: {
            try {
                if (a) {
                    var d = a.getItem("google_experiment_mod");
                    break a
                }
            } catch (g) {}
            d = null
        }
        d = null != (c = d) ? c : "";
        try {
            var e = Ie(d);
            if (d) {
                var f = Ie(d);
                Je(f, Ke(Le(1), -1));
                Me(f)
            }
        } catch (g) {
            Ne(d), e = new Oe
        }
        if (c = (_.C = Pe(e, Qe, 1), _.u(_.C, "find")).call(_.C, function(g) {
                return _.Re(g, 1, 0) === b
            }))
            if (f = Se(c, 2), null === f || isNaN(f)) Ne(d);
            else return f;
        d = (0, _.Te)() ? null : Math.floor(1E3 * _.Ue());
        if (null === d) return null;
        c ? Ke(c, d) : Je(e, Ke(Le(b), d));
        return Ve(a, Me(e)) ? d : null
    };
    Ne = function(a) {
        .01 > Math.random() && Xe({
            data: a
        }, "ls_tamp")
    };
    Ye = function(a) {
        var b = {};
        "string" === typeof a.data ? b = JSON.parse(a.data) : b = a.data;
        return {
            payload: b,
            Je: b.__uspapiReturn.callId
        }
    };
    af = function(a) {
        a = Ze(a.data.__fciReturn);
        return {
            payload: a,
            Je: _.$e(a, 1)
        }
    };
    cf = function(a, b) {
        b = void 0 === b ? window : b;
        if (bf(a)) try {
            return b.localStorage
        } catch (c) {}
        return null
    };
    df = function(a) {
        return "null" !== a.origin
    };
    ff = function(a, b, c) {
        b = bf(b) && df(c) ? c.document.cookie : null;
        return null === b ? null : (new ef({
            cookie: b
        })).get(a) || ""
    };
    _.hf = function(a) {
        a = void 0 === a ? _.q : a;
        return (a = a.performance) && a.now && a.timing ? Math.floor(a.now() + a.timing.navigationStart) : gf()
    };
    _.jf = function(a) {
        a = void 0 === a ? _.q : a;
        return (a = a.performance) && a.now ? a.now() : null
    };
    kf = function(a, b) {
        b = void 0 === b ? _.q : b;
        var c, d;
        return (null == (c = b.performance) ? void 0 : null == (d = c.timing) ? void 0 : d[a]) || 0
    };
    lf = function(a) {
        a = void 0 === a ? _.q : a;
        var b = Math.min(kf("domLoading", a) || Infinity, kf("domInteractive", a) || Infinity);
        return Infinity === b ? Math.max(kf("responseEnd", a), kf("navigationStart", a)) : b
    };
    mf = function(a, b, c) {
        return b[a] || c
    };
    pf = function(a) {
        _.nf( of ).H(a)
    };
    qf = function(a) {
        return _.nf( of ).m(a)
    };
    tf = function(a, b, c, d) {
        c = void 0 === c ? null : c;
        d = void 0 === d ? {} : d;
        var e = rf.j();
        0 === e.j && (e.j = .001 > Math.random() ? 2 : 1);
        2 === e.j && (e = {}, Xe(_.u(Object, "assign").call(Object, {}, (e.c = String(a), e.pc = String(sf(window)), e.em = c, e.lid = b, e.eids = _.nf( of ).j().join(), e), d), "esp"))
    };
    Bf = function(a, b, c, d) {
        tf(18, a);
        try {
            var e = _.hf();
            return c().then(function(f) {
                tf(29, a, null, {
                    delta: String(_.hf() - e)
                });
                if (null == f) return tf(41, a), uf(b, 111, d), b;
                null != f && ("string" !== typeof f ? tf(21, a) : f.length || tf(20, a));
                yf(_.z(b, 2, f), 10);
                zf().set(b, d) && tf(27, a);
                return b
            }).catch(function(f) {
                uf(b, 106, d);
                tf(28, a, Af(f));
                return b
            })
        } catch (f) {
            return uf(b, 107, d), tf(1, a, Af(f)), _.v.Promise.resolve(b)
        }
    };
    uf = function(a, b, c) {
        var d;
        a.Ea(Cf(null != (d = Df(a, Ef, 10)) ? d : new Ef, b));
        zf().set(a, c)
    };
    Ff = function() {
        var a = window;
        var b = void 0 === b ? function() {} : b;
        return new _.v.Promise(function(c) {
            var d = function() {
                c(b());
                _.Ae(a, "load", d)
            };
            _.yb(a, "load", d)
        })
    };
    Gf = function(a) {
        var b = [],
            c = RegExp("^_GESPSK-(.+)$");
        try {
            for (var d = 0; d < a.length; d++) {
                var e = (c.exec(a.key(d)) || [])[1];
                e && b.push(e)
            }
        } catch (f) {}
        return b
    };
    _.E = function(a) {
        return _.nf(Hf).j(a.j, a.defaultValue)
    };
    _.If = function(a) {
        return _.nf(Hf).o(a.j, a.defaultValue)
    };
    Jf = function(a) {
        return _.nf(Hf).m(a.j, a.defaultValue)
    };
    Kf = function(a) {
        return _.nf(Hf).H(a.j, a.defaultValue)
    };
    Qf = function(a, b, c, d, e, f) {
        var g = new Lf;
        f = null != f ? f : Mf(c, b);
        var h = _.u(f, "flatMap").call(f, function(k) {
            return k.m()
        }).map(function(k) {
            return k.m()
        });
        Nf(g, a, b, h, e);
        Of(g, f.concat(null != d ? d : []), c, b, a);
        if (!Pe(g, Pf, 2).length) return null;
        tf(50, "");
        return Sb(g.m(), 3)
    };
    Of = function(a, b, c, d, e) {
        if (d && c && b && "function" === typeof c.getUserIdsAsEidBySource) {
            if ("function" === typeof c.getUserIdsAsEids) try {
                for (var f = _.x(c.getUserIdsAsEids()), g = f.next(); !g.done; g = f.next()) {
                    var h = g.value;
                    "string" === typeof h.source && tf(52, h.source)
                }
            } catch (m) {
                var k;
                tf(45, "", null == (k = m) ? void 0 : k.message)
            }
            b = _.x(b);
            for (f = b.next(); !f.done; f = b.next())
                if (f = f.value, String(_.Rf(f, 1)) === d)
                    for (f = _.x(f.m()), g = f.next(); !g.done; g = f.next())
                        if (g = g.value, _.Sf(g, Tf(g, Uf, 3)) && (g = g.m(), !Vf(a, g))) {
                            h = null;
                            try {
                                var l = k = void 0,
                                    n = void 0;
                                h = null == (k = c.getUserIdsAsEidBySource(g)) ? void 0 : null == (l = k.uids) ? void 0 : null == (n = l[0]) ? void 0 : n.id
                            } catch (m) {
                                k = void 0, tf(45, g, null == (k = m) ? void 0 : k.message)
                            }
                            h ? 300 < h.length ? (k = {}, tf(12, g, null, (k.sl = String(h.length), k.fp = "1", k))) : (k = Wf(g), k = _.z(k, 2, h), k = _.z(k, 11, !0), _.Xf(a, 2, Pf, k), k = {}, tf(19, g, null, (k.fp = "1", k.hs = h ? "1" : "0", k))) : (k = h = void 0, e && (null == (h = zf().get(g, e).vb) ? 0 : null == (k = y(h, 2)) ? 0 : k.length) && tf(51, g))
                        }
        }
    };
    Nf = function(a, b, c, d, e) {
        if (b)
            for (var f = _.x(Gf(b)), g = f.next(); !g.done; g = f.next()) {
                g = g.value;
                var h = void 0;
                if (null == (h = d) || !_.u(h, "includes").call(h, g))
                    if (h = zf().get(g, b).vb) {
                        var k = Yf(h);
                        if (2 !== k && 3 !== k) {
                            k = !1;
                            if (c) {
                                var l = void 0,
                                    n = null == (l = e) ? void 0 : l.get(c);
                                if (n && !n.has(g)) continue;
                                if ((l = /^(\d+)$/.exec(g)) && !(k = _.u(c.split(","), "includes").call(c.split(","), l[1]))) continue
                            }
                            _.z(h, 9, k);
                            l = y(h, 2);
                            _.E(Zf) || (k = k ? 1E3 : 300, 0 <= k && l && l.length > k && (k = {}, tf(12, g, null, (k.sl = String(l.length), k)), uf(h, 108, b), yf(h, 2)));
                            _.Xf(a, 2, Pf, h);
                            h = {};
                            tf(19, g, null, (h.hs = l ? "1" : "0", h))
                        }
                    }
            }
    };
    Mf = function(a, b) {
        if (!b || "function" !== typeof(null == a ? void 0 : a.getUserIdsAsEidBySource)) return [];
        a = [];
        for (var c = _.x(Kf($f)), d = c.next(); !d.done; d = c.next()) {
            d = d.value;
            var e = null;
            try {
                e = ag(d)
            } catch (f) {
                d = void 0;
                tf(44, "UNKNOWN_ID", null == (d = f) ? void 0 : d.message);
                continue
            }
            _.Rf(e, 1) === b && a.push(e)
        }
        return a
    };
    Vf = function(a, b) {
        return Pe(a, Pf, 2).some(function(c) {
            return y(c, 1) === b && _.bg(c, 2)
        })
    };
    eg = function(a, b, c) {
        var d, e, f, g, h, k;
        return _.Ab(function(l) {
            if (1 == l.j) return d = c ? a.filter(function(n) {
                return !n.xb
            }) : a, Bb(l, _.v.Promise.all(d.map(function(n) {
                return n.fb.promise
            })), 2);
            if (4 != l.j) {
                if (a.length === d.length) return l.return(0);
                e = a.filter(function(n) {
                    return n.xb
                });
                f = _.hf();
                if (_.E(cg)) {
                    g = _.x(b);
                    for (h = g.next(); !h.done; h = g.next()) k = h.value, dg(k);
                    return Bb(l, _.v.Promise.all(e.map(function(n) {
                        return n.fb.promise
                    })), 4)
                }
                return Bb(l, _.v.Promise.race([_.v.Promise.all(e.map(function(n) {
                    return n.fb.promise
                })), new _.v.Promise(function(n) {
                    return void setTimeout(n, c)
                })]), 4)
            }
            return l.return(_.hf() - f)
        })
    };
    fg = function(a) {
        var b = function(c) {
            var d = {};
            tf(c, (0, B.K)(y(a, 1)), null, (d.tic = String(Math.round((Date.now() - (0, B.K)(y(a, 3))) / 6E4)), d))
        };
        switch (Yf(a)) {
            case 0:
                b(24);
                break;
            case 1:
                b(25);
                break;
            case 2:
                b(26);
                break;
            case 3:
                tf(9, (0, B.K)(y(a, 1)));
                break;
            case 4:
                b(23)
        }
    };
    gg = function(a) {
        return "string" === typeof a ? a : a instanceof Error ? a.message : null
    };
    tg = function(a, b, c, d, e) {
        var f, g, h, k, l, n, m, p, r, t, w;
        return _.Ab(function(D) {
            f = new hg;
            g = new ig(a, c, d, e);
            h = new jg(g.A, c, d, e);
            k = new kg(g.l, e);
            n = l = null;
            _.E(Zf) ? (m = new lg(k.l, e), H(f, m), l = m.A, p = new mg(b, m.l, e), H(f, p), H(f, new jg(p.l, c, d, e)), r = new ng(p.A, p.G, 300, 1E3, e), H(f, r), H(f, new jg(r.l, c, d, e)), n = function() {
                var G, F, O;
                return _.Ab(function(I) {
                    return 1 == I.j ? (O = a, Bb(I, r.l.promise, 2)) : I.return({
                        id: O,
                        collectorGeneratedData: null != (F = null == (G = I.o) ? void 0 : og(G, 2)) ? F : null
                    })
                })
            }) : (t = new pg(b, k.l, c, d, e), H(f, t), l = t.G, n = function() {
                var G;
                return _.Ab(function(F) {
                    return 1 == F.j ? Bb(F, t.l.promise, 2) : F.return(null != (G = F.o) ? G : {
                        id: a,
                        collectorGeneratedData: null
                    })
                })
            });
            w = new qg(b, l, c, d, e);
            rg(f, [g, h, k, w]);
            sg(f);
            return D.return(n())
        })
    };
    Og = function(a, b, c) {
        var d = {
            Se: _.E(ug)
        };
        d = void 0 === d ? vg : d;
        b ? wg() !== xg(window) ? tf(16, "") : yg(a, "encryptedSignalProviders", c) && yg(a, "secureSignalProviders", c) || (tf(38, ""), Ng(a, "encryptedSignalProviders", b, c, d), Ng(a, "secureSignalProviders", b, c, d)) : tf(15, "")
    };
    yg = function(a, b, c) {
        if (void 0 === a[b] || a[b] instanceof Array) return !1;
        a[b].addErrorHandler(c);
        return !0
    };
    Ng = function(a, b, c, d, e) {
        var f, g = new Pg(null != (f = a[b]) ? f : [], c, "secureSignalProviders" === b, e);
        a[b] = new Qg(g);
        g.addErrorHandler(d)
    };
    Tg = function(a, b) {
        var c = new hg,
            d = new Rg(b);
        a = new Sg(d.C, a, b);
        rg(c, [d, a]);
        sg(c)
    };
    Xg = function(a, b, c, d, e) {
        if (!c) return null;
        var f = b.toString();
        if (Ug.has(f)) return null;
        Ug.add(f);
        f = new hg;
        a = new ig(a, c, d, e);
        var g = new jg(a.A, c, d, e),
            h = new Vg(a.l, e),
            k = new kg(h.l, e);
        b = new Wg(k.l, b, e);
        c = new jg(b.l, c, d, e);
        rg(f, [a, g, h, k, b, c]);
        sg(f);
        return f
    };
    Yg = function(a, b) {
        b = void 0 === b ? document : b;
        var c;
        return !(null == (c = b.featurePolicy) || !(_.C = c.allowedFeatures(), _.u(_.C, "includes")).call(_.C, a))
    };
    $g = function(a) {
        _.nf(Zg).j(a)
    };
    dh = function() {
        if (void 0 === b) {
            var a = void 0 === a ? _.q : a;
            var b = a.ggeac || (a.ggeac = {})
        }
        a = b;
        ah(_.nf( of ), a);
        bh(b);
        ch(_.nf(Zg), b);
        _.nf(Hf).B()
    };
    bh = function(a) {
        var b = _.nf(Hf);
        b.j = function(c, d) {
            return mf(5, a, function() {
                return !1
            })(c, d, 2)
        };
        b.o = function(c, d) {
            return mf(6, a, function() {
                return 0
            })(c, d, 2)
        };
        b.m = function(c, d) {
            return mf(7, a, function() {
                return ""
            })(c, d, 2)
        };
        b.H = function(c, d) {
            return mf(8, a, function() {
                return []
            })(c, d, 2)
        };
        b.B = function() {
            mf(15, a, function() {})(2)
        }
    };
    ih = function(a) {
        var b = void 0 === b ? eh : b;
        var c = _.u(Object, "assign").call(Object, {}, a),
            d = a.id,
            e = a.style;
        a = a.data;
        c = (delete c.id, delete c.style, delete c.data, c);
        if (_.u(Object, "keys").call(Object, c).length) throw Error("Invalid attribute(s): " + _.u(Object, "keys").call(Object, c));
        d = {
            id: d,
            style: e ? e : void 0
        };
        if (a)
            for (e = _.x(_.u(a, "entries").call(a)), a = e.next(); !a.done; a = e.next()) c = _.x(a.value), a = c.next().value, c = c.next().value, (0, B.Pf)(fh.test(a)), d[a] = c;
        _.gh("div");
        return _.hh("div", d, b)
    };
    nh = function(a) {
        jh();
        var b = kh.googleToken[5] || 0;
        a && (0 != b || lh[3] >= gf() ? mh.Ze(a) : (mh.ud().push(a), mh.Sf()));
        lh[3] >= gf() && lh[2] >= gf() || mh.Sf()
    };
    rh = function(a, b, c, d) {
        var e = new _.oh,
            f = "",
            g = function(k) {
                try {
                    var l = "object" === typeof k.data ? k.data : JSON.parse(k.data);
                    f === l.paw_id && (_.Ae(a, "message", g), l.error ? e.reject(Error(l.error)) : e.resolve(d(l)))
                } catch (n) {}
            },
            h = ph(a);
        return h ? (_.yb(a, "message", g), f = c(h), e.promise) : (c = qh(a)) ? (f = String(Math.floor(2147483647 * _.Ue())), _.yb(a, "message", g), b(c, f), e.promise) : null
    };
    sh = function(a) {
        return rh(a, function(b, c) {
            var d, e;
            return void(null == (d = null != (e = b.getGmaQueryInfo) ? e : b.getGmaSig) ? void 0 : d.postMessage(c))
        }, function(b) {
            return b.getQueryInfo()
        }, function(b) {
            return b.signal
        })
    };
    th = function(a) {
        return !!ph(a) || !!qh(a)
    };
    ph = function(a) {
        var b;
        if ("function" === typeof(null == (b = a.gmaSdk) ? void 0 : b.getQueryInfo)) return a.gmaSdk
    };
    qh = function(a) {
        var b, c, d, e, f, g;
        if ("function" === typeof(null == (b = a.webkit) ? void 0 : null == (c = b.messageHandlers) ? void 0 : null == (d = c.getGmaQueryInfo) ? void 0 : d.postMessage) || "function" === typeof(null == (e = a.webkit) ? void 0 : null == (f = e.messageHandlers) ? void 0 : null == (g = f.getGmaSig) ? void 0 : g.postMessage)) return a.webkit.messageHandlers
    };
    uh = function(a) {
        var b, c;
        return null != (c = (_.C = ["pbjs"].concat(null != (b = a._pbjsGlobals) ? b : []).map(function(d) {
            return a[d]
        }), _.u(_.C, "find")).call(_.C, function(d) {
            return Array.isArray(null == d ? void 0 : d.que)
        })) ? c : null
    };
    vh = function(a, b, c, d) {
        try {
            if (a.setAttribute("data-google-query-id", c), !d) {
                null != b.googletag || (b.googletag = {
                    cmd: []
                });
                var e, f = null != (e = b.googletag.queryIds) ? e : [];
                f.push(c);
                500 < f.length && f.shift();
                b.googletag.queryIds = f
            }
        } catch (g) {}
    };
    _.Dh = function(a) {
        var b = a.ta,
            c = a.Be,
            d = a.Bd,
            e = a.af,
            f = a.Ja;
        a = a.Dg;
        var g = 0;
        try {
            g |= b != b.top ? 512 : 0;
            var h = Math.min(b.screen.width || 0, b.screen.height || 0);
            g |= h ? 320 > h ? 8192 : 0 : 2048;
            var k;
            if (k = b.navigator) {
                var l = b.navigator.userAgent;
                k = /Android 2/.test(l) || /iPhone OS [34]_/.test(l) || /Windows Phone (?:OS )?[67]/.test(l) || /MSIE.*Windows NT/.test(l) || /Windows NT.*Trident/.test(l)
            }
            g |= k ? 1048576 : 0;
            g = c ? g | (b.innerHeight >= c ? 0 : 1024) : g | (_.wh(b) ? 0 : 8);
            g |= xh(b, d);
            g |= yh(b)
        } catch (n) {
            g |= 32
        }
        switch (e) {
            case 2:
                c = f;
                c = void 0 === c ? null : c;
                d = zh(b.innerWidth, 3, 0, Math.min(Math.round(b.innerWidth / 320 * 50), Ah) + 15, 3);
                null != Bh(b, d, void 0 === c ? null : c) && (g |= 16777216);
                break;
            case 1:
                c = f, c = void 0 === c ? null : c, d = b.innerWidth, e = b.innerHeight, h = Math.min(Math.round(b.innerWidth / 320 * 50), Ah) + 15, k = zh(d, 3, e - h, e, 3), 25 < h && k.push({
                    x: d - 25,
                    y: e - 25
                }), null != Bh(b, k, void 0 === c ? null : c) && (g |= 16777216)
        }
        a && null != _.Ch(b, void 0 === f ? null : f) && (g |= 16777216);
        return g
    };
    _.Ch = function(a, b) {
        b = void 0 === b ? null : b;
        var c = a.innerHeight;
        c = zh(a.innerWidth, 10, c - 45, c, 10);
        return Bh(a, c, b)
    };
    Bh = function(a, b, c) {
        c = void 0 === c ? null : c;
        b = _.x(b);
        for (var d = b.next(); !d.done; d = b.next()) {
            var e = a,
                f = d.value;
            d = c;
            d = void 0 === d ? null : d;
            var g = e.document;
            var h = f.x,
                k = f.y;
            g.hasOwnProperty("_goog_efp_called_") || (g._goog_efp_called_ = g.elementFromPoint(h, k));
            if (g = g.elementFromPoint(h, k)) {
                if (!(h = Eh(g, e, f, d))) a: {
                    d = void 0 === d ? null : d;h = e.document;
                    for (g = g.offsetParent; g && g !== h.body; g = g.offsetParent)
                        if (k = Eh(g, e, f, d)) {
                            h = k;
                            break a
                        }
                    h = null
                }
                d = h || null
            } else d = null;
            if (d) return d
        }
        return null
    };
    zh = function(a, b, c, d, e) {
        for (var f = [], g = 0; g < e; g++)
            for (var h = 0; h < b; h++) {
                var k = f,
                    l = b - 1,
                    n = e - 1;
                k.push.call(k, {
                    x: (0 === l ? 0 : h / l) * a,
                    y: c + (0 === n ? 0 : g / n) * (d - c)
                })
            }
        return f
    };
    Eh = function(a, b, c, d) {
        d = void 0 === d ? null : d;
        if ("fixed" !== Fh(a, "position")) return null;
        var e = "GoogleActiveViewInnerContainer" === a.getAttribute("class") || 1 >= _.Gh(_.Hh, a).width && 1 >= _.Gh(_.Hh, a).height ? !0 : !1;
        if (d) {
            var f, g;
            _.Ih(d, "ach_evt", {
                tn: a.tagName,
                id: null != (f = a.getAttribute("id")) ? f : "",
                cls: null != (g = a.getAttribute("class")) ? g : "",
                ign: String(e),
                pw: b.innerWidth,
                ph: b.innerHeight,
                x: c.x,
                y: c.y
            }, !0, 1)
        }
        return e ? null : a
    };
    Kh = function(a, b) {
        b = void 0 === b ? [] : b;
        var c = Date.now();
        return _.Jh(b, function(d) {
            return c - d < 1E3 * a
        })
    };
    Mh = function(a, b) {
        try {
            var c = a.getItem("__lsv__");
            if (!c) return [];
            try {
                var d = JSON.parse(c)
            } catch (e) {}
            if (!Array.isArray(d) || _.Lh(d, function(e) {
                    return !_.u(Number, "isInteger").call(Number, e)
                })) return a.removeItem("__lsv__"), [];
            d = Kh(b, d);
            d.length || null == a || a.removeItem("__lsv__");
            return d
        } catch (e) {
            return null
        }
    };
    Nh = function(a, b) {
        .001 > _.Ue() && Xe({
            c: a,
            s: b
        }, "gpt_whirs")
    };
    Oh = function(a) {
        var b = a.split("/");
        return "/" === a.charAt(0) && 2 <= b.length ? b[1] : "/" !== a.charAt(0) && 1 <= b.length ? b[0] : ""
    };
    _.Rh = function(a) {
        _.nf(Ph).j = !0;
        return Qh[a]
    };
    Vh = function(a) {
        var b = new Sh;
        b = _.id(b, 1, Date.now());
        b = _.id(b, 2, a.pvsid);
        b = _.jd(b, 3, a.jb || a.Ta);
        var c = _.nf( of ).j();
        b = _.ed(b, 4, c, Dc);
        b = _.id(b, 5, a.Eh);
        a = _.jd(b, 12, a.Ng);
        var d;
        if (b = null == (d = _.v.globalThis.performance) ? void 0 : d.memory) {
            d = new Th;
            try {
                _.id(d, 1, b.jsHeapSizeLimit)
            } catch (e) {}
            try {
                _.id(d, 2, b.totalJSHeapSize)
            } catch (e) {}
            try {
                _.id(d, 3, b.usedJSHeapSize)
            } catch (e) {}
        } else d = void 0;
        d && _.Uh(a, 10, d);
        return a
    };
    Zh = function(a) {
        var b = lf();
        if (a.Pc) {
            var c = a.Lb;
            a = Vh(a);
            var d = new Wh;
            b = _.id(d, 2, b);
            b = _.Xh(a, 6, Yh, b);
            we(c, b)
        }
    };
    J = function(a, b, c) {
        var d = void 0 === d ? !1 : d;
        return function() {
            var e = _.wb.apply(0, arguments),
                f = $h(a, b, c, d).apply(this, e);
            try {
                var g = e.length;
                if (a.Pc && a.li) {
                    var h = a.Lb,
                        k = Vh(a);
                    var l = _.id(k, 5, a.Dh);
                    var n = new ai;
                    var m = _.fd(n, 1, b, 0);
                    var p = _.fd(m, 2, g, 0);
                    var r = _.Xh(l, 9, Yh, p);
                    we(h, r)
                }
            } catch (t) {}
            return f
        }
    };
    $h = function(a, b, c, d) {
        d = void 0 === d ? !1 : d;
        return function() {
            var e = _.wb.apply(0, arguments),
                f = void 0,
                g = !1,
                h = null,
                k = _.nf(bi);
            try {
                var l = _.E(ci);
                l && k && (h = k.start(b.toString(), 3));
                f = c.apply(this, e);
                g = !0;
                l && k && k.end(h)
            } catch (n) {
                try {
                    if (g) di.call(this, a, 110, n);
                    else if (di.call(this, a, b, n), !d) throw n;
                } catch (m) {
                    if (_.ei(h), !g && !d) throw n;
                }
            }
            return f
        }
    };
    fi = function(a, b, c, d) {
        return $h(a, b, c, void 0 === d ? !1 : d)()
    };
    di = function(a, b, c) {
        if (a.bg) {
            c = c.error && c.meta && c.id ? c.error : c;
            var d = new gi,
                e = new hi;
            try {
                var f = sf(window);
                _.id(e, 1, f)
            } catch (p) {}
            try {
                var g = _.nf( of ).j();
                _.ed(e, 2, g, Dc)
            } catch (p) {}
            try {
                _.jd(e, 3, window.document.URL)
            } catch (p) {}
            f = _.Uh(d, 2, e);
            g = new ii;
            b = _.fd(g, 1, b, 0);
            try {
                var h = ji(null == c ? void 0 : c.name) ? c.name : "Unknown error";
                _.jd(b, 2, h)
            } catch (p) {}
            try {
                var k = ji(null == c ? void 0 : c.message) ? c.message : "Caught " + c;
                _.jd(b, 3, k)
            } catch (p) {}
            try {
                var l = ji(null == c ? void 0 : c.stack) ? c.stack : Error().stack;
                l && _.ed(b, 4, l.split(/\n\s*/), _.Hc)
            } catch (p) {}
            h = _.Uh(f, 1, b);
            k = new ki;
            try {
                _.jd(k, 1, a.jb || a.Ta)
            } catch (p) {}
            try {
                var n = li();
                _.fd(k, 2, n, 0)
            } catch (p) {}
            try {
                var m = [].concat(_.ue(_.u(mi, "keys").call(mi)));
                _.ed(k, 3, m, _.Hc)
            } catch (p) {}
            _.Xh(h, 4, ni, k);
            _.id(h, 5, a.jf);
            ve(a.Lb, h)
        }
    };
    qi = function(a, b) {
        var c, d;
        return null != (d = null == (c = _.u(a, "find").call(a, function(e) {
            e = (0, B.K)(Df(e, oi, 1));
            return pi(e, 1) <= pi(b, 1) && pi(e, 2) <= pi(b, 2)
        })) ? void 0 : Pe(c, oi, 2)) ? d : null
    };
    Ji = function(a, b, c) {
        return "number" === typeof b && "number" === typeof c && Pe(a, Gi, 6).length ? qi(Pe(a, Gi, 6), Hi(Ii(new oi, b), c)) : Pe(a, oi, 5)
    };
    Li = function(a) {
        var b = void 0 === b ? window : b;
        var c = null;
        b.top === b && (b = Ki(!1, b), c = Ji(a, b.width, b.height));
        null != c || (c = Ji(a));
        return null == c ? [] : c.map(function(d) {
            return K(d, 3) ? "fluid" : [(0, B.va)(pi(d, 1)), (0, B.va)(pi(d, 2))]
        })
    };
    Mi = function(a) {
        var b = [],
            c = !1;
        a = _.x(Li(a));
        for (var d = a.next(); !d.done; d = a.next()) d = d.value, Array.isArray(d) ? b.push(d.join("x")) : "fluid" === d ? c = !0 : b.push(d);
        c && b.unshift("320x50");
        return b.join("|")
    };
    Oi = function(a, b) {
        b = void 0 === b ? null : b;
        var c = [];
        a && (c.push(y(a, 1)), c.push(Mi(a)), c.push(y(a, 2)));
        if (b) {
            a = [];
            for (var d = 0; b && 25 > d; b = b.parentNode, ++d) 9 === b.nodeType ? a.push("") : a.push(b.id);
            (b = a.join()) && c.push(b)
        }
        return c.length ? _.Ni(c.join(":")).toString() : "0"
    };
    Pi = function(a) {
        return 0 !== a && 1 !== a
    };
    Ri = function(a, b) {
        var c;
        return !(null != (c = Qi(b, 22)) ? !c : !K(a, 15))
    };
    Ti = function(a) {
        var b = a.document;
        return Si(a) ? b.URL : b.referrer
    };
    Wi = function(a) {
        try {
            return Ui(a, window.top)
        } catch (b) {
            return new _.Vi(-12245933, -12245933)
        }
    };
    Zi = function(a) {
        if (!a) return null;
        var b, c;
        a.getBoundingClientRect ? (a = _.Gh(Xi, a), a = new _.Yi(a.right - a.left, a.bottom - a.top)) : a = null;
        return null != (c = null == (b = a) ? void 0 : b.floor()) ? c : null
    };
    aj = function(a, b) {
        for (var c = {}, d = _.x(_.u(Object, "keys").call(Object, b)), e = d.next(); !e.done; e = d.next()) {
            e = e.value;
            var f = _.Bd(b[e], !1),
                g = _.nf($i),
                h = g.j.get(e);
            null == h ? h = ++_.nf(bi).m : g.j.delete(e);
            _.z(f, 20, h);
            c[e] = f
        }
        return {
            U: _.Bd(a, !1),
            V: c
        }
    };
    dj = function() {
        switch (_.If(bj)) {
            case 2:
                return "9901b501132b9fabe59d89fcfe6bb421";
            default:
                return cj()
        }
    };
    fj = function() {
        for (var a = "", b = _.x(ej()), c = b.next(); !c.done; c = b.next()) c = c.value, 15 >= c && (a += "0"), a += c.toString(16);
        return a
    };
    ej = function() {
        var a;
        if ("function" === typeof(null == (a = window.crypto) ? void 0 : a.getRandomValues)) return a = new Uint8Array(16), window.crypto.getRandomValues(a), a;
        a = window;
        var b;
        if ("function" === typeof(null == (b = a.msCrypto) ? void 0 : b.getRandomValues)) return b = new Uint8Array(16), a.msCrypto.getRandomValues(b), b;
        a = Array(16);
        for (b = 0; b < a.length; b++) a[b] = Math.floor(255 * Math.random());
        return a
    };
    mj = function(a, b, c, d) {
        var e = gj(b, a) || hj(b, a);
        if (!e) return null;
        var f = Wi(e),
            g = e === hj(b, a),
            h = ij(function() {
                var p = g ? hj(b, a) : e;
                return p && jj(p, window)
            }),
            k = function(p) {
                var r;
                return null == (r = h()) ? void 0 : r.getPropertyValue(p)
            };
        c = Li(c)[0];
        var l = !1;
        Array.isArray(c) && (l = d ? g : 0 === f.x && "center" === k("text-align"));
        l && (f.x += Math.round(Math.max(0, (g ? e.clientWidth : e.parentElement.clientWidth) - Number(c[0])) / 2));
        if (g) {
            var n;
            f.y += Math.round(Math.min(null != (n = kj(k("padding-top"))) ? n : 0, e.clientHeight));
            if (!l) {
                d = e.clientWidth;
                var m;
                f.x += Math.round(Math.min(null != (m = kj(k("padding-left"))) ? m : 0, d))
            }
        }
        return f && lj(e) ? f : new _.Vi(-12245933, -12245933)
    };
    nj = function(a, b, c, d) {
        var e = hj(a, c),
            f = "none" === (null == e ? void 0 : e.style.display);
        f && (e.style.display = "block");
        a = mj(c, a, b, d);
        f && (e.style.display = "none");
        return a
    };
    oj = function(a) {
        return "google_ads_iframe_" + a.toString()
    };
    pj = function(a) {
        return oj(a) + "__container__"
    };
    gj = function(a, b) {
        var c;
        return (null == (c = hj(a, b)) ? void 0 : c.querySelector('[id="' + pj(a) + '"]')) || null
    };
    qj = function(a, b) {
        var c, d;
        return null != (d = null == (c = gj(a, b)) ? void 0 : c.querySelector('iframe[id="' + oj(a) + '"]')) ? d : null
    };
    hj = function(a, b) {
        b = void 0 === b ? document : b;
        return rj().m.get(a) || b.getElementById(a.getDomId())
    };
    sj = function(a) {
        return Math.round(Number(kj(a)))
    };
    uj = function(a, b, c) {
        for (var d = 100; a && a !== b && --d;) _.tj(a, c), a = a.parentElement
    };
    vj = function(a, b, c, d, e) {
        _.tj(a, {
            "margin-left": "0px",
            "margin-right": "0px"
        });
        var f = {},
            g = "rtl" === d.direction,
            h = ((e && -12245933 !== e.width ? e.width : b.innerWidth) - c) / 2;
        d = function() {
            var k = a.getBoundingClientRect().left;
            return g ? h - k : k - h
        };
        b = d();
        return 0 !== b ? (c = function(k) {
            g ? f["margin-right"] = k + "px" : f["margin-left"] = k + "px"
        }, c(-b), _.tj(a, f), d = d(), 0 !== d && b !== d && (c(b / (d - b) * b), _.tj(a, f)), !0) : !1
    };
    xj = function(a, b, c, d, e, f, g, h, k) {
        var l = Mi(d);
        _.q.setTimeout($h(a, 459, function() {
            return void wj(a, b, c, e, f, g, l, h, k)
        }), 500)
    };
    wj = function(a, b, c, d, e, f, g, h, k) {
        if (_.q.IntersectionObserver) {
            var l = null,
                n, m = null != (n = qj(c, b)) ? n : hj(c, b);
            n = $h(a, 459, function(p) {
                if (p = p && p[0]) {
                    var r = p.boundingClientRect,
                        t = window.innerWidth,
                        w = Math.round(r.left),
                        D = Math.round(r.right),
                        G = 0 > w + 2,
                        F = 0 < D - (t + 2);
                    if (p.intersectionRatio >= 1 - ((0 <= Math.round(r.left) ? 0 : 2) + (Math.round(r.right) <= window.innerWidth ? 0 : 2)) / e || G || F) yj(h, function(O) {
                        if (G || F) {
                            var I = new zj;
                            I.set(8);
                            Aj(m) && I.set(10);
                            I = Bj(I)
                        } else I = Cj(b, c);
                        var Q = Dj(c, m, f),
                            S = Q.xh;
                        Q = Q.yh;
                        Ej(O, a);
                        L(O, "qid", k);
                        L(O, "iu", c.getAdUnitPath());
                        L(O, "e", String(I));
                        G && L(O, "ofl", String(w));
                        F && L(O, "ofr", String(D - t));
                        L(O, "ret", e + "x" + f);
                        L(O, "req", g);
                        L(O, "bm", String(d));
                        L(O, "efh", Number(S));
                        L(O, "stk", Number(Q));
                        L(O, "ifi", Fj(window))
                    }, _.If(Gj)), l && l.unobserve((0, B.K)(m))
                }
            });
            m && (l = new _.q.IntersectionObserver(n, {
                threshold: [1]
            }), (0, B.K)(l).observe(m))
        }
    };
    Cj = function(a, b) {
        var c = qj(b, a) || hj(b, a),
            d = new zj;
        try {
            var e = c.getBoundingClientRect(),
                f = e.left,
                g = e.top,
                h = e.width,
                k = e.height,
                l = hj(b, a),
                n = (0, B.K)(jj(l, window));
            if ("hidden" === n.visibility || "none" === n.display) return Bj(d);
            var m = sj(n.getPropertyValue("border-top-width") || 0) + 1;
            b = f + h;
            k = g + k;
            var p = a.elementsFromPoint(f + m + 2, g + m);
            var r = a.elementsFromPoint(b - m - 2, g + m);
            var t = a.elementsFromPoint(b - m - 2, k - m);
            var w = a.elementsFromPoint(f + m + 2, k - m);
            var D = a.elementsFromPoint(b / 2, k - m)
        } catch (F) {
            return d.set(1), Bj(d)
        }
        if (!(p && p.length && r && r.length && t && t.length && w && w.length && D && D.length)) return d.set(7), Bj(d);
        a = function(F, O) {
            for (var I = !1, Q = 0; Q < F.length; Q++) {
                var S = F[Q];
                if (I) {
                    var W = jj(S, window);
                    if ("hidden" !== W.visibility && !Hj(S) && !G(c, S)) {
                        d.set(O);
                        "absolute" === W.position && d.set(11);
                        break
                    }
                } else c === S && (I = !0)
            }
        };
        Ij(c) && d.set(9);
        var G = function(F, O) {
            return Jj(F, O) || Jj(O, F)
        };
        f = p[0];
        c === f || G(c, f) || Hj(f) || d.set(2);
        f = r[0];
        c === f || G(c, f) || Hj(f) || d.set(3);
        f = t[0];
        c === f || G(c, f) || Hj(f) || d.set(4);
        f = w[0];
        c === f || G(c, f) || Hj(f) || d.set(5);
        if (Hj(c)) return Bj(d);
        a(p, 12);
        a(r, 13);
        a(t, 14);
        a(w, 15);
        a(D, 6);
        return Bj(d)
    };
    Aj = function(a) {
        var b = !1,
            c = !1;
        return Kj(a, function(d) {
            c = c || "scroll" === d.overflowX || "auto" === d.overflowX;
            return (b = b || "flex" === d.display) && c
        })
    };
    Dj = function(a, b, c) {
        var d = (a = hj(a)) && jj(a, window),
            e = d ? "absolute" !== d.position : !0,
            f = !1,
            g = a && a.parentElement,
            h = !1;
        Lj(b, function(k) {
            var l = k.style;
            if (e)
                if (h || (h = k === g)) e = Mj(k, _.q, -1, -1);
                else {
                    l = l && l.height;
                    var n = (l && _.u(l, "endsWith").call(l, "px") ? sj(l) : 0) >= c;
                    !l || n || "string" === typeof l && _.u(Nj, "includes").call(Nj, l) || (e = !1)
                }
            f || (k = jj(k, _.q), "sticky" !== k.position && "fixed" !== k.position) || (f = !0);
            return !(f && !e)
        }, 100);
        return {
            xh: e,
            yh: f
        }
    };
    Mj = function(a, b, c, d) {
        var e = a.style;
        return (null == e ? 0 : e.height) && !_.u(Nj, "includes").call(Nj, e.height) || (null == e ? 0 : e.maxHeight) && !_.u(Oj, "includes").call(Oj, e.maxHeight) || Pj(a, b.document, function(f) {
            var g = f.style.height;
            f = f.style.getPropertyValue("max-height");
            return !!g && !_.u(Nj, "includes").call(Nj, g) || !!f && !_.u(Oj, "includes").call(Oj, f)
        }, c, d) ? !1 : !0
    };
    Pj = function(a, b, c, d, e) {
        b = b.styleSheets;
        if (!b) return !1;
        var f = a.matches || a.msMatchesSelector;
        d = -1 === d ? Infinity : d;
        e = -1 === e ? Infinity : e;
        for (var g = 0; g < Math.min(b.length, d); ++g) {
            var h = null;
            try {
                var k = b[g],
                    l = null;
                try {
                    l = k.cssRules || k.rules
                } catch (O) {
                    if (15 == O.code) throw O.styleSheet = k, O;
                }
                h = l
            } catch (O) {
                continue
            }
            l = void 0;
            if (null != (l = h) && l.length)
                for (l = 0; l < Math.min(h.length, e); ++l) try {
                    var n = h[l],
                        m, p = c;
                    if (!(m = f.call(a, n.selectorText) && p(n))) a: {
                        var r = void 0;p = a;
                        var t = c,
                            w = e,
                            D = null != (r = n.cssRules) ? r : [];
                        for (r = 0; r < Math.min(D.length, w); r++) {
                            var G = D[r],
                                F = t;
                            if (f.call(p, G.selectorText) && F(G)) {
                                m = !0;
                                break a
                            }
                        }
                        m = !1
                    }
                    if (m) return !0
                } catch (O) {}
        }
        return !1
    };
    Hj = function(a) {
        return Kj(a, function(b) {
            return "fixed" === b.position || "sticky" === b.position
        })
    };
    Ij = function(a) {
        return Kj(a, function(b) {
            var c;
            return (_.C = ["left", "right"], _.u(_.C, "includes")).call(_.C, null != (c = b["float"]) ? c : b.cssFloat)
        })
    };
    Qj = function(a) {
        return "number" === typeof a || "string" === typeof a
    };
    Rj = function(a, b) {
        /^(uuid-in-package|urn:uuid):[0-9a-fA-F-]*$/.test(b) && (b = re(b), a.src = _.kb(b).toString())
    };
    Tj = function(a, b, c) {
        c = void 0 === c ? Sj : c;
        a.goog_sdr_l || (Object.defineProperty(a, "goog_sdr_l", {
            value: !0
        }), "complete" === a.document.readyState ? c(a, b) : _.yb(a, "load", function() {
            return void c(a, b)
        }))
    };
    Uj = function(a) {
        try {
            var b, c;
            return (null != (c = null == (b = a.top) ? void 0 : b.frames) ? c : {}).google_ads_top_frame
        } catch (d) {}
        return null
    };
    Vj = function(a) {
        var b = RegExp("^https?://[^/#?]+/?$");
        return !!a && !b.test(a)
    };
    Wj = function(a) {
        if (a === a.top || _.ne(a.top)) return _.v.Promise.resolve({
            status: 4
        });
        var b = Uj(a);
        if (!b) return _.v.Promise.resolve({
            status: 2
        });
        if (a.parent === a.top && Vj(a.document.referrer)) return _.v.Promise.resolve({
            status: 3
        });
        var c = new _.oh;
        a = new MessageChannel;
        a.port1.onmessage = function(d) {
            "__goog_top_url_resp" === d.data.msgType && c.resolve({
                md: d.data.topUrl,
                status: d.data.topUrl ? 0 : 1
            })
        };
        b.postMessage({
            msgType: "__goog_top_url_req"
        }, "*", [a.port2]);
        return c.promise
    };
    ak = function(a) {
        var b = void 0 === b ? Xj : b;
        var c = Yj(a);
        return c.messageChannelSendRequestFn ? _.v.Promise.resolve(c.messageChannelSendRequestFn) : new _.v.Promise(function(d) {
            function e(k) {
                return h.j(k).then(function(l) {
                    return l.data
                })
            }
            var f = _.ze("IFRAME");
            f.style.display = "none";
            f.name = "goog_topics_frame";
            f.src = _.kb(b).toString();
            var g = (new URL(b.toString())).origin,
                h = Zj({
                    destination: a,
                    xd: f,
                    origin: g,
                    Xa: "goog:gRpYw:doubleclick"
                });
            h.j("goog:topics:frame:handshake:ack").then(function(k) {
                "goog:topics:frame:handshake:ack" === k.data && d(e)
            });
            c.messageChannelSendRequestFn = e;
            a.document.documentElement.appendChild(f)
        })
    };
    gk = function(a, b, c, d) {
        var e = _.E(bk);
        e = void 0 === e ? !1 : e;
        var f = ck(d),
            g = f.fd,
            h = f.ed;
        b = Yj(b);
        b.getTopicsPromise || (a = a({
            message: "goog:topics:frame:get:topics",
            skipTopicsObservation: e
        }).then(function(k) {
            var l = h;
            if (k instanceof Uint8Array) l || (l = !(g instanceof Uint8Array && Aa(k, g)));
            else if (De()(k)) l || (l = k !== g);
            else return c.Xb(989, Error(JSON.stringify(k))), 7;
            if (l && d) try {
                var n = new dk;
                var m = _.z(n, 2, _.hf());
                k instanceof Uint8Array ? ek(m, 1, fk, xc(k, !1, !1)) : ek(m, 3, fk, k);
                d.setItem("goog:cached:topics", Me(m))
            } catch (p) {}
            return k
        }), b.getTopicsPromise = (0, B.va)(a));
        return g && !h ? _.v.Promise.resolve(g) : b.getTopicsPromise
    };
    ck = function(a) {
        if (!a) return {
            fd: null,
            ed: !0
        };
        try {
            var b = a.getItem("goog:cached:topics");
            if (!b) return {
                fd: null,
                ed: !0
            };
            var c = hk(b),
                d = ik(c, fk);
            switch (d) {
                case 0:
                    var e = null;
                    break;
                case 1:
                    var f = Tf(c, fk, 1),
                        g = y(c, f),
                        h = xc(g, !0, !!(jc(c.ga) & 18));
                    null != h && h !== g && Wc(c, f, h);
                    var k = null == h ? wc() : h;
                    var l = jk(k);
                    e = l ? new Uint8Array(l) : kk || (kk = new Uint8Array(0));
                    break;
                case 3:
                    e = _.Re(c, Tf(c, fk, 3), 0);
                    break;
                default:
                    gb(d)
            }
            var n = _.$e(c, 2) + 6048E5 < _.hf();
            return {
                fd: e,
                ed: n
            }
        } catch (m) {
            return {
                fd: null,
                ed: !0
            }
        }
    };
    Yj = function(a) {
        var b;
        return null != (b = a.google_tag_topics_state) ? b : a.google_tag_topics_state = {}
    };
    nk = function(a) {
        if (Wa()) {
            var b = a.document.documentElement.lang;
            lk(a) ? mk(sf(a), !0, "", b) : (new MutationObserver(function(c, d) {
                lk(a) && (mk(sf(a), !1, b, a.document.documentElement.lang), d.disconnect())
            })).observe(a.document.documentElement, {
                attributeFilter: ["class"]
            })
        }
    };
    lk = function(a) {
        var b, c;
        a = null == (b = a.document) ? void 0 : null == (c = b.documentElement) ? void 0 : c.classList;
        return !!((null == a ? 0 : a.contains("translated-rtl")) || (null == a ? 0 : a.contains("translated-ltr")))
    };
    mk = function(a, b, c, d) {
        Xe({
            ptt: "17",
            pvsid: "" + a,
            ibatl: String(b),
            pl: c,
            nl: d
        }, "translate-event")
    };
    ok = function(a) {
        var b = "";
        me(function(c) {
            if (c === c.top) return !0;
            var d;
            if (null == (d = c.document) ? 0 : d.referrer) b = c.document.referrer;
            return !1
        }, !1, !1, a);
        return b
    };
    pk = function(a) {
        var b;
        return null != (b = a.google_tag_data) ? b : a.google_tag_data = {}
    };
    qk = function(a) {
        var b, c;
        return "function" === typeof(null == (b = a.navigator) ? void 0 : null == (c = b.userAgentData) ? void 0 : c.getHighEntropyValues)
    };
    sk = function() {
        var a = window;
        if (!qk(a)) return null;
        var b = pk(a);
        if (b.uach_promise) return b.uach_promise;
        a = a.navigator.userAgentData.getHighEntropyValues(rk).then(function(c) {
            null != b.uach || (b.uach = c);
            return c
        });
        return b.uach_promise = a
    };
    Ek = function(a) {
        var b;
        return tk(uk(vk(wk(xk(yk(zk(Ak(Bk(new Ck, a.architecture || ""), a.bitness || ""), a.mobile || !1), a.model || ""), a.platform || ""), a.platformVersion || ""), a.uaFullVersion || ""), (null == (b = a.fullVersionList) ? void 0 : b.map(function(c) {
            var d = new Dk;
            d = _.z(d, 1, c.brand);
            return _.z(d, 2, c.version)
        })) || []), a.wow64 || !1)
    };
    Fk = function() {
        var a, b;
        return null != (b = null == (a = sk()) ? void 0 : a.then(function(c) {
            return Ek(c)
        })) ? b : null
    };
    Ik = function(a, b) {
        var c = Gk.get(a);
        c || (b = c = b(), Hk.set(b, a), Gk.set(a, b));
        return c
    };
    Kk = function(a, b) {
        return (0, B.va)(Ik(b, function() {
            return new Jk(a, b)
        }))
    };
    M = function(a) {
        return function() {
            return new Lk(a, [].concat(_.ue(_.wb.apply(0, arguments))))
        }
    };
    Mk = function(a) {
        return "[" + a.map(function(b) {
            return "string" === typeof b ? "'" + b + "'" : Array.isArray(b) ? Mk(b) : String(b)
        }).join(", ") + "]"
    };
    Nk = function(a, b) {
        b = Mk(b);
        b = b.substring(1, b.length - 1);
        return new Lk(96, [a, b])
    };
    Ok = function(a) {
        return (_.C = "rewardedSlotReady rewardedSlotGranted rewardedSlotClosed slotAdded slotRequested slotResponseReceived slotRenderEnded slotOnload slotVisibilityChanged impressionViewable".split(" "), _.u(_.C, "includes")).call(_.C, a) ? a : null
    };
    Qk = function(a, b, c) {
        return Ik(c, function() {
            return new Pk(a, b, c)
        })
    };
    Sk = function(a, b, c) {
        return Ik(c, function() {
            return new Rk(a, b, c)
        })
    };
    Tk = function() {
        var a;
        return null != (a = _.q.googletag) ? a : _.q.googletag = {
            cmd: []
        }
    };
    Uk = function() {
        var a = Tk();
        a.hasOwnProperty("pubadsReady") || (a.pubadsReady = !0)
    };
    Xk = function(a) {
        var b = window;
        "complete" === _.q.document.readyState ? fi(a, 94, function() {
            Tk()._pubconsole_disable_ || null !== Vk(b) && Wk(a, b)
        }) : _.yb(_.q, "load", $h(a, 94, function() {
            Tk()._pubconsole_disable_ || null !== Vk(b) && Wk(a, b)
        }))
    };
    Wk = function(a, b) {
        b = void 0 === b ? _.q : b;
        if (!Yk) {
            var c = new Zk("gpt_pubconsole_loaded");
            Ej(c, a);
            L(c, "param", String(Vk(b)));
            L(c, "api", String($k));
            al(c);
            bl(b.document, cl);
            Yk = !0
        }
    };
    Vk = function(a) {
        var b = Ti(a),
            c;
        return null != (c = (_.C = ["google_debug", "dfpdeb", "google_console", "google_force_console", "googfc"], _.u(_.C, "find")).call(_.C, function(d) {
            return null !== dl(b, d)
        })) ? c : null
    };
    el = function() {
        Tk()._pubconsole_disable_ = !0
    };
    hl = function() {
        fl && ((0, B.K)(Tk().console).openConsole(gl), gl = void 0, fl = !1)
    };
    ol = function(a, b, c, d, e) {
        if ("string" !== typeof c || il(c)) N(e, Nk("Slot.setTargeting", [c, d]), a);
        else {
            var f = [];
            Array.isArray(d) ? f = d : wa(d) ? f = _.u(Array, "from").call(Array, d) : d && (f = [d]);
            f = f.map(String);
            (d = (_.C = jl(b), _.u(_.C, "find")).call(_.C, function(g) {
                return y(g, 1) === c
            })) ? kl(d, f): (d = kl(ll(new ml, c), f), _.Xf(b, 9, ml, d));
            e.info(nl(c, f.join(), (0, B.K)(b.getAdUnitPath())), a)
        }
    };
    pl = function(a, b, c, d) {
        if (null != c && "object" === typeof c)
            for (var e = _.x(_.u(Object, "keys").call(Object, c)), f = e.next(); !f.done; f = e.next()) f = f.value, ol(a, b, f, c[f], d);
        else d.error(Nk("Slot.updateTargetingFromMap", [c]), a)
    };
    rl = function(a, b, c) {
        return Ik(c, function() {
            return new ql(a, b, c, c.m)
        })
    };
    sl = function(a) {
        return _.u(Object, "assign").call(Object, {}, a, _.u(Object, "fromEntries").call(Object, _.u(Object, "entries").call(Object, a).map(function(b) {
            b = _.x(b);
            var c = b.next().value;
            return [b.next().value, c]
        })))
    };
    wl = function() {
        var a = {},
            b = sl(tl);
        a.OutOfPageFormat = b;
        b = sl(ul);
        a.TrafficSource = b;
        b = sl(vl);
        a.Taxonomy = b;
        return a
    };
    yl = function() {
        for (var a = Jf(xl) || "0-0-0", b = a.split("-").map(function(e) {
                return Number(e)
            }), c = ["1", "0", "40"].map(function(e) {
                return Number(e)
            }), d = 0; d < b.length; d++) {
            if (b[d] > c[d]) return a;
            if (b[d] < c[d]) break
        }
        return "1-0-40"
    };
    Cl = function() {
        if (zl) return zl;
        for (var a = Kf(Al), b = [], c = 0; c < a.length; c += 2) Bl(a[c], a[c + 1], b);
        return zl = b.join("&")
    };
    Il = function(a, b) {
        if (!b || !_.na(b)) return null;
        var c = !1,
            d = new Dl;
        _.El(b, function(e, f) {
            var g = !1;
            switch (f) {
                case "allowOverlayExpansion":
                    "boolean" === typeof e ? _.z(d, 1, b.allowOverlayExpansion) : c = g = !0;
                    break;
                case "allowPushExpansion":
                    "boolean" === typeof e ? _.z(d, 2, b.allowPushExpansion) : c = g = !0;
                    break;
                case "sandbox":
                    !0 === e ? _.z(d, 3, b.sandbox) : c = g = !0;
                    break;
                case "useUniqueDomain":
                    Fl();
                    return;
                default:
                    g = !0
            }
            g && a.error(Gl("setSafeFrameConfig", Hl(b), f, Hl(e)))
        });
        return c ? null : d
    };
    Kl = function(a) {
        var b = new Dl;
        a = _.x(a);
        for (var c = a.next(); !c.done; c = a.next())
            if (c = c.value) Jl(c, 1) && _.z(b, 1, K(c, 1)), Jl(c, 2) && _.z(b, 2, K(c, 2)), Jl(c, 3) && _.z(b, 3, K(c, 3)), Jl(c, 4) && _.z(b, 4, K(c, 4));
        return b
    };
    Ml = function() {
        var a, b, c;
        return "pagead2.googlesyndication.com" === (null != (c = Ll.exec(null != (b = null == (a = _.Rh(172)) ? void 0 : a.src) ? b : "")) ? c : [])[1]
    };
    Nl = function(a) {
        return a + 'Correlator has been deprecated. Please see the Google Ad Manager help page on "Pageviews in GPT" for more information: https://support.google.com/admanager/answer/183281?hl=en'
    };
    $l = function(a, b) {
        var c = b.m;
        return a.map(function(d) {
            return _.u(c, "find").call(c, function(e) {
                return e.pa === d
            })
        }).filter(He())
    };
    bm = function(a, b) {
        var c = [];
        a = _.x(a);
        for (var d = a.next(); !d.done; d = a.next()) {
            d = d.value;
            b.H = d;
            var e = qf(9);
            1 === e.length && (c.push(d), c.push(d + "-" + e[0]))
        }
        return c
    };
    em = function(a, b, c, d, e, f) {
        var g = cm(f, a, b, d, e, void 0, !0);
        f = g.slotId;
        g = g.nb;
        if (!f || !g) return N(b, Nk("PubAdsService.definePassback", [d, e])), null;
        _.z(g, 17, !0);
        c.slotAdded(f, g);
        return {
            Of: rl(a, b, new dm(a, f, c)),
            nb: g
        }
    };
    gm = function(a, b, c, d, e) {
        return Ik(c, function() {
            return new fm(a, b, c, d, e)
        })
    };
    im = function(a) {
        return Array.isArray(a) && 2 === a.length ? a.every(hm) : "fluid" === a
    };
    jm = function(a) {
        return Array.isArray(a) && 2 === a.length && hm(a[0]) && hm(a[1])
    };
    lm = function(a) {
        return Array.isArray(a) ? Hi(Ii(new oi, (0, B.va)(a[0])), (0, B.va)(a[1])) : km()
    };
    nm = function(a) {
        var b = [];
        if (mm(a)) b.push(lm((0, B.K)(a)));
        else if (Array.isArray(a)) {
            a = _.x(a);
            for (var c = a.next(); !c.done; c = a.next()) c = c.value, mm(c) ? b.push(lm((0, B.K)(c))) : Aa(c, ["fluid"]) && b.push(km())
        }
        return b
    };
    om = function(a) {
        var b = void 0 === b ? window : b;
        if (!a) return [];
        if (!a.length) {
            var c, d;
            null == (c = b.console) || null == (d = c.warn) || d.call(c, "Invalid GPT fixed size specification: " + JSON.stringify(a))
        }
        return nm(a)
    };
    mm = function(a) {
        return _.E(pm) ? Array.isArray(a) && 2 === a.length ? a.every(qm) : "fluid" === a : Array.isArray(a) && 1 < a.length ? "number" === typeof a[0] && "number" === typeof a[1] : "fluid" === a
    };
    ta = function(a, b) {
        a: {
            b = (0, B.va)(b[0]);a = (0, B.va)(a[0]);
            for (var c = _.ra, d = Math.min(b.length, a.length), e = 0; e < d; e++) {
                var f = c(b[e], a[e]);
                if (0 != f) {
                    b = f;
                    break a
                }
            }
            b = _.ra(b.length, a.length)
        }
        return b
    };
    rm = function(a) {
        return Array.isArray(a) && 2 === a.length && "number" === typeof a[0] && _.u(a, "includes").call(a, 0)
    };
    sm = function(a) {
        return rm(a) ? [] : Array.isArray(a) && 0 < a.length && "number" !== typeof a[0] ? a.filter(function(b) {
            return !rm(b)
        }) : a
    };
    um = function(a) {
        if (!Array.isArray(a) || 2 !== a.length) throw new tm("Each mapping entry must be an array of size 2");
        var b = a[0];
        if (!jm(b)) throw new tm("Size must be an array of two non-negative integers");
        b = Hi(Ii(new oi, b[0]), b[1]);
        if (Array.isArray(a[1]) && 0 === a[1].length) a = [];
        else if (a = nm(a[1]), 0 === a.length) throw new tm("At least one slot size must be present");
        var c = new Gi;
        b = _.Uh(c, 1, b);
        return _.yd(b, 2, a)
    };
    wm = function(a, b, c) {
        return Ik(c, function() {
            return new vm(a, b, c)
        })
    };
    ym = function(a) {
        a = (_.ne(a.top) ? a.top : a).AMP;
        return "object" === typeof a && !!xm(a, function(b, c) {
            return !/^inabox/i.test(c)
        })
    };
    zm = function(a, b, c, d) {
        var e = _.ze("DIV");
        e.id = b;
        e.name = b;
        b = e.style;
        b.border = "0pt none";
        c && (b.margin = "auto", b.textAlign = "center");
        d && (c = Array.isArray(d), b.width = c ? d[0] + "px" : "100%", b.height = c ? d[1] + "px" : "0%");
        a.appendChild(e);
        return e
    };
    Am = function(a) {
        return "sticky" === (null == a ? void 0 : a.position) || "fixed" === (null == a ? void 0 : a.position)
    };
    Cm = function(a, b, c, d) {
        try {
            var e;
            if (!(e = !b)) {
                var f;
                if (!(f = !Bm(b, c, d))) {
                    a: {
                        do {
                            var g = jj(b, c);
                            if (g && "fixed" == g.position) {
                                var h = !1;
                                break a
                            }
                        } while (b = b.parentElement);h = !0
                    }
                    f = !h
                }
                e = f
            }
            e && (a.height = -1)
        } catch (k) {
            a.width = -1, a.height = -1
        }
    };
    Dm = function(a, b) {
        for (var c = new zj, d = 0; d < a.length; d++) c.set(a.length - d - 1, b(a[d]));
        return Bj(c)
    };
    Em = function(a, b, c) {
        c = void 0 === c ? {} : c;
        var d = void 0 === c.yc ? "" : c.yc;
        c = void 0 === c.oa ? "," : c.oa;
        var e = !1;
        a = a.map(function(f) {
            f = b(f);
            e || (e = !!f);
            return String(f || d)
        });
        return e ? a.join(c) : null
    };
    Gm = function(a, b, c, d) {
        for (var e = _.x(_.u(Object, "entries").call(Object, Fm)), f = e.next(); !f.done; f = e.next()) {
            var g = _.x(f.value);
            f = g.next().value;
            g = g.next().value;
            b & f && N(a, g(c, d))
        }
    };
    Lm = function(a, b, c) {
        c = void 0 === c ? null : c;
        b = (void 0 === b ? 0 : b) ? 604800 : -1;
        if (!(0 < b) || c && bf(c)) {
            c = c ? cf(c) : null;
            var d = 0;
            try {
                d |= a != a.top ? 512 : 0;
                var e;
                (e = !a.navigator) || (e = !1);
                d |= e || /Android 2/.test(a.navigator.userAgent) ? 1048576 : 0;
                d |= xh(a, 2500);
                if (_.E(Hm)) {
                    var f = _.Im(a).clientHeight;
                    d |= f ? 320 > f ? 2097152 : 0 : 1073741824
                }
                d |= yh(a);
                0 < b && !_.Jm(_.Km(c, b)) && (d |= 134217728)
            } catch (g) {
                d |= 32
            }
            a = d
        } else a = 4194304;
        return a
    };
    Pm = function(a, b, c, d, e, f) {
        d = Mm(d);
        if (5 !== d) return !1;
        var g = Lm(e, !Nm(c), f);
        if (g &= -134217729) yj("gpt_int_ns", function(h) {
            L(h, "nsr", g);
            Ej(h, a)
        }, _.If(Om)), Gm(b, g, d, c.getAdUnitPath());
        return !!g
    };
    Qm = function(a) {
        switch (a) {
            case 4:
                return 11;
            case 2:
                return 2;
            case 3:
                return 1;
            case 5:
                return 8;
            case 6:
                return 42
        }
    };
    Um = function(a, b) {
        a = Qm(a);
        if (!a) return null;
        var c = 0;
        if (11 !== a) {
            c |= _.q != _.q.top ? 512 : 0;
            var d = _.Rm(_.q);
            d = 26 !== a && 27 !== a && 40 !== a && 41 !== a && 10 !== a && d.adCount ? 1 == a || 2 == a ? !(!d.adCount[1] && !d.adCount[2]) : (d = d.adCount[a]) ? 1 <= d : !1 : !1;
            d && (c |= 64);
            if (c) return c
        }
        2 === a || 1 === a ? (b = {
            ta: _.q,
            Bd: _.Sm,
            af: b ? a : void 0
        }, 0 === (0, _.Tm)() && (b.Bd = 3E3, b.Be = 650), c |= _.Dh(b)) : 8 === a ? c |= Lm(_.q) : 11 !== a && 42 !== a && (c |= 32);
        c || (b = _.Rm(_.q), b.adCount = b.adCount || {}, b.adCount[a] = b.adCount[a] + 1 || 1);
        return c
    };
    Vm = function(a) {
        if (61440 >= a.length) return {
            url: a,
            Ud: 0
        };
        var b = a;
        61440 < b.length && (b = b.substring(0, 61432), b = b.replace(/%\w?$/, ""), b = b.replace(/&[^=]*=?$/, ""), b += "&trunc=1");
        return {
            url: b,
            Ud: a.length - b.length + 8
        }
    };
    Wm = function(a, b) {
        b = void 0 === b ? window : b;
        return b.location ? b.URLSearchParams ? (a = (new URLSearchParams(b.location.search)).get(a), (null == a ? 0 : a.length) ? a : null) : (a = (new RegExp("[?&]" + a + "=([^&]*)")).exec(b.location.search)) ? decodeURIComponent(a[1]) : null : null
    };
    Xm = function(a, b) {
        b = void 0 === b ? window : b;
        return !!Wm(a, b)
    };
    $m = function(a, b) {
        var c = b.V;
        return Em(a, function(d) {
            return Ym(c[d.getDomId()]).join("&")
        }, Zm)
    };
    Ym = function(a) {
        a = an(a);
        var b = [];
        _.El(a, function(c, d) {
            c.length && (c = c.map(encodeURIComponent), d = encodeURIComponent(d), b.push(d + "=" + c.join()))
        });
        return b
    };
    an = function(a) {
        for (var b = {}, c = _.x(jl(a)), d = c.next(); !d.done; d = c.next()) d = d.value, b[(0, B.K)(y(d, 1))] = _.bn(d, 2);
        a = _.bn(a, 8);
        a.length && (null != b.excl_cat || (b.excl_cat = a));
        return b
    };
    cn = function(a) {
        var b = !1,
            c = Pe(a, ml, 2).map(function(d) {
                var e = (0, B.K)(y(d, 1));
                b = "excl_cat" === e;
                d = _.bn(d, 2);
                return encodeURIComponent(e) + "=" + encodeURIComponent(d.join())
            });
        a = _.bn(a, 3);
        !b && a.length && c.push(encodeURIComponent("excl_cat") + "=" + encodeURIComponent(a.join()));
        return c
    };
    dn = function(a) {
        var b, c;
        return null != (c = null == (b = _.u(a, "find").call(a, function(d) {
            return "page_url" === y(d, 1)
        })) ? void 0 : _.bn(b, 2)[0]) ? c : null
    };
    en = function(a) {
        var b = a.indexOf("google_preview=", a.lastIndexOf("?")),
            c = a.indexOf("&", b); - 1 === c && (c = a.length - 1, --b);
        return a.substring(0, b) + a.substring(c + 1, a.length)
    };
    fn = function(a) {
        var b;
        if (null == (b = a.location) ? 0 : b.ancestorOrigins) return a.location.ancestorOrigins.length;
        var c = 0;
        me(function() {
            c++;
            return !1
        }, !0, !0, a);
        return c
    };
    gn = function(a, b) {
        var c = b.V;
        return !!dn(b.U.xa()) || a.some(function(d) {
            return null !== dn(c[d.getDomId()].xa())
        })
    };
    kn = function(a, b, c) {
        var d = null;
        try {
            var e = hn(b.top.document, b.top).y;
            d = a.map(function(f) {
                var g = c.U,
                    h = c.V[f.getDomId()],
                    k;
                f = null == (k = nj(f, h, b.document, Ri(g, h))) ? void 0 : k.y;
                k = Ki(!0, b).height;
                return void 0 === f || -12245933 === f || -12245933 === k ? -1 : f < e + k ? 0 : ++jn
            })
        } catch (f) {}
        return d
    };
    ln = function(a) {
        return K(a, 8) ? "loc gpic cookie ms ppid top etu uule video_doc_id adsid".split(" ") : []
    };
    nn = function() {
        var a = void 0 === a ? window : a;
        mn = _.hf(a)
    };
    rn = function(a) {
        if (null == a || !a.ba.Z.length) return "";
        for (var b = new _.v.Map, c = _.x(on), d = c.next(); !d.done; d = c.next()) d = d.value, d(a, b);
        c = "https://" + (pn(a) ? "pagead2.googlesyndication.com" : "securepubads.g.doubleclick.net") + "/gampad/ads?";
        b = _.x(b);
        for (d = b.next(); !d.done; d = b.next()) {
            var e = _.x(d.value);
            d = e.next().value;
            var f = e.next().value;
            e = f.value;
            f = void 0 === f.options ? {} : f.options;
            (new RegExp("[?&]" + d + "=")).test(c);
            var g = a,
                h = new _.v.Set(Kf(qn));
            g = _.x(ln(g.fa.X));
            for (var k = g.next(); !k.done; k = g.next()) h.add(k.value);
            !h.has(d) && null != e && (h = f, f = void 0 === h.oa ? "," : h.oa, h = void 0 === h.ya ? !1 : h.ya, e = "object" !== typeof e ? null == e || !h && 0 === e ? null : encodeURIComponent(e) : Array.isArray(e) && e.length ? encodeURIComponent(e.join(f)) : null) && ("?" !== c[c.length - 1] && (c += "&"), c += d + "=" + e)
        }
        return c
    };
    pn = function(a) {
        var b = a.fa.X,
            c, d;
        a = null != (d = null == (c = sn(a.ba.P.U)) ? void 0 : K(c, 9)) ? d : !1;
        c = K(b, 8);
        return a || c || !bf(b)
    };
    tn = function(a, b) {
        var c;
        return !(null != (c = Qi(a, 11)) ? !c : !K(b, 10))
    };
    un = function(a, b, c, d) {
        if (a = hj(a, b)) {
            var e;
            if (c = null != (e = Qi(c, 24)) ? e : K(d, 30)) c = a.getBoundingClientRect(), d = c.top, e = c.bottom, 0 === c.height ? c = !1 : (c = _.q.innerHeight, c = 0 < e && e < c || 0 < d && d < c);
            c || (a.style.display = "none")
        }
    };
    An = function(a, b, c, d, e, f, g) {
        var h = new hg,
            k = new vn(a, d);
        H(h, k);
        f = new wn(a, e, f);
        H(h, f);
        f = new xn(a, b, e, g, k.ob);
        H(h, f);
        b = new yn(a, b, c, e, d, g, k.ob);
        H(h, b);
        a = new zn(a, k.ob, b.l, f.l);
        H(h, a);
        sg(h);
        return {
            ob: a.C,
            zc: h
        }
    };
    Bn = function(a) {
        var b = a.match(/\/?([0-9]+)(?:,[0-9]+)?((?:\/.+?)+?)(?:\/*)$/);
        return 3 !== (null == b ? void 0 : b.length) ? a : "/" + b[1] + b[2]
    };
    Dn = function(a, b) {
        var c, d;
        return null != (d = null != (c = null == b ? void 0 : b.get(_.E(Cn) ? Bn(a) : a)) ? c : null == b ? void 0 : b.get(_.Ni(a))) ? d : 0
    };
    In = function(a, b, c, d, e) {
        if (null != b && b.size) {
            var f, g;
            e = null != (g = null != (f = null == e ? void 0 : e.adUnits) ? f : null == a ? void 0 : a.adUnits) ? g : [];
            a = {};
            f = _.x(e);
            for (g = f.next(); !g.done; a = {
                    Wc: a.Wc
                }, g = f.next()) {
                e = g.value;
                g = e.code;
                var h = e.bids;
                e = void 0;
                if (g && null != (e = h) && e.length && (g = Dn(g, b), a.Wc = g / 1E6, !(0 >= g))) {
                    var k = void 0;
                    e = {};
                    h = _.x(null != (k = h) ? k : []);
                    for (k = h.next(); !k.done; e = {
                            bb: e.bb,
                            Md: e.Md
                        }, k = h.next()) k = k.value, e.Md = "function" === typeof k.getFloor ? k.getFloor : void 0, e.bb = En(Fn(Gn(new Hn, 4), g), c), k.getFloor = function(l, n) {
                        return function(m) {
                            4 === _.Re(l.bb, 1, 0) && Gn(l.bb, 1);
                            var p, r = null == (p = l.Md) ? void 0 : p.apply(this, [m]);
                            m = c ? r || {} : {
                                currency: "USD",
                                floor: n.Wc
                            };
                            return null != r && r.floor ? (null == r ? 0 : r.currency) && "USD" !== r.currency ? (1 === _.Re(l.bb, 1, 0) && (m = Fn(Gn(l.bb, 6), 1E6 * r.floor), _.z(m, 3, r.currency)), r) : (r.floor || 0) > n.Wc ? (1 === _.Re(l.bb, 1, 0) && Fn(Gn(l.bb, 5), 1E6 * r.floor), r) : m : m
                        }
                    }(e, a), d.set(k.getFloor, e.bb)
                }
            }
        }
    };
    Jn = function(a, b) {
        var c = a.que,
            d = function() {
                var e;
                null == a || null == (e = a.requestBids) || e.before.call(b, function(f, g) {
                    return Tk().pbjs_hooks.push({
                        context: b,
                        nextFunction: f,
                        requestBidsConfig: g
                    })
                }, 0)
            };
        (null == c ? 0 : c.hasOwnProperty("push")) ? null == c || c.push(d): null == c || c.unshift(d)
    };
    Ln = function(a, b) {
        return (0, B.va)(Ik(b, function() {
            return new Kn(a, b)
        }))
    };
    Qn = function(a, b, c) {
        var d = window,
            e = new hg;
        d = new Mn(d);
        _.Nn(e, d);
        c = new On(a, d, c);
        H(e, c);
        a = new Pn(a, d, b, c.Ub);
        H(e, a);
        sg(e);
        return {
            Ub: c.Ub,
            pf: a.l,
            zc: e
        }
    };
    Vn = function(a) {
        var b, c = null == (b = window.top) ? void 0 : b.location.href;
        if (!c) return !1;
        var d = _.Ni(c),
            e;
        return null == (e = Pe(a, Rn, 1)) ? void 0 : e.some(function(f) {
            switch (ik(f, Sn)) {
                case 1:
                    f = (0, B.K)(Df(f, Tn, Tf(f, Sn, 1)));
                    if (null != Un(f, 1) && null != Un(f, 2)) {
                        var g = (0, B.K)(Se(f, 1));
                        f = 0 >= g || g > c.length ? !1 : (0, B.K)(Se(f, 2)) === _.Ni(c.substring(0, g))
                    } else f = !1;
                    return f;
                case 2:
                    return (0, B.K)(Se(f, Tf(f, Sn, 2))) === d;
                default:
                    return !1
            }
        })
    };
    Xn = function(a) {
        var b;
        return null == (b = Wn(a, 2)) ? void 0 : b.some(function(c) {
            switch (c) {
                case 0:
                    return !1;
                case 1:
                    return !0;
                case 2:
                    return 0 === (0, _.Tm)();
                case 4:
                    return 2 === (0, _.Tm)();
                case 3:
                    return 1 === (0, _.Tm)();
                default:
                    return !1
            }
        })
    };
    bo = function(a, b, c, d, e) {
        var f = [];
        c = _.x(Pe(c, Yn, 3));
        for (var g = c.next(); !g.done; g = c.next())
            if (g = g.value, _.bg(g, 1) && _.bg(g, 2) && null != Un(g, 3) && null != Un(g, 4)) {
                var h = a.querySelector(_.Rf(g, 1)),
                    k = void 0;
                if (null != (k = h) && k.parentElement) {
                    k = g.getAdUnitPath();
                    var l = "gpt_opp_" + k;
                    if (!a.getElementById(l)) {
                        var n = a.createElement("div");
                        n.id = l;
                        h.insertAdjacentElement("beforebegin", n);
                        if (g = b.defineSlot(k, [g.getWidth(), g.getHeight()], l)) g.addService(b.pubads()), h = Zn(rj(), g.getSlotElementId()), e && (k = void 0, null == (k = h) || $n(k, e)), f.push(g)
                    }
                }
            }
        f.length && ao(a, function() {
            for (var m = _.x(f), p = m.next(); !p.done; p = m.next()) b.display(p.value);
            K(d, 4) && b.pubads().refresh(f)
        })
    };
    fo = function(a, b, c, d) {
        var e = d.ge,
            f = d.adUnitPath;
        d = void 0 === d.La ? !1 : d.La;
        return "string" === typeof f && f.length && (null == e || "string" === typeof e || "number" === typeof e && co(e)) ? eo(a, b, f, c, {
            pb: "string" === typeof e ? e : void 0,
            format: "number" === typeof e ? e : 1,
            La: d
        }) : (b.error(Nk("googletag.defineOutOfPageSlot", [f, e])), null)
    };
    co = function(a) {
        return !!xm(tl, function(b) {
            return b === a
        }) || 6 === a
    };
    eo = function(a, b, c, d, e) {
        var f = e.format;
        b = d.add(a, b, c, [1, 1], {
            pb: e.pb,
            format: f,
            La: e.La
        });
        a = b.slotId;
        b = b.nb;
        a && b && (_.z(b, 15, f), _.go(a, function() {
            var g = window,
                h = Qm((0, B.K)(f));
            if (h) {
                g = _.Rm(g);
                var k = g.adCount && g.adCount[h];
                k && (g.adCount[h] = k - 1)
            }
        }));
        return null != a ? a : null
    };
    ho = function(a) {
        switch (Number(a)) {
            case 2:
            case 3:
                return "Anchor";
            case 5:
                return "Interstitial";
            case 6:
                return "Shoppit";
            default:
                return "Out-of-page creative"
        }
    };
    ro = function(a, b, c, d, e) {
        var f = e.getBidResponsesForAdUnitCode;
        if (f) {
            var g, h, k, l = null != (k = null == (g = f(b.getDomId())) ? void 0 : g.bids) ? k : null == (h = f(b.getAdUnitPath())) ? void 0 : h.bids;
            if (null != l && l.length && (g = l.filter(function(p) {
                    var r = p.adId;
                    return p.auctionId !== c && d.some(function(t) {
                        return (_.C = _.bn(t, 2), _.u(_.C, "includes")).call(_.C, r)
                    })
                }), g.length)) {
                var n, m;
                f = null == (n = e.adUnits) ? void 0 : null == (m = _.u(n, "find").call(n, function(p) {
                    p = p.code;
                    return p === b.getAdUnitPath() || p === b.getDomId()
                })) ? void 0 : m.mediaTypes;
                n = _.x(g);
                for (m = n.next(); !m.done; m = n.next()) m = m.value, g = io(m, d, f), g = jo(a, ko(_.z(lo(mo(new no, m.bidder), 1), 6, !0), g)), _.E(oo) && po(m.bidder, e, g), "number" === typeof m.timeToRespond && qo(g, m.timeToRespond)
            }
        }
    };
    po = function(a, b, c) {
        for (var d = []; a && !_.u(d, "includes").call(d, a);) {
            d.unshift(a);
            var e = void 0,
                f = void 0;
            a = null == (e = b) ? void 0 : null == (f = e.aliasRegistry) ? void 0 : f[a]
        }
        _.ed(c, 10, d, _.Hc)
    };
    so = function(a, b, c) {
        null != y(a, 3) || (c === b.getAdUnitPath() ? _.z(a, 3, 1) : c === b.getDomId() && _.z(a, 3, 2))
    };
    vo = function(a, b, c, d, e, f, g) {
        f = f.get(null != g ? g : function() {
            return null
        });
        1 !== (null == f ? void 0 : _.Re(f, 1, 0)) && _.Uh(b, 5, f);
        to(a, Hn, 5) || (f ? 1 === _.Re(f, 1, 0) ? uo(a, f) : uo(a, Fn(Gn(En(new Hn, e), 1), Dn(c, d))) : uo(a, Gn(En(new Hn, e), Dn(c, d) ? 2 : 3)))
    };
    io = function(a, b, c) {
        var d = a.cpm,
            e = a.originalCpm,
            f = a.currency,
            g = a.originalCurrency,
            h = a.dealId,
            k = a.adserverTargeting,
            l = a.bidder,
            n = a.adUnitCode,
            m = a.adId,
            p = a.mediaType,
            r = a.height;
        a = a.width;
        var t = new wo;
        "number" === typeof d && (_.z(t, 2, Math.round(1E6 * d)), g && g !== f || (d = Math.round(1E6 * Number(e)), isNaN(d) || d === _.$e(t, 2) || _.z(t, 8, d)));
        "string" === typeof f && _.z(t, 3, f);
        "string" === typeof h && xo(t, yo(h));
        if ("object" === typeof k)
            for (b = _.u(Object, "fromEntries").call(Object, b.map(function(G) {
                    return [y(G, 1), _.bn(G, 2)]
                })), f = _.x(["", "_" + l]), h = f.next(); !h.done; h = f.next()) {
                h = h.value;
                d = [];
                e = _.x(_.u(Object, "entries").call(Object, k));
                for (g = e.next(); !g.done; g = e.next()) {
                    g = _.x(g.value);
                    var w = g.next().value;
                    g = g.next().value;
                    w = (w + h).slice(0, 20);
                    var D = void 0;
                    if (null != (D = b[w]) && D.length)
                        if (b[w][0] === String(g)) d.push(w);
                        else {
                            d = [];
                            break
                        }
                }
                zo(t, _.bn(t, 4).concat(d))
            }
        switch (p || "banner") {
            case "banner":
                _.z(t, 5, 1);
                break;
            case "native":
                _.z(t, 5, 2);
                yj("hbyg_nat", function(G) {
                    L(G, "pub_url", document.URL);
                    L(G, "b", l);
                    L(G, "auc", null != n ? n : "");
                    L(G, "hmt", Number(!!c));
                    var F;
                    L(G, "hat", Number(!!(null == c ? 0 : null == (F = c.native) ? 0 : F.adTemplate)))
                }, _.If(Ao));
                break;
            case "video":
                _.z(t, 5, 3)
        }
        "number" === typeof r && "number" === typeof a && Bo(t, Co(Do(a), r));
        "string" === typeof m && _.z(t, 1, m);
        return t
    };
    Eo = function(a, b) {
        var c = new _.v.Map,
            d = function(k) {
                var l = c.get(k);
                l || (l = {}, c.set(k, l));
                return l
            },
            e = [];
        a = _.x(a);
        for (var f = a.next(); !f.done; f = a.next()) {
            f = f.value;
            var g = f.args,
                h = f.eventType;
            f = f.elapsedTime;
            "bidTimeout" === h && e.push.apply(e, _.ue(g));
            switch (h) {
                case "bidRequested":
                    if (g.auctionId !== b) continue;
                    if (!Array.isArray(g.bids)) continue;
                    g = _.x(g.bids);
                    for (h = g.next(); !h.done; h = g.next())
                        if (h = h.value.bidId) d(h).requestTime = f;
                    break;
                case "noBid":
                    g.auctionId === b && g.bidId && (d(g.bidId).fi = f)
            }
        }
        d = new _.v.Map;
        a = _.x(_.u(c, "entries").call(c));
        for (f = a.next(); !f.done; f = a.next()) g = _.x(f.value), f = g.next().value, h = g.next().value, g = h.requestTime, h = h.fi, g && h && d.set(f, {
            latency: h - g,
            yf: !1
        });
        e = _.x(e);
        for (a = e.next(); !a.done; a = e.next())
            if (f = a.value, a = f.bidId, f = f.auctionId, a && f === b && (a = d.get(a))) a.yf = !0;
        return d
    };
    Go = function(a) {
        return null != Un(a, 1) ? null != Fo(a, 3) && 0 !== (0, _.Tm)() ? (0, B.va)(Un(a, 1)) * (0, B.va)(Fo(a, 3)) : Un(a, 1) : null
    };
    Ho = function(a, b) {
        return window.IntersectionObserver && new IntersectionObserver(a, {
            rootMargin: b
        })
    };
    Io = function(a, b) {
        if ("undefined" !== typeof IntersectionObserver) return new IntersectionObserver(b, {
            rootMargin: a + "%"
        })
    };
    Jo = function(a) {
        var b = {};
        a = _.x(a);
        for (var c = a.next(); !c.done; c = a.next()) c = c.value, b[y(c, 1)] = y(c, 2);
        return b
    };
    Mo = function(a, b, c) {
        return new Ko(c, a, Lo, function(d) {
            d = d.detail.data;
            try {
                var e = JSON.parse(d);
                if ("rewarded" === e.type && e.message === b) return e
            } catch (f) {}
            return null
        })
    };
    No = function(a) {
        var b = a.be,
            c = a.Nb,
            d = void 0 === a.Fg ? [] : a.Fg,
            e = void 0 === a.ig ? !1 : a.ig,
            f = e ? "https://securepubads.g.doubleclick.net" : "https://pubads.g.doubleclick.net",
            g = e ? "https://securepubads.g.doubleclick.net/td/sjs" : "https://pubads.g.doubleclick.net/td/sjs",
            h;
        a = {
            seller: f,
            decisionLogicUrl: g,
            trustedScoringSignalsUrl: e ? "https://securepubads.g.doubleclick.net/td/sts" : "https://pubads.g.doubleclick.net/td/sts",
            interestGroupBuyers: null != (h = a.interestGroupBuyers) ? h : ["https://googleads.g.doubleclick.net", "https://td.doubleclick.net"],
            sellerExperimentGroupId: 0,
            auctionSignals: b.auctionSignals.promise,
            sellerSignals: b.j.promise,
            sellerTimeout: 50,
            perBuyerExperimentGroupIds: {},
            perBuyerSignals: b.perBuyerSignals.promise,
            perBuyerTimeouts: b.perBuyerTimeouts.promise
        };
        return {
            seller: f,
            decisionLogicUrl: g,
            interestGroupBuyers: [],
            auctionSignals: {},
            sellerExperimentGroupId: 0,
            sellerSignals: b.topLevelSellerSignals.promise,
            sellerTimeout: 50,
            signal: c.signal,
            perBuyerExperimentGroupIds: {},
            perBuyerSignals: {},
            perBuyerTimeouts: {},
            componentAuctions: [a].concat(_.ue(d))
        }
    };
    Oo = function(a, b) {
        b.topLevelSellerSignals.resolve(a.sellerSignals);
        var c;
        if (a = null == (c = a.componentAuctions) ? void 0 : _.u(c, "find").call(c, function(e) {
                return (_.C = ["https://securepubads.g.doubleclick.net", "https://pubads.g.doubleclick.net"], _.u(_.C, "includes")).call(_.C, e.seller)
            })) {
            b.auctionSignals.resolve(a.auctionSignals);
            b.j.resolve(a.sellerSignals);
            b.perBuyerSignals.resolve(a.perBuyerSignals);
            var d;
            b.perBuyerTimeouts.resolve(null != (d = a.perBuyerTimeouts) ? d : {})
        } else b.auctionSignals.resolve(void 0), b.j.resolve(void 0), b.perBuyerSignals.resolve({}), b.perBuyerTimeouts.resolve({})
    };
    Vo = function(a, b) {
        var c, d, e, f, g, h, k, l, n, m, p, r;
        return _.Ab(function(t) {
            if (1 == t.j) return _.u(a, "startsWith").call(a, "urn:") && Po.deprecatedURNToURL && Po.deprecatedReplaceInURN ? Bb(t, Po.deprecatedURNToURL(a), 2) : t.return();
            c = t.o;
            d = {};
            e = b.gdprApplies || "";
            (null != (f = c.match(Qo)) ? f : []).forEach(function(w) {
                d[w] = e
            });
            g = b.ih || "";
            (null != (h = c.match(Ro)) ? h : []).forEach(function(w) {
                d[w] = g
            });
            k = b.tg || "";
            (null != (l = c.match(So)) ? l : []).forEach(function(w) {
                d[w] = k
            });
            n = b.rg || "";
            (null != (m = c.match(To)) ? m : []).forEach(function(w) {
                d[w] = n
            });
            p = b.pg || "";
            (null != (r = c.match(Uo)) ? r : []).forEach(function(w) {
                d[w] = p
            });
            return Bb(t, Po.deprecatedReplaceInURN(a, d), 0)
        })
    };
    Xo = function(a, b, c) {
        var d = "https://googleads.g.doubleclick.net/td/auctionwinner?status=nowinner",
            e = _.Sf(c, 18),
            f = _.Sf(c, 7);
        if (f || e) d += "&isContextualWinner=1";
        f && (d += "&hasXfpAds=1");
        e = c.getEscapedQemQueryId();
        f = _.Rf(c, 6);
        e && (d += "&winner_qid=" + encodeURIComponent(e));
        f && (d += "&xfpQid=" + encodeURIComponent(f));
        _.Sf(c, 4) && (d += "&is_plog=1");
        (e = _.Rf(c, 11)) && (d += "&ecrs=" + e);
        (null == c ? 0 : _.Sf(c, 21)) || (d += "&turtlexTest=1");
        d += "&applied_timeout_ms=" + (b + "&duration_ms=" + Math.round(a));
        Wo(d)
    };
    Yo = function() {
        return new _.v.Promise(function(a) {
            setTimeout(function() {
                a(null)
            }, 0)
        })
    };
    $o = function(a) {
        Zo = a
    };
    ap = function(a, b, c, d) {
        N(a, Gl("googletag.setConfig.commerce", Hl(b), c, Hl(d)))
    };
    bp = function(a) {
        return "string" === typeof a && 0 < a.length && 5E3 > a.length
    };
    cp = function(a) {
        if (!Array.isArray(a) || 0 === a.length) return !1;
        var b = a.length - 1;
        return a.every(function(c) {
            if ("string" !== typeof c || 0 === c.length) return !1;
            b += c.length;
            return 5E3 < b ? !1 : !0
        })
    };
    fp = function(a, b, c) {
        if ("object" === typeof a && null !== a && _.u(Object, "keys").call(Object, (0, B.K)(a)).some(function(d) {
                return (_.C = _.u(Object, "values").call(Object, dp), _.u(_.C, "includes")).call(_.C, Number(d))
            })) return !0;
        ep("taxonomies", a, b, c);
        return !1
    };
    hp = function(a, b) {
        var c = Pe(b, gp, 1).filter(function(d) {
            return _.Re(d, 1, 0) !== a
        });
        _.yd(b, 1, c)
    };
    op = function(a, b, c, d) {
        if (void 0 !== _.u(b, "values"))
            if (null === _.u(b, "values")) hp(a, c);
            else if (ip(_.u(b, "values"), d, b) && (b = jp(a, _.u(b, "values"), d, b), b.length)) {
            var e = (_.C = Pe(c, gp, 1), _.u(_.C, "find")).call(_.C, function(f) {
                return _.Re(f, 1, 0) === a
            });
            e ? kp(e, b) : lp(c, kp(mp(new gp, a), b));
            d.info(np(Hl(b), Hl(a)))
        }
    };
    ip = function(a, b, c) {
        if (Array.isArray(a)) return !0;
        ep("taxonomyData.values", a, b, c);
        return !1
    };
    jp = function(a, b, c, d) {
        var e = [],
            f = [],
            g = !1;
        b = _.x(b);
        for (var h = b.next(); !h.done; h = b.next()) h = h.value, 5 <= e.length && (g = !0), "string" !== typeof h ? f.push(h) : g || h in e || e.push(h);
        0 < f.length && ep("taxonomyData.values", f, c, d);
        g && N(c, pp(Hl(a), Hl(5)));
        return e
    };
    ep = function(a, b, c, d) {
        N(c, Gl("googletag.setConfig.pps", Hl(d), a, Hl(b)))
    };
    sp = function() {
        for (var a = _.x(_.u(Array, "from").call(Array, document.getElementsByTagName("script"))), b = a.next(); !b.done; b = a.next()) {
            var c = b = b.value,
                d = b.src;
            d && (Ma(d, "/tag/js/gpt.js") || Ma(d, "/tag/js/gpt_mobile.js")) && !c.googletag_executed && b.textContent && (c.googletag_executed = !0, c = document.createElement("script"), jb(c, new _.qp(b.textContent, rp)), document.head.appendChild(c), document.head.removeChild(c))
        }
    };
    tp = function(a, b) {
        b = _.x(_.u(Object, "entries").call(Object, b));
        for (var c = b.next(); !c.done; c = b.next()) {
            var d = _.x(c.value);
            c = d.next().value;
            d = d.next().value;
            a.hasOwnProperty(c) || (a[c] = d)
        }
    };
    wp = function(a, b, c) {
        var d = [];
        c = [].concat(_.ue(c.Z)).slice();
        if (b) {
            if (!Array.isArray(b)) return N(a, Nk("googletag.destroySlots", [b])), !1;
            qa(b);
            d = c.filter(function(e) {
                return _.u(b, "includes").call(b, e.pa)
            })
        } else d = c;
        if (!d.length) return !1;
        up(d);
        vp(d);
        return !0
    };
    Mp = function(a, b, c, d, e, f, g, h, k, l) {
        var n = Tk(),
            m, p, r = J(a, 74, function(w, D, G) {
                return e.defineSlot(a, b, w, D, G)
            }),
            t = {};
        r = (t._loaded_ = !0, t.cmd = [], t._vars_ = n._vars_, t.evalScripts = function() {
            try {
                sp()
            } catch (G) {
                di(a, 297, G);
                var w, D;
                null == (w = window.console) || null == (D = w.error) || D.call(w, G)
            }
        }, t.display = J(a, 95, function(w) {
            void xp(c, w, e)
        }), t.defineOutOfPageSlot = J(a, 73, function(w, D) {
            return (w = fo(a, b, e, {
                ge: D,
                adUnitPath: w
            })) ? w.pa : null
        }), t.getVersion = J(a, 946, function() {
            return a.Hb ? String(a.Hb) : a.Ta
        }), t.pubads = J(a, 947, function() {
            return gm(a, b, c, e, h)
        }), t.companionAds = J(a, 816, function() {
            null != m || (m = new yp(b, c, f, h));
            return Qk(a, b, m)
        }), t.content = J(a, 817, function() {
            null != p || (p = new zp(b, g));
            return Sk(a, b, p)
        }), t.setAdIframeTitle = J(a, 729, $o), t.getEventLog = J(a, 945, function() {
            return new Ap(a, b)
        }), t.sizeMapping = J(a, 90, function() {
            return new Bp(a, b)
        }), t.enableServices = J(a, 91, function() {
            for (var w = _.x(Cp), D = w.next(); !D.done; D = w.next()) D = D.value, D.B && b.info(Dp()), Ep(D)
        }), t.destroySlots = J(a, 75, function(w) {
            return wp(b, w, e)
        }), t.enums = wl(), t.defineSlot = r, t.defineUnit = r, t.getWindowsThatCanCommunicateWithHostpageLibrary = J(a, 955, function(w) {
            return Fp(k, w).map(function(D) {
                var G;
                return null == (G = qj(D, document)) ? void 0 : G.contentWindow
            }).filter(function(D) {
                return !!D
            })
        }), t.disablePublisherConsole = J(a, 93, el), t.onPubConsoleJsLoad = J(a, 731, hl), t.openConsole = J(a, 732, function(w) {
            $k = !0;
            var D;
            (null == (D = Tk()) ? 0 : D.console) ? (0, B.K)(Tk().console).openConsole(w): (w && (gl = w), fl = !0, Wk(a))
        }), t.setConfig = J(a, 1034, function(w) {
            if (_.na(w)) {
                var D = w.commerce,
                    G = w.pps;
                if (null === D) yf(Gp(d, Hp, 33), 1);
                else if (void 0 !== D)
                    if (w = Gp(d, Hp, 33), _.na(D)) {
                        var F = D.query,
                            O = D.categories,
                            I = D.productIds,
                            Q = D.filter,
                            S = _.Bd(Ip(w, Jp, 1), !1);
                        null === F ? yf(S, 1) : bp(F) ? _.z(S, 1, F) : void 0 !== F && ap(b, D, "query", F);
                        null === O ? _.z(S, 2, Vc) : cp(O) ? _.ed(S, 2, O, _.Hc) : void 0 !== O && ap(b, D, "categories", O);
                        null === I ? _.z(S, 3, Vc) : cp(I) ? _.ed(S, 3, I, _.Hc) : void 0 !== I && ap(b, D, "productIds", I);
                        null === Q ? yf(S, 4) : bp(Q) ? _.z(S, 4, Q) : void 0 !== Q && ap(b, D, "filter", Q);
                        _.bg(S, 1) || _.bn(S, 2).length ? _.Uh(w, 1, S) : N(b, Kp())
                    } else N(b, Nk("googletag.setConfig.commerce", [D]));
                if (null === G) yf(Gp(d, Hp, 33), 2);
                else if (void 0 !== G && (D = Gp(Gp(d, Hp, 33), Lp, 2), "object" === typeof G && (0, B.K)(G).hasOwnProperty("taxonomies") ? w = !0 : (N(b, Nk("googletag.setConfig.pps", [G])), w = !1), w))
                    if (w = G.taxonomies, void 0 === w) ep("taxonomies", w, b, G);
                    else if (null === w) _.yd(D, 1);
                else if (fp(w, b, G))
                    for (G = _.x(_.u(Object, "entries").call(Object, w)), F = G.next(); !F.done; F = G.next()) {
                        F = _.x(F.value);
                        var W = F.next().value;
                        F = F.next().value;
                        O = D;
                        I = b;
                        S = w;
                        if (void 0 === W || null === W) ep("taxonomy", W, I, S);
                        else {
                            Q = Number(W);
                            var ja = Q,
                                ca = I,
                                ya = S;
                            (_.C = _.u(Object, "values").call(Object, vl), _.u(_.C, "includes")).call(_.C, Number(ja)) ? W = !0 : (ep("taxonomy", W, ca, ya), W = !1);
                            W && void 0 !== F && (null === F ? hp(Q, O) : (W = I, "object" === typeof F && (0, B.K)(F).hasOwnProperty("values") ? S = !0 : (ep("taxonomyData", F, W, S), S = !1), S && op(Q, F, O, I)))
                        }
                    }
            } else N(b, Nk("googletag.setConfig", [w]))
        }), t.apiReady = !0, t);
        Og(n, l, function(w, D) {
            di(a, w, D);
            var G, F;
            null == (F = (G = window.console).error) || F.call(G, D)
        });
        tp(n, r)
    };
    Zp = function(a) {
        var b = window,
            c = new hg;
        if (_.E(Np)) {
            var d = new Op(a);
            H(c, d);
            d = d.C
        }
        if (_.E(Pp)) {
            var e = new Qp(a, b);
            H(c, e);
            e = e.C
        }
        var f = new Rp(a, b);
        H(c, f);
        var g = new Sp(a, b);
        H(c, g);
        _.E(Tp) && H(c, new Up(a, b));
        if (_.E(Vp)) {
            var h = new Wp(a, b);
            H(c, h);
            h = h.C
        }
        if (_.E(Xp)) {
            a = new Yp(a);
            H(c, a);
            var k = a.C
        }
        sg(c);
        return {
            fg: f.C,
            lh: g.l,
            Bi: k,
            Rh: d,
            Wh: h,
            Jg: e
        }
    };
    $p = function(a) {
        var b = function() {
            return a.Reflect.construct(a.HTMLElement, [], this.constructor)
        };
        b.prototype = a.HTMLElement.prototype;
        b.prototype.constructor = b;
        _.u(Object, "setPrototypeOf").call(Object, b, a.HTMLElement);
        return b
    };
    bq = function(a, b) {
        var c = _.If(aq);
        Math.random() <= c && Xe(b, a)
    };
    hq = function(a, b, c) {
        var d = {};
        if (!c) return b.error(cq("missing data-rendering attribute")), d;
        try {
            var e = dq(eq(c))
        } catch (k) {}
        var f;
        (null == (f = e) ? 0 : to(f, fq, 1)) ? (b = new gq, b = _.fd(b, 4, 1, 0), b = _.fd(b, 2, 7, 0), a = _.jd(b, 3, a.jb || a.Ta), b = Df(e, fq, 1), a = _.Uh(a, 5, b), a = _.hd(a, 6, !0), d.ni = a) : b.error(cq("invalid data-rendering attribute"));
        var g;
        d.di = null == (g = e) ? void 0 : _.Rf(g, 2);
        var h;
        d.Wd = null == (h = e) ? void 0 : _.Rf(h, 3);
        return d
    };
    kq = function(a, b) {
        var c = dl(b, "ai");
        if (!c || 0 === c.length) return _.v.Promise.resolve(b);
        var d = iq();
        if (null == d ? 0 : d.gmaSdk) {
            if (c = d.gmaSdk.getClickSignalsWithTimeout ? d.gmaSdk.getClickSignalsWithTimeout(c, 200) : d.gmaSdk.getClickSignals(c)) return _.v.Promise.resolve(b.replace("?", "?ms=" + encodeURIComponent(c) + "&"))
        } else {
            var e, f;
            if (null == d ? 0 : null == (e = d.webkit) ? 0 : null == (f = e.messageHandlers) ? 0 : f.getGmaClickSignals) {
                e = new _.oh;
                var g = e.resolve;
                e = e.promise;
                jq(d.webkit.messageHandlers.getGmaClickSignals, {
                    click_string: c
                }, function(h) {
                    g(b.replace("?", "?" + h + "&"))
                }, function() {
                    g(b)
                }, function(h, k) {
                    return $h(a, h, k)
                });
                return e
            }
        }
        return _.v.Promise.resolve(b)
    };
    lq = function(a, b, c, d) {
        var e, f, g;
        return _.Ab(function(h) {
            e = b.getBoundingClientRect();
            f = {};
            var k = d.replace;
            var l = (f.nx = Math.floor(c.clientX - e.x), f.ny = Math.floor(c.clientY - e.y), f.dim = Math.floor(e.width) + "x" + Math.floor(e.height), f);
            var n = [];
            for (m in l) Bl(m, l[m], n);
            l = n.join("&");
            if (l) {
                n = -1;
                0 > n && (n = 0);
                var m = -1;
                if (0 > m || m > n) {
                    m = n;
                    var p = ""
                } else p = "".substring(m + 1, n);
                n = ["".slice(0, m), p, "".slice(n)];
                m = n[1];
                n[1] = l ? m ? m + "&" + l : l : m;
                l = n[0] + (n[1] ? "?" + n[1] : "") + n[2]
            } else l = "";
            g = k.call(d, "?", l + "&");
            return h.return(kq(a, g))
        })
    };
    mq = function(a, b, c) {
        var d;
        if (null == c ? 0 : null == (d = c.gmaSdk) ? 0 : d.getViewSignals) {
            if (c = c.gmaSdk.getViewSignals()) return c = b.replace(/^(.*?)(&adurl=)?$/, "$1&ms=" + c + "$2"), _.v.Promise.resolve(c)
        } else {
            var e, f;
            if (null == c ? 0 : null == (e = c.webkit) ? 0 : null == (f = e.messageHandlers) ? 0 : f.getGmaViewSignals) {
                d = new _.oh;
                var g = d.resolve;
                d = d.promise;
                jq(c.webkit.messageHandlers.getGmaViewSignals, {}, function(h) {
                    g(b.replace(/^(.*?)(&adurl=)?$/, "$1&" + h + "$2"))
                }, function() {
                    g(b)
                }, function(h, k) {
                    return $h(a, h, k)
                });
                return d
            }
        }
        return _.v.Promise.resolve(b)
    };
    rq = function(a, b) {
        var c = window;
        var d = void 0 === d ? Mb : d;
        var e;
        if (c.customElements && null != (e = c.Reflect) && e.construct && !c.customElements.get("google-product-ad")) {
            var f = iq(),
                g;
            null == (g = f ? new nq(function(k, l) {
                return $h(a, k, l)
            }, function() {}) : void 0) || oq(g);
            var h = $p(c);
            e = function() {
                return h.apply(this, arguments) || this
            };
            _.P(e, h);
            e.prototype.connectedCallback = function() {
                var k = hq(a, b, this.dataset.rendering),
                    l = k.ni,
                    n = k.di;
                k = k.Wd;
                l && d(pq(window, l));
                n && mq(a, n, f).then(function(m) {
                    return void Wo(m)
                });
                k && ("true" === this.getAttribute("data-enable-click") || this.querySelector('[data-enable-click="true"]') ? (this.Wd = k, this.addEventListener("click", this.j)) : N(b, qq(k)))
            };
            e.prototype.j = function(k) {
                var l = k.target instanceof c.HTMLElement ? k.target.closest("[data-enable-click]") : void 0;
                l instanceof c.HTMLElement && "true" === l.getAttribute("data-enable-click") && lq(a, this, k, this.Wd).then(function(n) {
                    return void Wo(n)
                })
            };
            c.customElements.define("google-product-ad", e)
        }
    };
    sq = function(a) {
        .001 > _.Ue() && Xe({
            c: "sd",
            s: String(a)
        }, "gpt_whirs")
    };
    xq = function(a, b, c, d) {
        d = d.xi;
        var e = b.kind;
        switch (e) {
            case 0:
                return new(d ? tq : uq)(a, b, c);
            case 1:
                return new vq(a, b, c);
            case 2:
                return new wq(a, b, c);
            default:
                gb(e)
        }
    };
    yq = function(a) {
        if (!_.ne(a)) return -1;
        a = a.pageYOffset;
        return 0 > a ? -1 : a
    };
    Bq = function(a, b, c) {
        return new Ko(a, b, Lo, function(d) {
            d = d.detail;
            var e;
            return "asmreq" === (null == (e = d.data) ? void 0 : e.type) && zq(Aq(d.data.payload), 1) === Number(c) ? d : null
        })
    };
    Gq = function(a, b, c, d) {
        var e = hj(a, document);
        e && vh(e, window, d, !0);
        Cq(_.nf(bi), "5", (0, B.K)(pi(c.V[a.getDomId()], 20)));
        a.dispatchEvent(Dq, 801, {
            ef: null,
            isBackfill: !1
        });
        if (_.Eq(b, a) && !qj(a, document)) {
            b = c.U;
            c = c.V[a.getDomId()];
            var f;
            (null != (f = Qi(c, 10)) ? f : K(b, 11)) && un(a, document, c, b)
        }
        a.dispatchEvent(Fq, 825, {
            isEmpty: !0
        })
    };
    Hq = function(a, b) {
        var c = _.ze("DIV");
        c.id = a;
        c.textContent = b;
        _.tj(c, {
            height: "24px",
            "line-height": "24px",
            "text-align": "center",
            "vertical-align": "middle",
            color: "white",
            "background-color": "black",
            margin: "0",
            "font-family": "Roboto",
            "font-style": "normal",
            "font-weight": "500",
            "font-size": "11px",
            "letter-spacing": "0.08em"
        });
        return c
    };
    Iq = function(a) {
        var b = {
            threshold: [0, .3, .5, .75, 1]
        };
        return window.IntersectionObserver && new IntersectionObserver(a, b)
    };
    zr = function(a, b, c, d, e, f, g, h, k, l, n, m, p, r, t, w, D, G, F, O) {
        var I = new hg,
            Q = Ki(!0, window),
            S = k.U,
            W = k.V[e.getDomId()],
            ja = new Jq(a, window);
        H(I, ja);
        var ca = n.oh,
            ya = n.Hi,
            ua = n.Zg,
            za = n.lf,
            ka = n.vg,
            Oa = n.uh,
            $a = n.yi,
            Jb = n.hh,
            Gb = n.Wg,
            $b = n.dd,
            Da = n.zi,
            ob = n.th,
            mc = n.Ch,
            Hb = n.vi,
            Kb = n.Ei,
            nc = n.Fi,
            oc = n.qh,
            zd = n.Rg,
            Rb = n.Qa,
            ie = n.gg,
            Gc = n.Ii,
            je = n.Kc;
        n = n.Cg;
        .01 > Math.random() && (F = new Kq(a, Gc, null == F ? void 0 : F.Ye.tb, $a, za), H(I, F));
        Gc = new Lq;
        Gc.J(r);
        F = new Mq(a, window.top, Gc);
        H(I, F);
        m = new Nq(a, console, m, void 0, F.C);
        H(I, m);
        m = new Oq(a, Mm(W), Q.height, Gb, ca);
        H(I, m);
        ca = new Pq(a, e, hj(e, p), e.getDomId(), pj(e), p, Mm(W), h, f);
        H(I, ca);
        Rb = new Qq(a, Rb, ka, Oa, $a);
        H(I, Rb);
        $a = new Rq(a, S, W, ka, $a);
        H(I, $a);
        Kb = new Sq(a, Df(S, Tq, 5), Kb);
        H(I, Kb);
        ya = new Uq(a, e.getAdUnitPath(), W, Q.width, f, $b, ya, m.C, Rb.C, ca.C);
        H(I, ya);
        $b = new Vq(a, W, ie);
        H(I, $b);
        f = new Wq(a, h, r, f, ie, $b.C, ya.Qa, ya.G, ca.C, t);
        H(I, f);
        if (g || _.E(Xq)) {
            var pb = new Yq(a, e, k, h, za, f.D);
            H(I, pb);
            G = new Zq(a, G, f.D);
            H(I, G);
            pb = new $q(a, pb.l, G.C);
            H(I, pb);
            pb = pb.C
        }
        G = new ar(a, e, S, W, Mm(W), p, h, ca.C, $a.C, f.A, ua, pb);
        H(I, G);
        g = new br(a, G.C);
        H(I, g);
        r = new cr(a, e, Q, h, g.C, Kb.l, pb);
        H(I, r);
        g = new dr(a, window, ca.C);
        H(I, g);
        nc = new er(a, r.C, G.C, nc, Kb.l, void 0, pb);
        H(I, nc);
        Q = new fr(a, p, e, W, Q, ua, ca.C, G.C, f.A, ya.dd, g.C, za, pb);
        H(I, Q);
        Da = new gr(a, S, W, f.Qa, $a.C, Da);
        H(I, Da);
        zd = new hr(a, window, zd, ja.C, pb);
        H(I, zd);
        g = new ir(a, Mm(W), p);
        H(I, g);
        _.E(Pp) ? r = O.Jg : (r = new jr(a, window), H(I, r), r = r.C);
        D = new kr(a, D, Mm(W), Gb, Jb, pb);
        H(I, D);
        mc = new lr(a, mc, pb);
        H(I, mc);
        _.E(bk) && (O = O.fg) && (O = new mr(a, window, O, n), H(I, O));
        l = new nr(a, e, h, k, w, l, window, f.Qa, $a.C, nc.C, ca.C, G.C, f.A, za, ua, Da.C, Oa, ob, Hb, Q.C, zd.C, g.C, D.C, ie, r, pb);
        H(I, l);
        Oa = new or(a, window, e, l.A, Gc);
        H(I, Oa);
        Gb = new pr(a, h, Mm(W), e, window, Gb, l.l, ca.C, D.C);
        H(I, Gb);
        k = new qr(a, e, Mm(W), (0, B.K)(k.lc), Jb, l.l, ca.C, F.C, D.C, za);
        H(I, k);
        4 === Mm(W) && (W = new rr(a, e, w, window, l.l, ca.C), _.Nn(I, W), sg(W));
        p = new sr(a, e, l.l, p, w);
        H(I, p);
        (p = _.E(tr) ? Bq(a, e, ur(h, e)) : void 0) && H(I, p);
        h = new vr(a, ur(h, e), window.top, l.l, ja.C, null == p ? void 0 : p.C);
        H(I, h);
        e = new wr(a, e, ua, ka, Hb, l.l, G.C, l.D);
        H(I, e);
        oc = new xr(a, window, oc, l.l, G.C, ca.C);
        H(I, oc);
        H(I, new yr(a, Tk(), S, b, c, d, [je]));
        return I
    };
    Cr = function() {
        if (Xa()) {
            var a = Za();
            var b = 0;
            a = Ar(String(a)).split(".");
            for (var c = Ar("11").split("."), d = Math.max(a.length, c.length), e = 0; 0 == b && e < d; e++) {
                var f = a[e] || "",
                    g = c[e] || "";
                do {
                    f = /(\d*)(\D*)(.*)/.exec(f) || ["", "", "", ""];
                    g = /(\d*)(\D*)(.*)/.exec(g) || ["", "", "", ""];
                    if (0 == f[0].length && 0 == g[0].length) break;
                    b = Br(0 == f[1].length ? 0 : parseInt(f[1], 10), 0 == g[1].length ? 0 : parseInt(g[1], 10)) || Br(0 == f[2].length, 0 == g[2].length) || Br(f[2], g[2]);
                    f = f[3];
                    g = g[3]
                } while (0 == b)
            }
            b = 0 <= b
        } else b = 65 <= bb();
        return b
    };
    Dr = function(a) {
        function b(f) {
            var g = f;
            return function() {
                var h = _.wb.apply(0, arguments);
                if (g) {
                    var k = g;
                    g = null;
                    k.apply(null, _.ue(h))
                }
            }
        }
        var c = null,
            d = 0,
            e = 0;
        return function() {
            var f, g, h, k;
            return _.Ab(function(l) {
                if (1 == l.j) return d && clearTimeout(d), d = 0, f = new _.oh, g = b(f.resolve), h = ++e, Bb(l, 0, 2);
                if (e !== h) return g(!1), l.return(f.promise);
                c ? c(!1) : g(!0);
                k = b(function() {
                    c = null;
                    d = 0;
                    g(!0)
                });
                d = setTimeout(k, 1E3);
                _.go(a, function() {
                    return void g(!1)
                });
                c = g;
                return l.return(f.promise)
            })
        }
    };
    Lr = function() {
        var a = new Er;
        var b = (new Fr).setCorrelator(sf(_.q));
        var c = _.nf( of ).j().join();
        b = _.jd(b, 5, c);
        b = _.fd(b, 2, 1, 0);
        a = _.Uh(a, 1, b);
        b = new Gr;
        c = _.E(Hr);
        b = _.hd(b, 7, c);
        c = _.E(Ir);
        b = _.hd(b, 8, c);
        c = _.E(Jr);
        b = _.hd(b, 9, c);
        b = _.hd(b, 10, !0);
        c = _.E(Kr);
        b = _.hd(b, 13, c);
        b = _.hd(b, 16, !0);
        a = _.Uh(a, 2, b);
        window.google_rum_config = a.toJSON()
    };
    Nr = function() {
        var a = Mr,
            b = Number(a);
        return 1 > b || Math.floor(b) !== b ? (Xe({
            v: a
        }, "gpt_inv_ver"), "1") : a
    };
    Pr = function(a) {
        var b = Or() || (0, _.Te)() ? 1 : _.Ue(),
            c = .001 > b;
        c ? (a.l = !0, pf(31067358)) : .002 > b && pf(31067357);
        qf(23);
        return {
            Pc: c,
            Eh: 1E3,
            li: 1E-4 > b,
            Dh: 1E4,
            bg: c,
            jf: 1E3
        }
    };
    Sr = function(a) {
        var b = Nr();
        if (/m\d+/.test("m202304030101")) var c = Number("202304030101");
        else Xe({
            mjsv: "m202304030101"
        }, "gpt_inv_ver"), c = void 0;
        var d = sf(window),
            e = window.document.URL,
            f = _.If(Qr);
        return _.u(Object, "assign").call(Object, {}, a, {
            Ta: b,
            jb: "m202304030101",
            Hb: c,
            pvsid: d,
            Lb: new _.Rr(f),
            Ng: e
        })
    };
    _.ba = [];
    Tr = function(a) {
        var b = 0;
        return function() {
            return b < a.length ? {
                done: !1,
                value: a[b++]
            } : {
                done: !0
            }
        }
    };
    Ur = "function" == typeof Object.defineProperties ? Object.defineProperty : function(a, b, c) {
        if (a == Array.prototype || a == Object.prototype) return a;
        a[b] = c.value;
        return a
    };
    Vr = function(a) {
        a = ["object" == typeof globalThis && globalThis, a, "object" == typeof window && window, "object" == typeof self && self, "object" == typeof global && global];
        for (var b = 0; b < a.length; ++b) {
            var c = a[b];
            if (c && c.Math == Math) return c
        }
        throw Error("Cannot find global object");
    };
    _.Wr = Vr(this);
    Xr = "function" === typeof Symbol && "symbol" === typeof Symbol("x");
    _.v = {};
    Yr = {};
    _.u = function(a, b, c) {
        if (!c || null != a) {
            c = Yr[b];
            if (null == c) return a[b];
            c = a[c];
            return void 0 !== c ? c : a[b]
        }
    };
    Zr = function(a, b, c) {
        if (b) a: {
            var d = a.split(".");a = 1 === d.length;
            var e = d[0],
                f;!a && e in _.v ? f = _.v : f = _.Wr;
            for (e = 0; e < d.length - 1; e++) {
                var g = d[e];
                if (!(g in f)) break a;
                f = f[g]
            }
            d = d[d.length - 1];c = Xr && "es6" === c ? f[d] : null;b = b(c);null != b && (a ? Ur(_.v, d, {
                configurable: !0,
                writable: !0,
                value: b
            }) : b !== c && (void 0 === Yr[d] && (a = 1E9 * Math.random() >>> 0, Yr[d] = Xr ? _.Wr.Symbol(d) : "$jscp$" + a + "$" + d), Ur(f, Yr[d], {
                configurable: !0,
                writable: !0,
                value: b
            })))
        }
    };
    Zr("Symbol", function(a) {
        if (a) return a;
        var b = function(f, g) {
            this.j = f;
            Ur(this, "description", {
                configurable: !0,
                writable: !0,
                value: g
            })
        };
        b.prototype.toString = function() {
            return this.j
        };
        var c = "jscomp_symbol_" + (1E9 * Math.random() >>> 0) + "_",
            d = 0,
            e = function(f) {
                if (this instanceof e) throw new TypeError("Symbol is not a constructor");
                return new b(c + (f || "") + "_" + d++, f)
            };
        return e
    }, "es6");
    Zr("Symbol.iterator", function(a) {
        if (a) return a;
        a = (0, _.v.Symbol)("Symbol.iterator");
        for (var b = "Array Int8Array Uint8Array Uint8ClampedArray Int16Array Uint16Array Int32Array Uint32Array Float32Array Float64Array".split(" "), c = 0; c < b.length; c++) {
            var d = _.Wr[b[c]];
            "function" === typeof d && "function" != typeof d.prototype[a] && Ur(d.prototype, a, {
                configurable: !0,
                writable: !0,
                value: function() {
                    return $r(Tr(this))
                }
            })
        }
        return a
    }, "es6");
    $r = function(a) {
        a = {
            next: a
        };
        a[_.u(_.v.Symbol, "iterator")] = function() {
            return this
        };
        return a
    };
    _.R = function(a) {
        return a.raw = a
    };
    as = function(a, b) {
        a.raw = b;
        return a
    };
    _.x = function(a) {
        var b = "undefined" != typeof _.v.Symbol && _.u(_.v.Symbol, "iterator") && a[_.u(_.v.Symbol, "iterator")];
        if (b) return b.call(a);
        if ("number" == typeof a.length) return {
            next: Tr(a)
        };
        throw Error(String(a) + " is not an iterable or ArrayLike");
    };
    _.ue = function(a) {
        if (!(a instanceof Array)) {
            a = _.x(a);
            for (var b, c = []; !(b = a.next()).done;) c.push(b.value);
            a = c
        }
        return a
    };
    bs = function(a, b) {
        return Object.prototype.hasOwnProperty.call(a, b)
    };
    cs = Xr && "function" == typeof _.u(Object, "assign") ? _.u(Object, "assign") : function(a, b) {
        for (var c = 1; c < arguments.length; c++) {
            var d = arguments[c];
            if (d)
                for (var e in d) bs(d, e) && (a[e] = d[e])
        }
        return a
    };
    Zr("Object.assign", function(a) {
        return a || cs
    }, "es6");
    var ds = "function" == typeof Object.create ? Object.create : function(a) {
            var b = function() {};
            b.prototype = a;
            return new b
        },
        es = function() {
            function a() {
                function c() {}
                new c;
                _.u(_.v.Reflect, "construct").call(_.v.Reflect, c, [], function() {});
                return new c instanceof c
            }
            if (Xr && "undefined" != typeof _.v.Reflect && _.u(_.v.Reflect, "construct")) {
                if (a()) return _.u(_.v.Reflect, "construct");
                var b = _.u(_.v.Reflect, "construct");
                return function(c, d, e) {
                    c = b(c, d);
                    e && _.u(_.v.Reflect, "setPrototypeOf").call(_.v.Reflect, c, e.prototype);
                    return c
                }
            }
            return function(c, d, e) {
                void 0 === e && (e = c);
                e = ds(e.prototype || Object.prototype);
                return Function.prototype.apply.call(c, e, d) || e
            }
        }(),
        fs;
    if (Xr && "function" == typeof _.u(Object, "setPrototypeOf")) fs = _.u(Object, "setPrototypeOf");
    else {
        var gs;
        a: {
            var hs = {
                    a: !0
                },
                is = {};
            try {
                is.__proto__ = hs;
                gs = is.a;
                break a
            } catch (a) {}
            gs = !1
        }
        fs = gs ? function(a, b) {
            a.__proto__ = b;
            if (a.__proto__ !== b) throw new TypeError(a + " is not extensible");
            return a
        } : null
    }
    js = fs;
    _.P = function(a, b) {
        a.prototype = ds(b.prototype);
        a.prototype.constructor = a;
        if (js) js(a, b);
        else
            for (var c in b)
                if ("prototype" != c)
                    if (Object.defineProperties) {
                        var d = Object.getOwnPropertyDescriptor(b, c);
                        d && Object.defineProperty(a, c, d)
                    } else a[c] = b[c];
        a.oi = b.prototype
    };
    ks = function() {
        this.l = !1;
        this.H = null;
        this.o = void 0;
        this.j = 1;
        this.A = this.m = 0;
        this.B = null
    };
    ls = function(a) {
        if (a.l) throw new TypeError("Generator is already running");
        a.l = !0
    };
    ks.prototype.I = function(a) {
        this.o = a
    };
    var ms = function(a, b) {
        a.B = {
            mf: b,
            wh: !0
        };
        a.j = a.m || a.A
    };
    ks.prototype.return = function(a) {
        this.B = {
            return: a
        };
        this.j = this.A
    };
    Bb = function(a, b, c) {
        a.j = c;
        return {
            value: b
        }
    };
    Db = function(a, b) {
        a.j = b;
        a.m = 0
    };
    Eb = function(a) {
        a.m = 0;
        var b = a.B.mf;
        a.B = null;
        return b
    };
    ns = function(a) {
        this.j = new ks;
        this.o = a
    };
    qs = function(a, b) {
        ls(a.j);
        var c = a.j.H;
        if (c) return os(a, "return" in c ? c["return"] : function(d) {
            return {
                value: d,
                done: !0
            }
        }, b, a.j.return);
        a.j.return(b);
        return ps(a)
    };
    os = function(a, b, c, d) {
        try {
            var e = b.call(a.j.H, c);
            if (!(e instanceof Object)) throw new TypeError("Iterator result " + e + " is not an object");
            if (!e.done) return a.j.l = !1, e;
            var f = e.value
        } catch (g) {
            return a.j.H = null, ms(a.j, g), ps(a)
        }
        a.j.H = null;
        d.call(a.j, f);
        return ps(a)
    };
    ps = function(a) {
        for (; a.j.j;) try {
            var b = a.o(a.j);
            if (b) return a.j.l = !1, {
                value: b.value,
                done: !1
            }
        } catch (c) {
            a.j.o = void 0, ms(a.j, c)
        }
        a.j.l = !1;
        if (a.j.B) {
            b = a.j.B;
            a.j.B = null;
            if (b.wh) throw b.mf;
            return {
                value: b.return,
                done: !0
            }
        }
        return {
            value: void 0,
            done: !0
        }
    };
    rs = function(a) {
        this.next = function(b) {
            ls(a.j);
            a.j.H ? b = os(a, a.j.H.next, b, a.j.I) : (a.j.I(b), b = ps(a));
            return b
        };
        this.throw = function(b) {
            ls(a.j);
            a.j.H ? b = os(a, a.j.H["throw"], b, a.j.I) : (ms(a.j, b), b = ps(a));
            return b
        };
        this.return = function(b) {
            return qs(a, b)
        };
        this[_.u(_.v.Symbol, "iterator")] = function() {
            return this
        }
    };
    ss = function(a) {
        function b(d) {
            return a.next(d)
        }

        function c(d) {
            return a.throw(d)
        }
        return new _.v.Promise(function(d, e) {
            function f(g) {
                g.done ? d(g.value) : _.v.Promise.resolve(g.value).then(b, c).then(f, e)
            }
            f(a.next())
        })
    };
    _.Ab = function(a) {
        return ss(new rs(new ns(a)))
    };
    _.wb = function() {
        for (var a = Number(this), b = [], c = a; c < arguments.length; c++) b[c - a] = arguments[c];
        return b
    };
    Zr("Reflect", function(a) {
        return a ? a : {}
    }, "es6");
    Zr("Reflect.construct", function() {
        return es
    }, "es6");
    Zr("Reflect.setPrototypeOf", function(a) {
        return a ? a : js ? function(b, c) {
            try {
                return js(b, c), !0
            } catch (d) {
                return !1
            }
        } : null
    }, "es6");
    Zr("Promise", function(a) {
        function b() {
            this.j = null
        }

        function c(g) {
            return g instanceof e ? g : new e(function(h) {
                h(g)
            })
        }
        if (a) return a;
        b.prototype.o = function(g) {
            if (null == this.j) {
                this.j = [];
                var h = this;
                this.m(function() {
                    h.B()
                })
            }
            this.j.push(g)
        };
        var d = _.Wr.setTimeout;
        b.prototype.m = function(g) {
            d(g, 0)
        };
        b.prototype.B = function() {
            for (; this.j && this.j.length;) {
                var g = this.j;
                this.j = [];
                for (var h = 0; h < g.length; ++h) {
                    var k = g[h];
                    g[h] = null;
                    try {
                        k()
                    } catch (l) {
                        this.H(l)
                    }
                }
            }
            this.j = null
        };
        b.prototype.H = function(g) {
            this.m(function() {
                throw g;
            })
        };
        var e = function(g) {
            this.o = 0;
            this.m = void 0;
            this.j = [];
            this.I = !1;
            var h = this.H();
            try {
                g(h.resolve, h.reject)
            } catch (k) {
                h.reject(k)
            }
        };
        e.prototype.H = function() {
            function g(l) {
                return function(n) {
                    k || (k = !0, l.call(h, n))
                }
            }
            var h = this,
                k = !1;
            return {
                resolve: g(this.R),
                reject: g(this.B)
            }
        };
        e.prototype.R = function(g) {
            if (g === this) this.B(new TypeError("A Promise cannot resolve to itself"));
            else if (g instanceof e) this.L(g);
            else {
                a: switch (typeof g) {
                    case "object":
                        var h = null != g;
                        break a;
                    case "function":
                        h = !0;
                        break a;
                    default:
                        h = !1
                }
                h ? this.D(g) : this.l(g)
            }
        };
        e.prototype.D = function(g) {
            var h = void 0;
            try {
                h = g.then
            } catch (k) {
                this.B(k);
                return
            }
            "function" == typeof h ? this.O(h, g) : this.l(g)
        };
        e.prototype.B = function(g) {
            this.A(2, g)
        };
        e.prototype.l = function(g) {
            this.A(1, g)
        };
        e.prototype.A = function(g, h) {
            if (0 != this.o) throw Error("Cannot settle(" + g + ", " + h + "): Promise already settled in state" + this.o);
            this.o = g;
            this.m = h;
            2 === this.o && this.G();
            this.N()
        };
        e.prototype.G = function() {
            var g = this;
            d(function() {
                if (g.ia()) {
                    var h = _.Wr.console;
                    "undefined" !== typeof h && h.error(g.m)
                }
            }, 1)
        };
        e.prototype.ia = function() {
            if (this.I) return !1;
            var g = _.Wr.CustomEvent,
                h = _.Wr.Event,
                k = _.Wr.dispatchEvent;
            if ("undefined" === typeof k) return !0;
            "function" === typeof g ? g = new g("unhandledrejection", {
                cancelable: !0
            }) : "function" === typeof h ? g = new h("unhandledrejection", {
                cancelable: !0
            }) : (g = _.Wr.document.createEvent("CustomEvent"), g.initCustomEvent("unhandledrejection", !1, !0, g));
            g.promise = this;
            g.reason = this.m;
            return k(g)
        };
        e.prototype.N = function() {
            if (null != this.j) {
                for (var g = 0; g < this.j.length; ++g) f.o(this.j[g]);
                this.j = null
            }
        };
        var f = new b;
        e.prototype.L = function(g) {
            var h = this.H();
            g.gd(h.resolve, h.reject)
        };
        e.prototype.O = function(g, h) {
            var k = this.H();
            try {
                g.call(h, k.resolve, k.reject)
            } catch (l) {
                k.reject(l)
            }
        };
        e.prototype.then = function(g, h) {
            function k(p, r) {
                return "function" == typeof p ? function(t) {
                    try {
                        l(p(t))
                    } catch (w) {
                        n(w)
                    }
                } : r
            }
            var l, n, m = new e(function(p, r) {
                l = p;
                n = r
            });
            this.gd(k(g, l), k(h, n));
            return m
        };
        e.prototype.catch = function(g) {
            return this.then(void 0, g)
        };
        e.prototype.gd = function(g, h) {
            function k() {
                switch (l.o) {
                    case 1:
                        g(l.m);
                        break;
                    case 2:
                        h(l.m);
                        break;
                    default:
                        throw Error("Unexpected state: " + l.o);
                }
            }
            var l = this;
            null == this.j ? f.o(k) : this.j.push(k);
            this.I = !0
        };
        e.resolve = c;
        e.reject = function(g) {
            return new e(function(h, k) {
                k(g)
            })
        };
        e.race = function(g) {
            return new e(function(h, k) {
                for (var l = _.x(g), n = l.next(); !n.done; n = l.next()) c(n.value).gd(h, k)
            })
        };
        e.all = function(g) {
            var h = _.x(g),
                k = h.next();
            return k.done ? c([]) : new e(function(l, n) {
                function m(t) {
                    return function(w) {
                        p[t] = w;
                        r--;
                        0 == r && l(p)
                    }
                }
                var p = [],
                    r = 0;
                do p.push(void 0), r++, c(k.value).gd(m(p.length - 1), n), k = h.next(); while (!k.done)
            })
        };
        return e
    }, "es6");
    Zr("Object.setPrototypeOf", function(a) {
        return a || js
    }, "es6");
    Zr("WeakMap", function(a) {
        function b() {}

        function c(g) {
            var h = typeof g;
            return "object" === h && null !== g || "function" === h
        }
        if (function() {
                if (!a || !Object.seal) return !1;
                try {
                    var g = Object.seal({}),
                        h = Object.seal({}),
                        k = new a([
                            [g, 2],
                            [h, 3]
                        ]);
                    if (2 != k.get(g) || 3 != k.get(h)) return !1;
                    k.delete(g);
                    k.set(h, 4);
                    return !k.has(g) && 4 == k.get(h)
                } catch (l) {
                    return !1
                }
            }()) return a;
        var d = "$jscomp_hidden_" + Math.random(),
            e = 0,
            f = function(g) {
                this.j = (e += Math.random() + 1).toString();
                if (g) {
                    g = _.x(g);
                    for (var h; !(h = g.next()).done;) h = h.value, this.set(h[0], h[1])
                }
            };
        f.prototype.set = function(g, h) {
            if (!c(g)) throw Error("Invalid WeakMap key");
            if (!bs(g, d)) {
                var k = new b;
                Ur(g, d, {
                    value: k
                })
            }
            if (!bs(g, d)) throw Error("WeakMap key fail: " + g);
            g[d][this.j] = h;
            return this
        };
        f.prototype.get = function(g) {
            return c(g) && bs(g, d) ? g[d][this.j] : void 0
        };
        f.prototype.has = function(g) {
            return c(g) && bs(g, d) && bs(g[d], this.j)
        };
        f.prototype.delete = function(g) {
            return c(g) && bs(g, d) && bs(g[d], this.j) ? delete g[d][this.j] : !1
        };
        return f
    }, "es6");
    Zr("Map", function(a) {
        if (function() {
                if (!a || "function" != typeof a || !_.u(a.prototype, "entries") || "function" != typeof Object.seal) return !1;
                try {
                    var h = Object.seal({
                            x: 4
                        }),
                        k = new a(_.x([
                            [h, "s"]
                        ]));
                    if ("s" != k.get(h) || 1 != k.size || k.get({
                            x: 4
                        }) || k.set({
                            x: 4
                        }, "t") != k || 2 != k.size) return !1;
                    var l = _.u(k, "entries").call(k),
                        n = l.next();
                    if (n.done || n.value[0] != h || "s" != n.value[1]) return !1;
                    n = l.next();
                    return n.done || 4 != n.value[0].x || "t" != n.value[1] || !l.next().done ? !1 : !0
                } catch (m) {
                    return !1
                }
            }()) return a;
        var b = new _.v.WeakMap,
            c = function(h) {
                this.o = {};
                this.j = f();
                this.size = 0;
                if (h) {
                    h = _.x(h);
                    for (var k; !(k = h.next()).done;) k = k.value, this.set(k[0], k[1])
                }
            };
        c.prototype.set = function(h, k) {
            h = 0 === h ? 0 : h;
            var l = d(this, h);
            l.list || (l.list = this.o[l.id] = []);
            l.Ba ? l.Ba.value = k : (l.Ba = {
                next: this.j,
                kb: this.j.kb,
                head: this.j,
                key: h,
                value: k
            }, l.list.push(l.Ba), this.j.kb.next = l.Ba, this.j.kb = l.Ba, this.size++);
            return this
        };
        c.prototype.delete = function(h) {
            h = d(this, h);
            return h.Ba && h.list ? (h.list.splice(h.index, 1), h.list.length || delete this.o[h.id], h.Ba.kb.next = h.Ba.next, h.Ba.next.kb = h.Ba.kb, h.Ba.head = null, this.size--, !0) : !1
        };
        c.prototype.clear = function() {
            this.o = {};
            this.j = this.j.kb = f();
            this.size = 0
        };
        c.prototype.has = function(h) {
            return !!d(this, h).Ba
        };
        c.prototype.get = function(h) {
            return (h = d(this, h).Ba) && h.value
        };
        c.prototype.entries = function() {
            return e(this, function(h) {
                return [h.key, h.value]
            })
        };
        c.prototype.keys = function() {
            return e(this, function(h) {
                return h.key
            })
        };
        c.prototype.values = function() {
            return e(this, function(h) {
                return h.value
            })
        };
        c.prototype.forEach = function(h, k) {
            for (var l = _.u(this, "entries").call(this), n; !(n = l.next()).done;) n = n.value, h.call(k, n[1], n[0], this)
        };
        c.prototype[_.u(_.v.Symbol, "iterator")] = _.u(c.prototype, "entries");
        var d = function(h, k) {
                var l = k && typeof k;
                "object" == l || "function" == l ? b.has(k) ? l = b.get(k) : (l = "" + ++g, b.set(k, l)) : l = "p_" + k;
                var n = h.o[l];
                if (n && bs(h.o, l))
                    for (h = 0; h < n.length; h++) {
                        var m = n[h];
                        if (k !== k && m.key !== m.key || k === m.key) return {
                            id: l,
                            list: n,
                            index: h,
                            Ba: m
                        }
                    }
                return {
                    id: l,
                    list: n,
                    index: -1,
                    Ba: void 0
                }
            },
            e = function(h, k) {
                var l = h.j;
                return $r(function() {
                    if (l) {
                        for (; l.head != h.j;) l = l.kb;
                        for (; l.next != l.head;) return l = l.next, {
                            done: !1,
                            value: k(l)
                        };
                        l = null
                    }
                    return {
                        done: !0,
                        value: void 0
                    }
                })
            },
            f = function() {
                var h = {};
                return h.kb = h.next = h.head = h
            },
            g = 0;
        return c
    }, "es6");
    var ts = function(a, b) {
        a instanceof String && (a += "");
        var c = 0,
            d = !1,
            e = {
                next: function() {
                    if (!d && c < a.length) {
                        var f = c++;
                        return {
                            value: b(f, a[f]),
                            done: !1
                        }
                    }
                    d = !0;
                    return {
                        done: !0,
                        value: void 0
                    }
                }
            };
        e[_.u(_.v.Symbol, "iterator")] = function() {
            return e
        };
        return e
    };
    Zr("Array.prototype.entries", function(a) {
        return a ? a : function() {
            return ts(this, function(b, c) {
                return [b, c]
            })
        }
    }, "es6");
    Zr("Array.prototype.keys", function(a) {
        return a ? a : function() {
            return ts(this, function(b) {
                return b
            })
        }
    }, "es6");
    var us = function(a, b, c) {
        if (null == a) throw new TypeError("The 'this' value for String.prototype." + c + " must not be null or undefined");
        if (b instanceof RegExp) throw new TypeError("First argument to String.prototype." + c + " must not be a regular expression");
        return a + ""
    };
    Zr("String.prototype.endsWith", function(a) {
        return a ? a : function(b, c) {
            var d = us(this, b, "endsWith");
            void 0 === c && (c = d.length);
            c = Math.max(0, Math.min(c | 0, d.length));
            for (var e = b.length; 0 < e && 0 < c;)
                if (d[--c] != b[--e]) return !1;
            return 0 >= e
        }
    }, "es6");
    var vs = function(a, b, c) {
        a instanceof String && (a = String(a));
        for (var d = a.length, e = 0; e < d; e++) {
            var f = a[e];
            if (b.call(c, f, e, a)) return {
                i: e,
                jg: f
            }
        }
        return {
            i: -1,
            jg: void 0
        }
    };
    Zr("Array.prototype.find", function(a) {
        return a ? a : function(b, c) {
            return vs(this, b, c).jg
        }
    }, "es6");
    Zr("Number.MAX_SAFE_INTEGER", function() {
        return 9007199254740991
    }, "es6");
    Zr("Number.isFinite", function(a) {
        return a ? a : function(b) {
            return "number" !== typeof b ? !1 : !isNaN(b) && Infinity !== b && -Infinity !== b
        }
    }, "es6");
    Zr("Array.from", function(a) {
        return a ? a : function(b, c, d) {
            c = null != c ? c : function(h) {
                return h
            };
            var e = [],
                f = "undefined" != typeof _.v.Symbol && _.u(_.v.Symbol, "iterator") && b[_.u(_.v.Symbol, "iterator")];
            if ("function" == typeof f) {
                b = f.call(b);
                for (var g = 0; !(f = b.next()).done;) e.push(c.call(d, f.value, g++))
            } else
                for (f = b.length, g = 0; g < f; g++) e.push(c.call(d, b[g], g));
            return e
        }
    }, "es6");
    Zr("Number.isInteger", function(a) {
        return a ? a : function(b) {
            return _.u(Number, "isFinite").call(Number, b) ? b === Math.floor(b) : !1
        }
    }, "es6");
    Zr("Array.prototype.values", function(a) {
        return a ? a : function() {
            return ts(this, function(b, c) {
                return c
            })
        }
    }, "es8");
    Zr("Set", function(a) {
        if (function() {
                if (!a || "function" != typeof a || !_.u(a.prototype, "entries") || "function" != typeof Object.seal) return !1;
                try {
                    var c = Object.seal({
                            x: 4
                        }),
                        d = new a(_.x([c]));
                    if (!d.has(c) || 1 != d.size || d.add(c) != d || 1 != d.size || d.add({
                            x: 4
                        }) != d || 2 != d.size) return !1;
                    var e = _.u(d, "entries").call(d),
                        f = e.next();
                    if (f.done || f.value[0] != c || f.value[1] != c) return !1;
                    f = e.next();
                    return f.done || f.value[0] == c || 4 != f.value[0].x || f.value[1] != f.value[0] ? !1 : e.next().done
                } catch (g) {
                    return !1
                }
            }()) return a;
        var b = function(c) {
            this.j = new _.v.Map;
            if (c) {
                c = _.x(c);
                for (var d; !(d = c.next()).done;) this.add(d.value)
            }
            this.size = this.j.size
        };
        b.prototype.add = function(c) {
            c = 0 === c ? 0 : c;
            this.j.set(c, c);
            this.size = this.j.size;
            return this
        };
        b.prototype.delete = function(c) {
            c = this.j.delete(c);
            this.size = this.j.size;
            return c
        };
        b.prototype.clear = function() {
            this.j.clear();
            this.size = 0
        };
        b.prototype.has = function(c) {
            return this.j.has(c)
        };
        b.prototype.entries = function() {
            return _.u(this.j, "entries").call(this.j)
        };
        b.prototype.values = function() {
            return _.u(this.j, "values").call(this.j)
        };
        b.prototype.keys = _.u(b.prototype, "values");
        b.prototype[_.u(_.v.Symbol, "iterator")] = _.u(b.prototype, "values");
        b.prototype.forEach = function(c, d) {
            var e = this;
            this.j.forEach(function(f) {
                return c.call(d, f, f, e)
            })
        };
        return b
    }, "es6");
    Zr("Object.entries", function(a) {
        return a ? a : function(b) {
            var c = [],
                d;
            for (d in b) bs(b, d) && c.push([d, b[d]]);
            return c
        }
    }, "es8");
    Zr("String.prototype.startsWith", function(a) {
        return a ? a : function(b, c) {
            var d = us(this, b, "startsWith"),
                e = d.length,
                f = b.length;
            c = Math.max(0, Math.min(c | 0, d.length));
            for (var g = 0; g < f && c < e;)
                if (d[c++] != b[g++]) return !1;
            return g >= f
        }
    }, "es6");
    Zr("globalThis", function(a) {
        return a || _.Wr
    }, "es_2020");
    Zr("Array.prototype.flatMap", function(a) {
        return a ? a : function(b, c) {
            var d = [];
            Array.prototype.forEach.call(this, function(e, f) {
                e = b.call(c, e, f, this);
                Array.isArray(e) ? d.push.apply(d, e) : d.push(e)
            });
            return d
        }
    }, "es9");
    Zr("Object.is", function(a) {
        return a ? a : function(b, c) {
            return b === c ? 0 !== b || 1 / b === 1 / c : b !== b && c !== c
        }
    }, "es6");
    Zr("Array.prototype.includes", function(a) {
        return a ? a : function(b, c) {
            var d = this;
            d instanceof String && (d = String(d));
            var e = d.length;
            c = c || 0;
            for (0 > c && (c = Math.max(c + e, 0)); c < e; c++) {
                var f = d[c];
                if (f === b || _.u(Object, "is").call(Object, f, b)) return !0
            }
            return !1
        }
    }, "es7");
    Zr("String.prototype.includes", function(a) {
        return a ? a : function(b, c) {
            return -1 !== us(this, b, "includes").indexOf(b, c || 0)
        }
    }, "es6");
    Zr("AggregateError", function(a) {
        if (a) return a;
        a = function(b, c) {
            c = Error(c);
            "stack" in c && (this.stack = c.stack);
            this.errors = b;
            this.message = c.message
        };
        _.P(a, Error);
        a.prototype.name = "AggregateError";
        return a
    }, "es_2021");
    Zr("Promise.any", function(a) {
        return a ? a : function(b) {
            b = b instanceof Array ? b : _.u(Array, "from").call(Array, b);
            return _.v.Promise.all(b.map(function(c) {
                return _.v.Promise.resolve(c).then(function(d) {
                    throw d;
                }, function(d) {
                    return d
                })
            })).then(function(c) {
                throw new _.v.AggregateError(c, "All promises were rejected");
            }, function(c) {
                return c
            })
        }
    }, "es_2021");
    Zr("Object.values", function(a) {
        return a ? a : function(b) {
            var c = [],
                d;
            for (d in b) bs(b, d) && c.push(b[d]);
            return c
        }
    }, "es8");
    Zr("Object.fromEntries", function(a) {
        return a ? a : function(b) {
            var c = {};
            if (!(_.u(_.v.Symbol, "iterator") in b)) throw new TypeError("" + b + " is not iterable");
            b = b[_.u(_.v.Symbol, "iterator")].call(b);
            for (var d = b.next(); !d.done; d = b.next()) {
                d = d.value;
                if (Object(d) !== d) throw new TypeError("iterable for fromEntries should yield objects");
                c[d[0]] = d[1]
            }
            return c
        }
    }, "es_2019");
    Zr("Array.prototype.findIndex", function(a) {
        return a ? a : function(b, c) {
            return vs(this, b, c).i
        }
    }, "es6");
    Zr("Array.prototype.flat", function(a) {
        return a ? a : function(b) {
            b = void 0 === b ? 1 : b;
            var c = [];
            Array.prototype.forEach.call(this, function(d) {
                Array.isArray(d) && 0 < b ? (d = _.u(Array.prototype, "flat").call(d, b - 1), c.push.apply(c, d)) : c.push(d)
            });
            return c
        }
    }, "es9");
    Zr("Promise.prototype.finally", function(a) {
        return a ? a : function(b) {
            return this.then(function(c) {
                return _.v.Promise.resolve(b()).then(function() {
                    return c
                })
            }, function(c) {
                return _.v.Promise.resolve(b()).then(function() {
                    throw c;
                })
            })
        }
    }, "es9");
    Zr("String.raw", function(a) {
        return a ? a : function(b, c) {
            if (null == b) throw new TypeError("Cannot convert undefined or null to object");
            for (var d = b.raw, e = d.length, f = "", g = 0; g < e; ++g) f += d[g], g + 1 < e && g + 1 < arguments.length && (f += String(arguments[g + 1]));
            return f
        }
    }, "es6");
    _.q = this || self;
    wa = function(a) {
        var b = typeof a;
        b = "object" != b ? b : a ? Array.isArray(a) ? "array" : b : "null";
        return "array" == b || "object" == b && "number" == typeof a.length
    };
    _.na = function(a) {
        var b = typeof a;
        return "object" == b && null != a || "function" == b
    };
    oa = "closure_uid_" + (1E9 * Math.random() >>> 0);
    pa = 0;
    ws = function(a, b, c) {
        return a.call.apply(a.bind, arguments)
    };
    xs = function(a, b, c) {
        if (!a) throw Error();
        if (2 < arguments.length) {
            var d = Array.prototype.slice.call(arguments, 2);
            return function() {
                var e = Array.prototype.slice.call(arguments);
                Array.prototype.unshift.apply(e, d);
                return a.apply(b, e)
            }
        }
        return function() {
            return a.apply(b, arguments)
        }
    };
    _.ys = function(a, b, c) {
        Function.prototype.bind && -1 != Function.prototype.bind.toString().indexOf("native code") ? _.ys = ws : _.ys = xs;
        return _.ys.apply(null, arguments)
    };
    _.zs = function(a, b) {
        var c = Array.prototype.slice.call(arguments, 1);
        return function() {
            var d = c.slice();
            d.push.apply(d, arguments);
            return a.apply(this, d)
        }
    };
    gf = function() {
        return Date.now()
    };
    var As;
    var Ks, Gs, Fs;
    _.Hs = function(a, b) {
        this.j = a === Fs && b || "";
        this.o = Gs
    };
    _.Hs.prototype.Ua = !0;
    _.Hs.prototype.Ia = function() {
        return this.j
    };
    _.Is = function(a) {
        return a instanceof _.Hs && a.constructor === _.Hs && a.o === Gs ? a.j : "type_error:Const"
    };
    Ks = function(a) {
        return new _.Hs(Fs, a)
    };
    Gs = {};
    Fs = {};
    var Lb = Ks("https://tpc.googlesyndication.com/sodar/%{basename}.js");
    var Ms, Qs, ij, Ss;
    Ms = function() {
        return !0
    };
    Qs = function(a) {
        return function() {
            return !a.apply(this, arguments)
        }
    };
    ij = function(a) {
        var b = !1,
            c;
        return function() {
            b || (c = a(), b = !0);
            return c
        }
    };
    _.Rs = function(a) {
        var b = a;
        return function() {
            if (b) {
                var c = b;
                b = null;
                c()
            }
        }
    };
    Ss = function(a) {
        var b = 0,
            c = !1,
            d = [],
            e = function() {
                b = 0;
                c && (c = !1, f())
            },
            f = function() {
                b = _.q.setTimeout(e, 200);
                var g = d;
                d = [];
                a.apply(void 0, g)
            };
        return function(g) {
            d = arguments;
            b ? c = !0 : f()
        }
    };
    var Ts, ea;
    Ts = {
        passive: !0
    };
    ea = ij(function() {
        var a = !1;
        try {
            var b = Object.defineProperty({}, "passive", {
                get: function() {
                    a = !0
                }
            });
            _.q.addEventListener("test", null, b)
        } catch (c) {}
        return a
    });
    _.yb = function(a, b, c, d) {
        return a.addEventListener ? (a.addEventListener(b, c, fa(d)), !0) : !1
    };
    _.Ae = function(a, b, c, d) {
        return a.removeEventListener ? (a.removeEventListener(b, c, fa(d)), !0) : !1
    };
    var Vs;
    _.ha = function(a, b) {
        return Array.prototype.indexOf.call(a, b, void 0)
    };
    _.Us = function(a, b) {
        Array.prototype.forEach.call(a, b, void 0)
    };
    _.Jh = function(a, b) {
        return Array.prototype.filter.call(a, b, void 0)
    };
    _.xd = function(a, b) {
        return Array.prototype.map.call(a, b, void 0)
    };
    Vs = function(a, b) {
        return Array.prototype.reduce.call(a, b, 0)
    };
    _.Lh = function(a, b) {
        return Array.prototype.some.call(a, b, void 0)
    };
    var Ha = "constructor hasOwnProperty isPrototypeOf propertyIsEnumerable toLocaleString toString valueOf".split(" ");
    var Ws = {
        area: !0,
        base: !0,
        br: !0,
        col: !0,
        command: !0,
        embed: !0,
        hr: !0,
        img: !0,
        input: !0,
        keygen: !0,
        link: !0,
        meta: !0,
        param: !0,
        source: !0,
        track: !0,
        wbr: !0
    };
    var rp;
    rp = {};
    _.qp = function(a, b) {
        this.j = b === rp ? a : "";
        this.Ua = !0
    };
    _.qp.prototype.toString = function() {
        return this.j.toString()
    };
    _.qp.prototype.Ia = function() {
        return this.j.toString()
    };
    _.ib = function(a) {
        return a instanceof _.qp && a.constructor === _.qp ? a.j : "type_error:SafeScript"
    };
    var at, Ib, ct, bt, Zs, Xs, re, $s;
    _.Ys = function(a, b) {
        this.j = b === Xs ? a : ""
    };
    _.Ys.prototype.toString = function() {
        return this.j + ""
    };
    _.Ys.prototype.Ua = !0;
    _.Ys.prototype.Ia = function() {
        return this.j.toString()
    };
    at = function(a, b) {
        a = Zs.exec(_.kb(a).toString());
        var c = a[3] || "";
        return re(a[1] + $s("?", a[2] || "", b) + $s("#", c))
    };
    _.kb = function(a) {
        return a instanceof _.Ys && a.constructor === _.Ys ? a.j : "type_error:TrustedResourceUrl"
    };
    Ib = function(a, b) {
        var c = _.Is(a);
        if (!bt.test(c)) throw Error("Invalid TrustedResourceUrl format: " + c);
        a = c.replace(ct, function(d, e) {
            if (!Object.prototype.hasOwnProperty.call(b, e)) throw Error('Found marker, "' + e + '", in format string, "' + c + '", but no valid label mapping found in args: ' + JSON.stringify(b));
            d = b[e];
            return d instanceof _.Hs ? _.Is(d) : encodeURIComponent(String(d))
        });
        return re(a)
    };
    ct = /%{(\w+)}/g;
    bt = RegExp("^((https:)?//[0-9a-z.:[\\]-]+/|/[^/\\\\]|[^:/\\\\%]+/|[^:/\\\\%]*[?#]|about:blank#)", "i");
    Zs = /^([^?#]*)(\?[^#]*)?(#[\s\S]*)?/;
    Xs = {};
    re = function(a) {
        return new _.Ys(a, Xs)
    };
    $s = function(a, b, c) {
        if (null == c) return b;
        if ("string" === typeof c) return c ? a + encodeURIComponent(c) : "";
        for (var d in c)
            if (Object.prototype.hasOwnProperty.call(c, d)) {
                var e = c[d];
                e = Array.isArray(e) ? e : [e];
                for (var f = 0; f < e.length; f++) {
                    var g = e[f];
                    null != g && (b || (b = a), b += (b.length > a.length ? "&" : "") + encodeURIComponent(d) + "=" + encodeURIComponent(String(g)))
                }
            }
        return b
    };
    var dt = function(a, b) {
            var c = a.length - b.length;
            return 0 <= c && a.indexOf(b, c) == c
        },
        il = function(a) {
            return /^[\s\xa0]*$/.test(a)
        },
        Ar = function(a) {
            return /^[\s\xa0]*([\s\S]*?)[\s\xa0]*$/.exec(a)[1]
        },
        lt = function(a) {
            if (!et.test(a)) return a; - 1 != a.indexOf("&") && (a = a.replace(ft, "&amp;")); - 1 != a.indexOf("<") && (a = a.replace(gt, "&lt;")); - 1 != a.indexOf(">") && (a = a.replace(ht, "&gt;")); - 1 != a.indexOf('"') && (a = a.replace(it, "&quot;")); - 1 != a.indexOf("'") && (a = a.replace(jt, "&#39;")); - 1 != a.indexOf("\x00") && (a = a.replace(kt, "&#0;"));
            return a
        },
        ft = /&/g,
        gt = /</g,
        ht = />/g,
        it = /"/g,
        jt = /'/g,
        kt = /\x00/g,
        et = /[\x00&<>"']/,
        Ma = function(a, b) {
            return -1 != a.indexOf(b)
        },
        Br = function(a, b) {
            return a < b ? -1 : a > b ? 1 : 0
        };
    var nt, ot, qt, rt, st, mt, tb;
    _.cb = function(a, b) {
        this.j = b === mt ? a : ""
    };
    _.cb.prototype.toString = function() {
        return this.j.toString()
    };
    _.cb.prototype.Ua = !0;
    _.cb.prototype.Ia = function() {
        return this.j.toString()
    };
    _.db = function(a) {
        return a instanceof _.cb && a.constructor === _.cb ? a.j : "type_error:SafeUrl"
    };
    nt = /^data:(.*);base64,[a-z0-9+\/]+=*$/i;
    ot = /^(?:(?:https?|mailto|ftp):|[^:/?#]*(?:[/?#]|$))/i;
    _.pt = function(a) {
        if (a instanceof _.cb) return a;
        a = "object" == typeof a && a.Ua ? a.Ia() : String(a);
        ot.test(a) ? a = tb(a) : (a = String(a).replace(/(%0A|%0D)/g, ""), a = a.match(nt) ? tb(a) : null);
        return a
    };
    try {
        new URL("s://g"), qt = !0
    } catch (a) {
        qt = !1
    }
    rt = qt;
    st = function(a) {
        if (a instanceof _.cb) return a;
        a = "object" == typeof a && a.Ua ? a.Ia() : String(a);
        a: {
            var b = a;
            if (rt) {
                try {
                    var c = new URL(b)
                } catch (d) {
                    b = "https:";
                    break a
                }
                b = c.protocol
            } else b: {
                c = document.createElement("a");
                try {
                    c.href = b
                } catch (d) {
                    b = void 0;
                    break b
                }
                b = c.protocol;b = ":" === b || "" === b ? "https:" : b
            }
        }
        "javascript:" === b && (a = "about:invalid#zClosurez");
        return tb(a)
    };
    mt = {};
    tb = function(a) {
        return new _.cb(a, mt)
    };
    _.ub = tb("about:invalid#zClosurez");
    _.tt = {};
    _.ut = function(a, b) {
        this.j = b === _.tt ? a : "";
        this.Ua = !0
    };
    _.ut.prototype.Ia = function() {
        return this.j
    };
    _.ut.prototype.toString = function() {
        return this.j.toString()
    };
    _.vt = new _.ut("", _.tt);
    _.wt = RegExp("^[-+,.\"'%_!#/ a-zA-Z0-9\\[\\]]+$");
    _.xt = RegExp("\\b(url\\([ \t\n]*)('[ -&(-\\[\\]-~]*'|\"[ !#-\\[\\]-~]*\"|[!#-&*-\\[\\]-~]*)([ \t\n]*\\))", "g");
    _.yt = RegExp("\\b(calc|cubic-bezier|fit-content|hsl|hsla|linear-gradient|matrix|minmax|radial-gradient|repeat|rgb|rgba|(rotate|scale|translate)(X|Y|Z|3d)?|steps|var)\\([-+*/0-9a-zA-Z.%#\\[\\], ]+\\)", "g");
    var Ka, zt;
    a: {
        for (var At = ["CLOSURE_FLAGS"], Bt = _.q, Ct = 0; Ct < At.length; Ct++)
            if (Bt = Bt[At[Ct]], null == Bt) {
                zt = null;
                break a
            }
        zt = Bt
    }
    var Dt = zt && zt[610401301];
    Ka = null != Dt ? Dt : !1;
    var La, Et = _.q.navigator;
    La = Et ? Et.userAgentData || null : null;
    var Ft, It, Lt, Jt, Nt, Kt, eh;
    Ft = {};
    _.Gt = function(a, b) {
        this.j = b === Ft ? a : "";
        this.Ua = !0
    };
    _.Gt.prototype.Ia = function() {
        return this.j.toString()
    };
    _.Gt.prototype.toString = function() {
        return this.j.toString()
    };
    _.mb = function(a) {
        return a instanceof _.Gt && a.constructor === _.Gt ? a.j : "type_error:SafeHtml"
    };
    It = function(a) {
        return a instanceof _.Gt ? a : _.Ht(lt("object" == typeof a && a.Ua ? a.Ia() : String(a)))
    };
    _.gh = function(a) {
        if (!Jt.test(a)) throw Error("");
        if (a.toUpperCase() in Kt) throw Error("");
    };
    Lt = function(a) {
        var b = It(eh),
            c = [],
            d = function(e) {
                Array.isArray(e) ? e.forEach(d) : (e = It(e), c.push(_.mb(e).toString()))
            };
        a.forEach(d);
        return _.Ht(c.join(_.mb(b).toString()))
    };
    _.Mt = function(a) {
        return Lt(Array.prototype.slice.call(arguments))
    };
    _.Ht = function(a) {
        return new _.Gt(a, Ft)
    };
    _.hh = function(a, b, c) {
        var d = "";
        if (b)
            for (var e in b)
                if (Object.prototype.hasOwnProperty.call(b, e)) {
                    if (!Jt.test(e)) throw Error("");
                    var f = b[e];
                    if (null != f) {
                        var g = e;
                        if (f instanceof _.Hs) f = _.Is(f);
                        else {
                            if ("style" == g.toLowerCase()) throw Error("");
                            if (/^on/i.test(g)) throw Error("");
                            if (g.toLowerCase() in Nt)
                                if (f instanceof _.Ys) f = _.kb(f).toString();
                                else if (f instanceof _.cb) f = _.db(f);
                            else if ("string" === typeof f) f = (_.pt(f) || _.ub).Ia();
                            else throw Error("");
                        }
                        f.Ua && (f = f.Ia());
                        f = g + '="' + lt(String(f)) + '"';
                        d += " " + f
                    }
                }
        b = "<" + a + d;
        null == c ? c = [] : Array.isArray(c) || (c = [c]);
        !0 === Ws[a.toLowerCase()] ? b += ">" : (c = _.Mt(c), b += ">" + _.mb(c).toString() + "</" + a + ">");
        return _.Ht(b)
    };
    Jt = /^[a-zA-Z0-9-]+$/;
    Nt = {
        action: !0,
        cite: !0,
        data: !0,
        formaction: !0,
        href: !0,
        manifest: !0,
        poster: !0,
        src: !0
    };
    Kt = {
        APPLET: !0,
        BASE: !0,
        EMBED: !0,
        IFRAME: !0,
        LINK: !0,
        MATH: !0,
        META: !0,
        OBJECT: !0,
        SCRIPT: !0,
        STYLE: !0,
        SVG: !0,
        TEMPLATE: !0
    };
    eh = new _.Gt(_.q.trustedTypes && _.q.trustedTypes.emptyHTML || "", Ft);
    _.Ot = _.Ht("<br>");
    var Pt;
    try {
        new URL("s://g"), Pt = !0
    } catch (a) {
        Pt = !1
    }
    var eb = Pt;
    var Qt = {
            ij: 0,
            ej: 1,
            fj: 2,
            0: "HTML_FORMATTED_CONTENT",
            1: "EMBEDDED_INTERNAL_CONTENT",
            2: "EMBEDDED_TRUSTED_EXTERNAL_CONTENT"
        },
        Rt = function(a, b) {
            b = Error.call(this, a + " cannot be used with intent " + Qt[b]);
            this.message = b.message;
            "stack" in b && (this.stack = b.stack);
            this.type = a;
            this.name = "TypeCannotBeUsedWithIntentError"
        };
    _.P(Rt, Error);
    var qb = function(a) {
            this.zh = a
        },
        sb = [rb("data"), rb("http"), rb("https"), rb("mailto"), rb("ftp"), new qb(function(a) {
            return /^[^:]*([/?#]|$)/.test(a)
        })];
    var Cb = function(a) {
        return new _.v.Promise(function(b, c) {
            var d = new XMLHttpRequest;
            d.onreadystatechange = function() {
                d.readyState === d.DONE && (200 <= d.status && 300 > d.status ? b(JSON.parse(d.responseText)) : c())
            };
            d.open("GET", a, !0);
            d.send()
        })
    };
    var Ob, Nb = "undefined" !== typeof TextEncoder;
    _.St = function(a) {
        _.St[" "](a);
        return a
    };
    _.St[" "] = function() {};
    var Tt = function(a, b) {
        try {
            return _.St(a[b]), !0
        } catch (c) {}
        return !1
    };
    var Ut, Wt, Xt, Yt, Zt, $t;
    Ut = Sa();
    _.Vt = Ta();
    Wt = Pa("Edge");
    Xt = Pa("Gecko") && !(Ma(Ja().toLowerCase(), "webkit") && !Pa("Edge")) && !(Pa("Trident") || Pa("MSIE")) && !Pa("Edge");
    Yt = Ma(Ja().toLowerCase(), "webkit") && !Pa("Edge");
    Zt = function() {
        var a = _.q.document;
        return a ? a.documentMode : void 0
    };
    a: {
        var au = "",
            bu = function() {
                var a = Ja();
                if (Xt) return /rv:([^\);]+)(\)|;)/.exec(a);
                if (Wt) return /Edge\/([\d\.]+)/.exec(a);
                if (_.Vt) return /\b(?:MSIE|rv)[: ]([^\);]+)(\)|;)/.exec(a);
                if (Yt) return /WebKit\/(\S+)/.exec(a);
                if (Ut) return /(?:Version)[ \/]?(\S+)/.exec(a)
            }();bu && (au = bu ? bu[1] : "");
        if (_.Vt) {
            var cu = Zt();
            if (null != cu && cu > parseFloat(au)) {
                $t = String(cu);
                break a
            }
        }
        $t = au
    }
    var du = $t,
        eu;
    if (_.q.document && _.Vt) {
        var fu = Zt();
        eu = fu ? fu : parseInt(du, 10) || void 0
    } else eu = void 0;
    var gu = eu;
    !Pa("Android") || Wa();
    Wa();
    Xa();
    var hu = {},
        iu = null,
        ju = Xt || Yt || "function" == typeof _.q.btoa,
        Sb = function(a, b) {
            void 0 === b && (b = 0);
            ku();
            b = hu[b];
            for (var c = Array(Math.floor(a.length / 3)), d = b[64] || "", e = 0, f = 0; e < a.length - 2; e += 3) {
                var g = a[e],
                    h = a[e + 1],
                    k = a[e + 2],
                    l = b[g >> 2];
                g = b[(g & 3) << 4 | h >> 4];
                h = b[(h & 15) << 2 | k >> 6];
                k = b[k & 63];
                c[f++] = l + g + h + k
            }
            l = 0;
            k = d;
            switch (a.length - e) {
                case 2:
                    l = a[e + 1], k = b[(l & 15) << 2] || d;
                case 1:
                    a = a[e], c[f] = b[a >> 2] + b[(a & 3) << 4 | l >> 4] + k + d
            }
            return c.join("")
        },
        lu = function(a, b) {
            if (ju && !b) a = _.q.btoa(a);
            else {
                for (var c = [], d = 0, e = 0; e < a.length; e++) {
                    var f = a.charCodeAt(e);
                    255 < f && (c[d++] = f & 255, f >>= 8);
                    c[d++] = f
                }
                a = Sb(c, b)
            }
            return a
        },
        eq = function(a) {
            var b = "";
            mu(a, function(c) {
                b += String.fromCharCode(c)
            });
            return b
        },
        nu = function(a) {
            var b = a.length,
                c = 3 * b / 4;
            c % 3 ? c = Math.floor(c) : Ma("=.", a[b - 1]) && (c = Ma("=.", a[b - 2]) ? c - 2 : c - 1);
            var d = new Uint8Array(c),
                e = 0;
            mu(a, function(f) {
                d[e++] = f
            });
            return e !== c ? d.subarray(0, e) : d
        },
        mu = function(a, b) {
            function c(k) {
                for (; d < a.length;) {
                    var l = a.charAt(d++),
                        n = iu[l];
                    if (null != n) return n;
                    if (!il(l)) throw Error("Unknown base64 encoding at char: " + l);
                }
                return k
            }
            ku();
            for (var d = 0;;) {
                var e = c(-1),
                    f = c(0),
                    g = c(64),
                    h = c(64);
                if (64 === h && -1 === e) break;
                b(e << 2 | f >> 4);
                64 != g && (b(f << 4 & 240 | g >> 2), 64 != h && b(g << 6 & 192 | h))
            }
        },
        ku = function() {
            if (!iu) {
                iu = {};
                for (var a = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789".split(""), b = ["+/=", "+/", "-_=", "-_.", "-_"], c = 0; 5 > c; c++) {
                    var d = a.concat(b[c].split(""));
                    hu[c] = d;
                    for (var e = 0; e < d.length; e++) {
                        var f = d[e];
                        void 0 === iu[f] && (iu[f] = e)
                    }
                }
            }
        };
    var Wb = "undefined" !== typeof Uint8Array,
        Qb = !_.Vt && "function" === typeof btoa,
        ou = /[-_.]/g,
        Ub = {
            "-": "+",
            _: "/",
            ".": "="
        },
        kk, Yb = {};
    var pu, vc = function(a, b) {
            Zb(b);
            this.j = a;
            if (null != a && 0 === a.length) throw Error("ByteString should be constructed with non-empty values");
        },
        wc = function() {
            return pu || (pu = new vc(null, Yb))
        },
        nd = function(a) {
            var b = a.j;
            return null == b ? "" : "string" === typeof b ? b : a.j = Tb(b)
        };
    vc.prototype.isEmpty = function() {
        return null == this.j
    };
    var jk = function(a) {
        Zb(Yb);
        var b = a.j;
        if (null != b && !Xb(b))
            if ("string" === typeof b)
                if (Qb) {
                    ou.test(b) && (b = b.replace(ou, Vb));
                    b = atob(b);
                    for (var c = new Uint8Array(b.length), d = 0; d < b.length; d++) c[d] = b.charCodeAt(d);
                    b = c
                } else b = nu(b);
        else b = null;
        return null == b ? b : a.j = b
    };
    var bc = 0,
        cc = 0,
        ec = "function" === typeof BigInt;
    var qu = function(a, b) {
            this.o = a >>> 0;
            this.j = b >>> 0
        },
        su = function(a) {
            if (!a) return ru || (ru = new qu(0, 0));
            if (!/^\d+$/.test(a)) return null;
            fc(a);
            return new qu(bc, cc)
        },
        ru, tu = function(a, b) {
            this.o = a >>> 0;
            this.j = b >>> 0
        },
        Wd = function(a) {
            if (!a) return uu || (uu = new tu(0, 0));
            if (!/^-?\d+$/.test(a)) return null;
            fc(a);
            return new tu(bc, cc)
        },
        uu;
    var vu = function() {
        this.j = []
    };
    vu.prototype.length = function() {
        return this.j.length
    };
    vu.prototype.end = function() {
        var a = this.j;
        this.j = [];
        return a
    };
    var Yd = function(a, b, c) {
            for (; 0 < c || 127 < b;) a.j.push(b & 127 | 128), b = (b >>> 7 | c << 25) >>> 0, c >>>= 7;
            a.j.push(b)
        },
        Xd = function(a, b) {
            for (; 127 < b;) a.j.push(b & 127 | 128), b >>>= 7;
            a.j.push(b)
        },
        wu = function(a, b) {
            if (0 <= b) Xd(a, b);
            else {
                for (var c = 0; 9 > c; c++) a.j.push(b & 127 | 128), b >>= 7;
                a.j.push(1)
            }
        };
    var ee = function() {
            this.m = [];
            this.o = 0;
            this.j = new vu
        },
        fe = function(a, b) {
            0 !== b.length && (a.m.push(b), a.o += b.length)
        },
        xu = function(a, b) {
            Xd(a.j, 8 * b + 2);
            b = a.j.end();
            fe(a, b);
            b.push(a.o);
            return b
        },
        yu = function(a, b) {
            var c = b.pop();
            for (c = a.o + a.j.length() - c; 127 < c;) b.push(c & 127 | 128), c >>>= 7, a.o++;
            b.push(c);
            a.o++
        },
        Hd = function(a, b) {
            if (b = b.we) {
                fe(a, a.j.end());
                for (var c = 0; c < b.length; c++) fe(a, jk(b[c]) || kk || (kk = new Uint8Array(0)))
            }
        },
        zu = function(a, b, c) {
            Xd(a.j, 8 * b + 2);
            Xd(a.j, c.length);
            fe(a, a.j.end());
            fe(a, c)
        };
    var gc = "function" === typeof _.v.Symbol && "symbol" === typeof(0, _.v.Symbol)() ? (0, _.v.Symbol)() : void 0;
    var Jc = {},
        Au, Vc = Object.freeze(kc([], 23)),
        Bu = function(a) {
            this.vf = 0;
            this.We = a
        };
    Bu.prototype.next = function() {
        return this.vf < this.We.length ? {
            done: !1,
            value: this.We[this.vf++]
        } : {
            done: !0,
            value: void 0
        }
    };
    Bu.prototype[_.u(_.v.Symbol, "iterator")] = function() {
        return this
    };
    var Pc = "function" === typeof _.v.Symbol && "symbol" === typeof(0, _.v.Symbol)() ? (0, _.v.Symbol)() : "di";
    var bd = function(a, b, c, d) {
            c = void 0 === c ? Qc : c;
            d = void 0 === d ? Qc : d;
            var e = jc(a);
            e |= 32;
            kc(a, e);
            this.m = e;
            this.o = b;
            this.H = c || Qc;
            this.B = this.o ? Tc : d || Qc;
            var f = new _.v.Map;
            this.j = f;
            for (var g = 0; g < a.length; g++) {
                var h = a[g],
                    k = c(h[0], !1, !0),
                    l = h[1];
                b || (l = d(h[1], !1, !0, void 0, void 0, e));
                null != k && f.set(k, l)
            }
            this.size = f.size
        },
        Cu = function(a) {
            if (a.m & 2) throw Error("Cannot mutate an immutable Map");
        },
        od = function(a, b) {
            b = void 0 === b ? Uc : b;
            for (var c = _.u(Array, "from").call(Array, _.u(a.j, "keys").call(a.j)), d = 0; d < c.length; d++) {
                var e = c[d],
                    f = a.j.get(c[d]);
                c[d] = [b(e), b(f)]
            }
            return c
        },
        cd = function(a, b) {
            b = void 0 === b ? Uc : b;
            var c = [];
            a = _.u(a.j, "entries").call(a.j);
            for (var d; !(d = a.next()).done;) d = d.value, d[0] = b(d[0]), d[1] = b(d[1]), c.push(d);
            return c
        };
    _.aa = bd.prototype;
    _.aa.clear = function() {
        Cu(this);
        this.j.clear();
        this.size = 0
    };
    _.aa.delete = function(a) {
        Cu(this);
        return this.j.delete(a) ? (this.size = this.j.size, !0) : !1
    };
    _.aa.entries = function() {
        for (var a = _.u(Array, "from").call(Array, _.u(this.j, "keys").call(this.j)), b = 0; b < a.length; b++) {
            var c = a[b];
            a[b] = [c, this.get(c)]
        }
        return new Bu(a)
    };
    _.aa.keys = function() {
        return _.u(this.j, "keys").call(this.j)
    };
    _.aa.values = function() {
        for (var a = _.u(Array, "from").call(Array, _.u(this.j, "keys").call(this.j)), b = 0; b < a.length; b++) a[b] = this.get(a[b]);
        return new Bu(a)
    };
    _.aa.forEach = function(a, b) {
        var c = this;
        this.j.forEach(function(d, e) {
            a.call(b, c.get(e), e, c)
        })
    };
    _.aa.set = function(a, b) {
        Cu(this);
        var c = this.j;
        a = this.H(a, !0, !1);
        if (null == a) return this;
        if (null == b) return c.delete(a), this;
        c.set(a, this.B(b, !0, !0, this.o, !1, this.m));
        this.size = c.size;
        return this
    };
    _.aa.get = function(a) {
        a = this.H(a, !1, !1);
        var b = this.j,
            c = b.get(a);
        if (void 0 !== c) {
            var d = this.m,
                e = this.o;
            return e ? (Array.isArray(c) && d & 16 && rc(c), d = this.B(c, !1, !0, e, this.l, d), d !== c && b.set(a, d), d) : c
        }
    };
    _.aa.has = function(a) {
        return this.o ? null != this.get(a) : this.j.has(a)
    };
    bd.prototype[_.u(_.v.Symbol, "iterator")] = function() {
        return _.u(this, "entries").call(this)
    };
    var Du, y, Wc, Jl, to, Fo, K, ad, yf, ek, Tf, ik, Gp, Eu, Ip, Df, Pe, Fu, Se, Un, Qi, zq, pi, Gu, Iu, Wn, Ju, Ku, Lu, og, Mu;
    Du = function(a) {
        var b = a.o + a.yb;
        return a.Va || (a.Va = a.ga[b] = {})
    };
    y = function(a, b, c) {
        return -1 === b ? null : b >= a.o ? a.Va ? a.Va[b] : void 0 : c && a.Va && (c = a.Va[b], null != c) ? c : a.ga[b + a.yb]
    };
    _.z = function(a, b, c, d) {
        zc(a);
        return Wc(a, b, c, d)
    };
    Wc = function(a, b, c, d) {
        a.B && (a.B = void 0);
        if (b >= a.o || d) return Du(a)[b] = c, a;
        a.ga[b + a.yb] = c;
        (c = a.Va) && b in c && delete c[b];
        return a
    };
    Jl = function(a, b) {
        return null != y(a, b, !1)
    };
    to = function(a, b, c) {
        return void 0 !== Eu(a, b, c, !1)
    };
    Fo = function(a, b) {
        var c = y(a, b);
        var d = null == c ? c : "number" === typeof c || "NaN" === c || "Infinity" === c || "-Infinity" === c ? Number(c) : void 0;
        null != d && d !== c && Wc(a, b, d);
        return d
    };
    K = function(a, b) {
        a = y(a, b);
        return null == a ? a : !!a
    };
    _.Sf = function(a, b, c) {
        return kd(K(a, b), void 0 === c ? !1 : c)
    };
    yf = function(a, b) {
        return _.z(a, b, void 0, !1)
    };
    ek = function(a, b, c, d) {
        zc(a);
        (c = ik(a, c)) && c !== b && null != d && Wc(a, c, void 0, !1);
        return Wc(a, b, d)
    };
    Tf = function(a, b, c) {
        return ik(a, b) === c ? c : -1
    };
    ik = function(a, b) {
        for (var c = 0, d = 0; d < b.length; d++) {
            var e = b[d];
            null != y(a, e) && (0 !== c && Wc(a, c, void 0, !1), c = e)
        }
        return c
    };
    Gp = function(a, b, c) {
        var d = jc(a.ga);
        yc(d);
        var e = y(a, c);
        b = Sc(Mc(e, b, !0, d));
        e !== b && Wc(a, c, b);
        return b
    };
    Eu = function(a, b, c, d) {
        var e = y(a, c, d);
        b = Mc(e, b, !1, jc(a.ga));
        b !== e && null != b && Wc(a, c, b, d);
        return b
    };
    Ip = function(a, b, c) {
        return (a = Eu(a, b, c, !1)) ? a : Kc(b)
    };
    Df = function(a, b, c) {
        var d = void 0 === d ? !1 : d;
        b = Eu(a, b, c, d);
        if (null == b) return b;
        if (!pc(a.ga)) {
            var e = Sc(b);
            e !== b && (b = e, Wc(a, c, b, d))
        }
        return b
    };
    Pe = function(a, b, c) {
        var d = jc(a.ga),
            e = !!(d & 2);
        b = gd(a, b, c, e ? 1 : 2, d);
        a = Xc(a, c, 3, void 0, e);
        if (!(e || jc(a) & 8)) {
            for (e = 0; e < b.length; e++) c = b[e], d = Sc(c), c !== d && (b[e] = d, a[e] = d.ga);
            hc(a, 8)
        }
        return b
    };
    _.Uh = function(a, b, c) {
        zc(a);
        null == c && (c = void 0);
        return Wc(a, b, c)
    };
    _.Xh = function(a, b, c, d) {
        zc(a);
        null == d && (d = void 0);
        return ek(a, b, c, d)
    };
    _.yd = function(a, b, c, d) {
        zc(a);
        var e = null == c ? Vc : lc([]);
        if (null != c) {
            for (var f = !!c.length, g = 0; g < c.length; g++) {
                var h = c[g];
                f = f && !pc(h.ga);
                e[g] = h.ga
            }
            f = (f ? 8 : 0) | 1;
            g = jc(e);
            (g & f) !== f && (Object.isFrozen(e) && (e = Array.prototype.slice.call(e)), kc(e, g | f));
            a.j || (a.j = {});
            a.j[b] = c
        } else a.j && (a.j[b] = void 0);
        return Wc(a, b, e, d)
    };
    Fu = function(a, b, c, d) {
        var e = jc(a.ga);
        yc(e);
        e = gd(a, c, b, 2, e);
        c = null != d ? d : new c;
        a = Xc(a, b, 2, void 0, !1);
        e.push(c);
        a.push(c.ga);
        pc(c.ga) && ic(a, 8);
        return c
    };
    _.Xf = function(a, b, c, d) {
        Fu(a, b, c, d);
        return a
    };
    Se = function(a, b) {
        return kd(y(a, b), 0)
    };
    Un = function(a, b) {
        return Cc(y(a, b))
    };
    Qi = function(a, b) {
        a = K(a, b);
        return null == a ? void 0 : a
    };
    zq = function(a, b) {
        return kd(pi(a, b), 0)
    };
    pi = function(a, b) {
        a: if (a = y(a, b), null != a) {
            switch (typeof a) {
                case "string":
                    a = +a;
                    break a;
                case "number":
                    break a
            }
            a = void 0
        }return a
    };
    _.$e = function(a, b, c) {
        return kd(y(a, b), void 0 === c ? 0 : c)
    };
    Gu = function() {
        var a = rj().j;
        return y(a, 26)
    };
    Iu = function(a) {
        var b = Hu;
        var c = void 0 === c ? 0 : c;
        return _.$e(a, Tf(a, b, 3), c)
    };
    _.bn = function(a, b, c, d) {
        return Yc(a, b, Ic, c, d)
    };
    Wn = function(a, b) {
        return Xc(a, b, 0, !1, pc(a.ga))
    };
    _.Rf = function(a, b) {
        return kd(y(a, b), "")
    };
    _.Re = function(a, b, c) {
        return kd(y(a, b), void 0 === c ? 0 : c)
    };
    Ju = function(a, b, c) {
        a = _.bn(a, b, void 0, 2);
        if (0 > c || c >= a.length) throw Error();
        return a[c]
    };
    Ku = function(a, b, c) {
        zc(a);
        Xc(a, b, 2, !1, !1).push(c);
        return a
    };
    Lu = function(a, b) {
        return _.Rf(a, Tf(a, b, 2))
    };
    og = function(a, b) {
        a = y(a, b);
        return null == a ? void 0 : a
    };
    Mu = function(a, b) {
        a = y(a, b);
        return null == a ? void 0 : a
    };
    _.bg = function(a, b) {
        return null != y(a, b)
    };
    var ld;
    _.T = function(a, b, c, d) {
        null == a && (a = ld);
        ld = void 0;
        var e = this.constructor.messageId;
        if (null == a) {
            a = e ? [e] : [];
            var f = 48;
            var g = !0;
            d && (f |= 128);
            kc(a, f)
        } else {
            if (!Array.isArray(a)) throw Error();
            if (e && e !== a[0]) throw Error();
            f = hc(a, 0) | 32;
            g = 0 !== (16 & f);
            if (d) {
                if (f |= 128, 0 < a.length) {
                    var h = a[a.length - 1];
                    if (uc(h) && "g" in h) {
                        delete h.g;
                        var k = !0,
                            l;
                        for (l in h) {
                            k = !1;
                            break
                        }
                        k && a.pop()
                    }
                }
            } else if (128 & f) throw Error();
            kc(a, f)
        }
        this.yb = e ? 0 : -1;
        this.j = void 0;
        this.ga = a;
        a: {
            f = this.ga.length;e = f - 1;
            if (f && (f = this.ga[e], uc(f))) {
                this.Va = f;
                this.o = e - this.yb;
                break a
            }
            void 0 !== b && -1 < b ? (this.o = Math.max(b, e + 1 - this.yb), this.Va = void 0) : this.o = Number.MAX_VALUE
        }
        if (!d && this.Va && "g" in this.Va) throw Error('Unexpected "g" flag in sparse object of message that is not a group type.');
        if (c) {
            b = g && !0;
            d = this.o;
            var n;
            for (g = 0; g < c.length; g++) e = c[g], e < d ? (e += this.yb, (f = a[e]) ? Cd(f, b) : a[e] = Vc) : (n || (n = Du(this)), (f = n[e]) ? Cd(f, b) : n[e] = Vc)
        }
    };
    _.T.prototype.toJSON = function() {
        var a = this.ga,
            b;
        Au ? b = a : b = qd(a, sd, td, void 0, !1, !1);
        return b
    };
    var Me = function(a) {
        Au = !0;
        try {
            return JSON.stringify(a.toJSON(), Dd)
        } finally {
            Au = !1
        }
    };
    _.T.prototype.Ae = Jc;
    var Md = (0, _.v.Symbol)(),
        Kd = (0, _.v.Symbol)(),
        Jd = (0, _.v.Symbol)(),
        Nu = Vd(function(a, b, c) {
            if (5 !== a.j()) return !1;
            _.z(b, c, a.l());
            return !0
        }, function(a, b, c) {
            b = Fo(b, c);
            if (null != b) {
                Xd(a.j, 8 * c + 5);
                a = a.j;
                var d = +b;
                0 === d ? 0 < 1 / d ? bc = cc = 0 : (cc = 0, bc = 2147483648) : isNaN(d) ? (cc = 0, bc = 2147483647) : (d = (c = 0 > d ? -2147483648 : 0) ? -d : d, 3.4028234663852886E38 < d ? (cc = 0, bc = (c | 2139095040) >>> 0) : 1.1754943508222875E-38 > d ? (d = Math.round(d / Math.pow(2, -149)), cc = 0, bc = (c | d) >>> 0) : (b = Math.floor(Math.log(d) / Math.LN2), d *= Math.pow(2, -b), d = Math.round(8388608 * d), 16777216 <= d && ++b, cc = 0, bc = (c | b + 127 << 23 | d & 8388607) >>> 0));
                c = bc;
                a.j.push(c >>> 0 & 255);
                a.j.push(c >>> 8 & 255);
                a.j.push(c >>> 16 & 255);
                a.j.push(c >>> 24 & 255)
            }
        }),
        Ou = Vd(function(a, b, c) {
            if (0 !== a.j()) return !1;
            _.z(b, c, a.N());
            return !0
        }, Zd),
        Pu = Vd(function(a, b, c) {
            if (0 !== a.j()) return !1;
            _.z(b, c, a.A());
            return !0
        }, Zd),
        Qu = Vd(function(a, b, c) {
            if (0 !== a.j()) return !1;
            _.z(b, c, a.ia());
            return !0
        }, function(a, b, c) {
            b = y(b, c);
            null != b && ("string" === typeof b && su(b), null != b && (Xd(a.j, 8 * c), "number" === typeof b ? (a = a.j, dc(b), Yd(a, bc, cc)) : (c = su(b), Yd(a.j, c.o, c.j))))
        }),
        Ru = Vd(function(a, b, c) {
            if (0 !== a.j()) return !1;
            _.z(b, c, a.I());
            return !0
        }, function(a, b, c) {
            b = Un(b, c);
            null != b && null != b && (Xd(a.j, 8 * c), wu(a.j, b))
        }),
        Su = Vd(function(a, b, c) {
            if (0 !== a.j()) return !1;
            _.z(b, c, a.H());
            return !0
        }, function(a, b, c) {
            b = K(b, c);
            null != b && (Xd(a.j, 8 * c), a.j.j.push(b ? 1 : 0))
        }),
        Tu = Vd(function(a, b, c) {
            if (2 !== a.j()) return !1;
            _.z(b, c, a.m());
            return !0
        }, function(a, b, c) {
            b = y(b, c);
            null != b && zu(a, c, Pb(b))
        }),
        Uu = Vd(function(a, b, c) {
            if (2 !== a.j()) return !1;
            Ku(b, c, a.m());
            return !0
        }, function(a, b, c) {
            b = _.bn(b, c);
            if (null != b)
                for (var d = 0; d < b.length; d++) {
                    var e = b[d];
                    null != e && zu(a, c, Pb(e))
                }
        }),
        Vu = Vd(function(a, b, c, d, e) {
            if (2 !== a.j()) return !1;
            a.o(Gp(b, d, c), e);
            return !0
        }, function(a, b, c, d, e) {
            b = Df(b, d, c);
            null != b && (c = xu(a, c), e(b, a), yu(a, c))
        }),
        Wu = Vd(function(a, b, c, d, e) {
            if (2 !== a.j()) return !1;
            a.o(Fu(b, c, d), e);
            return !0
        }, function(a, b, c, d, e) {
            b = Pe(b, d, c);
            if (null != b)
                for (d = 0; d < b.length; d++) {
                    var f = xu(a, c);
                    e(b[d], a);
                    yu(a, f)
                }
        }),
        Xu = Vd(function(a, b, c) {
            if (0 !== a.j()) return !1;
            _.z(b, c, a.B());
            return !0
        }, function(a, b, c) {
            b = y(b, c);
            null != b && (b = parseInt(b, 10), Xd(a.j, 8 * c), wu(a.j, b))
        });
    var B = {
        Rj: function() {
            return ""
        }
    };
    B.te = $d;
    var Yu = $d(function(a) {
        return null !== a && void 0 !== a
    }, "exists");
    B.assert = function() {};
    B.va = function(a) {
        return a
    };
    var ae = void 0;
    B.Wj = be;
    B.Yj = ce;
    B.Mj = function() {};
    B.Pj = function(a) {
        return a
    };
    B.Pf = de;
    B.ak = function(a, b) {
        de(a, b);
        return a
    };
    B.Lj = function() {};
    B.K = function(a) {
        return a
    };
    B.Xj = function(a, b) {
        be(a, Yu, b)
    };
    B.Zj = function(a, b) {
        return ce(a, Yu, b)
    };
    B.Qj = function(a, b) {
        return a(b)
    };
    B.Sj = function(a) {
        de(!ae);
        ae = function() {
            var b = "function" === typeof a ? a() : a;
            ae = void 0;
            return b
        }
    };
    var fq = function(a) {
        _.T.call(this, a)
    };
    _.P(fq, _.T);
    var gq = function(a) {
        _.T.call(this, a)
    };
    _.P(gq, _.T);
    var Zu = function(a) {
            this.j = a.o;
            this.o = a.m;
            this.H = a.H;
            this.Ec = a.Ec;
            this.F = a.F;
            this.ec = a.ec;
            this.zd = a.zd;
            this.Jd = a.Jd;
            this.yd = a.yd;
            this.m = a.j
        },
        $u = function(a, b, c) {
            this.o = a;
            this.m = b;
            this.H = c;
            this.F = window;
            this.ec = "env";
            this.zd = "n";
            this.Jd = "0";
            this.yd = "1";
            this.j = !0
        };
    $u.prototype.build = function() {
        return new Zu(this)
    };
    var pq = function(a, b) {
        var c = void 0 === _.Sf(b, 6) ? !0 : _.Sf(b, 6),
            d, e;
        a: switch (_.Re(b, 4, 0)) {
            case 1:
                var f = "pt";
                break a;
            case 2:
                f = "cr";
                break a;
            default:
                f = ""
        }
        f = new $u(ke(_.Re(b, 2, 0)), _.Rf(b, 3), f);
        b = null != (e = null == (d = Df(b, fq, 5)) ? void 0 : _.Rf(d, 1)) ? e : "";
        f.Ec = b;
        f.j = c;
        f.F = a;
        return f.build()
    };
    var av = function(a) {
        _.T.call(this, a)
    };
    _.P(av, _.T);
    av.prototype.getId = function() {
        return _.Rf(this, 1)
    };
    var yo = function(a) {
            var b = new av;
            return _.z(b, 1, a)
        },
        bv = [av, 1, Tu];
    var cv = function(a) {
        _.T.call(this, a)
    };
    _.P(cv, _.T);
    cv.prototype.getWidth = function() {
        return Se(this, 1)
    };
    var Do = function(a) {
        var b = new cv;
        return _.z(b, 1, a)
    };
    cv.prototype.getHeight = function() {
        return Se(this, 2)
    };
    var Co = function(a, b) {
            return _.z(a, 2, b)
        },
        dv = [cv, 1, Ru, 2, Ru];
    var ev = function(a) {
        _.T.call(this, a)
    };
    _.P(ev, _.T);
    var fv = [ev, 1, Pu, 2, Su];
    var wo = function(a) {
        _.T.call(this, a, -1, gv)
    };
    _.P(wo, _.T);
    var zo = function(a, b) {
            _.ed(a, 4, b, _.Hc)
        },
        xo = function(a, b) {
            _.Uh(a, 6, b)
        },
        Bo = function(a, b) {
            _.Uh(a, 7, b)
        },
        gv = [4],
        hv = [wo, 1, Tu, 2, Pu, 8, Pu, 3, Tu, 4, Uu, 5, Xu, 6, Vu, bv, 7, Vu, dv, 9, Vu, fv];
    var Hn = function(a) {
        _.T.call(this, a)
    };
    _.P(Hn, _.T);
    var Gn = function(a, b) {
            return _.z(a, 1, b)
        },
        En = function(a, b) {
            return _.z(a, 4, b)
        },
        Fn = function(a, b) {
            return _.z(a, 2, b)
        },
        iv = [Hn, 1, Xu, 4, Su, 2, Ru, 3, Tu];
    var no = function(a) {
        _.T.call(this, a, -1, jv)
    };
    _.P(no, _.T);
    var mo = function(a, b) {
            return _.z(a, 1, b)
        },
        qo = function(a, b) {
            _.z(a, 2, b)
        },
        ko = function(a, b) {
            return _.Xf(a, 3, wo, b)
        },
        lo = function(a, b) {
            return _.z(a, 4, b)
        };
    no.prototype.rf = function() {
        return _.Re(this, 7, 0)
    };
    var jv = [10, 3],
        kv = [no, 1, Tu, 10, Uu, 2, Pu, 3, Wu, hv, 4, Xu, 5, Vu, iv, 6, Su, 7, Xu];
    var lv = function(a) {
        _.T.call(this, a)
    };
    _.P(lv, _.T);
    var mv = [lv, 1, Xu, 2, Su];
    var ov = function(a) {
        _.T.call(this, a, -1, nv)
    };
    _.P(ov, _.T);
    var jo = function(a, b) {
            return Fu(a, 2, no, b)
        },
        uo = function(a, b) {
            _.Uh(a, 5, b)
        },
        pv = function(a, b) {
            _.Uh(a, 9, b)
        },
        nv = [2],
        qv = [ov, 1, Xu, 6, Tu, 2, Wu, kv, 3, Xu, 4, Tu, 5, Vu, iv, 9, Vu, mv, 7, Su, 8, Ru];
    var sv = function(a) {
        _.T.call(this, a, -1, rv)
    };
    _.P(sv, _.T);
    var tv = function(a) {
            var b = new ov;
            b = _.z(b, 1, 1);
            return Fu(a, 1, ov, b)
        },
        rv = [1];
    sv.prototype.m = ge([sv, 1, Wu, qv]);
    var uv = function(a) {
        _.T.call(this, a)
    };
    _.P(uv, _.T);
    var Hu = [2, 3];
    var wv = function(a) {
        _.T.call(this, a, -1, vv)
    };
    _.P(wv, _.T);
    var vv = [1];
    var yv = function(a) {
        _.T.call(this, a, -1, xv)
    };
    _.P(yv, _.T);
    var xv = [1];
    var zv = function(a) {
        _.T.call(this, a)
    };
    _.P(zv, _.T);
    zv.prototype.m = function() {
        return _.Rf(this, 1)
    };
    zv.prototype.H = function() {
        return Lu(this, Uf)
    };
    var Uf = [2, 3];
    var Bv = function(a) {
        _.T.call(this, a, -1, Av)
    };
    _.P(Bv, _.T);
    Bv.prototype.m = function() {
        return Pe(this, zv, 2)
    };
    var ag = he(Bv),
        Av = [2];
    var Dv = function(a) {
        _.T.call(this, a, -1, Cv)
    };
    _.P(Dv, _.T);
    var Cv = [4];
    var Ev = function(a) {
        _.T.call(this, a)
    };
    _.P(Ev, _.T);
    var Gv = function(a) {
        _.T.call(this, a, -1, Fv)
    };
    _.P(Gv, _.T);
    Gv.prototype.vd = function() {
        return Ip(this, Ev, 2)
    };
    var Fv = [1];
    var Hv = function(a) {
        _.T.call(this, a)
    };
    _.P(Hv, _.T);
    var Jv = function(a) {
        _.T.call(this, a, -1, Iv)
    };
    _.P(Jv, _.T);
    var Iv = [1];
    var Kv = function(a) {
        _.T.call(this, a)
    };
    _.P(Kv, _.T);
    var Lv = [Kv, 1, Xu, 2, Pu];
    var Mv = function(a) {
        _.T.call(this, a)
    };
    _.P(Mv, _.T);
    var Nv = [Mv, 1, Ou];
    var Ov = function(a) {
        _.T.call(this, a)
    };
    _.P(Ov, _.T);
    Ov.prototype.getEscapedQemQueryId = function() {
        return _.Rf(this, 1)
    };
    var Pv = [Ov, 1, Tu, 2, Vu, Nv, 3, Vu, Lv];
    var Qv = function(a) {
        _.T.call(this, a)
    };
    _.P(Qv, _.T);
    Qv.prototype.getAdUnitPath = function() {
        return _.Rf(this, 1)
    };
    var Tn = function(a) {
        _.T.call(this, a)
    };
    _.P(Tn, _.T);
    var Rn = function(a) {
        _.T.call(this, a)
    };
    _.P(Rn, _.T);
    var Sn = [1, 2];
    var Sv = function(a) {
        _.T.call(this, a, -1, Rv)
    };
    _.P(Sv, _.T);
    var Rv = [1, 2];
    var Yn = function(a) {
        _.T.call(this, a)
    };
    _.P(Yn, _.T);
    Yn.prototype.getAdUnitPath = function() {
        return _.Rf(this, 2)
    };
    Yn.prototype.getWidth = function() {
        return Se(this, 3)
    };
    Yn.prototype.getHeight = function() {
        return Se(this, 4)
    };
    var Uv = function(a) {
        _.T.call(this, a, -1, Tv)
    };
    _.P(Uv, _.T);
    var Tv = [3];
    var Wv = function(a) {
        _.T.call(this, a, -1, Vv)
    };
    _.P(Wv, _.T);
    var Vv = [5];
    var Yv = function(a) {
            _.T.call(this, a, -1, Xv)
        },
        Xv;
    _.P(Yv, _.T);
    _.Zv = function(a) {
        return Pe(a, Wv, 15)
    };
    Xv = [15];
    var $v = function(a) {
        _.T.call(this, a)
    };
    _.P($v, _.T);
    $v.prototype.getAdUnitPath = function() {
        return _.Rf(this, 2)
    };
    var aw = function(a) {
        _.T.call(this, a)
    };
    _.P(aw, _.T);
    var bw = [5, 6, 7, 8, 9];
    var dw = function(a) {
        _.T.call(this, a, -1, cw)
    };
    _.P(dw, _.T);
    var cw = [4, 5, 6];
    var ew = function(a) {
        _.T.call(this, a)
    };
    _.P(ew, _.T);
    ew.prototype.Ac = function() {
        return _.bg(this, 2)
    };
    var gw = function(a) {
        _.T.call(this, a, -1, fw)
    };
    _.P(gw, _.T);
    var fw = [13];
    var iw = function(a) {
        _.T.call(this, a, -1, hw)
    };
    _.P(iw, _.T);
    var hw = [13];
    var Ef = function(a) {
        _.T.call(this, a)
    };
    _.P(Ef, _.T);
    var Cf = function(a, b) {
            return _.z(a, 1, b)
        },
        jw = [Ef, 1, Xu];
    var Pf = function(a) {
        _.T.call(this, a)
    };
    _.P(Pf, _.T);
    var Wf = function(a) {
        var b = new Pf;
        return _.z(b, 1, a)
    };
    Pf.prototype.Ea = function(a) {
        return _.Uh(this, 10, a)
    };
    var kw = he(Pf),
        lw = [Pf, 1, Tu, 2, Tu, 3, Pu, 7, Pu, 8, Nu, 4, Ru, 5, Ru, 6, Ru, 9, Su, 11, Su, 10, Vu, jw];
    var mw = function(a) {
        _.T.call(this, a)
    };
    _.P(mw, _.T);
    var nw = [mw, 4, Xu, 5, Tu];
    var ow = function(a) {
        _.T.call(this, a)
    };
    _.P(ow, _.T);
    var pw = [ow, 1, Qu, 2, Qu, 3, Qu];
    var qw = function(a) {
        _.T.call(this, a)
    };
    _.P(qw, _.T);
    qw.prototype.Ea = function(a) {
        return _.Uh(this, 7, a)
    };
    var rw = [qw, 5, Tu, 4, Tu, 2, Vu, pw, 3, Vu, pw, 6, Su, 7, Vu, nw, 8, Pu];
    var Lf = function(a) {
        _.T.call(this, a, -1, sw)
    };
    _.P(Lf, _.T);
    var sw = [1, 2];
    Lf.prototype.m = ge([Lf, 1, Wu, rw, 2, Wu, lw]);
    var tw = function(a) {
        _.T.call(this, a)
    };
    _.P(tw, _.T);
    tw.prototype.m = function() {
        return _.Rf(this, 1)
    };
    tw.prototype.H = function() {
        return Lu(this, uw)
    };
    var uw = [2, 3];
    var ww = function(a) {
        _.T.call(this, a, -1, vw)
    };
    _.P(ww, _.T);
    ww.prototype.m = function() {
        return Pe(this, tw, 1)
    };
    var vw = [1];
    var xw = function(a) {
        _.T.call(this, a)
    };
    _.P(xw, _.T);
    xw.prototype.Ac = function() {
        return _.bg(this, 1)
    };
    xw.prototype.getVersion = function() {
        return y(this, 5)
    };
    var yw = function(a) {
        _.T.call(this, a)
    };
    _.P(yw, _.T);
    var zw = function(a) {
        _.T.call(this, a)
    };
    _.P(zw, _.T);
    var Aw = function(a) {
        _.T.call(this, a)
    };
    _.P(Aw, _.T);
    var Cw = function(a) {
        _.T.call(this, a, -1, Bw)
    };
    _.P(Cw, _.T);
    Cw.prototype.getEscapedQemQueryId = function() {
        return _.Rf(this, 4)
    };
    var Bw = [2];
    var Dw = function(a) {
        _.T.call(this, a)
    };
    _.P(Dw, _.T);
    var Ew = function(a) {
        _.T.call(this, a)
    };
    _.P(Ew, _.T);
    var Fw = function(a) {
        _.T.call(this, a)
    };
    _.P(Fw, _.T);
    var Gw = function(a) {
        _.T.call(this, a)
    };
    _.P(Gw, _.T);
    Gw.prototype.getEscapedQemQueryId = function() {
        return _.Rf(this, 2)
    };
    var Iw = function(a) {
        _.T.call(this, a, -1, Hw)
    };
    _.P(Iw, _.T);
    Iw.prototype.getWidth = function() {
        return Se(this, 9)
    };
    Iw.prototype.getHeight = function() {
        return Se(this, 10)
    };
    var Hw = [3, 7, 11];
    var Kw = function(a) {
        _.T.call(this, a, -1, Jw)
    };
    _.P(Kw, _.T);
    Kw.prototype.getHeight = function() {
        return Un(this, 6)
    };
    Kw.prototype.getWidth = function() {
        return Un(this, 7)
    };
    Kw.prototype.getEscapedQemQueryId = function() {
        return y(this, 34)
    };
    var Jw = [14, 15, 16, 17, 18, 19, 20, 21, 22, 45, 23, 27, 38, 53, 62, 63],
        Lw = [39, 48];
    var Mw = function(a) {
        _.T.call(this, a)
    };
    _.P(Mw, _.T);
    var dq = he(Mw);
    var Ow = function(a) {
        _.T.call(this, a, -1, Nw)
    };
    _.P(Ow, _.T);
    var Pw = he(Ow),
        Nw = [1, 2, 3];
    var Qw = window;
    var Gr = function(a) {
        _.T.call(this, a, -1, Rw)
    };
    _.P(Gr, _.T);
    var Rw = [15];
    var Fr = function(a) {
        _.T.call(this, a)
    };
    _.P(Fr, _.T);
    Fr.prototype.getCorrelator = function() {
        return _.$e(this, 1)
    };
    Fr.prototype.setCorrelator = function(a) {
        return _.id(this, 1, a)
    };
    var Er = function(a) {
        _.T.call(this, a)
    };
    _.P(Er, _.T);
    var Sw = _.Vt || Yt;
    var Uw, Vw, Ww;
    _.Tw = ij(function() {
        var a = document.createElement("div"),
            b = document.createElement("div");
        b.appendChild(document.createElement("div"));
        a.appendChild(b);
        b = a.firstChild.firstChild;
        a.innerHTML = _.mb(eh);
        return !b.parentElement
    });
    Uw = function(a, b) {
        b = b instanceof _.cb ? b : st(b);
        a.href = _.db(b)
    };
    Vw = /^[\w+/_-]+[=]{0,2}$/;
    Ww = function(a, b) {
        b = (b || _.q).document;
        return b.querySelector ? (a = b.querySelector(a)) && (a = a.nonce || a.getAttribute("nonce")) && Vw.test(a) ? a : "" : ""
    };
    _.Vi = function(a, b) {
        this.x = void 0 !== a ? a : 0;
        this.y = void 0 !== b ? b : 0
    };
    _.Vi.prototype.ceil = function() {
        this.x = Math.ceil(this.x);
        this.y = Math.ceil(this.y);
        return this
    };
    _.Vi.prototype.floor = function() {
        this.x = Math.floor(this.x);
        this.y = Math.floor(this.y);
        return this
    };
    _.Vi.prototype.round = function() {
        this.x = Math.round(this.x);
        this.y = Math.round(this.y);
        return this
    };
    _.Yi = function(a, b) {
        this.width = a;
        this.height = b
    };
    _.aa = _.Yi.prototype;
    _.aa.aspectRatio = function() {
        return this.width / this.height
    };
    _.aa.isEmpty = function() {
        return !(this.width * this.height)
    };
    _.aa.ceil = function() {
        this.width = Math.ceil(this.width);
        this.height = Math.ceil(this.height);
        return this
    };
    _.aa.floor = function() {
        this.width = Math.floor(this.width);
        this.height = Math.floor(this.height);
        return this
    };
    _.aa.round = function() {
        this.width = Math.round(this.width);
        this.height = Math.round(this.height);
        return this
    };
    var Xw, Yw, Zw, ax;
    Xw = function(a) {
        return a = lt(a)
    };
    Yw = function() {
        return Math.floor(2147483648 * Math.random()).toString(36) + Math.abs(Math.floor(2147483648 * Math.random()) ^ gf()).toString(36)
    };
    Zw = 2147483648 * Math.random() | 0;
    _.$w = function(a) {
        return String(a).replace(/\-([a-z])/g, function(b, c) {
            return c.toUpperCase()
        })
    };
    ax = function(a) {
        return a.replace(RegExp("(^|[\\s]+)([a-z])", "g"), function(b, c, d) {
            return c + d.toUpperCase()
        })
    };
    var dx, fx, ex, ix, kx, le, oe;
    dx = function(a) {
        return a ? new _.bx(_.cx(a)) : As || (As = new _.bx)
    };
    fx = function(a, b) {
        Ea(b, function(c, d) {
            c && "object" == typeof c && c.Ua && (c = c.Ia());
            "style" == d ? a.style.cssText = c : "class" == d ? a.className = c : "for" == d ? a.htmlFor = c : ex.hasOwnProperty(d) ? a.setAttribute(ex[d], c) : 0 == d.lastIndexOf("aria-", 0) || 0 == d.lastIndexOf("data-", 0) ? a.setAttribute(d, c) : a[d] = c
        })
    };
    ex = {
        cellpadding: "cellPadding",
        cellspacing: "cellSpacing",
        colspan: "colSpan",
        frameborder: "frameBorder",
        height: "height",
        maxlength: "maxLength",
        nonce: "nonce",
        role: "role",
        rowspan: "rowSpan",
        type: "type",
        usemap: "useMap",
        valign: "vAlign",
        width: "width"
    };
    _.hx = function(a) {
        a = a.document;
        a = _.gx(a) ? a.documentElement : a.body;
        return new _.Yi(a.clientWidth, a.clientHeight)
    };
    ix = function(a) {
        return a.scrollingElement ? a.scrollingElement : !Yt && _.gx(a) ? a.documentElement : a.body || a.documentElement
    };
    _.jx = function(a) {
        return a ? a.parentWindow || a.defaultView : window
    };
    kx = function(a, b, c) {
        function d(h) {
            h && b.appendChild("string" === typeof h ? a.createTextNode(h) : h)
        }
        for (var e = 1; e < c.length; e++) {
            var f = c[e];
            if (!wa(f) || _.na(f) && 0 < f.nodeType) d(f);
            else {
                a: {
                    if (f && "number" == typeof f.length) {
                        if (_.na(f)) {
                            var g = "function" == typeof f.item || "string" == typeof f.item;
                            break a
                        }
                        if ("function" === typeof f) {
                            g = "function" == typeof f.item;
                            break a
                        }
                    }
                    g = !1
                }
                _.Us(g ? la(f) : f, d)
            }
        }
    };
    _.lx = function(a, b) {
        b = String(b);
        "application/xhtml+xml" === a.contentType && (b = b.toLowerCase());
        return a.createElement(b)
    };
    _.gx = function(a) {
        return "CSS1Compat" == a.compatMode
    };
    _.mx = function(a) {
        return a && a.parentNode ? a.parentNode.removeChild(a) : null
    };
    _.nx = function(a) {
        var b;
        if (Sw && (b = a.parentElement)) return b;
        b = a.parentNode;
        return _.na(b) && 1 == b.nodeType ? b : null
    };
    le = function(a) {
        var b, c = arguments.length;
        if (!c) return null;
        if (1 == c) return arguments[0];
        var d = [],
            e = Infinity;
        for (b = 0; b < c; b++) {
            for (var f = [], g = arguments[b]; g;) f.unshift(g), g = g.parentNode;
            d.push(f);
            e = Math.min(e, f.length)
        }
        f = null;
        for (b = 0; b < e; b++) {
            g = d[0][b];
            for (var h = 1; h < c; h++)
                if (g != d[h][b]) return f;
            f = g
        }
        return f
    };
    _.cx = function(a) {
        return 9 == a.nodeType ? a : a.ownerDocument || a.document
    };
    oe = function(a) {
        try {
            return a.contentWindow || (a.contentDocument ? _.jx(a.contentDocument) : null)
        } catch (b) {}
        return null
    };
    _.bx = function(a) {
        this.j = a || _.q.document || document
    };
    _.aa = _.bx.prototype;
    _.aa.jh = function(a) {
        return "string" === typeof a ? this.j.getElementById(a) : a
    };
    _.aa.Mi = _.bx.prototype.jh;
    _.aa.getElementsByTagName = function(a, b) {
        return (b || this.j).getElementsByTagName(String(a))
    };
    _.aa.createElement = function(a) {
        return _.lx(this.j, a)
    };
    _.aa.createTextNode = function(a) {
        return this.j.createTextNode(String(a))
    };
    _.aa.append = function(a, b) {
        kx(_.cx(a), a, arguments)
    };
    _.aa.og = _.mx;
    var ox = function() {
        return Ka && La ? !La.mobile && (Pa("iPad") || Pa("Android") || Pa("Silk")) : Pa("iPad") || Pa("Android") && !Pa("Mobile") || Pa("Silk")
    };
    var qx, Bl, rx, dl;
    _.px = RegExp("^(?:([^:/?#.]+):)?(?://(?:([^\\\\/?#]*)@)?([^\\\\/?#]*?)(?::([0-9]+))?(?=[\\\\/?#]|$))?([^?#]+)?(?:\\?([^#]*))?(?:#([\\s\\S]*))?$");
    qx = function(a) {
        return a ? decodeURI(a) : a
    };
    Bl = function(a, b, c) {
        if (Array.isArray(b))
            for (var d = 0; d < b.length; d++) Bl(a, String(b[d]), c);
        else null != b && c.push(a + ("" === b ? "" : "=" + encodeURIComponent(String(b))))
    };
    rx = /#|$/;
    dl = function(a, b) {
        var c = a.search(rx);
        a: {
            var d = 0;
            for (var e = b.length; 0 <= (d = a.indexOf(b, d)) && d < c;) {
                var f = a.charCodeAt(d - 1);
                if (38 == f || 63 == f)
                    if (f = a.charCodeAt(d + e), !f || 61 == f || 38 == f || 35 == f) break a;
                d += e + 1
            }
            d = -1
        }
        if (0 > d) return null;
        e = a.indexOf("&", d);
        if (0 > e || e > c) e = c;
        d += b.length + 1;
        return decodeURIComponent(a.slice(d, -1 !== e ? e : 0).replace(/\+/g, " "))
    };
    var me, wg, sx, xg, bl, jj, xm, Ve, Or, ux, vx, kj, wx, xx, yx, zx, Ax, Bx, Cx, Dx, Ex, Jj, Lj, Kj, Fx, Gx, Ix, Jx, Kx, Lx, Mx, sf, Nx, ao, qm, hm, Hl, Ox;
    _.ne = function(a) {
        try {
            return !!a && null != a.location.href && Tt(a, "foo")
        } catch (b) {
            return !1
        }
    };
    me = function(a, b, c, d) {
        b = void 0 === b ? !1 : b;
        d = void 0 === d ? _.q : d;
        c = (void 0 === c ? 0 : c) ? sx(d) : d;
        for (d = 0; c && 40 > d++ && (!b && !_.ne(c) || !a(c));) c = sx(c)
    };
    wg = function() {
        var a = window;
        me(function(b) {
            a = b;
            return !1
        });
        return a
    };
    sx = function(a) {
        try {
            var b = a.parent;
            if (b && b != a) return b
        } catch (c) {}
        return null
    };
    xg = function(a) {
        return _.ne(a.top) ? a.top : null
    };
    bl = function(a, b) {
        var c = _.ze("SCRIPT", a);
        lb(c, b);
        return (a = a.getElementsByTagName("script")[0]) && a.parentNode ? (a.parentNode.insertBefore(c, a), c) : null
    };
    jj = function(a, b) {
        return b.getComputedStyle ? b.getComputedStyle(a, null) : a.currentStyle
    };
    _.Ue = function() {
        if (!_.v.globalThis.crypto) return Math.random();
        try {
            var a = new Uint32Array(1);
            _.v.globalThis.crypto.getRandomValues(a);
            return a[0] / 65536 / 65536
        } catch (b) {
            return Math.random()
        }
    };
    _.El = function(a, b) {
        if (a)
            for (var c in a) Object.prototype.hasOwnProperty.call(a, c) && b(a[c], c, a)
    };
    _.tx = function(a) {
        var b = [];
        _.El(a, function(c) {
            b.push(c)
        });
        return b
    };
    xm = function(a, b) {
        return Ga(a, function(c, d) {
            return Object.prototype.hasOwnProperty.call(a, d) && b(c, d)
        })
    };
    _.Ni = function(a) {
        var b = a.length;
        if (0 == b) return 0;
        for (var c = 305419896, d = 0; d < b; d++) c ^= (c << 5) + (c >> 2) + a.charCodeAt(d) & 4294967295;
        return 0 < c ? c : 4294967296 + c
    };
    _.Te = ij(function() {
        return _.Lh(["Google Web Preview", "Mediapartners-Google", "Google-Read-Aloud", "Google-Adwords"], ux) || 1E-4 > Math.random()
    });
    Ve = function(a, b) {
        try {
            if (a) return a.setItem("google_experiment_mod", b), b
        } catch (c) {}
        return null
    };
    Or = ij(function() {
        return ux("MSIE")
    });
    ux = function(a) {
        return Ma(Ja(), a)
    };
    vx = /^([0-9.]+)px$/;
    kj = function(a) {
        return (a = vx.exec(a)) ? +a[1] : null
    };
    wx = function() {
        var a = window;
        try {
            for (var b = null; b != a; b = a, a = a.parent) switch (a.location.protocol) {
                case "https:":
                    return !0;
                case "file:":
                    return !0;
                case "http:":
                    return !1
            }
        } catch (c) {}
        return !0
    };
    xx = function(a) {
        if (!a) return "";
        var b = RegExp(".*[&#?]google_debug(=[^&]*)?(&.*)?$");
        try {
            var c = b.exec(decodeURIComponent(a));
            if (c) return c[1] && 1 < c[1].length ? c[1].substring(1) : "true"
        } catch (d) {}
        return ""
    };
    yx = {
        Qi: "allow-forms",
        Ri: "allow-modals",
        Si: "allow-orientation-lock",
        Ti: "allow-pointer-lock",
        Ui: "allow-popups",
        Vi: "allow-popups-to-escape-sandbox",
        Wi: "allow-presentation",
        Xi: "allow-same-origin",
        Yi: "allow-scripts",
        Zi: "allow-top-navigation",
        aj: "allow-top-navigation-by-user-activation"
    };
    zx = ij(function() {
        return _.tx(yx)
    });
    Ax = function(a) {
        var b = zx();
        return a.length ? _.Jh(b, function(c) {
            return !(0 <= _.ha(a, c))
        }) : b
    };
    Bx = function() {
        var a = _.ze("IFRAME"),
            b = {};
        _.Us(zx(), function(c) {
            a.sandbox && a.sandbox.supports && a.sandbox.supports(c) && (b[c] = !0)
        });
        return b
    };
    Cx = function(a) {
        a = a && a.toString && a.toString();
        return "string" === typeof a && Ma(a, "[native code]")
    };
    Dx = function(a, b) {
        for (var c = 0; 50 > c; ++c) {
            try {
                var d = !(!a.frames || !a.frames[b])
            } catch (e) {
                d = !1
            }
            if (d) return a;
            if (!(a = sx(a))) break
        }
        return null
    };
    Ex = function(a) {
        if (!a || !a.frames) return null;
        if (a.frames.google_ads_top_frame) return a.frames.google_ads_top_frame.frameElement;
        try {
            var b = a.document,
                c = b.head,
                d, e = null != (d = b.body) ? d : null == c ? void 0 : c.parentElement;
            if (e) {
                var f = _.ze("IFRAME");
                f.name = "google_ads_top_frame";
                f.id = "google_ads_top_frame";
                f.style.display = "none";
                f.style.position = "fixed";
                f.style.left = "-999px";
                f.style.top = "-999px";
                f.style.width = "0px";
                f.style.height = "0px";
                e.appendChild(f);
                return f
            }
        } catch (g) {}
        return null
    };
    _.Tm = ij(function() {
        return (Ka && La ? La.mobile : !ox() && (Pa("iPod") || Pa("iPhone") || Pa("Android") || Pa("IEMobile"))) ? 2 : ox() ? 1 : 0
    });
    Jj = function(a, b) {
        var c;
        for (c = void 0 === c ? 100 : c; a && c--;) {
            if (a == b) return !0;
            a = a.parentElement
        }
        return !1
    };
    _.tj = function(a, b) {
        _.El(b, function(c, d) {
            a.style.setProperty(d, c, "important")
        })
    };
    Lj = function(a, b, c) {
        for (c = void 0 === c ? 100 : c; a && c-- && !1 !== b(a);) a = a.parentElement
    };
    Kj = function(a, b) {
        for (var c = 100; a && c--;) {
            var d = jj(a, window);
            if (d) {
                if (b(d)) return !0;
                a = a.parentElement
            }
        }
        return !1
    };
    Fx = function(a) {
        if (!a) return null;
        a = a.transform;
        if (!a) return null;
        a = a.replace(/^.*\(([0-9., -]+)\)$/, "$1").split(/, /);
        return 6 != a.length ? null : _.xd(a, parseFloat)
    };
    Gx = {};
    _.Hx = (Gx["http://googleads.g.doubleclick.net"] = !0, Gx["http://pagead2.googlesyndication.com"] = !0, Gx["https://googleads.g.doubleclick.net"] = !0, Gx["https://pagead2.googlesyndication.com"] = !0, Gx);
    Ix = function(a) {
        _.q.console && _.q.console.warn && _.q.console.warn(a)
    };
    Jx = [];
    Kx = function() {
        var a = Jx;
        Jx = [];
        a = _.x(a);
        for (var b = a.next(); !b.done; b = a.next()) {
            b = b.value;
            try {
                b()
            } catch (c) {}
        }
    };
    Lx = function(a) {
        return a.replace(/\\(n|r|\\)/g, function(b, c) {
            return "n" == c ? "\n" : "r" == c ? "\r" : "\\"
        })
    };
    Mx = function() {
        return Math.floor(Math.random() * Math.pow(2, 52))
    };
    sf = function(a) {
        if ("number" !== typeof a.goog_pvsid) try {
            Object.defineProperty(a, "goog_pvsid", {
                value: Mx(),
                configurable: !1
            })
        } catch (b) {}
        return Number(a.goog_pvsid) || -1
    };
    Nx = function(a, b) {
        pe(_.jx(_.cx(a)), a, b)
    };
    ao = function(a, b) {
        "complete" === a.readyState || "interactive" === a.readyState ? (Jx.push(b), 1 == Jx.length && (_.v.Promise ? _.v.Promise.resolve().then(Kx) : window.setImmediate ? setImmediate(Kx) : setTimeout(Kx, 0))) : a.addEventListener("DOMContentLoaded", b)
    };
    qm = function(a) {
        return "number" === typeof a && isFinite(a) && 0 == a % 1 && 0 < a
    };
    hm = function(a) {
        return 0 === a || qm(a)
    };
    Hl = function(a) {
        try {
            var b = JSON.stringify(a)
        } catch (c) {}
        return b || String(a)
    };
    _.ze = function(a, b) {
        b = void 0 === b ? document : b;
        return b.createElement(String(a).toLowerCase())
    };
    Ox = function(a) {
        for (var b = a; a && a != a.parent;) a = a.parent, _.ne(a) && (b = a);
        return b
    };
    _.Px = function(a, b, c, d) {
        this.top = a;
        this.right = b;
        this.bottom = c;
        this.left = d
    };
    _.Px.prototype.getWidth = function() {
        return this.right - this.left
    };
    _.Px.prototype.getHeight = function() {
        return this.bottom - this.top
    };
    _.Qx = function(a) {
        return new _.Px(a.top, a.right, a.bottom, a.left)
    };
    _.Px.prototype.ceil = function() {
        this.top = Math.ceil(this.top);
        this.right = Math.ceil(this.right);
        this.bottom = Math.ceil(this.bottom);
        this.left = Math.ceil(this.left);
        return this
    };
    _.Px.prototype.floor = function() {
        this.top = Math.floor(this.top);
        this.right = Math.floor(this.right);
        this.bottom = Math.floor(this.bottom);
        this.left = Math.floor(this.left);
        return this
    };
    _.Px.prototype.round = function() {
        this.top = Math.round(this.top);
        this.right = Math.round(this.right);
        this.bottom = Math.round(this.bottom);
        this.left = Math.round(this.left);
        return this
    };
    var Rx = function(a, b, c, d) {
            this.left = a;
            this.top = b;
            this.width = c;
            this.height = d
        },
        Sx = function(a) {
            return new _.Px(a.top, a.left + a.width, a.top + a.height, a.left)
        },
        Tx = function(a, b) {
            var c = Math.max(a.left, b.left),
                d = Math.min(a.left + a.width, b.left + b.width);
            if (c <= d) {
                var e = Math.max(a.top, b.top);
                a = Math.min(a.top + a.height, b.top + b.height);
                if (e <= a) return new Rx(c, e, d - c, a - e)
            }
            return null
        };
    Rx.prototype.ceil = function() {
        this.left = Math.ceil(this.left);
        this.top = Math.ceil(this.top);
        this.width = Math.ceil(this.width);
        this.height = Math.ceil(this.height);
        return this
    };
    Rx.prototype.floor = function() {
        this.left = Math.floor(this.left);
        this.top = Math.floor(this.top);
        this.width = Math.floor(this.width);
        this.height = Math.floor(this.height);
        return this
    };
    Rx.prototype.round = function() {
        this.left = Math.round(this.left);
        this.top = Math.round(this.top);
        this.width = Math.round(this.width);
        this.height = Math.round(this.height);
        return this
    };
    var Ux = function(a) {
        return (a = void 0 === a ? qe() : a) ? _.ne(a.master) ? a.master : null : null
    };
    var Xx, Fh, Xi, Zx, $x, Ui;
    _.Wx = function(a, b, c) {
        if ("string" === typeof b)(b = _.Vx(a, b)) && (a.style[b] = c);
        else
            for (var d in b) {
                c = a;
                var e = b[d],
                    f = _.Vx(c, d);
                f && (c.style[f] = e)
            }
    };
    Xx = {};
    _.Vx = function(a, b) {
        var c = Xx[b];
        if (!c) {
            var d = _.$w(b);
            c = d;
            void 0 === a.style[d] && (d = (Yt ? "Webkit" : Xt ? "Moz" : _.Vt ? "ms" : null) + ax(d), void 0 !== a.style[d] && (c = d));
            Xx[b] = c
        }
        return c
    };
    _.Yx = function(a, b) {
        var c = _.cx(a);
        return c.defaultView && c.defaultView.getComputedStyle && (a = c.defaultView.getComputedStyle(a, null)) ? a[b] || a.getPropertyValue(b) || "" : ""
    };
    Fh = function(a, b) {
        return _.Yx(a, b) || (a.currentStyle ? a.currentStyle[b] : null) || a.style && a.style[b]
    };
    Xi = function(a) {
        try {
            return a.getBoundingClientRect()
        } catch (b) {
            return {
                left: 0,
                top: 0,
                right: 0,
                bottom: 0
            }
        }
    };
    Zx = function(a) {
        if (_.Vt && !(8 <= Number(gu))) return a.offsetParent;
        var b = _.cx(a),
            c = Fh(a, "position"),
            d = "fixed" == c || "absolute" == c;
        for (a = a.parentNode; a && a != b; a = a.parentNode)
            if (11 == a.nodeType && a.host && (a = a.host), c = Fh(a, "position"), d = d && "static" == c && a != b.documentElement && a != b.body, !d && (a.scrollWidth > a.clientWidth || a.scrollHeight > a.clientHeight || "fixed" == c || "absolute" == c || "relative" == c)) return a;
        return null
    };
    $x = function(a) {
        var b = _.cx(a),
            c = new _.Vi(0, 0);
        var d = b ? _.cx(b) : document;
        d = !_.Vt || 9 <= Number(gu) || _.gx(dx(d).j) ? d.documentElement : d.body;
        if (a == d) return c;
        a = Xi(a);
        d = dx(b).j;
        b = ix(d);
        d = d.parentWindow || d.defaultView;
        b = _.Vt && d.pageYOffset != b.scrollTop ? new _.Vi(b.scrollLeft, b.scrollTop) : new _.Vi(d.pageXOffset || b.scrollLeft, d.pageYOffset || b.scrollTop);
        c.x = a.left + b.x;
        c.y = a.top + b.y;
        return c
    };
    Ui = function(a, b) {
        var c = new _.Vi(0, 0),
            d = _.jx(_.cx(a));
        if (!Tt(d, "parent")) return c;
        do {
            var e = d == b ? $x(a) : _.ay(a);
            c.x += e.x;
            c.y += e.y
        } while (d && d != b && d != d.parent && (a = d.frameElement) && (d = d.parent));
        return c
    };
    _.ay = function(a) {
        a = Xi(a);
        return new _.Vi(a.left, a.top)
    };
    _.by = function(a, b) {
        "number" == typeof a && (a = (b ? Math.round(a) : a) + "px");
        return a
    };
    _.Gh = function(a, b) {
        if ("none" != Fh(b, "display")) return a(b);
        var c = b.style,
            d = c.display,
            e = c.visibility,
            f = c.position;
        c.visibility = "hidden";
        c.position = "absolute";
        c.display = "inline";
        a = a(b);
        c.display = d;
        c.position = f;
        c.visibility = e;
        return a
    };
    _.Hh = function(a) {
        var b = a.offsetWidth,
            c = a.offsetHeight,
            d = Yt && !b && !c;
        return (void 0 === b || d) && a.getBoundingClientRect ? (a = Xi(a), new _.Yi(a.right - a.left, a.bottom - a.top)) : new _.Yi(b, c)
    };
    var Fj = function(a) {
        a = Ux(qe(a)) || a;
        a = a.google_unique_id;
        return "number" === typeof a ? a : 0
    };
    var cy = function(a, b) {
        if (_.v.globalThis.fetch) _.v.globalThis.fetch(a, {
            method: "POST",
            body: b,
            keepalive: 65536 > b.length,
            credentials: "omit",
            mode: "no-cors",
            redirect: "follow"
        }).catch(function() {});
        else {
            var c = new XMLHttpRequest;
            c.open("POST", a, !0);
            c.send(b)
        }
    };
    var dy = function(a) {
        _.T.call(this, a)
    };
    _.P(dy, _.T);
    var ey = function(a) {
        _.T.call(this, a)
    };
    _.P(ey, _.T);
    var ai = function(a) {
        _.T.call(this, a)
    };
    _.P(ai, _.T);
    var Wh = function(a) {
        _.T.call(this, a)
    };
    _.P(Wh, _.T);
    var Th = function(a) {
        _.T.call(this, a)
    };
    _.P(Th, _.T);
    var fy = function(a) {
        _.T.call(this, a)
    };
    _.P(fy, _.T);
    var Sh = function(a) {
        _.T.call(this, a, -1, gy)
    };
    _.P(Sh, _.T);
    Sh.prototype.getTagSessionCorrelator = function() {
        return _.$e(this, 2)
    };
    var gy = [4],
        Yh = [6, 7, 8, 9, 11];
    var ki = function(a) {
        _.T.call(this, a, -1, hy)
    };
    _.P(ki, _.T);
    var hy = [3];
    var ii = function(a) {
        _.T.call(this, a, -1, iy)
    };
    _.P(ii, _.T);
    var iy = [4, 5];
    var hi = function(a) {
        _.T.call(this, a, -1, jy)
    };
    _.P(hi, _.T);
    hi.prototype.getTagSessionCorrelator = function() {
        return _.$e(this, 1)
    };
    var jy = [2];
    var gi = function(a) {
        _.T.call(this, a)
    };
    _.P(gi, _.T);
    var ni = [4];
    _.U = function() {
        this.H = this.H;
        this.ia = this.ia
    };
    _.U.prototype.H = !1;
    _.U.prototype.Ha = function() {
        this.H || (this.H = !0, this.o())
    };
    _.Nn = function(a, b) {
        _.go(a, _.zs(xe, b))
    };
    _.go = function(a, b) {
        a.H ? b() : (a.ia || (a.ia = []), a.ia.push(b))
    };
    _.U.prototype.o = function() {
        if (this.ia)
            for (; this.ia.length;) this.ia.shift()()
    };
    var ky = function(a, b, c, d, e) {
            this.l = a;
            this.B = b;
            this.I = c;
            this.m = d;
            this.H = e;
            this.j = [];
            this.o = null
        },
        ly = function(a) {
            null !== a.o && (clearTimeout(a.o), a.o = null);
            if (a.j.length) {
                var b = te(a.j);
                a.B(a.l + "?e=1", b);
                a.j = []
            }
        };
    ky.prototype.Oe = function() {
        var a = _.wb.apply(0, arguments),
            b = this;
        this.H && 65536 <= te(this.j.concat(a)).length && ly(this);
        this.j.push.apply(this.j, _.ue(a));
        this.j.length >= this.m && ly(this);
        this.j.length && null === this.o && (this.o = setTimeout(function() {
            ly(b)
        }, this.I))
    };
    _.Rr = function(a, b, c) {
        ky.call(this, "https://pagead2.googlesyndication.com/pagead/ping", cy, void 0 === a ? 1E3 : a, void 0 === b ? 100 : b, (void 0 === c ? !1 : c) && !!_.v.globalThis.fetch)
    };
    _.P(_.Rr, ky);
    var my = function(a, b) {
            this.j = a;
            this.defaultValue = void 0 === b ? !1 : b
        },
        ny = function(a, b) {
            this.j = a;
            this.defaultValue = void 0 === b ? 0 : b
        },
        oy = function(a, b) {
            this.j = a;
            this.defaultValue = void 0 === b ? "" : b
        },
        py = function(a) {
            var b = void 0 === b ? [] : b;
            this.j = a;
            this.defaultValue = b
        };
    var qy, ry, sy, Gj, ty, Ao, uy, vy, Cn, oo, wy, xy, yy, zy, Ay, By, Cy, Dy, Pp, Ey, Fy, Gy, Hy, Iy, Jy, Ky, Ly, aq, My, tr, Xq, Ny, Oy, cg, Py, Qy, Xp, Ry, Sy, Om, Ty, Uy, Vy, ci, Wy, Xy, Yy, Zy, $y, az, bz, Vp, cz, dz, ez, fz, Al, xl, gz, bj, hz, ug, Np, qn, kz, lz, mz, pm, nz, oz, Qr, bk, pz, qz, rz, sz, tz, uz, vz, wz, xz, yz, zz, Az, Bz, Cz, $f, Zf, Dz, Ez, Ir, Jr, Hm, Kr, Hr, Fz, Gz, Tp, Hz, Rz;
    qy = new my(1122, !0);
    ry = new oy(3);
    sy = new py(481);
    Gj = new ny(7, .1);
    ty = new my(212);
    Ao = new ny(474069761);
    uy = new ny(455645877);
    vy = new ny(462420536);
    Cn = new my(476475256);
    oo = new my(514499457, !0);
    wy = new ny(448338836, .01);
    xy = new ny(427198696, 1);
    yy = new ny(438663674);
    zy = new my(513922122);
    Ay = new my(23);
    By = new my(369430);
    Cy = new my(510178293, !0);
    Dy = new my(513037477);
    Pp = new my(508533393);
    Ey = new ny(408380992, .01);
    Fy = new ny(377289019, 1E4);
    Gy = new ny(488);
    Hy = new ny(529, 20);
    Iy = new oy(10);
    Jy = new my(489217043);
    Ky = new my(495013820);
    Ly = new ny(428094087);
    aq = new ny(447000223, .01);
    My = new my(360245597, !0);
    tr = new my(520092823);
    Xq = new my(485209195);
    Ny = new my(499996722);
    Oy = new my(471855283);
    cg = new my(465118388);
    Py = new my(220);
    Qy = new my(200);
    Xp = new my(494337909);
    Ry = new my(503331120);
    Sy = new my(512833161);
    Om = new ny(492, .01);
    Ty = new ny(363650251);
    Uy = new ny(474872234);
    Vy = new my(83);
    ci = new my(85);
    Wy = new my(437061931, !0);
    Xy = new py(466086960);
    Yy = new my(45388169);
    Zy = new ny(398776877, 6E4);
    $y = new ny(374201269, 6E4);
    az = new ny(371364213, 6E4);
    bz = new ny(376149757, .0025);
    Vp = new my(517454235);
    cz = new my(453275889);
    dz = new my(377936516, !0);
    ez = new my(503519166);
    fz = new ny(24);
    Al = new py(1);
    xl = new oy(2, "1-0-40");
    gz = new my(441529989);
    bj = new ny(504377075);
    hz = new my(514876375);
    ug = new my(516945042, !0);
    Np = new my(513069161);
    _.iz = new ny(506394061, 100);
    _.jz = new ny(506394060);
    qn = new py(489);
    kz = new my(392065905);
    lz = new ny(360245595, 500);
    mz = new my(513312887);
    pm = new my(45397804, !0);
    nz = new my(45398607, !0);
    oz = new my(424117738);
    Qr = new ny(397316938, 1E3);
    bk = new my(507033477, !0);
    pz = new my(518989998);
    qz = new my(399705355);
    rz = new ny(514795754);
    sz = new my(517255869);
    tz = new my(515410344);
    uz = new my(491464096, !0);
    vz = new my(501);
    wz = new my(439828594);
    xz = new my(483962503);
    yz = new ny(494575051);
    zz = new py(489560439);
    Az = new py(505762507);
    Bz = new my(453);
    Cz = new my(454);
    $f = new py(471270390);
    Zf = new my(478009624);
    Dz = new my(512522806);
    Ez = new my(506738118);
    Ir = new my(77);
    Jr = new my(78);
    Hm = new my(309);
    Kr = new my(80);
    Hr = new my(76);
    Fz = new my(84);
    Gz = new my(1958);
    Tp = new my(1973);
    Hz = new my(188);
    _.Iz = new ny(1972);
    _.Jz = new my(1162);
    _.Kz = new ny(1157);
    _.Lz = new ny(1119, 300);
    _.Mz = new ny(1103);
    _.Nz = new my(501545961);
    _.Oz = new ny(1116, 300);
    _.Pz = new my(506619840, !0);
    _.Qz = new my(506852289);
    Rz = new my(485990406);
    var Sz = function(a, b, c, d, e, f) {
            try {
                var g = a.j,
                    h = _.ze("SCRIPT", g);
                h.async = !0;
                lb(h, b);
                g.head.appendChild(h);
                h.addEventListener("load", function() {
                    e();
                    d && g.head.removeChild(h)
                });
                h.addEventListener("error", function() {
                    0 < c ? Sz(a, b, c - 1, d, e, f) : (d && g.head.removeChild(h), f())
                })
            } catch (k) {
                f()
            }
        },
        Tz = function(a, b, c, d) {
            c = void 0 === c ? function() {} : c;
            d = void 0 === d ? function() {} : d;
            Sz(dx(a), b, 0, !1, c, d)
        };
    Fa({
        tj: 0,
        sj: 1,
        pj: 2,
        kj: 3,
        qj: 4,
        lj: 5,
        rj: 6,
        nj: 7,
        oj: 8,
        jj: 9,
        mj: 10
    }).map(function(a) {
        return Number(a)
    });
    Fa({
        vj: 0,
        wj: 1,
        uj: 2
    }).map(function(a) {
        return Number(a)
    });
    var Uz = function(a, b) {
        this.j = ye(a);
        this.o = b
    };
    Uz.prototype[_.u(_.v.Symbol, "iterator")] = function() {
        return this
    };
    Uz.prototype.next = function() {
        var a = this.j.next();
        return {
            value: a.done ? void 0 : this.o.call(void 0, a.value),
            done: a.done
        }
    };
    var Vz = function(a, b) {
            return new Uz(a, b)
        },
        Wz = function(a) {
            this.o = a;
            this.j = 0
        };
    Wz.prototype[_.u(_.v.Symbol, "iterator")] = function() {
        return this
    };
    Wz.prototype.next = function() {
        for (; this.j < this.o.length;) {
            var a = this.o[this.j].next();
            if (!a.done) return a;
            this.j++
        }
        return {
            done: !0
        }
    };
    var Xz = function() {
        return new Wz(_.wb.apply(0, arguments).map(ye))
    };
    var Yz = window.URL,
        Zz;
    try {
        new Yz("http://example.com"), Zz = !0
    } catch (a) {
        Zz = !1
    }
    var $z = Zz,
        aA = function(a) {
            this.j = new _.v.Map;
            0 == a.indexOf("?") && (a = a.substring(1));
            a = _.x(a.split("&"));
            for (var b = a.next(); !b.done; b = a.next()) {
                var c = b.value;
                b = c;
                var d = "";
                c = c.split("=");
                1 < c.length && (b = decodeURIComponent(c[0].replace("+", " ")), d = decodeURIComponent(c[1].replace("+", " ")));
                c = this.j.get(b);
                null == c && (c = [], this.j.set(b, c));
                c.push(d)
            }
        };
    aA.prototype.get = function(a) {
        return (a = this.j.get(a)) && a.length ? a[0] : null
    };
    aA.prototype.getAll = function(a) {
        return [].concat(_.ue(this.j.get(a) || []))
    };
    aA.prototype.has = function(a) {
        return this.j.has(a)
    };
    aA.prototype[_.u(_.v.Symbol, "iterator")] = function() {
        return Xz.apply(null, _.ue(Vz(this.j, function(a) {
            var b = a[0];
            return Vz(a[1], function(c) {
                return [b, c]
            })
        })))
    };
    aA.prototype.toString = function() {
        return bA(this)
    };
    var bA = function(a) {
            var b = function(c) {
                return encodeURIComponent(c).replace(/[!()~']|(%20)/g, function(d) {
                    return {
                        "!": "%21",
                        "(": "%28",
                        ")": "%29",
                        "%20": "+",
                        "'": "%27",
                        "~": "%7E"
                    }[d]
                })
            };
            return _.u(Array, "from").call(Array, a, function(c) {
                return b(c[0]) + "=" + b(c[1])
            }).join("&")
        },
        dA = function(a) {
            var b = _.lx(document, "A");
            try {
                Uw(b, tb(a));
                var c = b.protocol
            } catch (e) {
                throw Error(a + " is not a valid URL.");
            }
            if ("" === c || ":" === c || ":" != c[c.length - 1]) throw Error(a + " is not a valid URL.");
            if (!cA.has(c)) throw Error(a + " is not a valid URL.");
            if (!b.hostname) throw Error(a + " is not a valid URL.");
            var d = b.href;
            a = {
                href: d,
                protocol: b.protocol,
                username: "",
                password: "",
                hostname: b.hostname,
                pathname: "/" + b.pathname,
                search: b.search,
                hash: b.hash,
                toString: function() {
                    return d
                }
            };
            cA.get(b.protocol) === b.port ? (a.host = a.hostname, a.port = "", a.origin = a.protocol + "//" + a.hostname) : (a.host = b.host, a.port = b.port, a.origin = a.protocol + "//" + a.hostname + ":" + a.port);
            return a
        },
        eA = function(a) {
            if ($z) {
                try {
                    var b = new Yz(a)
                } catch (d) {
                    throw Error(a + " is not a valid URL.");
                }
                var c = cA.get(b.protocol);
                if (!c) throw Error(a + " is not a valid URL.");
                if (!b.hostname) throw Error(a + " is not a valid URL.");
                "null" == b.origin && (a = {
                    href: b.href,
                    protocol: b.protocol,
                    username: "",
                    password: "",
                    host: b.host,
                    port: b.port,
                    hostname: b.hostname,
                    pathname: b.pathname,
                    search: b.search,
                    hash: b.hash
                }, a.origin = c === b.port ? b.protocol + "//" + b.hostname : b.protocol + "//" + b.hostname + ":" + b.port, b = a);
                return b
            }
            return dA(a)
        },
        cA = new _.v.Map([
            ["http:", "80"],
            ["https:", "443"],
            ["ws:", "80"],
            ["wss:", "443"],
            ["ftp:", "21"]
        ]),
        fA = function(a) {
            return $z && a.searchParams ? a.searchParams : new aA(a.search)
        };
    var gA = function(a) {
            var b = fA(eA(a.location.href));
            a = b.get("fcconsent");
            b = b.get("fc");
            return "alwaysshow" === b ? b : "alwaysshow" === a ? a : null
        },
        hA = function(a) {
            a = fA(eA(a.location.href)).get("fctype");
            return -1 !== ["ab", "gdpr", "consent", "ccpa", "monetization"].indexOf(a) ? a : null
        };
    var iA = function(a) {
        var b = a.document,
            c = function() {
                if (!a.frames.googlefcPresent)
                    if (b.body) {
                        var d = _.ze("IFRAME", b);
                        d.style.display = "none";
                        d.style.width = "0px";
                        d.style.height = "0px";
                        d.style.border = "none";
                        d.style.zIndex = "-1000";
                        d.style.left = "-1000px";
                        d.style.top = "-1000px";
                        d.name = "googlefcPresent";
                        b.body.appendChild(d)
                    } else a.setTimeout(c, 5)
            };
        c()
    };
    var jA = function(a, b, c, d, e) {
            Be(a, b, void 0 === c ? null : c, void 0 === d ? !1 : d, void 0 === e ? !1 : e)
        },
        Xe = function(a, b) {
            var c = void 0 === c ? !1 : c;
            var d = "https://pagead2.googlesyndication.com/pagead/gen_204?id=" + b;
            _.El(a, function(e, f) {
                if (e || 0 === e) d += "&" + f + "=" + encodeURIComponent("" + e)
            });
            Wo(d, c)
        },
        Wo = function(a, b) {
            var c = window;
            b = void 0 === b ? !1 : b;
            var d = void 0 === d ? !1 : d;
            c.fetch ? (b = {
                keepalive: !0,
                credentials: "include",
                redirect: "follow",
                method: "get",
                mode: "no-cors"
            }, d && (b.mode = "cors", b.headers = {
                "Attribution-Reporting-Eligible": "event-source"
            }), c.fetch(a, b)) : jA(c, a, void 0, b, d)
        };
    var kA = function(a) {
            void 0 !== a.addtlConsent && "string" !== typeof a.addtlConsent && (a.addtlConsent = void 0);
            void 0 !== a.gdprApplies && "boolean" !== typeof a.gdprApplies && (a.gdprApplies = void 0);
            return void 0 !== a.tcString && "string" !== typeof a.tcString || void 0 !== a.listenerId && "number" !== typeof a.listenerId ? 2 : a.cmpStatus && "error" !== a.cmpStatus ? 0 : 3
        },
        lA = function(a, b) {
            b = void 0 === b ? {} : b;
            _.U.call(this);
            this.m = a;
            this.j = null;
            this.l = {};
            this.N = 0;
            var c;
            this.A = null != (c = b.Wa) ? c : 500;
            var d;
            this.I = null != (d = b.yg) ? d : !1;
            this.B = null
        };
    _.P(lA, _.U);
    lA.prototype.o = function() {
        this.l = {};
        this.B && (_.Ae(this.m, "message", this.B), delete this.B);
        delete this.l;
        delete this.m;
        delete this.j;
        _.U.prototype.o.call(this)
    };
    var nA = function(a) {
        return "function" === typeof a.m.__tcfapi || null != mA(a)
    };
    lA.prototype.addEventListener = function(a) {
        var b = this,
            c = {
                internalBlockOnErrors: this.I
            },
            d = _.Rs(function() {
                return a(c)
            }),
            e = 0; - 1 !== this.A && (e = setTimeout(function() {
            c.tcString = "tcunavailable";
            c.internalErrorState = 1;
            d()
        }, this.A));
        var f = function(g, h) {
            clearTimeout(e);
            g ? (c = g, c.internalErrorState = kA(c), c.internalBlockOnErrors = b.I, h && 0 === c.internalErrorState || (c.tcString = "tcunavailable", h || (c.internalErrorState = 3))) : (c.tcString = "tcunavailable", c.internalErrorState = 3);
            a(c)
        };
        try {
            oA(this, "addEventListener", f)
        } catch (g) {
            c.tcString = "tcunavailable", c.internalErrorState = 3, e && (clearTimeout(e), e = 0), d()
        }
    };
    lA.prototype.removeEventListener = function(a) {
        a && a.listenerId && oA(this, "removeEventListener", null, a.listenerId)
    };
    var pA = function(a, b) {
            var c = void 0 === c ? "755" : c;
            a: {
                if (a.publisher && a.publisher.restrictions) {
                    var d = a.publisher.restrictions[b];
                    if (void 0 !== d) {
                        d = d[void 0 === c ? "755" : c];
                        break a
                    }
                }
                d = void 0
            }
            if (0 === d) return !1;
            a.purpose && a.vendor ? (d = a.vendor.consents, (c = !(!d || !d[void 0 === c ? "755" : c])) && "1" === b && a.purposeOneTreatment && "CH" === a.publisherCC ? b = !0 : (c && (a = a.purpose.consents, c = !(!a || !a[b])), b = c)) : b = !0;
            return b
        },
        oA = function(a, b, c, d) {
            c || (c = function() {});
            if ("function" === typeof a.m.__tcfapi) a = a.m.__tcfapi, a(b, 2, c, d);
            else if (mA(a)) {
                qA(a);
                var e = ++a.N;
                a.l[e] = c;
                a.j && (c = {}, a.j.postMessage((c.__tcfapiCall = {
                    command: b,
                    version: 2,
                    callId: e,
                    parameter: d
                }, c), "*"))
            } else c({}, !1)
        },
        mA = function(a) {
            if (a.j) return a.j;
            a.j = Dx(a.m, "__tcfapiLocator");
            return a.j
        },
        qA = function(a) {
            a.B || (a.B = function(b) {
                try {
                    var c = ("string" === typeof b.data ? JSON.parse(b.data) : b.data).__tcfapiReturn;
                    a.l[c.callId](c.returnValue, c.success)
                } catch (d) {}
            }, _.yb(a.m, "message", a.B))
        },
        rA = function(a) {
            if (!1 === a.gdprApplies) return !0;
            void 0 === a.internalErrorState && (a.internalErrorState = kA(a));
            return "error" === a.cmpStatus || 0 !== a.internalErrorState ? a.internalBlockOnErrors ? (Xe({
                e: String(a.internalErrorState)
            }, "tcfe"), !1) : !0 : "loaded" !== a.cmpStatus || "tcloaded" !== a.eventStatus && "useractioncomplete" !== a.eventStatus ? !1 : !0
        },
        sA = function(a, b) {
            return !1 === a.gdprApplies ? !0 : b.every(function(c) {
                return pA(a, c)
            })
        };
    var tA = function(a, b, c) {
            this.j = a;
            this.m = b;
            this.o = void 0 === c ? function() {} : c
        },
        uA = function(a, b, c) {
            return new tA(a, b, c)
        };
    tA.prototype.start = function() {
        if (this.j === this.j.top) try {
            iA(this.j), vA(this)
        } catch (a) {}
    };
    var vA = function(a) {
            var b = gA(a.j),
                c = hA(a.j),
                d = {};
            b = (d.fc = b, d.fctype = c, d);
            b = wA(a.m, b);
            Tz(a.j, b, function() {
                a.o(!0)
            }, function() {
                a.o(!1)
            })
        },
        wA = function(a, b) {
            var c = Ks("https://fundingchoicesmessages.google.com/i/%{id}");
            b = _.u(Object, "assign").call(Object, {}, b, {
                ers: 3
            });
            return at(Ib(c, {
                id: a
            }), b)
        };
    var xA = _.v.Promise;
    var yA = function(a) {
        this.m = a
    };
    yA.prototype.o = function(a, b, c) {
        this.m.then(function(d) {
            d.o(a, b, c)
        })
    };
    yA.prototype.j = function(a, b) {
        return this.m.then(function(c) {
            return c.j(a, b)
        })
    };
    var zA = function(a) {
        this.data = a
    };
    var AA = function(a) {
        this.m = a
    };
    AA.prototype.o = function(a, b, c) {
        c = void 0 === c ? [] : c;
        var d = new MessageChannel;
        BA(d.port1, b);
        this.m.postMessage(a, [d.port2].concat(c))
    };
    AA.prototype.j = function(a, b) {
        var c = this;
        return new xA(function(d) {
            c.o(a, d, b)
        })
    };
    var CA = function(a, b) {
            BA(a, b);
            return new AA(a)
        },
        BA = function(a, b) {
            b && (a.onmessage = function(c) {
                b(new zA(c.data, CA(c.ports[0])))
            })
        };
    var Zj = function(a) {
            var b = a.xd,
                c = void 0 === a.Xa ? "ZNWN1d" : a.Xa,
                d = void 0 === a.onMessage ? void 0 : a.onMessage,
                e = void 0 === a.Ed ? void 0 : a.Ed;
            return DA({
                destination: a.destination,
                rf: function() {
                    return b.contentWindow
                },
                Lh: EA(a.origin),
                Xa: c,
                onMessage: d,
                Ed: e
            })
        },
        DA = function(a) {
            var b = a.destination,
                c = a.rf,
                d = a.Lh,
                e = void 0 === a.Qe ? void 0 : a.Qe,
                f = a.Xa,
                g = void 0 === a.onMessage ? void 0 : a.onMessage,
                h = void 0 === a.Ed ? void 0 : a.Ed,
                k = Object.create(null);
            d.forEach(function(l) {
                k[l] = !0
            });
            return new yA(new xA(function(l, n) {
                var m = function(p) {
                    p.source && p.source === c() && !0 === k[p.origin] && (p.data.n || p.data) === f && (b.removeEventListener("message", m, !1), e && p.data.t !== e ? n(Error('Token mismatch while establishing channel "' + f + '". Expected ' + e + ", but received " + p.data.t + ".")) : (l(CA(p.ports[0], g)), h && h(p)))
                };
                b.addEventListener("message", m, !1)
            }))
        },
        EA = function(a) {
            a = "string" === typeof a ? [a] : a;
            var b = Object.create(null);
            a.forEach(function(c) {
                if ("null" === c) throw Error("Receiving from null origin not allowed without token verification. Please use NullOriginConnector.");
                b[c] = !0
            });
            return a
        };
    var ji = (0, B.te)(function(a) {
        return "string" === typeof a
    }, "string");
    var FA = navigator,
        GA = function(a) {
            var b = 1,
                c;
            if (void 0 != a && "" != a)
                for (b = 0, c = a.length - 1; 0 <= c; c--) {
                    var d = a.charCodeAt(c);
                    b = (b << 6 & 268435455) + d + (d << 14);
                    d = b & 266338304;
                    b = 0 != d ? b ^ d >> 21 : b
                }
            return b
        },
        HA = function(a, b) {
            if (!a || "none" == a) return 1;
            a = String(a);
            "auto" == a && (a = b, "www." == a.substring(0, 4) && (a = a.substring(4, a.length)));
            return GA(a.toLowerCase())
        },
        IA = RegExp("^\\s*_ga=\\s*1\\.(\\d+)[^.]*\\.(.*?)\\s*$"),
        JA = RegExp("^[^=]+=\\s*GA1\\.(\\d+)[^.]*\\.(.*?)\\s*$"),
        KA = RegExp("^\\s*_ga=\\s*()(amp-[\\w.-]{22,64})$");
    var Si = function(a) {
            return !!a && a.top == a
        },
        LA = function(a, b, c) {
            b = b || a.google_ad_width;
            c = c || a.google_ad_height;
            if (Si(a)) return !1;
            var d = a.document,
                e = d.documentElement;
            if (b && c) {
                var f = 1,
                    g = 1;
                a.innerHeight ? (f = a.innerWidth, g = a.innerHeight) : e && e.clientHeight ? (f = e.clientWidth, g = e.clientHeight) : d.body && (f = d.body.clientWidth, g = d.body.clientHeight);
                if (g > 2 * c || f > 2 * b) return !1
            }
            return !0
        };
    var MA = function(a) {
        a = void 0 === a ? window : a;
        return a._gmptnl ? "afma-gpt-sdk-a" : a.webkit && a.webkit.messageHandlers && a.webkit.messageHandlers._gmptnl ? "afma-gpt-sdk-i" : null
    };
    var zj = function() {
        this.j = [];
        this.o = -1
    };
    zj.prototype.set = function(a, b) {
        b = void 0 === b ? !0 : b;
        0 <= a && 52 > a && _.u(Number, "isInteger").call(Number, a) && this.j[a] !== b && (this.j[a] = b, this.o = -1)
    };
    zj.prototype.get = function(a) {
        return !!this.j[a]
    };
    var Bj = function(a) {
        -1 === a.o && (a.o = Vs(a.j, function(b, c, d) {
            return c ? b + Math.pow(2, d) : b
        }));
        return a.o
    };
    var Qe = function(a) {
        _.T.call(this, a)
    };
    _.P(Qe, _.T);
    var Le = function(a) {
            var b = new Qe;
            return _.fd(b, 1, a, 0)
        },
        Ke = function(a, b) {
            return _.fd(a, 2, b, 0)
        };
    var Oe = function(a) {
        _.T.call(this, a, -1, NA)
    };
    _.P(Oe, _.T);
    var Je = function(a, b) {
            _.Xf(a, 1, Qe, b)
        },
        Ie = he(Oe),
        NA = [1];
    var OA = function(a, b, c, d) {
        _.U.call(this);
        this.G = b;
        this.R = c;
        this.D = d;
        this.N = new _.v.Map;
        this.L = 0;
        this.l = new _.v.Map;
        this.A = new _.v.Map;
        this.I = new _.v.Map;
        this.B = void 0;
        this.m = a
    };
    _.P(OA, _.U);
    OA.prototype.o = function() {
        delete this.j;
        this.N.clear();
        this.l.clear();
        this.A.clear();
        this.I.clear();
        this.B && (_.Ae((0, B.K)(this.m), "message", this.B), delete this.B);
        delete this.m;
        delete this.D;
        _.U.prototype.o.call(this)
    };
    var PA = function(a) {
            if (a.j) return a.j;
            a.R && a.R((0, B.K)(a.m)) ? a.j = a.m : a.j = Dx((0, B.K)(a.m), a.G);
            var b;
            return null != (b = a.j) ? b : null
        },
        RA = function(a, b) {
            if (PA(a))
                if (a.j === a.m) {
                    var c = a.N.get("getDataWithCallback");
                    c && c((0, B.K)(a.j), b)
                } else if ((c = a.l.get("getDataWithCallback")) && c.ye) {
                QA(a);
                var d = ++a.L;
                a.A.set(d, c.Jf);
                a.I.set(d, c.Ef(b));
                a.j.postMessage(c.ye(b, d), "*")
            }
        },
        QA = function(a) {
            a.B || (a.B = function(b) {
                try {
                    var c = a.D ? a.D(b) : void 0;
                    if (c) {
                        var d = c.Je,
                            e = a.A.get(d);
                        if (e) {
                            a.A.delete(d);
                            var f = a.I.get(c.Je);
                            a.I.delete(d);
                            e(f, c.payload)
                        }
                    }
                } catch (g) {}
            }, _.yb((0, B.K)(a.m), "message", a.B))
        };
    var SA = function(a, b) {
            (0, B.K)(a.__uspapi)("getUSPData", 1, function(c, d) {
                b.wc({
                    consentData: null != c ? c : void 0,
                    kf: d ? void 0 : 2
                })
            })
        },
        TA = {
            Ef: function(a) {
                return a.wc
            },
            ye: function(a, b) {
                a = {};
                return a.__uspapiCall = {
                    callId: b,
                    command: "getUSPData",
                    version: 1
                }, a
            },
            Jf: function(a, b) {
                b = b.__uspapiReturn;
                var c;
                a({
                    consentData: null != (c = b.returnValue) ? c : void 0,
                    kf: b.success ? void 0 : 2
                })
            }
        },
        UA = function(a) {
            _.U.call(this);
            this.caller = new OA(a, "__uspapiLocator", function(b) {
                return "function" === typeof b.__uspapi
            }, Ye);
            this.caller.N.set("getDataWithCallback", SA);
            this.caller.l.set("getDataWithCallback", TA)
        };
    _.P(UA, _.U);
    UA.prototype.o = function() {
        this.caller.Ha();
        _.U.prototype.o.call(this)
    };
    var VA = function(a, b) {
        var c = {};
        if (PA(a.caller)) {
            var d = _.Rs(function() {
                b(c)
            });
            RA(a.caller, {
                wc: function(e) {
                    e.kf || (c = (0, B.K)(e.consentData));
                    d()
                }
            });
            setTimeout(d, 500)
        } else b(c)
    };
    var XA = function(a) {
        _.T.call(this, a, -1, WA)
    };
    _.P(XA, _.T);
    var WA = [1, 2];
    var YA = function(a) {
        _.T.call(this, a)
    };
    _.P(YA, _.T);
    var Ze = he(YA);
    var ZA = function(a, b) {
            a = a.googlefc || (a.googlefc = {});
            a.__fci = a.__fci || [];
            a.__fci.push(b.command, function(c) {
                c = Ze(c);
                b.wc({
                    consentData: c
                })
            })
        },
        $A = {
            Ef: function(a) {
                return a.wc
            },
            ye: function(a, b) {
                var c = {};
                return c.__fciCall = {
                    callId: b,
                    command: a.command
                }, c
            },
            Jf: function(a, b) {
                a({
                    consentData: b
                })
            }
        },
        Mn = function(a) {
            _.U.call(this);
            this.j = this.m = !1;
            this.caller = new OA(a, "googlefcPresent", void 0, af);
            this.caller.N.set("getDataWithCallback", ZA);
            this.caller.l.set("getDataWithCallback", $A)
        };
    _.P(Mn, _.U);
    Mn.prototype.o = function() {
        this.caller.Ha();
        _.U.prototype.o.call(this)
    };
    var aB = function(a) {
            a.m || (a.j = !!PA(a.caller), a.m = !0);
            return a.j
        },
        bB = function(a) {
            return new _.v.Promise(function(b) {
                aB(a) && RA(a.caller, {
                    command: "loaded",
                    wc: function(c) {
                        b((0, B.K)(c.consentData))
                    }
                })
            })
        };
    var ef = function(a) {
            this.j = a || {
                cookie: ""
            }
        },
        eB = function() {
            var a = cB;
            if (!_.q.navigator.cookieEnabled) return !1;
            if (!a.isEmpty()) return !0;
            a.set("TESTCOOKIESENABLED", "1", {
                ze: 60
            });
            if ("1" !== a.get("TESTCOOKIESENABLED")) return !1;
            dB(a, "TESTCOOKIESENABLED");
            return !0
        };
    ef.prototype.set = function(a, b, c) {
        var d = !1;
        if ("object" === typeof c) {
            var e = c.dk;
            d = c.ji || !1;
            var f = c.domain || void 0;
            var g = c.path || void 0;
            var h = c.ze
        }
        if (/[;=\s]/.test(a)) throw Error('Invalid cookie name "' + a + '"');
        if (/[;\r\n]/.test(b)) throw Error('Invalid cookie value "' + b + '"');
        void 0 === h && (h = -1);
        this.j.cookie = a + "=" + b + (f ? ";domain=" + f : "") + (g ? ";path=" + g : "") + (0 > h ? "" : 0 == h ? ";expires=" + (new Date(1970, 1, 1)).toUTCString() : ";expires=" + (new Date(Date.now() + 1E3 * h)).toUTCString()) + (d ? ";secure" : "") + (null != e ? ";samesite=" + e : "")
    };
    ef.prototype.get = function(a, b) {
        for (var c = a + "=", d = (this.j.cookie || "").split(";"), e = 0, f; e < d.length; e++) {
            f = Ar(d[e]);
            if (0 == f.lastIndexOf(c, 0)) return f.slice(c.length);
            if (f == a) return ""
        }
        return b
    };
    var dB = function(a, b, c, d) {
        a.get(b);
        a.set(b, "", {
            ze: 0,
            path: c,
            domain: d
        })
    };
    ef.prototype.isEmpty = function() {
        return !this.j.cookie
    };
    ef.prototype.clear = function() {
        for (var a = (this.j.cookie || "").split(";"), b = [], c = [], d, e, f = 0; f < a.length; f++) e = Ar(a[f]), d = e.indexOf("="), -1 == d ? (b.push(""), c.push(e)) : (b.push(e.substring(0, d)), c.push(e.substring(d + 1)));
        for (a = b.length - 1; 0 <= a; a--) dB(this, b[a])
    };
    var cB = new ef("undefined" == typeof document ? null : document);
    _.fB = RegExp("^https?://(\\w|-)+\\.cdn\\.ampproject\\.(net|org)(\\?|/|$)");
    var jB, iB, lB, kB;
    _.gB = function() {
        this.m = "&";
        this.o = {};
        this.H = 0;
        this.j = []
    };
    _.hB = function(a, b) {
        var c = {};
        c[a] = b;
        return [c]
    };
    jB = function(a, b, c, d, e) {
        var f = [];
        _.El(a, function(g, h) {
            (g = iB(g, b, c, d, e)) && f.push(h + "=" + g)
        });
        return f.join(b)
    };
    iB = function(a, b, c, d, e) {
        if (null == a) return "";
        b = b || "&";
        c = c || ",$";
        "string" == typeof c && (c = c.split(""));
        if (a instanceof Array) {
            if (d = d || 0, d < c.length) {
                for (var f = [], g = 0; g < a.length; g++) f.push(iB(a[g], b, c, d + 1, e));
                return f.join(c[d])
            }
        } else if ("object" == typeof a) return e = e || 0, 2 > e ? encodeURIComponent(jB(a, b, c, d, e + 1)) : "...";
        return encodeURIComponent(String(a))
    };
    lB = function(a, b) {
        var c = "https://pagead2.googlesyndication.com" + b,
            d = kB(a) - b.length;
        if (0 > d) return "";
        a.j.sort(function(n, m) {
            return n - m
        });
        b = null;
        for (var e = "", f = 0; f < a.j.length; f++)
            for (var g = a.j[f], h = a.o[g], k = 0; k < h.length; k++) {
                if (!d) {
                    b = null == b ? g : b;
                    break
                }
                var l = jB(h[k], a.m, ",$");
                if (l) {
                    l = e + l;
                    if (d >= l.length) {
                        d -= l.length;
                        c += l;
                        e = a.m;
                        break
                    }
                    b = null == b ? g : b
                }
            }
        a = "";
        null != b && (a = e + "trn=" + b);
        return c + a
    };
    kB = function(a) {
        var b = 1,
            c;
        for (c in a.o) b = c.length > b ? c.length : b;
        return 3997 - b - a.m.length - 1
    };
    _.mB = function() {
        this.j = _.E(Ry) ? .001 : _.Rh(23);
        this.o = Math.random()
    };
    _.Ih = function(a, b, c, d, e) {
        if (((void 0 === d ? 0 : d) ? a.o : Math.random()) < (e || a.j)) try {
            if (c instanceof _.gB) var f = c;
            else f = new _.gB, _.El(c, function(h, k) {
                var l = f,
                    n = l.H++;
                h = _.hB(k, h);
                l.j.push(n);
                l.o[n] = h
            });
            var g = lB(f, "/pagead/gen_204?id=" + b + "&");
            g && jA(_.q, g)
        } catch (h) {}
    };
    var nB = null,
        oB = function() {
            if (null === nB) {
                nB = "";
                try {
                    var a = "";
                    try {
                        a = _.q.top.location.hash
                    } catch (c) {
                        a = _.q.location.hash
                    }
                    if (a) {
                        var b = a.match(/\bdeid=([\d,]+)/);
                        nB = b ? b[1] : ""
                    }
                } catch (c) {}
            }
            return nB
        };
    var pB = function(a, b, c, d, e) {
        this.label = a;
        this.type = b;
        this.value = c;
        this.duration = void 0 === d ? 0 : d;
        this.uniqueId = Math.random();
        this.slotId = e;
        this.taskId = void 0
    };
    var qB, rB, sB, tB, uB;
    qB = _.q.performance;
    rB = !!(qB && qB.mark && qB.measure && qB.clearMarks);
    sB = ij(function() {
        var a;
        if (a = rB) a = oB(), a = !!a.indexOf && 0 <= a.indexOf("1337");
        return a
    });
    tB = function(a, b) {
        this.o = [];
        var c = null;
        b && (b.google_js_reporting_queue = b.google_js_reporting_queue || [], this.o = b.google_js_reporting_queue, c = b.google_measure_js_timing);
        this.j = sB() || (null != c ? c : Math.random() < a)
    };
    _.ei = function(a) {
        a && qB && sB() && (qB.clearMarks("goog_" + a.label + "_" + a.uniqueId + "_start"), qB.clearMarks("goog_" + a.label + "_" + a.uniqueId + "_end"))
    };
    uB = function(a, b, c, d, e, f) {
        a.j && (b = new pB(b, c, d, void 0 === e ? 0 : e, f), !a.j || 2048 < a.o.length || a.o.push(b))
    };
    tB.prototype.start = function(a, b) {
        if (!this.j) return null;
        a = new pB(a, b, _.jf() || _.hf());
        b = "goog_" + a.label + "_" + a.uniqueId + "_start";
        qB && sB() && qB.mark(b);
        return a
    };
    tB.prototype.end = function(a) {
        if (this.j && "number" === typeof a.value) {
            a.duration = (_.jf() || _.hf()) - a.value;
            var b = "goog_" + a.label + "_" + a.uniqueId + "_end";
            qB && sB() && qB.mark(b);
            !this.j || 2048 < this.o.length || this.o.push(a)
        }
    };
    var Cq = function(a, b, c) {
        var d = _.jf();
        d && uB(a, b, 9, d, 0, c)
    };
    _.vB = function(a, b) {
        try {
            -1 == a.indexOf(b) && (a = b + "\n" + a);
            for (var c; a != c;) c = a, a = a.replace(RegExp("((https?:/..*/)[^/:]*:\\d+(?:.|\n)*)\\2"), "$1");
            return a.replace(RegExp("\n *", "g"), "\n")
        } catch (d) {
            return b
        }
    };
    var tm = function(a) {
        a = Error.call(this, a);
        this.message = a.message;
        "stack" in a && (this.stack = a.stack);
        _.u(Object, "setPrototypeOf").call(Object, this, tm.prototype)
    };
    _.P(tm, Error);
    tm.prototype.name = "PublisherInputError";
    var wB = function(a) {
        a = Error.call(this, a);
        this.message = a.message;
        "stack" in a && (this.stack = a.stack);
        _.u(Object, "setPrototypeOf").call(Object, this, wB.prototype)
    };
    _.P(wB, Error);
    wB.prototype.name = "ServerError";
    var xB = function(a) {
        a = Error.call(this, a);
        this.message = a.message;
        "stack" in a && (this.stack = a.stack);
        _.u(Object, "setPrototypeOf").call(Object, this, xB.prototype)
    };
    _.P(xB, Error);
    xB.prototype.name = "NetworkError";
    _.nf = function(a) {
        var b = "Db";
        if (a.Db && a.hasOwnProperty(b)) return a.Db;
        b = new a;
        return a.Db = b
    };
    var of = function() {}; of .prototype.o = function() {}; of .prototype.H = function() {}; of .prototype.m = function() {
        return []
    }; of .prototype.j = function() {
        return []
    };
    var ah = function(a, b) {
        a.o = mf(1, b, function() {});
        a.m = function(c) {
            return mf(2, b, function() {
                return []
            })(c, 2, void 0)
        };
        a.j = function() {
            return mf(3, b, function() {
                return []
            })(2)
        };
        a.H = function(c) {
            mf(16, b, function() {})(c, 2)
        }
    };
    var yB = function() {};
    yB.j = function() {
        throw Error("Must be overridden");
    };
    var rf = function() {
        this.j = 0
    };
    _.P(rf, yB);
    rf.Db = void 0;
    rf.j = function() {
        return rf.Db ? rf.Db : rf.Db = new rf
    };
    var zB = function() {
            this.cache = {}
        },
        zf = function() {
            AB || (AB = new zB);
            return AB
        },
        Yf = function(a) {
            var b = y(a, 3);
            if (!b) return 3;
            if (void 0 === y(a, 2)) return 4;
            a = Date.now();
            return a > b + 2592E5 ? 2 : a > b + 432E5 ? 1 : 0
        };
    zB.prototype.get = function(a, b) {
        if (this.cache[a]) return {
            vb: this.cache[a],
            success: !0
        };
        var c = "";
        try {
            c = b.getItem("_GESPSK-" + a)
        } catch (g) {
            var d;
            tf(6, a, null == (d = g) ? void 0 : d.message);
            return {
                vb: null,
                success: !1
            }
        }
        if (!c) return {
            vb: null,
            success: !0
        };
        try {
            var e = kw(c);
            this.cache[a] = e;
            return {
                vb: e,
                success: !0
            }
        } catch (g) {
            var f;
            tf(5, a, null == (f = g) ? void 0 : f.message);
            return {
                vb: null,
                success: !1
            }
        }
    };
    zB.prototype.set = function(a, b) {
        var c = (0, B.K)(y(a, 1)),
            d = "_GESPSK-" + c;
        _.z(a, 3, Date.now());
        try {
            b.setItem(d, Me(a))
        } catch (f) {
            var e;
            tf(7, c, null == (e = f) ? void 0 : e.message);
            return !1
        }
        this.cache[c] = a;
        return !0
    };
    var AB = null;
    var Af = function(a) {
        return "string" === typeof a ? a : a instanceof Error ? a.message : null
    };
    var Hf = function() {
        var a = {};
        this.j = function(b, c) {
            return null != a[b] ? a[b] : c
        };
        this.o = function(b, c) {
            return null != a[b] ? a[b] : c
        };
        this.m = function(b, c) {
            return null != a[b] ? a[b] : c
        };
        this.H = function(b, c) {
            return null != a[b] ? a[b] : c
        };
        this.B = function() {}
    };
    var BB = function(a) {
        _.U.call(this);
        this.I = a;
        this.j = [];
        this.m = [];
        this.l = [];
        this.B = []
    };
    _.P(BB, _.U);
    var DB = function(a, b, c) {
        a.m.push({
            xb: void 0 === c ? !1 : c,
            fb: b
        });
        _.E(Oy) && CB(b, a.I)
    };
    BB.prototype.o = function() {
        this.j.length = 0;
        this.l.length = 0;
        if (_.E(Oy))
            for (var a = _.x(this.m), b = a.next(); !b.done; b = a.next()) b.value.fb.Vd();
        this.m.length = 0;
        this.B.length = 0;
        _.U.prototype.o.call(this)
    };
    _.oh = function() {
        var a = this;
        this.promise = new _.v.Promise(function(b, c) {
            a.resolve = b;
            a.reject = c
        })
    };
    var EB = function(a) {
        a = Error.call(this, a);
        this.message = a.message;
        "stack" in a && (this.stack = a.stack);
        _.u(Object, "setPrototypeOf").call(Object, this, EB.prototype);
        this.name = "InputError"
    };
    _.P(EB, Error);
    var FB = function() {
            this.Ma = !1
        },
        GB = function() {
            FB.apply(this, arguments);
            this.j = [];
            this.Ic = new _.oh
        };
    _.P(GB, FB);
    var IB = function(a, b) {
            a.Ma || (a.Ma = !0, a.Zb = b, a.Ic.resolve(b), _.E(Oy) && HB(a))
        },
        JB = function(a, b) {
            a.Ma = !0;
            a.Fd = b;
            a.Ic.reject(b);
            _.E(Oy) && HB(a)
        },
        HB = function(a) {
            for (var b = _.x(a.j), c = b.next(); !c.done; c = b.next()) c = c.value, c(a.Zb);
            a.j.length = 0
        };
    GB.prototype.Vd = function() {
        this.j.length = 0
    };
    var CB = function(a, b) {
        _.E(Oy) && a.j.push(b)
    };
    _.Wr.Object.defineProperties(GB.prototype, {
        promise: {
            configurable: !0,
            enumerable: !0,
            get: function() {
                return this.Ic.promise
            }
        },
        mb: {
            configurable: !0,
            enumerable: !0,
            get: function() {
                return this.Ma
            }
        },
        error: {
            configurable: !0,
            enumerable: !0,
            get: function() {
                return this.Fd
            }
        }
    });
    var Lq = function() {
        GB.apply(this, arguments)
    };
    _.P(Lq, GB);
    Lq.prototype.J = function(a) {
        IB(this, a)
    };
    var KB = function(a, b) {
            IB(a, null != b ? b : null)
        },
        LB = function(a) {
            IB(a, null)
        };
    Lq.prototype.lb = function(a) {
        var b = this;
        a.then(function(c) {
            b.J(c)
        })
    };
    Lq.prototype.Ea = function(a) {
        this.Ma || (this.Ma = !0, this.Zb = null, this.Fd = a, this.Ic.reject(a), _.E(Oy) && HB(this))
    };
    var MB = function() {
        GB.apply(this, arguments)
    };
    _.P(MB, GB);
    MB.prototype.J = function(a) {
        IB(this, a)
    };
    MB.prototype.lb = function(a) {
        var b = this;
        a.then(function(c) {
            return void b.J(c)
        })
    };
    MB.prototype.Ea = function(a) {
        this.Ma || (this.Ma = !0, this.Fd = a, this.Ic.reject(a))
    };
    var NB = function(a) {
        this.Ma = !1;
        this.rb = a
    };
    _.P(NB, FB);
    NB.prototype.mb = function() {
        return this.rb.Ma
    };
    NB.prototype.Ac = function() {
        return null != this.rb.Zb
    };
    _.Wr.Object.defineProperties(NB.prototype, {
        error: {
            configurable: !0,
            enumerable: !0,
            get: function() {
                return this.rb.Fd
            }
        }
    });
    var OB = function(a) {
        NB.call(this, a);
        this.rb = a
    };
    _.P(OB, NB);
    _.Wr.Object.defineProperties(OB.prototype, {
        value: {
            configurable: !0,
            enumerable: !0,
            get: function() {
                return (0, B.K)(this.rb.Zb)
            }
        }
    });
    var PB = function(a) {
        NB.call(this, a);
        this.rb = a
    };
    _.P(PB, NB);
    _.Wr.Object.defineProperties(PB.prototype, {
        value: {
            configurable: !0,
            enumerable: !0,
            get: function() {
                var a;
                return null != (a = this.rb.Zb) ? a : null
            }
        }
    });
    var QB = function() {
        NB.apply(this, arguments)
    };
    _.P(QB, NB);
    _.Wr.Object.defineProperties(QB.prototype, {
        value: {
            configurable: !0,
            enumerable: !0,
            get: function() {
                var a;
                return null != (a = this.rb.Zb) ? a : null
            }
        }
    });
    var RB = function() {
        GB.apply(this, arguments)
    };
    _.P(RB, GB);
    RB.prototype.notify = function() {
        IB(this, null)
    };
    var SB = function(a, b) {
            b.then(function() {
                a.notify()
            })
        },
        TB = function(a, b) {
            b = void 0 === b ? !1 : b;
            GB.call(this);
            var c = this;
            this.m = a;
            this.o = 0;
            if (_.E(Oy)) {
                a = {};
                for (var d = _.x(this.m), e = d.next(); !e.done; a = {
                        qc: a.qc
                    }, e = d.next()) a.qc = e.value, CB(a.qc, function(f) {
                    return function(g) {
                        c.o += 1;
                        f.qc.error ? JB(c, f.qc.error) : b || null !== g ? IB(c, null != g ? g : null) : c.o === c.m.length && IB(c, null)
                    }
                }(a))
            } else a = a.map(function(f) {
                return f.promise.then(function(g) {
                    if (b || null != g) return g;
                    throw g;
                }, function(g) {
                    JB(c, g);
                    return null
                })
            }), _.u(_.v.Promise, "any").call(_.v.Promise, a).then(function(f) {
                c.Ma || IB(c, f)
            }, function() {
                c.Ma || IB(c, null)
            })
        };
    _.P(TB, GB);
    var UB = function(a, b) {
        GB.call(this);
        this.Wa = a;
        this.defaultValue = b
    };
    _.P(UB, GB);
    var dg = function(a) {
        setTimeout(function() {
            var b;
            IB(a, null != (b = a.defaultValue) ? b : null)
        }, a.Wa)
    };
    var WB = function(a, b) {
        _.U.call(this);
        var c = this;
        this.id = a;
        this.Wa = b;
        this.qa = this.la = this.ka = this.N = !1;
        this.Oa = -1;
        this.B = new BB(function() {
            VB(c)
        });
        _.Nn(this, this.B)
    };
    _.P(WB, _.U);
    WB.prototype.start = function() {
        var a = this,
            b, c;
        return _.Ab(function(d) {
            switch (d.j) {
                case 1:
                    if (a.N) return d.return();
                    a.N = !0;
                    d.m = 2;
                    b = a;
                    return Bb(d, eg(a.B.m, a.B.B, a.Wa), 4);
                case 4:
                    b.Oa = d.o;
                    if (a.H) {
                        d.j = 5;
                        break
                    }
                    for (var e = 0, f = _.x(a.B.l), g = f.next(); !g.done; g = f.next()) {
                        if (!g.value.Ac()) throw Error("missing input: " + a.id + "/" + e);
                        ++e
                    }
                    return Bb(d, a.j(), 5);
                case 5:
                    Db(d, 0);
                    break;
                case 2:
                    c = Eb(d);
                    if (a.H) return d.return();
                    c instanceof EB ? a.I(c) : c instanceof Error && (a.R(c), a.m(c));
                    d.j = 0
            }
        })
    };
    var VB = function(a) {
            if (!a.N && a.ka) try {
                var b = a.B.m,
                    c = a.Wa ? b.filter(function(k) {
                        return !k.xb
                    }) : b,
                    d = b.filter(function(k) {
                        return k.xb
                    }),
                    e, f = null == (e = _.u(b, "find").call(b, function(k) {
                        return void 0 !== k.fb.error
                    })) ? void 0 : e.fb.error;
                if (f) throw a.N = !0, f;
                if (!c.some(function(k) {
                        return !k.fb.mb
                    })) {
                    if (d.length)
                        if (_.E(cg)) {
                            for (var g = _.x(a.B.B), h = g.next(); !h.done; h = g.next()) dg(h.value);
                            if (d.some(function(k) {
                                    return !k.fb.mb
                                })) return
                        } else if (a.la || (a.la = !0, setTimeout(function() {
                            a.qa = !0;
                            VB(a)
                        }, a.Wa)), d.some(function(k) {
                            return !k.fb.mb
                        }) && !a.qa) return;
                    a.N = !0;
                    a.j()
                }
            } catch (k) {
                a.H || (k instanceof EB ? a.I(k) : k instanceof Error && (a.R(k), a.m(k)))
            }
        },
        V = function(a) {
            var b = new Lq;
            a.B.j.push(b);
            return b
        },
        XB = function(a) {
            var b = new MB;
            a.B.j.push(b);
            return b
        },
        YB = function(a) {
            var b = new RB;
            a.B.j.push(b);
            return b
        },
        X = function(a, b) {
            DB(a.B, b);
            b = new OB(b);
            a.B.l.push(b);
            return b
        },
        Y = function(a, b) {
            DB(a.B, b);
            return new PB(b)
        },
        ZB = function(a, b) {
            if (_.E(cg)) {
                if (a.Wa) {
                    var c = new UB(a.Wa, void 0);
                    b = new TB([b, c], !0);
                    DB(a.B, b, !0);
                    a.B.B.push(c);
                    return new PB(b)
                }
                DB(a.B, b);
                return new PB(b)
            }
            DB(a.B, b, !0);
            return new PB(b)
        },
        $B = function(a, b) {
            DB(a.B, b)
        },
        aC = function(a, b) {
            if (_.E(cg))
                if (a.Wa) {
                    var c = new UB(a.Wa);
                    b = new TB([b, c], !0);
                    DB(a.B, b, !0);
                    a.B.B.push(c)
                } else $B(a, b);
            else DB(a.B, b, !0)
        },
        bC = function(a, b) {
            b = new TB(b);
            DB(a.B, b);
            b = new OB(b);
            a.B.l.push(b);
            return b
        };
    WB.prototype.I = function() {};
    WB.prototype.m = function(a) {
        if (this.B.j.length) {
            a = new EB(a.message);
            for (var b = _.x(this.B.j), c = b.next(); !c.done; c = b.next()) c = c.value, c.mb || JB(c, a)
        }
    };
    var cC = function(a, b) {
        WB.call(this, a);
        this.id = a;
        this.D = b
    };
    _.P(cC, WB);
    cC.prototype.R = function(a) {
        this.D(this.id, a)
    };
    var jg = function(a, b, c, d) {
        cC.call(this, 1041, d);
        this.storage = b;
        this.l = c;
        this.G = X(this, a);
        this.l && (this.A = X(this, this.l))
    };
    _.P(jg, cC);
    jg.prototype.j = function() {
        var a = this.G.value,
            b, c, d = (0, B.K)(null != (c = null == (b = this.A) ? void 0 : b.value) ? c : this.storage);
        zf().set(a, d) && _.bg(a, 2) && tf(27, (0, B.K)(y(a, 1)))
    };
    var lg = function(a, b) {
        cC.call(this, 1048, b);
        this.l = V(this);
        this.A = V(this);
        this.G = X(this, a)
    };
    _.P(lg, cC);
    lg.prototype.j = function() {
        var a = this.G.value,
            b = function(c) {
                var d = {};
                tf(c, (0, B.K)(y(a, 1)), null, (d.tic = String(Math.round((Date.now() - (0, B.K)(y(a, 3))) / 6E4)), d))
            };
        switch (Yf(a)) {
            case 0:
                b(24);
                break;
            case 1:
                b(25);
                this.A.J(a);
                break;
            case 2:
                b(26);
                this.l.J(a);
                break;
            case 3:
                tf(9, (0, B.K)(y(a, 1)));
                this.l.J(a);
                break;
            case 4:
                b(23), this.l.J(a)
        }
    };
    var dC = function(a, b, c) {
        cC.call(this, 1094, c);
        this.storage = a;
        this.l = YB(this);
        b && (this.A = X(this, b))
    };
    _.P(dC, cC);
    dC.prototype.j = function() {
        var a, b, c = (0, B.K)(null != (b = null == (a = this.A) ? void 0 : a.value) ? b : this.storage);
        if (void 0 !== c)
            for (a = _.x(_.u(Object, "keys").call(Object, c)), b = a.next(); !b.done; b = a.next())
                if (b = b.value, _.u(b, "startsWith").call(b, "_GESPSK")) try {
                    c.removeItem(b)
                } catch (d) {}
        AB = new zB;
        this.l.notify()
    };
    var Sg = function(a, b, c) {
        cC.call(this, 1049, c);
        this.storage = b;
        $B(this, a)
    };
    _.P(Sg, cC);
    Sg.prototype.j = function() {
        for (var a = _.x(Gf(this.storage)), b = a.next(); !b.done; b = a.next()) {
            b = b.value;
            var c = zf().get(b, this.storage).vb;
            if (c) {
                var d = Yf(c);
                if (2 === d || 3 === d) {
                    d = void 0;
                    var e = zf();
                    c = (0, B.K)(y(c, 1));
                    try {
                        this.storage.removeItem("_GESPSK-" + c), delete e.cache[c]
                    } catch (f) {
                        tf(8, c, null == (d = f) ? void 0 : d.message)
                    }
                    tf(40, b)
                }
            }
        }
    };
    var pg = function(a, b, c, d, e) {
        cC.call(this, 658, e);
        this.collectorFunction = a;
        this.storage = c;
        this.l = V(this);
        this.G = V(this);
        this.A = Y(this, b);
        d && (this.L = X(this, d))
    };
    _.P(pg, cC);
    pg.prototype.j = function() {
        var a = this,
            b, c, d = (0, B.K)(null != (c = null == (b = this.L) ? void 0 : b.value) ? c : this.storage);
        if (this.A.value) {
            b = function(g) {
                a.l.J({
                    id: (0, B.K)(y(g, 1)),
                    collectorGeneratedData: y(g, 2)
                })
            };
            c = this.A.value;
            var e = (0, B.K)(y(c, 1)),
                f = Yf(c);
            fg(c);
            switch (f) {
                case 0:
                    b(c);
                    break;
                case 1:
                    b(c);
                    this.G.J(c);
                    break;
                case 3:
                case 2:
                case 4:
                    _.z(c, 2, null), Bf(e, c, this.collectorFunction, d).then(b)
            }
        } else LB(this.l)
    };
    var ig = function(a, b, c, d) {
        cC.call(this, 1027, d);
        this.jd = a;
        this.storage = b;
        this.l = V(this);
        this.A = V(this);
        c && (this.G = X(this, c))
    };
    _.P(ig, cC);
    ig.prototype.j = function() {
        var a, b, c = (0, B.K)(null != (b = null == (a = this.G) ? void 0 : a.value) ? b : this.storage);
        a = zf().get(this.jd, c).vb;
        a || (a = Wf(this.jd), a = _.z(a, 3, Date.now()), this.A.J(a.Ea(Cf(new Ef, 100))));
        this.l.J(a)
    };
    var mg = function(a, b, c) {
        cC.call(this, 1047, c);
        this.collectorFunction = a;
        this.A = V(this);
        this.l = V(this);
        this.G = V(this);
        this.L = X(this, b)
    };
    _.P(mg, cC);
    mg.prototype.j = function() {
        var a = this,
            b = this.L.value,
            c = (0, B.K)(y(b, 1));
        tf(18, c);
        try {
            var d = _.hf();
            this.collectorFunction().then(function(e) {
                tf(29, c, null, {
                    delta: String(_.hf() - d)
                });
                a.A.J(_.z(b, 2, e));
                KB(a.G, e)
            }).catch(function(e) {
                tf(28, c, gg(e));
                a.l.J(b.Ea(Cf(new Ef, 106)))
            })
        } catch (e) {
            tf(1, c, gg(e)), this.l.J(b.Ea(Cf(new Ef, 107)))
        }
    };
    var qg = function(a, b, c, d, e) {
        cC.call(this, 662, e);
        this.A = a;
        this.storage = c;
        this.G = X(this, b);
        d && (this.l = X(this, d))
    };
    _.P(qg, cC);
    qg.prototype.j = function() {
        var a = this,
            b, c, d = (0, B.K)(null != (c = null == (b = this.l) ? void 0 : b.value) ? c : this.storage);
        Ff().then(function() {
            var e = (0, B.K)(a.G.value);
            Bf((0, B.K)(y(e, 1)), e, a.A, d)
        })
    };
    var kg = function(a, b) {
        cC.call(this, 1028, b);
        this.l = V(this);
        this.A = X(this, a)
    };
    _.P(kg, cC);
    kg.prototype.j = function() {
        var a = this.A.value,
            b = (0, B.K)(y(a, 1));
        null != y(a, 3) || tf(35, b);
        this.l.J(a)
    };
    var ng = function(a, b, c, d, e) {
        cC.call(this, 1050, e);
        this.L = c;
        this.G = d;
        this.l = V(this);
        this.A = X(this, a);
        this.O = Y(this, b)
    };
    _.P(ng, cC);
    ng.prototype.j = function() {
        var a = this.A.value,
            b = (0, B.K)(y(a, 1)),
            c = this.O.value;
        if (null == c) tf(41, b), a.Ea(Cf(new Ef, 111)), this.l.J(a);
        else if ("string" !== typeof c) tf(21, b), this.l.J(a.Ea(Cf(new Ef, 113)));
        else {
            if (c.length > (/^(\d+)$/.test(b) ? this.G : this.L)) {
                var d = {};
                tf(12, b, null, (d.sl = String(c.length), d));
                b = a.Ea(Cf(new Ef, 108));
                yf(b, 2)
            } else c.length || tf(20, b), yf(a, 10);
            this.l.J(a)
        }
    };
    var hg = function() {
        _.U.apply(this, arguments);
        this.l = [];
        this.A = [];
        this.I = {};
        this.B = [];
        this.m = new _.oh;
        this.j = {}
    };
    _.P(hg, _.U);
    var H = function(a, b) {
            _.Nn(a, b);
            a.l.push(b);
            return b
        },
        rg = function(a, b) {
            b = _.x(b);
            for (var c = b.next(); !c.done; c = b.next()) H(a, c.value)
        },
        sg = function(a) {
            var b, c, d, e, f, g, h, k, l, n, m, p;
            return _.Ab(function(r) {
                switch (r.j) {
                    case 1:
                        if (!a.B.length) {
                            r.j = 2;
                            break
                        }
                        return Bb(r, _.v.Promise.all(a.B.map(function(t) {
                            return t.m.promise
                        })), 2);
                    case 2:
                        b = _.x(a.l);
                        for (c = b.next(); !c.done; c = b.next()) d = c.value, _.E(Oy) ? (d.ka = !0, VB(d)) : d.start();
                        e = _.x(a.A);
                        for (f = e.next(); !f.done; f = e.next()) g = f.value, sg(g);
                        if (!a.j) {
                            r.j = 4;
                            break
                        }
                        h = _.u(Object, "keys").call(Object, a.j);
                        if (!h.length) {
                            r.j = 4;
                            break
                        }
                        return Bb(r, _.v.Promise.all(_.u(Object, "values").call(Object, a.j).map(function(t) {
                            return t.promise
                        })), 6);
                    case 6:
                        for (k = r.o, l = 0, n = _.x(h), m = n.next(); !m.done; m = n.next()) p = m.value, a.I[p] = k[l++];
                    case 4:
                        return a.m.resolve(a.I), r.return(a.m.promise)
                }
            })
        };
    hg.prototype.o = function() {
        _.U.prototype.o.call(this);
        this.l.length = 0;
        this.A.length = 0;
        this.B.length = 0
    };
    var eC = function(a, b, c, d, e) {
        cC.call(this, 1059, e);
        this.L = b;
        this.storage = c;
        this.G = d;
        this.l = V(this);
        this.O = X(this, a);
        d && (this.A = Y(this, d))
    };
    _.P(eC, cC);
    eC.prototype.j = function() {
        var a, b, c = null != (b = this.storage) ? b : null == (a = this.A) ? void 0 : a.value;
        if (c) {
            var d = this.O.value;
            b = d.id;
            a = d.collectorFunction;
            var e;
            d = (0, B.K)(null != (e = d.networkCode) ? e : b);
            e = {};
            tf(42, d, null, (e.ea = String(Number(this.L)), e));
            this.l.lb(tg(d, a, c, this.G, this.D))
        }
    };
    var fC = function(a, b) {
        cC.call(this, 1057, b);
        this.l = a;
        this.A = V(this);
        this.G = V(this)
    };
    _.P(fC, cC);
    fC.prototype.j = function() {
        if (this.l)
            if ("object" !== typeof this.l) tf(46, "UNKNOWN_COLLECTOR_ID"), gC(this, "UNKNOWN_COLLECTOR_ID", 112);
            else {
                var a = this.l.id,
                    b = this.l.networkCode;
                a && b && (delete this.l.id, tf(47, a + ";" + b));
                a = null != b ? b : a;
                "string" !== typeof a ? (b = {}, tf(37, "INVALID_COLLECTOR_ID", null, (b.ii = JSON.stringify(a), b)), gC(this, "INVALID_COLLECTOR_ID", 102)) : "function" !== typeof this.l.collectorFunction ? (tf(14, a), gC(this, a, 105)) : (_.C = Kf(Az), _.u(_.C, "includes")).call(_.C, a) ? (tf(22, a), gC(this, a, 104)) : this.G.J(this.l)
            }
        else tf(39, "UNKNOWN_COLLECTOR_ID"), gC(this, "UNKNOWN_COLLECTOR_ID", 110)
    };
    var gC = function(a, b, c) {
        a.A.J(Wf(b).Ea(Cf(new Ef, c)))
    };
    var Pg = function(a, b, c, d) {
        var e = void 0 === e ? document : e;
        this.storage = null;
        this.j = b;
        this.I = c;
        this.H = d;
        this.W = e;
        this.l = [];
        this.B = [];
        this.m = [];
        this.o = 0;
        a = _.x(a);
        for (b = a.next(); !b.done; b = a.next()) this.push(b.value)
    };
    _.aa = Pg.prototype;
    _.aa.push = function(a) {
        var b = this,
            c = this.H.Se ? function(f, g) {
                return void b.Xc(f, g)
            } : this.Xc;
        a = new fC(a, c);
        var d = new jg(a.A, this.storage, this.j, c);
        c = new eC(a.G, this.I, this.storage, this.j, c);
        var e = new hg;
        rg(e, [a, d, c]);
        sg(e);
        a = c.l.promise;
        this.l.push(a);
        d = _.x(this.B);
        for (c = d.next(); !c.done; c = d.next()) a.then(c.value)
    };
    _.aa.addOnSignalResolveCallback = function(a) {
        this.B.push(a);
        for (var b = _.x(this.l), c = b.next(); !c.done; c = b.next()) c.value.then(a)
    };
    _.aa.addErrorHandler = function(a) {
        this.m.push(a)
    };
    _.aa.clearAllCache = function() {
        var a = this,
            b = this.W.currentScript instanceof HTMLScriptElement ? this.W.currentScript.src : "";
        if (1 === this.o) {
            var c = {};
            tf(49, "", null, (c.url = b, c))
        } else if (c = String(_.Ni(null != b ? b : "")), (_.C = Kf(zz), _.u(_.C, "includes")).call(_.C, c)) c = {}, tf(48, "", null, (c.url = b, c));
        else {
            var d = new hg;
            c = new dC(this.storage, this.j, this.H.Se ? function(e, f) {
                return void a.Xc(e, f)
            } : this.Xc);
            H(d, c);
            sg(d);
            this.o = 1;
            setTimeout(function() {
                a.o = 0
            }, 1E3 * _.If(yz));
            d = {};
            tf(43, "", null, (d.url = b, d));
            return c.l.promise
        }
    };
    _.aa.Xc = function(a, b) {
        for (var c = _.x(this.m), d = c.next(); !d.done; d = c.next()) d = d.value, d(a, b)
    };
    var Qg = function(a) {
        this.push = function(b) {
            a.push(b)
        };
        this.addOnSignalResolveCallback = function(b) {
            a.addOnSignalResolveCallback(b)
        };
        this.addErrorHandler = function(b) {
            a.addErrorHandler(b)
        };
        this.clearAllCache = function() {
            a.clearAllCache()
        }
    };
    var vg = {
        Se: !1
    };
    var Vg = function(a, b) {
        cC.call(this, 1036, b);
        this.l = V(this);
        this.A = X(this, a)
    };
    _.P(Vg, cC);
    Vg.prototype.j = function() {
        var a = this.A.value;
        0 !== Yf(a) && this.l.J(a)
    };
    var Wg = function(a, b, c) {
        cC.call(this, 1035, c);
        this.A = b;
        this.l = V(this);
        this.G = X(this, a)
    };
    _.P(Wg, cC);
    Wg.prototype.j = function() {
        var a = this,
            b = this.G.value,
            c = (0, B.K)(y(b, 1)),
            d = this.A.toString(),
            e = {};
        tf(30, c, null, (e.url = d, e));
        var f = document.createElement("script");
        f.setAttribute("esp-signal", "true");
        lb(f, this.A);
        var g = function() {
            var h = {};
            tf(31, (0, B.K)(c), null, (h.url = d, h));
            a.l.J(b.Ea(Cf(new Ef, 109)));
            _.Ae(f, "error", g)
        };
        document.head.appendChild(f);
        _.yb(f, "error", g)
    };
    var Rg = function(a) {
        cC.call(this, 1046, a);
        this.C = YB(this)
    };
    _.P(Rg, cC);
    Rg.prototype.j = function() {
        var a = this;
        Ff().then(function() {
            return a.C.notify()
        })
    };
    var Ug = new _.v.Set;
    var hC = 0,
        iC = re(_.Is(Ks("https://pagead2.googlesyndication.com/pagead/expansion_embed.js")));
    var Zg = function() {
            this.j = function() {}
        },
        ch = function(a, b) {
            a.j = mf(14, b, function() {})
        };
    var Ki = function(a, b, c) {
            a && null !== b && b != b.top && (b = b.top);
            try {
                return (void 0 === c ? 0 : c) ? (new _.Yi(b.innerWidth, b.innerHeight)).round() : _.hx(b || window).round()
            } catch (d) {
                return new _.Yi(-12245933, -12245933)
            }
        },
        jC = function(a) {
            return "CSS1Compat" == a.compatMode ? a.documentElement : a.body
        },
        hn = function(a, b) {
            b = void 0 === b ? _.q : b;
            a = a.scrollingElement || jC(a);
            return new _.Vi(b.pageXOffset || a.scrollLeft, b.pageYOffset || a.scrollTop)
        },
        lj = function(a) {
            try {
                return !(!a || !(a.offsetWidth || a.offsetHeight || a.getClientRects().length))
            } catch (b) {
                return !1
            }
        };
    var kC = function(a) {
        _.T.call(this, a)
    };
    _.P(kC, _.T);
    var bf = function(a) {
        return K(a, 5)
    };
    var nC, oC, pC;
    _.lC = function(a) {
        this.j = a;
        this.o = 0
    };
    nC = function(a, b) {
        if (0 === a.o) {
            if (_.mC(a, "__gads", b)) b = !0;
            else {
                var c = a.j;
                bf(b) && df(c) && (new ef(c.document)).set("GoogleAdServingTest", "Good", void 0);
                if (c = "Good" === ff("GoogleAdServingTest", b, a.j)) {
                    var d = a.j;
                    bf(b) && df(d) && dB(new ef(d.document), "GoogleAdServingTest")
                }
                b = c
            }
            a.o = b ? 2 : 1
        }
        return 2 === a.o
    };
    _.mC = function(a, b, c) {
        return c ? ff(b, c, a.j) : null
    };
    oC = function(a, b, c, d) {
        if (d) {
            var e = {
                ze: Math.max(y(c, 2) - Date.now() / 1E3, 0),
                path: y(c, 3),
                domain: y(c, 4),
                ji: !1
            };
            a = a.j;
            bf(d) && df(a) && (new ef(a.document)).set(b, y(c, 1), e)
        }
    };
    pC = function(a, b, c) {
        if (c && ff(b, c, a.j)) {
            var d = a.j.location.hostname;
            if ("localhost" === d) d = ["localhost"];
            else if (d = d.split("."), 2 > d.length) d = [];
            else {
                for (var e = [], f = 0; f < d.length - 1; ++f) e.push(d.slice(f).join("."));
                d = e
            }
            d = _.x(d);
            for (e = d.next(); !e.done; e = d.next()) f = a.j, bf(c) && df(f) && dB(new ef(f.document), b, "/", e.value)
        }
    };
    var qC = {},
        rC = (qC[3] = re(_.Is(Ks("https://s0.2mdn.net/ads/richmedia/studio/mu/templates/hifi/hifi.js"))), qC);
    ({})[3] = re(_.Is(Ks("https://s0.2mdn.net/ads/richmedia/studio_canary/mu/templates/hifi/hifi_canary.js")));
    var sC = function(a) {
            this.j = a;
            this.o = Yw()
        },
        tC = function(a) {
            var b = {};
            _.Us(a, function(c) {
                b[c.j] = c.o
            });
            return b
        };
    var uC = _.R(["https://adservice.google.com/adsid/integrator.", ""]),
        vC = _.R(["https://adservice.google.ad/adsid/integrator.", ""]),
        wC = _.R(["https://adservice.google.ae/adsid/integrator.", ""]),
        xC = _.R(["https://adservice.google.com.af/adsid/integrator.", ""]),
        yC = _.R(["https://adservice.google.com.ag/adsid/integrator.", ""]),
        zC = _.R(["https://adservice.google.com.ai/adsid/integrator.", ""]),
        AC = _.R(["https://adservice.google.al/adsid/integrator.", ""]),
        BC = _.R(["https://adservice.google.co.ao/adsid/integrator.", ""]),
        CC = _.R(["https://adservice.google.com.ar/adsid/integrator.", ""]),
        DC = _.R(["https://adservice.google.as/adsid/integrator.", ""]),
        TC = _.R(["https://adservice.google.at/adsid/integrator.", ""]),
        VC = _.R(["https://adservice.google.com.au/adsid/integrator.", ""]),
        $C = _.R(["https://adservice.google.az/adsid/integrator.", ""]),
        bD = _.R(["https://adservice.google.com.bd/adsid/integrator.", ""]),
        cD = _.R(["https://adservice.google.be/adsid/integrator.", ""]),
        dD = _.R(["https://adservice.google.bf/adsid/integrator.", ""]),
        eD = _.R(["https://adservice.google.bg/adsid/integrator.", ""]),
        fD = _.R(["https://adservice.google.com.bh/adsid/integrator.", ""]),
        gD = _.R(["https://adservice.google.bi/adsid/integrator.", ""]),
        hD = _.R(["https://adservice.google.bj/adsid/integrator.", ""]),
        iD = _.R(["https://adservice.google.com.bn/adsid/integrator.", ""]),
        jD = _.R(["https://adservice.google.com.bo/adsid/integrator.", ""]),
        kD = _.R(["https://adservice.google.com.br/adsid/integrator.", ""]),
        lD = _.R(["https://adservice.google.bs/adsid/integrator.", ""]),
        mD = _.R(["https://adservice.google.bt/adsid/integrator.", ""]),
        nD = _.R(["https://adservice.google.co.bw/adsid/integrator.", ""]),
        oD = _.R(["https://adservice.google.com.bz/adsid/integrator.", ""]),
        pD = _.R(["https://adservice.google.ca/adsid/integrator.", ""]),
        qD = _.R(["https://adservice.google.cd/adsid/integrator.", ""]),
        rD = _.R(["https://adservice.google.cf/adsid/integrator.", ""]),
        sD = _.R(["https://adservice.google.cg/adsid/integrator.", ""]),
        tD = _.R(["https://adservice.google.ch/adsid/integrator.", ""]),
        uD = _.R(["https://adservice.google.ci/adsid/integrator.", ""]),
        vD = _.R(["https://adservice.google.co.ck/adsid/integrator.", ""]),
        wD = _.R(["https://adservice.google.cl/adsid/integrator.", ""]),
        xD = _.R(["https://adservice.google.cm/adsid/integrator.", ""]),
        yD = _.R(["https://adservice.google.com.co/adsid/integrator.", ""]),
        zD = _.R(["https://adservice.google.co.cr/adsid/integrator.", ""]),
        AD = _.R(["https://adservice.google.com.cu/adsid/integrator.", ""]),
        BD = _.R(["https://adservice.google.cv/adsid/integrator.", ""]),
        CD = _.R(["https://adservice.google.com.cy/adsid/integrator.", ""]),
        DD = _.R(["https://adservice.google.cz/adsid/integrator.", ""]),
        ED = _.R(["https://adservice.google.de/adsid/integrator.", ""]),
        FD = _.R(["https://adservice.google.dj/adsid/integrator.", ""]),
        GD = _.R(["https://adservice.google.dk/adsid/integrator.", ""]),
        HD = _.R(["https://adservice.google.dm/adsid/integrator.", ""]),
        ID = _.R(["https://adservice.google.dz/adsid/integrator.", ""]),
        JD = _.R(["https://adservice.google.com.ec/adsid/integrator.", ""]),
        KD = _.R(["https://adservice.google.ee/adsid/integrator.", ""]),
        LD = _.R(["https://adservice.google.com.eg/adsid/integrator.", ""]),
        MD = _.R(["https://adservice.google.es/adsid/integrator.", ""]),
        ND = _.R(["https://adservice.google.com.et/adsid/integrator.", ""]),
        OD = _.R(["https://adservice.google.fi/adsid/integrator.", ""]),
        PD = _.R(["https://adservice.google.com.fj/adsid/integrator.", ""]),
        QD = _.R(["https://adservice.google.fm/adsid/integrator.", ""]),
        RD = _.R(["https://adservice.google.fr/adsid/integrator.", ""]),
        SD = _.R(["https://adservice.google.ga/adsid/integrator.", ""]),
        TD = _.R(["https://adservice.google.ge/adsid/integrator.", ""]),
        UD = _.R(["https://adservice.google.gg/adsid/integrator.", ""]),
        VD = _.R(["https://adservice.google.com.gh/adsid/integrator.", ""]),
        WD = _.R(["https://adservice.google.com.gi/adsid/integrator.", ""]),
        XD = _.R(["https://adservice.google.gl/adsid/integrator.", ""]),
        YD = _.R(["https://adservice.google.gm/adsid/integrator.", ""]),
        ZD = _.R(["https://adservice.google.gr/adsid/integrator.", ""]),
        $D = _.R(["https://adservice.google.com.gt/adsid/integrator.", ""]),
        aE = _.R(["https://adservice.google.gy/adsid/integrator.", ""]),
        bE = _.R(["https://adservice.google.com.hk/adsid/integrator.", ""]),
        cE = _.R(["https://adservice.google.hn/adsid/integrator.", ""]),
        dE = _.R(["https://adservice.google.hr/adsid/integrator.", ""]),
        eE = _.R(["https://adservice.google.ht/adsid/integrator.", ""]),
        fE = _.R(["https://adservice.google.hu/adsid/integrator.", ""]),
        gE = _.R(["https://adservice.google.co.id/adsid/integrator.", ""]),
        hE = _.R(["https://adservice.google.ie/adsid/integrator.", ""]),
        iE = _.R(["https://adservice.google.co.il/adsid/integrator.", ""]),
        jE = _.R(["https://adservice.google.im/adsid/integrator.", ""]),
        kE = _.R(["https://adservice.google.co.in/adsid/integrator.", ""]),
        lE = _.R(["https://adservice.google.iq/adsid/integrator.", ""]),
        mE = _.R(["https://adservice.google.is/adsid/integrator.", ""]),
        nE = _.R(["https://adservice.google.it/adsid/integrator.", ""]),
        oE = _.R(["https://adservice.google.je/adsid/integrator.", ""]),
        pE = _.R(["https://adservice.google.com.jm/adsid/integrator.", ""]),
        qE = _.R(["https://adservice.google.jo/adsid/integrator.", ""]),
        rE = _.R(["https://adservice.google.co.jp/adsid/integrator.", ""]),
        sE = _.R(["https://adservice.google.co.ke/adsid/integrator.", ""]),
        tE = _.R(["https://adservice.google.com.kh/adsid/integrator.", ""]),
        uE = _.R(["https://adservice.google.ki/adsid/integrator.", ""]),
        vE = _.R(["https://adservice.google.kg/adsid/integrator.", ""]),
        wE = _.R(["https://adservice.google.co.kr/adsid/integrator.", ""]),
        xE = _.R(["https://adservice.google.com.kw/adsid/integrator.", ""]),
        yE = _.R(["https://adservice.google.kz/adsid/integrator.", ""]),
        zE = _.R(["https://adservice.google.la/adsid/integrator.", ""]),
        AE = _.R(["https://adservice.google.com.lb/adsid/integrator.", ""]),
        BE = _.R(["https://adservice.google.li/adsid/integrator.", ""]),
        CE = _.R(["https://adservice.google.lk/adsid/integrator.", ""]),
        DE = _.R(["https://adservice.google.co.ls/adsid/integrator.", ""]),
        EE = _.R(["https://adservice.google.lt/adsid/integrator.", ""]),
        FE = _.R(["https://adservice.google.lu/adsid/integrator.", ""]),
        GE = _.R(["https://adservice.google.lv/adsid/integrator.", ""]),
        HE = _.R(["https://adservice.google.com.ly/adsid/integrator.", ""]),
        IE = _.R(["https://adservice.google.md/adsid/integrator.", ""]),
        JE = _.R(["https://adservice.google.me/adsid/integrator.", ""]),
        KE = _.R(["https://adservice.google.mg/adsid/integrator.", ""]),
        LE = _.R(["https://adservice.google.mk/adsid/integrator.", ""]),
        ME = _.R(["https://adservice.google.ml/adsid/integrator.", ""]),
        NE = _.R(["https://adservice.google.com.mm/adsid/integrator.", ""]),
        OE = _.R(["https://adservice.google.mn/adsid/integrator.", ""]),
        PE = _.R(["https://adservice.google.ms/adsid/integrator.", ""]),
        QE = _.R(["https://adservice.google.com.mt/adsid/integrator.", ""]),
        RE = _.R(["https://adservice.google.mu/adsid/integrator.", ""]),
        SE = _.R(["https://adservice.google.mv/adsid/integrator.", ""]),
        TE = _.R(["https://adservice.google.mw/adsid/integrator.", ""]),
        UE = _.R(["https://adservice.google.com.mx/adsid/integrator.", ""]),
        VE = _.R(["https://adservice.google.com.my/adsid/integrator.", ""]),
        WE = _.R(["https://adservice.google.co.mz/adsid/integrator.", ""]),
        XE = _.R(["https://adservice.google.com.na/adsid/integrator.", ""]),
        YE = _.R(["https://adservice.google.com.ng/adsid/integrator.", ""]),
        ZE = _.R(["https://adservice.google.com.ni/adsid/integrator.", ""]),
        $E = _.R(["https://adservice.google.ne/adsid/integrator.", ""]),
        aF = _.R(["https://adservice.google.nl/adsid/integrator.", ""]),
        bF = _.R(["https://adservice.google.no/adsid/integrator.", ""]),
        cF = _.R(["https://adservice.google.com.np/adsid/integrator.", ""]),
        dF = _.R(["https://adservice.google.nr/adsid/integrator.", ""]),
        eF = _.R(["https://adservice.google.nu/adsid/integrator.", ""]),
        fF = _.R(["https://adservice.google.co.nz/adsid/integrator.", ""]),
        gF = _.R(["https://adservice.google.com.om/adsid/integrator.", ""]),
        hF = _.R(["https://adservice.google.com.pa/adsid/integrator.", ""]),
        iF = _.R(["https://adservice.google.com.pe/adsid/integrator.", ""]),
        jF = _.R(["https://adservice.google.com.pg/adsid/integrator.", ""]),
        kF = _.R(["https://adservice.google.com.ph/adsid/integrator.", ""]),
        lF = _.R(["https://adservice.google.com.pk/adsid/integrator.", ""]),
        mF = _.R(["https://adservice.google.pl/adsid/integrator.", ""]),
        nF = _.R(["https://adservice.google.pn/adsid/integrator.", ""]),
        oF = _.R(["https://adservice.google.com.pr/adsid/integrator.", ""]),
        pF = _.R(["https://adservice.google.ps/adsid/integrator.", ""]),
        qF = _.R(["https://adservice.google.pt/adsid/integrator.", ""]),
        rF = _.R(["https://adservice.google.com.py/adsid/integrator.", ""]),
        sF = _.R(["https://adservice.google.com.qa/adsid/integrator.", ""]),
        tF = _.R(["https://adservice.google.ro/adsid/integrator.", ""]),
        uF = _.R(["https://adservice.google.rw/adsid/integrator.", ""]),
        vF = _.R(["https://adservice.google.com.sa/adsid/integrator.", ""]),
        wF = _.R(["https://adservice.google.com.sb/adsid/integrator.", ""]),
        xF = _.R(["https://adservice.google.sc/adsid/integrator.", ""]),
        yF = _.R(["https://adservice.google.se/adsid/integrator.", ""]),
        zF = _.R(["https://adservice.google.com.sg/adsid/integrator.", ""]),
        AF = _.R(["https://adservice.google.sh/adsid/integrator.", ""]),
        BF = _.R(["https://adservice.google.si/adsid/integrator.", ""]),
        CF = _.R(["https://adservice.google.sk/adsid/integrator.", ""]),
        DF = _.R(["https://adservice.google.sn/adsid/integrator.", ""]),
        EF = _.R(["https://adservice.google.so/adsid/integrator.", ""]),
        FF = _.R(["https://adservice.google.sm/adsid/integrator.", ""]),
        GF = _.R(["https://adservice.google.sr/adsid/integrator.", ""]),
        HF = _.R(["https://adservice.google.st/adsid/integrator.", ""]),
        IF = _.R(["https://adservice.google.com.sv/adsid/integrator.", ""]),
        JF = _.R(["https://adservice.google.td/adsid/integrator.", ""]),
        KF = _.R(["https://adservice.google.tg/adsid/integrator.", ""]),
        LF = _.R(["https://adservice.google.co.th/adsid/integrator.", ""]),
        MF = _.R(["https://adservice.google.com.tj/adsid/integrator.", ""]),
        NF = _.R(["https://adservice.google.tl/adsid/integrator.", ""]),
        OF = _.R(["https://adservice.google.tm/adsid/integrator.", ""]),
        PF = _.R(["https://adservice.google.tn/adsid/integrator.", ""]),
        QF = _.R(["https://adservice.google.to/adsid/integrator.", ""]),
        RF = _.R(["https://adservice.google.com.tr/adsid/integrator.", ""]),
        SF = _.R(["https://adservice.google.tt/adsid/integrator.", ""]),
        TF = _.R(["https://adservice.google.com.tw/adsid/integrator.", ""]),
        UF = _.R(["https://adservice.google.co.tz/adsid/integrator.", ""]),
        VF = _.R(["https://adservice.google.com.ua/adsid/integrator.", ""]),
        WF = _.R(["https://adservice.google.co.ug/adsid/integrator.", ""]),
        XF = _.R(["https://adservice.google.co.uk/adsid/integrator.", ""]),
        YF = _.R(["https://adservice.google.com.uy/adsid/integrator.", ""]),
        ZF = _.R(["https://adservice.google.co.uz/adsid/integrator.", ""]),
        $F = _.R(["https://adservice.google.com.vc/adsid/integrator.", ""]),
        aG = _.R(["https://adservice.google.co.ve/adsid/integrator.", ""]),
        bG = _.R(["https://adservice.google.vg/adsid/integrator.", ""]),
        cG = _.R(["https://adservice.google.co.vi/adsid/integrator.", ""]),
        dG = _.R(["https://adservice.google.com.vn/adsid/integrator.", ""]),
        eG = _.R(["https://adservice.google.vu/adsid/integrator.", ""]),
        fG = _.R(["https://adservice.google.ws/adsid/integrator.", ""]),
        gG = _.R(["https://adservice.google.rs/adsid/integrator.", ""]),
        hG = _.R(["https://adservice.google.co.za/adsid/integrator.", ""]),
        iG = _.R(["https://adservice.google.co.zm/adsid/integrator.", ""]),
        jG = _.R(["https://adservice.google.co.zw/adsid/integrator.", ""]),
        kG = _.R(["https://adservice.google.cat/adsid/integrator.", ""]),
        lG = new _.v.Map([
            [".google.com", function(a) {
                return _.A(uC, a)
            }],
            [".google.ad", function(a) {
                return _.A(vC, a)
            }],
            [".google.ae", function(a) {
                return _.A(wC, a)
            }],
            [".google.com.af", function(a) {
                return _.A(xC, a)
            }],
            [".google.com.ag", function(a) {
                return _.A(yC, a)
            }],
            [".google.com.ai", function(a) {
                return _.A(zC, a)
            }],
            [".google.al", function(a) {
                return _.A(AC, a)
            }],
            [".google.co.ao", function(a) {
                return _.A(BC, a)
            }],
            [".google.com.ar", function(a) {
                return _.A(CC, a)
            }],
            [".google.as", function(a) {
                return _.A(DC, a)
            }],
            [".google.at", function(a) {
                return _.A(TC, a)
            }],
            [".google.com.au", function(a) {
                return _.A(VC, a)
            }],
            [".google.az", function(a) {
                return _.A($C, a)
            }],
            [".google.com.bd", function(a) {
                return _.A(bD, a)
            }],
            [".google.be", function(a) {
                return _.A(cD, a)
            }],
            [".google.bf", function(a) {
                return _.A(dD, a)
            }],
            [".google.bg", function(a) {
                return _.A(eD, a)
            }],
            [".google.com.bh", function(a) {
                return _.A(fD, a)
            }],
            [".google.bi", function(a) {
                return _.A(gD, a)
            }],
            [".google.bj", function(a) {
                return _.A(hD, a)
            }],
            [".google.com.bn", function(a) {
                return _.A(iD, a)
            }],
            [".google.com.bo", function(a) {
                return _.A(jD, a)
            }],
            [".google.com.br", function(a) {
                return _.A(kD, a)
            }],
            [".google.bs", function(a) {
                return _.A(lD, a)
            }],
            [".google.bt", function(a) {
                return _.A(mD, a)
            }],
            [".google.co.bw", function(a) {
                return _.A(nD, a)
            }],
            [".google.com.bz", function(a) {
                return _.A(oD, a)
            }],
            [".google.ca", function(a) {
                return _.A(pD, a)
            }],
            [".google.cd", function(a) {
                return _.A(qD, a)
            }],
            [".google.cf", function(a) {
                return _.A(rD, a)
            }],
            [".google.cg", function(a) {
                return _.A(sD, a)
            }],
            [".google.ch", function(a) {
                return _.A(tD, a)
            }],
            [".google.ci", function(a) {
                return _.A(uD, a)
            }],
            [".google.co.ck", function(a) {
                return _.A(vD, a)
            }],
            [".google.cl", function(a) {
                return _.A(wD, a)
            }],
            [".google.cm", function(a) {
                return _.A(xD, a)
            }],
            [".google.com.co", function(a) {
                return _.A(yD, a)
            }],
            [".google.co.cr", function(a) {
                return _.A(zD, a)
            }],
            [".google.com.cu", function(a) {
                return _.A(AD, a)
            }],
            [".google.cv", function(a) {
                return _.A(BD, a)
            }],
            [".google.com.cy", function(a) {
                return _.A(CD, a)
            }],
            [".google.cz", function(a) {
                return _.A(DD, a)
            }],
            [".google.de", function(a) {
                return _.A(ED, a)
            }],
            [".google.dj", function(a) {
                return _.A(FD, a)
            }],
            [".google.dk", function(a) {
                return _.A(GD, a)
            }],
            [".google.dm", function(a) {
                return _.A(HD, a)
            }],
            [".google.dz", function(a) {
                return _.A(ID, a)
            }],
            [".google.com.ec", function(a) {
                return _.A(JD, a)
            }],
            [".google.ee", function(a) {
                return _.A(KD, a)
            }],
            [".google.com.eg", function(a) {
                return _.A(LD, a)
            }],
            [".google.es", function(a) {
                return _.A(MD, a)
            }],
            [".google.com.et", function(a) {
                return _.A(ND, a)
            }],
            [".google.fi", function(a) {
                return _.A(OD, a)
            }],
            [".google.com.fj", function(a) {
                return _.A(PD, a)
            }],
            [".google.fm", function(a) {
                return _.A(QD, a)
            }],
            [".google.fr", function(a) {
                return _.A(RD, a)
            }],
            [".google.ga", function(a) {
                return _.A(SD, a)
            }],
            [".google.ge", function(a) {
                return _.A(TD, a)
            }],
            [".google.gg", function(a) {
                return _.A(UD, a)
            }],
            [".google.com.gh", function(a) {
                return _.A(VD, a)
            }],
            [".google.com.gi", function(a) {
                return _.A(WD, a)
            }],
            [".google.gl", function(a) {
                return _.A(XD, a)
            }],
            [".google.gm", function(a) {
                return _.A(YD, a)
            }],
            [".google.gr", function(a) {
                return _.A(ZD, a)
            }],
            [".google.com.gt", function(a) {
                return _.A($D, a)
            }],
            [".google.gy", function(a) {
                return _.A(aE, a)
            }],
            [".google.com.hk", function(a) {
                return _.A(bE, a)
            }],
            [".google.hn", function(a) {
                return _.A(cE, a)
            }],
            [".google.hr", function(a) {
                return _.A(dE, a)
            }],
            [".google.ht", function(a) {
                return _.A(eE, a)
            }],
            [".google.hu", function(a) {
                return _.A(fE, a)
            }],
            [".google.co.id", function(a) {
                return _.A(gE, a)
            }],
            [".google.ie", function(a) {
                return _.A(hE, a)
            }],
            [".google.co.il", function(a) {
                return _.A(iE, a)
            }],
            [".google.im", function(a) {
                return _.A(jE, a)
            }],
            [".google.co.in", function(a) {
                return _.A(kE, a)
            }],
            [".google.iq", function(a) {
                return _.A(lE, a)
            }],
            [".google.is", function(a) {
                return _.A(mE, a)
            }],
            [".google.it", function(a) {
                return _.A(nE, a)
            }],
            [".google.je", function(a) {
                return _.A(oE, a)
            }],
            [".google.com.jm", function(a) {
                return _.A(pE, a)
            }],
            [".google.jo", function(a) {
                return _.A(qE, a)
            }],
            [".google.co.jp", function(a) {
                return _.A(rE, a)
            }],
            [".google.co.ke", function(a) {
                return _.A(sE, a)
            }],
            [".google.com.kh", function(a) {
                return _.A(tE, a)
            }],
            [".google.ki", function(a) {
                return _.A(uE, a)
            }],
            [".google.kg", function(a) {
                return _.A(vE, a)
            }],
            [".google.co.kr", function(a) {
                return _.A(wE, a)
            }],
            [".google.com.kw", function(a) {
                return _.A(xE, a)
            }],
            [".google.kz", function(a) {
                return _.A(yE, a)
            }],
            [".google.la", function(a) {
                return _.A(zE, a)
            }],
            [".google.com.lb", function(a) {
                return _.A(AE, a)
            }],
            [".google.li", function(a) {
                return _.A(BE, a)
            }],
            [".google.lk", function(a) {
                return _.A(CE, a)
            }],
            [".google.co.ls", function(a) {
                return _.A(DE, a)
            }],
            [".google.lt", function(a) {
                return _.A(EE, a)
            }],
            [".google.lu", function(a) {
                return _.A(FE, a)
            }],
            [".google.lv", function(a) {
                return _.A(GE, a)
            }],
            [".google.com.ly", function(a) {
                return _.A(HE, a)
            }],
            [".google.md", function(a) {
                return _.A(IE, a)
            }],
            [".google.me", function(a) {
                return _.A(JE, a)
            }],
            [".google.mg", function(a) {
                return _.A(KE, a)
            }],
            [".google.mk", function(a) {
                return _.A(LE, a)
            }],
            [".google.ml", function(a) {
                return _.A(ME, a)
            }],
            [".google.com.mm", function(a) {
                return _.A(NE, a)
            }],
            [".google.mn", function(a) {
                return _.A(OE, a)
            }],
            [".google.ms", function(a) {
                return _.A(PE, a)
            }],
            [".google.com.mt", function(a) {
                return _.A(QE, a)
            }],
            [".google.mu", function(a) {
                return _.A(RE, a)
            }],
            [".google.mv", function(a) {
                return _.A(SE, a)
            }],
            [".google.mw", function(a) {
                return _.A(TE, a)
            }],
            [".google.com.mx", function(a) {
                return _.A(UE, a)
            }],
            [".google.com.my", function(a) {
                return _.A(VE, a)
            }],
            [".google.co.mz", function(a) {
                return _.A(WE, a)
            }],
            [".google.com.na", function(a) {
                return _.A(XE, a)
            }],
            [".google.com.ng", function(a) {
                return _.A(YE, a)
            }],
            [".google.com.ni", function(a) {
                return _.A(ZE, a)
            }],
            [".google.ne", function(a) {
                return _.A($E, a)
            }],
            [".google.nl", function(a) {
                return _.A(aF, a)
            }],
            [".google.no", function(a) {
                return _.A(bF, a)
            }],
            [".google.com.np", function(a) {
                return _.A(cF, a)
            }],
            [".google.nr", function(a) {
                return _.A(dF, a)
            }],
            [".google.nu", function(a) {
                return _.A(eF, a)
            }],
            [".google.co.nz", function(a) {
                return _.A(fF, a)
            }],
            [".google.com.om", function(a) {
                return _.A(gF, a)
            }],
            [".google.com.pa", function(a) {
                return _.A(hF, a)
            }],
            [".google.com.pe", function(a) {
                return _.A(iF, a)
            }],
            [".google.com.pg", function(a) {
                return _.A(jF, a)
            }],
            [".google.com.ph", function(a) {
                return _.A(kF, a)
            }],
            [".google.com.pk", function(a) {
                return _.A(lF, a)
            }],
            [".google.pl", function(a) {
                return _.A(mF, a)
            }],
            [".google.pn", function(a) {
                return _.A(nF, a)
            }],
            [".google.com.pr", function(a) {
                return _.A(oF, a)
            }],
            [".google.ps", function(a) {
                return _.A(pF, a)
            }],
            [".google.pt", function(a) {
                return _.A(qF, a)
            }],
            [".google.com.py", function(a) {
                return _.A(rF, a)
            }],
            [".google.com.qa", function(a) {
                return _.A(sF, a)
            }],
            [".google.ro", function(a) {
                return _.A(tF, a)
            }],
            [".google.rw", function(a) {
                return _.A(uF, a)
            }],
            [".google.com.sa", function(a) {
                return _.A(vF, a)
            }],
            [".google.com.sb", function(a) {
                return _.A(wF, a)
            }],
            [".google.sc", function(a) {
                return _.A(xF, a)
            }],
            [".google.se", function(a) {
                return _.A(yF, a)
            }],
            [".google.com.sg", function(a) {
                return _.A(zF, a)
            }],
            [".google.sh", function(a) {
                return _.A(AF, a)
            }],
            [".google.si", function(a) {
                return _.A(BF, a)
            }],
            [".google.sk", function(a) {
                return _.A(CF, a)
            }],
            [".google.sn", function(a) {
                return _.A(DF, a)
            }],
            [".google.so", function(a) {
                return _.A(EF, a)
            }],
            [".google.sm", function(a) {
                return _.A(FF, a)
            }],
            [".google.sr", function(a) {
                return _.A(GF, a)
            }],
            [".google.st", function(a) {
                return _.A(HF, a)
            }],
            [".google.com.sv", function(a) {
                return _.A(IF, a)
            }],
            [".google.td", function(a) {
                return _.A(JF, a)
            }],
            [".google.tg", function(a) {
                return _.A(KF, a)
            }],
            [".google.co.th", function(a) {
                return _.A(LF, a)
            }],
            [".google.com.tj", function(a) {
                return _.A(MF, a)
            }],
            [".google.tl", function(a) {
                return _.A(NF, a)
            }],
            [".google.tm", function(a) {
                return _.A(OF, a)
            }],
            [".google.tn", function(a) {
                return _.A(PF, a)
            }],
            [".google.to", function(a) {
                return _.A(QF, a)
            }],
            [".google.com.tr", function(a) {
                return _.A(RF, a)
            }],
            [".google.tt", function(a) {
                return _.A(SF, a)
            }],
            [".google.com.tw", function(a) {
                return _.A(TF, a)
            }],
            [".google.co.tz", function(a) {
                return _.A(UF, a)
            }],
            [".google.com.ua", function(a) {
                return _.A(VF, a)
            }],
            [".google.co.ug", function(a) {
                return _.A(WF, a)
            }],
            [".google.co.uk", function(a) {
                return _.A(XF, a)
            }],
            [".google.com.uy", function(a) {
                return _.A(YF, a)
            }],
            [".google.co.uz", function(a) {
                return _.A(ZF, a)
            }],
            [".google.com.vc", function(a) {
                return _.A($F, a)
            }],
            [".google.co.ve", function(a) {
                return _.A(aG, a)
            }],
            [".google.vg", function(a) {
                return _.A(bG, a)
            }],
            [".google.co.vi", function(a) {
                return _.A(cG, a)
            }],
            [".google.com.vn", function(a) {
                return _.A(dG, a)
            }],
            [".google.vu", function(a) {
                return _.A(eG, a)
            }],
            [".google.ws", function(a) {
                return _.A(fG, a)
            }],
            [".google.rs", function(a) {
                return _.A(gG, a)
            }],
            [".google.co.za", function(a) {
                return _.A(hG, a)
            }],
            [".google.co.zm", function(a) {
                return _.A(iG, a)
            }],
            [".google.co.zw", function(a) {
                return _.A(jG, a)
            }],
            [".google.cat", function(a) {
                return _.A(kG, a)
            }]
        ].map(function(a) {
            var b = _.x(a);
            a = b.next().value;
            b = b.next().value;
            var c = {};
            return [a, (c.json = b("json"), c.js = b("js"), c["sync.js"] = b("sync.js"), c)]
        }));
    var mG = function(a, b, c) {
        var d = _.ze("LINK", a);
        try {
            if (d.rel = "preload", Ma("preload", "stylesheet")) {
                d.href = _.kb(b).toString();
                var e = Ww('style[nonce],link[rel="stylesheet"][nonce]', d.ownerDocument && d.ownerDocument.defaultView);
                e && d.setAttribute("nonce", e)
            } else d.href = b instanceof _.Ys ? _.kb(b).toString() : b instanceof _.cb ? _.db(b) : _.db(st(b))
        } catch (f) {
            return
        }
        d.as = "script";
        c && d.setAttribute("nonce", c);
        if (a = a.getElementsByTagName("head")[0]) try {
            a.appendChild(d)
        } catch (f) {}
    };
    var fh = /^data-(?!xml)[_a-z][_a-z.0-9-]*$/;
    var kh = _.q,
        nG = function(a) {
            var b = new _.v.Map([
                ["domain", _.q.location.hostname]
            ]);
            lh[3] >= gf() && b.set("adsid", lh[1]);
            return se(lG.get(a).js, b)
        },
        lh, oG, jh = function() {
            kh = _.q;
            lh = kh.googleToken = kh.googleToken || {};
            var a = gf();
            lh[1] && lh[3] > a && 0 < lh[2] || (lh[1] = "", lh[2] = -1, lh[3] = -1, lh[4] = "", lh[6] = "");
            oG = kh.googleIMState = kh.googleIMState || {};
            lG.has(oG[1]) || (oG[1] = ".google.com");
            Array.isArray(oG[5]) || (oG[5] = []);
            "boolean" !== typeof oG[6] && (oG[6] = !1);
            Array.isArray(oG[7]) || (oG[7] = []);
            "number" !== typeof oG[8] && (oG[8] = 0)
        },
        pG = function(a) {
            jh();
            lG.has(a) && (oG[1] = a)
        },
        mh = {
            re: function() {
                return 0 < oG[8]
            },
            ai: function() {
                oG[8]++
            },
            bi: function() {
                0 < oG[8] && oG[8]--
            },
            ci: function() {
                oG[8] = 0
            },
            gk: function() {
                return !1
            },
            ud: function() {
                return oG[5]
            },
            Ze: function(a) {
                try {
                    a()
                } catch (b) {
                    _.q.setTimeout(function() {
                        throw b;
                    }, 0)
                }
            },
            Sf: function() {
                if (!mh.re()) {
                    var a = _.q.document,
                        b = function(e) {
                            e = nG(e);
                            a: {
                                try {
                                    var f = Ww("script[nonce]");
                                    break a
                                } catch (g) {}
                                f = void 0
                            }
                            mG(a, e.toString(), f);
                            f = _.ze("SCRIPT", a);
                            f.type = "text/javascript";
                            f.onerror = function() {
                                return _.q.processGoogleToken({}, 2)
                            };
                            lb(f, e);
                            try {
                                (a.head || a.body || a.documentElement).appendChild(f), mh.ai()
                            } catch (g) {}
                        },
                        c = oG[1];
                    b(c);
                    ".google.com" != c && b(".google.com");
                    b = {};
                    var d = (b.newToken = "FBT", b);
                    _.q.setTimeout(function() {
                        return _.q.processGoogleToken(d, 1)
                    }, 1E3)
                }
            }
        },
        qG = function(a) {
            _.q.processGoogleToken = _.q.processGoogleToken || function(b, c) {
                var d = b;
                d = void 0 === d ? {} : d;
                c = void 0 === c ? 0 : c;
                b = d.newToken || "";
                var e = "NT" == b,
                    f = parseInt(d.freshLifetimeSecs || "", 10),
                    g = parseInt(d.validLifetimeSecs || "", 10),
                    h = d["1p_jar"] || "";
                d = d.pucrd || "";
                jh();
                1 == c ? mh.ci() : mh.bi();
                var k = kh.googleToken = kh.googleToken || {},
                    l = 0 == c && b && "string" === typeof b && !e && "number" === typeof f && 0 < f && "number" === typeof g && 0 < g && "string" === typeof h;
                e = e && !mh.re() && (!(lh[3] >= gf()) || "NT" == lh[1]);
                var n = !(lh[3] >= gf()) && 0 != c;
                if (l || e || n) e = gf(), f = e + 1E3 * f, g = e + 1E3 * g, 1E-5 > Math.random() && jA(_.q, "https://pagead2.googlesyndication.com/pagead/gen_204?id=imerr&err=" + c), k[5] = c, k[1] = b, k[2] = f, k[3] = g, k[4] = h, k[6] = d, jh();
                if (l || !mh.re()) {
                    c = mh.ud();
                    for (b = 0; b < c.length; b++) mh.Ze(c[b]);
                    c.length = 0
                }
            };
            nh(a)
        };
    var rG = function(a, b, c, d, e, f) {
        _.U.call(this);
        this.Xa = a;
        this.status = 1;
        this.B = b;
        this.m = c;
        this.G = d;
        this.Dc = !!e;
        this.l = Math.random();
        this.I = {};
        this.j = null;
        this.N = (0, _.ys)(this.R, this);
        this.A = f
    };
    _.P(rG, _.U);
    rG.prototype.R = function(a) {
        if (!("*" !== this.m && a.origin !== this.m || !this.Dc && a.source != this.B)) {
            var b = null;
            try {
                b = JSON.parse(a.data)
            } catch (c) {}
            if (_.na(b) && (a = b.i, b.c === this.Xa && a != this.l)) {
                if (2 !== this.status) try {
                    this.status = 2, sG(this), this.j && (this.j(), this.j = null)
                } catch (c) {}
                a = b.s;
                b = b.p;
                if ("string" === typeof a && ("string" === typeof b || _.na(b)) && this.I.hasOwnProperty(a)) this.I[a](b)
            }
        }
    };
    var sG = function(a) {
        var b = {};
        b.c = a.Xa;
        b.i = a.l;
        a.A && (b.e = a.A);
        a.B.postMessage(JSON.stringify(b), a.m)
    };
    rG.prototype.D = function() {
        if (1 === this.status) {
            try {
                this.B.postMessage && sG(this)
            } catch (a) {}
            window.setTimeout((0, _.ys)(this.D, this), 50)
        }
    };
    rG.prototype.connect = function(a) {
        a && (this.j = a);
        _.yb(window, "message", this.N);
        this.G && this.D()
    };
    var tG = function(a, b, c) {
            a.I[b] = c
        },
        uG = function(a, b, c) {
            var d = {};
            d.c = a.Xa;
            d.i = a.l;
            d.s = b;
            d.p = c;
            try {
                a.B.postMessage(JSON.stringify(d), a.m)
            } catch (e) {}
        };
    rG.prototype.o = function() {
        this.status = 3;
        _.Ae(window, "message", this.N);
        _.U.prototype.o.call(this)
    };
    var vG = new _.v.Map([
            ["navigate", 1],
            ["reload", 2],
            ["back_forward", 3],
            ["prerender", 4]
        ]),
        wG = new _.v.Map([
            [0, 1],
            [1, 2],
            [2, 3]
        ]);
    var xG = function(a) {
        _.T.call(this, a)
    };
    _.P(xG, _.T);
    var Aq = he(xG);
    var yG = function(a) {
        _.T.call(this, a)
    };
    _.P(yG, _.T);
    var zG = function(a) {
        _.T.call(this, a)
    };
    _.P(zG, _.T);
    var AG = function(a) {
            return a.prerendering ? 3 : {
                visible: 1,
                hidden: 2,
                prerender: 3,
                preview: 4,
                unloaded: 5
            }[a.visibilityState || a.webkitVisibilityState || a.mozVisibilityState || ""] || 0
        },
        BG = function(a) {
            var b;
            a.visibilityState ? b = "visibilitychange" : a.mozVisibilityState ? b = "mozvisibilitychange" : a.webkitVisibilityState && (b = "webkitvisibilitychange");
            return b
        },
        CG = function(a) {
            return null != a.hidden ? a.hidden : null != a.mozHidden ? a.mozHidden : null != a.webkitHidden ? a.webkitHidden : null
        },
        DG = function(a, b) {
            if (3 == AG(b)) return !1;
            a();
            return !0
        },
        EG = function(a, b) {
            if (!DG(a, b)) {
                var c = !1,
                    d = BG(b),
                    e = function() {
                        !c && DG(a, b) && (c = !0, _.Ae(b, d, e))
                    };
                d && _.yb(b, d, e)
            }
        };
    var nq = function(a, b) {
            this.j = a;
            this.m = b;
            this.o = {}
        },
        oq = function(a) {
            iq() && (document.addEventListener("touchstart", function(b) {
                a.j(902, function() {
                    a.o[b.touches[0].identifier] = Date.now()
                })()
            }, Ts), document.addEventListener("touchend", function(b) {
                a.j(902, function() {
                    var c = b.changedTouches[0],
                        d = c.clientX,
                        e = c.clientY,
                        f = c.force;
                    c = a.o[c.identifier];
                    if (void 0 !== c) try {
                        var g = iq(),
                            h = {
                                x: d,
                                y: e,
                                duration_ms: Date.now() - c
                            };
                        if (null == g ? 0 : g.gmaSdk) g.gmaSdk.reportTouchEvent(JSON.stringify(_.u(Object, "assign").call(Object, {}, h, {
                            type: 1,
                            force: f
                        })));
                        else {
                            var k, l, n;
                            null == g || null == (k = g.webkit) || null == (l = k.messageHandlers) || null == (n = l.reportGmaTouchEvent) || n.postMessage(h)
                        }
                    } catch (m) {
                        a.m("paw_sigs", {
                            msg: "reportTouchError",
                            err: m instanceof Error ? m.message : "nonError"
                        })
                    }
                })()
            }, Ts))
        },
        jq = function(a, b, c, d, e) {
            var f = 200,
                g = bq;
            b = void 0 === b ? {} : b;
            c = void 0 === c ? function() {} : c;
            d = void 0 === d ? function() {} : d;
            f = void 0 === f ? 200 : f;
            var h = String(Math.floor(2147483647 * _.Ue())),
                k = 0,
                l = function(n) {
                    try {
                        var m = "object" === typeof n.data ? n.data : JSON.parse(n.data);
                        h === m.paw_id && (window.clearTimeout(k), window.removeEventListener("message", l), m.signal ? c(m.signal) : m.error && d(m.error))
                    } catch (p) {
                        g("paw_sigs", {
                            msg: "postmessageError",
                            err: p instanceof Error ? p.message : "nonError",
                            data: null == n.data ? "null" : 500 < n.data.length ? n.data.substring(0, 500) : n.data
                        })
                    }
                };
            window.addEventListener("message", function(n) {
                e(903, function() {
                    l(n)
                })()
            });
            a.postMessage(_.u(Object, "assign").call(Object, {}, {
                paw_id: h
            }, b));
            k = window.setTimeout(function() {
                window.removeEventListener("message", l);
                d("PAW GMA postmessage timed out.")
            }, f)
        },
        iq = function() {
            var a = window,
                b, c;
            if (a.gmaSdk || (null == (b = a.webkit) ? 0 : null == (c = b.messageHandlers) ? 0 : c.getGmaViewSignals)) return a;
            try {
                var d = window.parent,
                    e, f;
                if (d.gmaSdk || (null == (e = d.webkit) ? 0 : null == (f = e.messageHandlers) ? 0 : f.getGmaViewSignals)) return d
            } catch (g) {}
            return null
        };
    var FG = function(a) {
        _.T.call(this, a)
    };
    _.P(FG, _.T);
    var HG = function(a) {
        _.T.call(this, a, -1, GG)
    };
    _.P(HG, _.T);
    var GG = [1],
        IG = [HG, 1, Wu, Pv];
    var KG = function(a) {
        _.T.call(this, a, -1, JG)
    };
    _.P(KG, _.T);
    var JG = [1, 2];
    KG.prototype.m = ge([KG, 1, Wu, Pv, 2, Wu, IG]);
    var MG, LG;
    MG = function() {
        this.wasPlaTagProcessed = !1;
        this.wasReactiveAdConfigReceived = {};
        this.adCount = {};
        this.wasReactiveAdVisible = {};
        this.stateForType = {};
        this.reactiveTypeEnabledInAsfe = {};
        this.wasReactiveTagRequestSent = !1;
        this.reactiveTypeDisabledByPublisher = {};
        this.tagSpecificState = {};
        this.messageValidationEnabled = !1;
        this.floatingAdsStacking = new LG;
        this.sideRailProcessedFixedElements = new _.v.Set;
        this.sideRailAvailableSpace = new _.v.Map;
        this.sideRailPlasParam = new _.v.Map
    };
    _.Rm = function(a) {
        a.google_reactive_ads_global_state ? (null == a.google_reactive_ads_global_state.sideRailProcessedFixedElements && (a.google_reactive_ads_global_state.sideRailProcessedFixedElements = new _.v.Set), null == a.google_reactive_ads_global_state.sideRailAvailableSpace && (a.google_reactive_ads_global_state.sideRailAvailableSpace = new _.v.Map), null == a.google_reactive_ads_global_state.sideRailPlasParam && (a.google_reactive_ads_global_state.sideRailPlasParam = new _.v.Map)) : a.google_reactive_ads_global_state = new MG;
        return a.google_reactive_ads_global_state
    };
    LG = function() {
        this.maxZIndexRestrictions = {};
        this.nextRestrictionId = 0;
        this.maxZIndexListeners = []
    };
    var RG, OG;
    _.NG = function(a) {
        this.j = _.Rm(a).floatingAdsStacking
    };
    _.PG = function(a, b) {
        return new OG(a, b)
    };
    _.QG = function(a) {
        a = _.tx(a.j.maxZIndexRestrictions);
        return a.length ? Math.min.apply(null, a) : null
    };
    RG = function(a) {
        var b = _.QG(a);
        _.Us(a.j.maxZIndexListeners, function(c) {
            return c(b)
        })
    };
    OG = function(a, b) {
        this.o = a;
        this.m = b;
        this.j = null
    };
    _.SG = function(a) {
        if (null == a.j) {
            var b = a.o,
                c = a.m,
                d = b.j.nextRestrictionId++;
            b.j.maxZIndexRestrictions[d] = c;
            RG(b);
            a.j = d
        }
    };
    _.TG = function(a) {
        if (null != a.j) {
            var b = a.o;
            delete b.j.maxZIndexRestrictions[a.j];
            RG(b);
            a.j = null
        }
    };
    var xh, yh;
    _.Sm = 728 * 1.38;
    _.wh = function(a) {
        return a.innerHeight >= a.innerWidth
    };
    _.UG = function(a) {
        var b = _.Im(a).clientWidth;
        a = a.innerWidth;
        return b && a ? b / a : 0
    };
    xh = function(a, b) {
        return (a = _.Im(a).clientWidth) ? a > (void 0 === b ? 420 : b) ? 32768 : 320 > a ? 65536 : 0 : 16384
    };
    yh = function(a) {
        return (a = _.UG(a)) ? 1.05 < a ? 262144 : .95 > a ? 524288 : 0 : 131072
    };
    _.Im = function(a) {
        a = a.document;
        var b = {};
        a && (b = "CSS1Compat" == a.compatMode ? a.documentElement : a.body);
        return b || {}
    };
    _.VG = function(a) {
        return void 0 === a.pageYOffset ? (a.document.documentElement || a.document.body.parentNode || a.document.body).scrollTop : a.pageYOffset
    };
    var Ah = 90 * 1.38;
    var WG;
    _.XG = function(a, b) {
        if (!a.body) return null;
        var c = new WG;
        c.apply(a, b);
        return function() {
            _.Wx(a.body, {
                filter: c.j,
                webkitFilter: c.j,
                overflow: c.m,
                position: c.H,
                top: c.B
            });
            b.scrollTo(0, c.o)
        }
    };
    WG = function() {
        this.j = this.B = this.H = this.m = null;
        this.o = 0
    };
    WG.prototype.apply = function(a, b) {
        this.m = a.body.style.overflow;
        this.H = a.body.style.position;
        this.B = a.body.style.top;
        this.j = a.body.style.filter ? a.body.style.filter : a.body.style.webkitFilter;
        this.o = _.VG(b);
        _.Wx(a.body, "top", -this.o + "px")
    };
    _.Km = function(a, b) {
        var c;
        if (!(c = 0 >= b) && !(c = null == a)) {
            try {
                a.setItem("__storage_test__", "__storage_test__");
                var d = a.getItem("__storage_test__");
                a.removeItem("__storage_test__");
                var e = "__storage_test__" === d
            } catch (f) {
                e = !1
            }
            c = !e
        }
        return c ? null : Mh(a, b)
    };
    _.Jm = function(a) {
        return !!a && 1 > a.length
    };
    var YG = {},
        Qh = (YG[23] = .001, YG[253] = !1, YG[246] = [], YG[150] = "", YG[221] = /^true$/.test("false"), YG[36] = /^true$/.test("false"), YG[172] = null, YG[260] = void 0, YG[251] = null, YG),
        Ph = function() {
            this.j = !1
        };
    var Zk = function(a) {
            var b = void 0 === b ? sf(_.q) : b;
            this.id = a;
            this.o = Math.random() < (_.E(Ry) ? .001 : _.Rh(23));
            this.j = {
                pvsid: String(b)
            }
        },
        ZG = function(a) {
            a = Oh(a);
            var b;
            mi.set(a, (null != (b = mi.get(a)) ? b : 0) + 1)
        },
        li = function() {
            return [].concat(_.ue(_.u(mi, "values").call(mi))).reduce(function(a, b) {
                return a + b
            }, 0)
        },
        L = function(a, b, c) {
            "string" !== typeof c && (c = String(c));
            /^\w+$/.test(b) && (c ? a.j[b] = c : delete a.j[b])
        },
        al = function(a) {
            var b = 1;
            b = void 0 === b ? null : b;
            if ($G()) b = !0;
            else {
                var c = a.o;
                b && 0 <= b && (c = Math.random() < b);
                b = c && !!a.id
            }
            b && jA(window, aH(a) || "", void 0, _.E(Wy))
        },
        aH = function(a) {
            var b = "https://pagead2.googlesyndication.com/pagead/gen_204?id=" + encodeURIComponent(a.id);
            _.El(a.j, function(c, d) {
                c && (b += "&" + d + "=" + encodeURIComponent(c))
            });
            return b
        },
        bH = function(a) {
            var b = [].concat(_.ue(_.u(mi, "keys").call(mi)));
            b = b.map(function(c) {
                return c.replace(/,/g, "\\,")
            });
            3 >= b.length ? L(a, "nw_id", b.join()) : (b = b.slice(0, 3), b.push("__extra__"), L(a, "nw_id", b.join()))
        },
        Ej = function(a, b) {
            L(a, "vrg", String(b.Hb || b.Ta));
            bH(a);
            L(a, "nslots", li().toString());
            b = _.nf( of ).j();
            b.length && L(a, "eid", b.join());
            L(a, "pub_url", document.URL)
        },
        yj = function(a, b, c) {
            c = void 0 === c ? _.E(Ry) ? .001 : _.Rh(23) : c;
            if (void 0 === c || 0 > c || 1 < c) c = _.E(Ry) ? .001 : _.Rh(23);
            Math.random() < c && (a = new Zk(a), b(a), al(a))
        },
        mi = new _.v.Map,
        $G = ij(function() {
            return !!xx(_.q.location.href)
        });
    var bi = function() {
        tB.call(this, _.E(ci) || _.E(Fz) ? 1 : 0, _.q);
        this.m = 0;
        var a = _.E(ci) || _.E(Fz);
        _.q.google_measure_js_timing = a || _.q.google_measure_js_timing
    };
    _.P(bi, tB);
    _.cH = function(a) {
        this.context = a
    };
    _.cH.prototype.Jb = function(a, b) {
        return fi(this.context, a, b)
    };
    _.cH.prototype.ra = function(a, b) {
        return $h(this.context, a, b)
    };
    _.cH.prototype.Xb = function(a, b) {
        di(this.context, a, b);
        return !1
    };
    _.cH.prototype.Jc = da(0);
    var dH = {},
        eH = (dH.companion_ads = "companionAds", dH.content = "content", dH.publisher_ads = "pubads", dH);
    var oi = function(a) {
        _.T.call(this, a)
    };
    _.P(oi, _.T);
    oi.prototype.getWidth = function() {
        return pi(this, 1)
    };
    var Ii = function(a, b) {
        return _.z(a, 1, b)
    };
    oi.prototype.getHeight = function() {
        return pi(this, 2)
    };
    var Hi = function(a, b) {
            return _.z(a, 2, b)
        },
        km = function() {
            var a = new oi;
            return _.z(a, 3, !0)
        };
    var ml = function(a) {
        _.T.call(this, a, -1, fH)
    };
    _.P(ml, _.T);
    var ll = function(a, b) {
            return _.z(a, 1, b)
        },
        kl = function(a, b) {
            return _.ed(a, 2, b, _.Hc)
        },
        gH = function(a, b) {
            return Ku(a, 2, b)
        },
        fH = [2];
    var Tq = function(a) {
        _.T.call(this, a)
    };
    _.P(Tq, _.T);
    var hH = function(a, b) {
        return _.z(a, 3, _.Bc(b))
    };
    var gp = function(a) {
        _.T.call(this, a, -1, iH)
    };
    _.P(gp, _.T);
    var mp = function(a, b) {
            return _.z(a, 1, b)
        },
        kp = function(a, b) {
            return _.ed(a, 2, b, _.Hc)
        },
        iH = [2];
    var Lp = function(a) {
        _.T.call(this, a, -1, jH)
    };
    _.P(Lp, _.T);
    var lp = function(a, b) {
            _.Xf(a, 1, gp, b)
        },
        jH = [1];
    var Jp = function(a) {
        _.T.call(this, a, -1, kH)
    };
    _.P(Jp, _.T);
    var kH = [2, 3];
    var Hp = function(a) {
        _.T.call(this, a)
    };
    _.P(Hp, _.T);
    var lH = function(a) {
        _.T.call(this, a)
    };
    _.P(lH, _.T);
    lH.prototype.setTagForChildDirectedTreatment = function(a) {
        return _.z(this, 5, a)
    };
    lH.prototype.clearTagForChildDirectedTreatment = function() {
        return yf(this, 5)
    };
    lH.prototype.setTagForUnderAgeOfConsent = function(a) {
        return _.z(this, 6, a)
    };
    var Dl = function(a) {
        _.T.call(this, a)
    };
    _.P(Dl, _.T);
    var nH = function(a) {
        _.T.call(this, a, -1, mH)
    };
    _.P(nH, _.T);
    nH.prototype.getCategoryExclusions = function(a) {
        return Ju(this, 3, a)
    };
    nH.prototype.xa = function() {
        return Pe(this, ml, 14)
    };
    nH.prototype.gb = function() {
        return Df(this, Dl, 18)
    };
    var sn = function(a) {
        return Df(a, lH, 25)
    };
    nH.prototype.getCorrelator = function() {
        return y(this, 26)
    };
    nH.prototype.setCorrelator = function(a) {
        return _.z(this, 26, a)
    };
    nH.prototype.vd = function() {
        return Ip(this, Hp, 33)
    };
    var mH = [2, 3, 14];
    var $i = function() {
        this.j = new _.v.Map
    };
    var oH = function() {
            this.o = {};
            this.j = new nH;
            this.m = new _.v.Map;
            this.j.setCorrelator(Mx());
            _.Rh(36) && _.z(this.j, 15, !0)
        },
        pH = function(a) {
            var b = rj(),
                c = a.getDomId();
            if (c && !b.o.hasOwnProperty(c)) {
                var d = _.nf($i),
                    e = ++_.nf(bi).m;
                d.j.set(c, e);
                _.z(a, 20, e);
                b.o[c] = a
            }
        },
        Zn = function(a, b) {
            return a.o[b]
        },
        rj = function() {
            return _.nf(oH)
        };
    var cj = ij(fj);
    var Nj = ["auto", "inherit", "100%"],
        Oj = Nj.concat(["none"]);
    var Bm = function(a, b, c) {
        if (!a) return !0;
        var d = !0;
        Lj(a, function(e) {
            return d = Mj(e, b, 10, 10)
        }, c);
        return d
    };
    var qH = function(a, b, c, d, e, f) {
            this.m = _.Qx(a);
            this.o = _.Qx(b);
            this.H = c;
            this.j = _.Qx(d);
            this.B = e;
            this.l = f
        },
        rH = function(a) {
            return JSON.stringify({
                windowCoords_t: a.m.top,
                windowCoords_r: a.m.right,
                windowCoords_b: a.m.bottom,
                windowCoords_l: a.m.left,
                frameCoords_t: a.o.top,
                frameCoords_r: a.o.right,
                frameCoords_b: a.o.bottom,
                frameCoords_l: a.o.left,
                styleZIndex: a.H,
                allowedExpansion_t: a.j.top,
                allowedExpansion_r: a.j.right,
                allowedExpansion_b: a.j.bottom,
                allowedExpansion_l: a.j.left,
                xInView: a.B,
                yInView: a.l
            })
        },
        sH = function(a) {
            var b = window,
                c = b.screenX || b.screenLeft || 0,
                d = b.screenY || b.screenTop || 0;
            b = new _.Px(d, c + (b.outerWidth || document.documentElement.clientWidth || 0), d + (b.outerHeight || document.documentElement.clientHeight || 0), c);
            c = $x(a);
            d = _.Gh(_.Hh, a);
            var e = new Rx(c.x, c.y, d.width, d.height);
            c = Sx(e);
            d = String(Fh(a, "zIndex"));
            var f = new _.Px(0, Infinity, Infinity, 0);
            for (var g = dx(a), h = g.j.body, k = g.j.documentElement, l = ix(g.j); a = Zx(a);)
                if (!(_.Vt && 0 == a.clientWidth || Yt && 0 == a.clientHeight && a == h) && a != h && a != k && "visible" != Fh(a, "overflow")) {
                    var n = $x(a),
                        m = new _.Vi(a.clientLeft, a.clientTop);
                    n.x += m.x;
                    n.y += m.y;
                    f.top = Math.max(f.top, n.y);
                    f.right = Math.min(f.right, n.x + a.clientWidth);
                    f.bottom = Math.min(f.bottom, n.y + a.clientHeight);
                    f.left = Math.max(f.left, n.x)
                }
            a = l.scrollLeft;
            l = l.scrollTop;
            f.left = Math.max(f.left, a);
            f.top = Math.max(f.top, l);
            g = g.j;
            g = _.hx(g.parentWindow || g.defaultView || window);
            f.right = Math.min(f.right, a + g.width);
            f.bottom = Math.min(f.bottom, l + g.height);
            l = (f = (f = 0 <= f.top && 0 <= f.left && f.bottom > f.top && f.right > f.left ? f : null) ? new Rx(f.left, f.top, f.right - f.left, f.bottom - f.top) : null) ? Tx(e, f) : null;
            g = a = 0;
            l && !(new _.Yi(l.width, l.height)).isEmpty() && (a = l.width / e.width, g = l.height / e.height);
            l = new _.Px(0, 0, 0, 0);
            if (h = f)(e = Tx(e, f)) ? (k = Sx(f), n = Sx(e), h = n.right != k.left && k.right != n.left, k = n.bottom != k.top && k.bottom != n.top, h = (0 != e.width || h) && (0 != e.height || k)) : h = !1;
            h && (l = new _.Px(Math.max(c.top - f.top, 0), Math.max(f.left + f.width - c.right, 0), Math.max(f.top + f.height - c.bottom, 0), Math.max(c.left - f.left, 0)));
            return new qH(b, c, d, l, a, g)
        };
    var tH = function(a) {
        this.H = a;
        this.B = null;
        this.ia = this.status = 0;
        this.o = null;
        this.Xa = "sfchannel" + a
    };
    var uH = function(a) {
        this.j = a
    };
    var vH = function(a, b) {
        this.od = a;
        this.pd = b;
        this.o = this.j = !1
    };
    var wH = function(a, b, c, d, e, f, g, h) {
        h = void 0 === h ? [] : h;
        this.o = a;
        this.m = b;
        this.H = c;
        this.permissions = d;
        this.metadata = e;
        this.B = f;
        this.Dc = g;
        this.hostpageLibraryTokens = h;
        this.j = ""
    };
    var xH = function(a, b) {
        this.o = a;
        this.H = b
    };
    xH.prototype.j = function(a) {
        this.H && a && (a.sentinel = this.H);
        return JSON.stringify(a)
    };
    var yH = function(a, b, c) {
        xH.call(this, a, void 0 === c ? "" : c);
        this.version = b
    };
    _.P(yH, xH);
    yH.prototype.j = function() {
        return xH.prototype.j.call(this, {
            uid: this.o,
            version: this.version
        })
    };
    var zH = function(a, b, c, d) {
        xH.call(this, a, void 0 === d ? "" : d);
        this.B = b;
        this.m = c
    };
    _.P(zH, xH);
    zH.prototype.j = function() {
        return xH.prototype.j.call(this, {
            uid: this.o,
            initialWidth: this.B,
            initialHeight: this.m
        })
    };
    var AH = function(a, b, c) {
        xH.call(this, a, void 0 === c ? "" : c);
        this.description = b
    };
    _.P(AH, xH);
    AH.prototype.j = function() {
        return xH.prototype.j.call(this, {
            uid: this.o,
            description: this.description
        })
    };
    var BH = function(a, b, c, d) {
        xH.call(this, a, void 0 === d ? "" : d);
        this.m = b;
        this.push = c
    };
    _.P(BH, xH);
    BH.prototype.j = function() {
        return xH.prototype.j.call(this, {
            uid: this.o,
            expand_t: this.m.top,
            expand_r: this.m.right,
            expand_b: this.m.bottom,
            expand_l: this.m.left,
            push: this.push
        })
    };
    var CH = function(a, b) {
        xH.call(this, a, void 0 === b ? "" : b)
    };
    _.P(CH, xH);
    CH.prototype.j = function() {
        return xH.prototype.j.call(this, {
            uid: this.o
        })
    };
    var DH = function(a, b, c) {
        xH.call(this, a, void 0 === c ? "" : c);
        this.B = b
    };
    _.P(DH, xH);
    DH.prototype.j = function() {
        var a = {
            uid: this.o,
            newGeometry: rH(this.B)
        };
        return xH.prototype.j.call(this, a)
    };
    var EH = function(a, b, c, d, e, f) {
        DH.call(this, a, c, void 0 === f ? "" : f);
        this.success = b;
        this.m = d;
        this.push = e
    };
    _.P(EH, DH);
    EH.prototype.j = function() {
        var a = {
            uid: this.o,
            success: this.success,
            newGeometry: rH(this.B),
            expand_t: this.m.top,
            expand_r: this.m.right,
            expand_b: this.m.bottom,
            expand_l: this.m.left,
            push: this.push
        };
        this.H && (a.sentinel = this.H);
        return JSON.stringify(a)
    };
    var FH = function(a, b, c, d) {
        xH.call(this, a, void 0 === d ? "" : d);
        this.width = b;
        this.height = c
    };
    _.P(FH, xH);
    FH.prototype.j = function() {
        return xH.prototype.j.call(this, {
            uid: this.o,
            width: this.width,
            height: this.height
        })
    };
    var GH = function(a) {
        var b;
        if (null == (b = a.location) ? 0 : b.ancestorOrigins) return a.location.ancestorOrigins.length;
        var c = 0;
        me(function() {
            c++;
            return !1
        }, !0, !0, a);
        return c
    };
    var HH = function() {
            this.j = []
        },
        JH = function(a, b, c, d, e) {
            a.j.push(new IH(b, c, d, e))
        },
        KH = function(a) {
            for (var b = a.j.length - 1; 0 <= b; b--) {
                var c = a.j[b];
                c.o ? (c.m.style.removeProperty(c.j), c.m.style.setProperty(c.j, String(c.H), c.B)) : c.m.style[c.j] = c.H
            }
            a.j.length = 0
        },
        IH = function(a, b, c, d) {
            this.m = a;
            this.j = (this.o = !(void 0 === d || !a.style || !a.style.getPropertyPriority)) ? String(b).replace(/([A-Z])/g, "-$1").toLowerCase() : b;
            this.H = this.o ? a.style.getPropertyValue(this.j) : a.style[this.j];
            this.B = this.o ? a.style.getPropertyPriority(this.j) : void 0;
            this.o ? (a.style.removeProperty(this.j), a.style.setProperty(this.j, String(c), d)) : a.style[this.j] = String(c)
        };
    var LH = function(a, b) {
            b = b.google_js_reporting_queue = b.google_js_reporting_queue || [];
            2048 > b.length && b.push(a)
        },
        MH = function() {
            var a = window,
                b = _.jf(a);
            b && LH({
                label: "2",
                type: 9,
                value: b
            }, a)
        },
        NH = function(a, b, c) {
            var d = void 0 === d ? !1 : d;
            var e = window,
                f = "undefined" !== typeof queueMicrotask;
            return function() {
                d && f && queueMicrotask(function() {
                    e.google_rum_task_id_counter = e.google_rum_task_id_counter || 1;
                    e.google_rum_task_id_counter += 1
                });
                var g = _.jf(),
                    h = 3;
                try {
                    var k = b.apply(this, arguments)
                } catch (l) {
                    h = 13;
                    if (!c) throw l;
                    c(a, l)
                } finally {
                    e.google_measure_js_timing && g && LH(_.u(Object, "assign").call(Object, {}, {
                        label: a.toString(),
                        value: g,
                        duration: (_.jf() || 0) - g,
                        type: h
                    }, d && f && {
                        taskId: e.google_rum_task_id_counter = e.google_rum_task_id_counter || 1
                    }), e)
                }
                return k
            }
        };
    var SH = function(a) {
        tH.call(this, a.uniqueId);
        var b = this;
        this.I = a.Tj;
        this.N = 1 === a.size;
        this.T = new vH(a.permissions.od && !this.N, a.permissions.pd && !this.N);
        this.l = a.Ie;
        var c;
        this.ma = null != (c = a.hostpageLibraryTokens) ? c : [];
        var d = window.location;
        c = d.protocol;
        d = d.host;
        this.ha = "file:" == c ? "*" : c + "//" + d;
        this.na = !!a.Dc;
        this.L = a.Xf ? "//" + a.Xf + ".safeframe.googlesyndication.com" : "//tpc.googlesyndication.com";
        this.da = a.xd ? "*" : "https:" + this.L;
        this.Y = !!a.Qg;
        this.qa = OH(a);
        this.m = new HH;
        PH(this, a.Ie, a.size);
        this.B = this.la = sH(a.Ie);
        this.G = a.hi || "1-0-40";
        var e;
        this.ca = null != (e = a.Bg) ? e : "";
        QH(this, a);
        this.D = NH(412, function() {
            return RH(b)
        }, a.Sa);
        this.R = -1;
        this.A = 0;
        var f = NH(415, function() {
            b.j && (b.j.name = "", a.Kf && a.Kf(), _.Ae(b.j, "load", f))
        }, a.Sa);
        _.yb(this.j, "load", f);
        this.ve = NH(413, this.ve, a.Sa);
        this.Ke = NH(417, this.Ke, a.Sa);
        this.Me = NH(419, this.Me, a.Sa);
        this.ne = NH(411, this.ne, a.Sa);
        this.Yd = NH(409, this.Yd, a.Sa);
        this.O = NH(410, this.O, a.Sa);
        this.Ee = NH(416, this.Ee, a.Sa);
        this.o = new rG(this.Xa, this.j.contentWindow, this.da, !1);
        tG(this.o, "init_done", (0, _.ys)(this.ve, this));
        tG(this.o, "register_done", (0, _.ys)(this.Ke, this));
        tG(this.o, "report_error", (0, _.ys)(this.Me, this));
        tG(this.o, "expand_request", (0, _.ys)(this.ne, this));
        tG(this.o, "collapse_request", (0, _.ys)(this.Yd, this));
        tG(this.o, "creative_geometry_update", (0, _.ys)(this.O, this));
        this.o.connect((0, _.ys)(this.Ee, this))
    };
    _.P(SH, tH);
    var PH = function(a, b, c) {
            a.N ? (b.style.width = _.by("100%", !0), b.style.height = _.by("auto", !0)) : (b.style.width = _.by(c.width, !0), b.style.height = _.by(c.height, !0))
        },
        QH = function(a, b) {
            var c = b.xd,
                d = b.content,
                e = b.Bc,
                f = b.size,
                g = void 0 === b.Cc ? "3rd party ad content" : b.Cc,
                h = b.rd;
            b = b.Td;
            var k = {
                shared: {
                    sf_ver: a.G,
                    ck_on: eB() ? 1 : 0,
                    flash_ver: "0"
                }
            };
            d = c ? "" : null != d ? d : "";
            d = a.G + ";" + d.length + ";" + d;
            k = new wH(a.H, a.ha, a.la, a.T, new uH(k), a.N, a.na, a.ma);
            var l = {};
            l.uid = k.o;
            l.hostPeerName = k.m;
            l.initialGeometry = rH(k.H);
            var n = k.permissions;
            n = JSON.stringify({
                expandByOverlay: n.od,
                expandByPush: n.pd,
                readCookie: n.j,
                writeCookie: n.o
            });
            l = (l.permissions = n, l.metadata = JSON.stringify(k.metadata.j), l.reportCreativeGeometry = k.B, l.isDifferentSourceWindow = k.Dc, l.goog_safeframe_hlt = tC(k.hostpageLibraryTokens), l);
            k.j && (l.sentinel = k.j);
            k = JSON.stringify(l);
            d += k;
            a.Y && f instanceof _.Yi && (k = _.jx(_.cx(a.l)), l = _.jx(_.cx(a.l)).location.protocol + a.L, hC || bl(k.document, iC), hC++, k.google_eas_queue = k.google_eas_queue || [], k.google_eas_queue.push({
                a: e,
                b: l,
                c: f.width,
                d: f.height,
                e: "sf-gdn-exp-" + hC,
                f: void 0,
                g: void 0,
                h: void 0,
                i: void 0
            }));
            k = f.width;
            f = f.height;
            a.N && (f = k = 0);
            l = {};
            e = (l.id = e, l.title = g, l.name = d, l.scrolling = "no", l.marginWidth = "0", l.marginHeight = "0", l.width = String(k), l.height = String(f), l["data-is-safeframe"] = "true", l);
            void 0 === c && (g = _.jx(_.cx(a.l)), f = a.ca, d = a.L, (k = f) && (k = "?" + k), d = (void 0 === d ? "//tpc.googlesyndication.com" : d) + ("/safeframe/" + a.G + "/html/container.html" + k), (k = GH(g)) && (d += (f ? "&" : "?") + "n=" + k), f = "https:" + d, d = [], a.Y && (k = xx(g.location.href), g = d.push, k = [0 < k.length ? "google_debug" + (k ? "=" + k : "") + "&" : "", "xpc=", "sf-gdn-exp-" + a.H, "&p=", encodeURIComponent(_.q.document.location.protocol), "//", encodeURIComponent(_.q.document.location.host)].join(""), g.call(d, k)), d.length && (f += "#" + d.join("&")), e.src = f);
            null !== a.qa && (e.sandbox = a.qa);
            h && (e.allow = h);
            b && (e.credentialless = "true");
            e.role = "region";
            e["aria-label"] = "Advertisement";
            e.tabIndex = "0";
            c ? (a.j = c, fx(a.j, e)) : (c = {}, c = (c.frameborder = 0, c.allowTransparency = "true", c.style = "border:0;vertical-align:bottom;", c.src = "about:blank", c), e && Ia(c, e), h = _.ze("IFRAME"), fx(h, c), a.j = h);
            a.N && (a.j.style.minWidth = "100%");
            a.l.appendChild(a.j)
        };
    _.aa = SH.prototype;
    _.aa.Ee = function() {
        _.yb(window, "resize", this.D);
        _.yb(window, "scroll", this.D)
    };
    _.aa.ve = function(a) {
        try {
            if (0 != this.status) throw Error("Container already initialized");
            if ("string" !== typeof a) throw Error("Could not parse serialized message");
            var b = JSON.parse(a);
            if (!_.na(b) || !Qj(b.uid) || "string" !== typeof b.version) throw Error("Cannot parse JSON message");
            var c = new yH(b.uid, b.version, b.sentinel);
            if (this.H !== c.o || this.G !== c.version) throw Error("Wrong source container");
            this.status = 1
        } catch (e) {
            var d;
            null == (d = this.I) || d.error("Invalid INITIALIZE_DONE message. Reason: " + e.message)
        }
    };
    _.aa.Ke = function(a) {
        try {
            if (1 != this.status) throw Error("Container not initialized");
            if ("string" !== typeof a) throw Error("Could not parse serialized message");
            var b = JSON.parse(a);
            if (!_.na(b) || !Qj(b.uid) || "number" !== typeof b.initialWidth || "number" !== typeof b.initialHeight) throw Error("Cannot parse JSON message");
            if (this.H !== (new zH(b.uid, b.initialWidth, b.initialHeight, b.sentinel)).o) throw Error("Wrong source container");
            this.status = 2
        } catch (d) {
            var c;
            null == (c = this.I) || c.error("Invalid REGISTER_DONE message. Reason: " + d.message)
        }
    };
    _.aa.Me = function(a) {
        try {
            if ("string" !== typeof a) throw Error("Could not parse serialized message");
            var b = JSON.parse(a);
            if (!_.na(b) || !Qj(b.uid) || "string" !== typeof b.description) throw Error("Cannot parse JSON message");
            var c = new AH(b.uid, b.description, b.sentinel);
            if (this.H !== c.o) throw Error("Wrong source container");
            var d;
            null == (d = this.I) || d.info("Ext reported an error. Description: " + c.description)
        } catch (f) {
            var e;
            null == (e = this.I) || e.error("Invalid REPORT_ERROR message. Reason: " + f.message)
        }
    };
    _.aa.ne = function(a) {
        try {
            if (2 != this.status) throw Error("Container is not registered");
            if (0 != this.ia) throw Error("Container is not collapsed");
            if ("string" !== typeof a) throw Error("Could not parse serialized message");
            var b = JSON.parse(a);
            if (!_.na(b) || !Qj(b.uid) || "number" !== typeof b.expand_t || "number" !== typeof b.expand_r || "number" !== typeof b.expand_b || "number" !== typeof b.expand_l || "boolean" !== typeof b.push) throw Error("Cannot parse JSON message");
            var c = new BH(b.uid, new _.Px(b.expand_t, b.expand_r, b.expand_b, b.expand_l), b.push, b.sentinel);
            if (this.H !== c.o) throw Error("Wrong source container");
            if (!(0 <= c.m.top && 0 <= c.m.left && 0 <= c.m.bottom && 0 <= c.m.right)) throw Error("Invalid expansion amounts");
            var d;
            if (d = c.push && this.T.pd || !c.push && this.T.od) {
                var e = c.m,
                    f = c.push,
                    g = this.B = sH(this.j);
                if (e.top <= g.j.top && e.right <= g.j.right && e.bottom <= g.j.bottom && e.left <= g.j.left) {
                    if (!f)
                        for (var h = this.j.parentNode; h && h.style; h = h.parentNode) JH(this.m, h, "overflowX", "visible", "important"), JH(this.m, h, "overflowY", "visible", "important");
                    var k = Sx(new Rx(0, 0, this.B.o.getWidth(), this.B.o.getHeight()));
                    _.na(e) ? (k.top -= e.top, k.right += e.right, k.bottom += e.bottom, k.left -= e.left) : (k.top -= e, k.right += Number(void 0), k.bottom += Number(void 0), k.left -= Number(void 0));
                    JH(this.m, this.l, "position", "relative");
                    JH(this.m, this.j, "position", "absolute");
                    if (f) {
                        var l = k.getWidth();
                        JH(this.m, this.l, "width", l + "px");
                        var n = k.getHeight();
                        JH(this.m, this.l, "height", n + "px")
                    } else JH(this.m, this.j, "zIndex", "10000");
                    var m = k.getWidth();
                    JH(this.m, this.j, "width", m + "px");
                    var p = k.getHeight();
                    JH(this.m, this.j, "height", p + "px");
                    JH(this.m, this.j, "left", k.left + "px");
                    JH(this.m, this.j, "top", k.top + "px");
                    this.ia = 2;
                    this.B = sH(this.j);
                    d = !0
                } else d = !1
            }
            a = d;
            uG(this.o, "expand_response", (new EH(this.H, a, this.B, c.m, c.push)).j());
            if (!a) throw Error("Viewport or document body not large enough to expand into.");
        } catch (t) {
            var r;
            null == (r = this.I) || r.error("Invalid EXPAND_REQUEST message. Reason: " + t.message)
        }
    };
    _.aa.Yd = function(a) {
        try {
            if (2 != this.status) throw Error("Container is not registered");
            if (2 != this.ia) throw Error("Container is not expanded");
            if ("string" !== typeof a) throw Error("Could not parse serialized message");
            var b = JSON.parse(a);
            if (!_.na(b) || !Qj(b.uid)) throw Error("Cannot parse JSON message");
            if (this.H !== (new CH(b.uid, b.sentinel)).o) throw Error("Wrong source container");
            KH(this.m);
            this.ia = 0;
            this.j && (this.B = sH(this.j));
            uG(this.o, "collapse_response", (new DH(this.H, this.B)).j())
        } catch (d) {
            var c;
            null == (c = this.I) || c.error("Invalid COLLAPSE_REQUEST message. Reason: " + d.message)
        }
    };
    var RH = function(a) {
        if (1 == a.status || 2 == a.status) switch (a.A) {
            case 0:
                TH(a);
                a.R = window.setTimeout((0, _.ys)(a.ka, a), 1E3);
                a.A = 1;
                break;
            case 1:
                a.A = 2;
                break;
            case 2:
                a.A = 2
        }
    };
    SH.prototype.O = function(a) {
        try {
            if ("string" !== typeof a) throw Error("Could not parse serialized message");
            var b = JSON.parse(a);
            if (!_.na(b) || !Qj(b.uid) || "number" !== typeof b.width || "number" !== typeof b.height || b.sentinel && "string" !== typeof b.sentinel) throw Error("Cannot parse JSON message");
            var c = new FH(b.uid, b.width, b.height, b.sentinel);
            if (this.H !== c.o) throw Error("Wrong source container");
            var d = String(c.height);
            if (this.N) d !== this.j.height && (this.j.height = d, RH(this));
            else {
                var e;
                null == (e = this.I) || e.error("Got CreativeGeometryUpdate message in non-fluidcontainer. The container is not resized.")
            }
        } catch (g) {
            var f;
            null == (f = this.I) || f.error("Invalid CREATIVE_GEOMETRY_UPDATE message. Reason: " + g.message)
        }
    };
    SH.prototype.ka = function() {
        if (1 == this.status || 2 == this.status) switch (this.A) {
            case 1:
                this.A = 0;
                break;
            case 2:
                TH(this), this.R = window.setTimeout((0, _.ys)(this.ka, this), 1E3), this.A = 1
        }
    };
    var TH = function(a) {
            a.B = sH(a.j);
            uG(a.o, "geometry_update", (new DH(a.H, a.B)).j())
        },
        OH = function(a) {
            var b = null;
            a.Zf && (b = a.Zf);
            return null == b ? null : b.join(" ")
        },
        UH = ["allow-modals", "allow-orientation-lock", "allow-presentation", "allow-pointer-lock"],
        VH = ["allow-top-navigation"],
        WH = ["allow-same-origin"],
        XH = Ax([].concat(_.ue(UH), _.ue(VH)));
    Ax([].concat(_.ue(UH), _.ue(WH)));
    Ax([].concat(_.ue(UH), _.ue(VH), _.ue(WH)));
    var YH = _.R(["https://tpc.googlesyndication.com/safeframe/", "/html/container.html"]),
        ZH = {
            Ah: function(a) {
                if ("string" !== typeof a.version) throw new TypeError("version is not a string");
                if (!/^[0-9]+-[0-9]+-[0-9]+$/.test(a.version)) throw new RangeError("Invalid version: " + a.version);
                if ("string" !== typeof a.Kd) throw new TypeError("subdomain is not a string");
                if (!/^[a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?$/.test(a.Kd)) throw new RangeError("Invalid subdomain: " + a.Kd);
                return re("https://" + a.Kd + ".safeframe.googlesyndication.com/safeframe/" + a.version + "/html/container.html")
            },
            fk: function(a) {
                return _.A(YH, a)
            }
        };
    var Sj = function(a, b) {
        try {
            Mb(pq(a, b))
        } catch (c) {}
    };
    var $H = function(a) {
        _.T.call(this, a)
    };
    _.P($H, _.T);
    $H.prototype.m = ge([$H, 4, Pu, 2, Pu, 1, Pu, 3, Pu, 5, Su]);
    var aI = [.05, .1, .2, .5],
        bI = [0, .5, 1],
        cI = function(a) {
            a = xg(a);
            if (!a) return -1;
            try {
                var b = jC(a.document);
                var c = new _.Yi(b.clientWidth, b.clientHeight)
            } catch (d) {
                c = new _.Yi(-12245933, -12245933)
            }
            return -12245933 == c.width || -12245933 == c.height ? -1 : c.width * c.height
        },
        dI = function(a, b) {
            return 0 >= a || 0 >= b ? [] : _.xd(aI, function(c) {
                return Math.min(a / b * c, 1)
            })
        },
        fI = function(a) {
            this.B = a.F;
            this.m = a.pb;
            this.l = a.wb;
            this.o = null;
            this.H = a.Sa;
            this.j = eI(this);
            this.I = a.mi || !1
        },
        gI = function() {
            var a;
            return !!window.IntersectionObserver && Cx(null == (a = window.performance) ? void 0 : a.now)
        };
    fI.prototype.getSlotId = function() {
        return this.o
    };
    var iI = function(a, b) {
            if (a.j) {
                if (null != a.o) {
                    try {
                        hI(a, Math.round(performance.now()), 0, 0, 0, !1)
                    } catch (c) {
                        a.H && a.H(c)
                    }
                    a.j && a.j.unobserve(a.m)
                }
                a.o = b;
                a.j.observe(a.m)
            }
        },
        eI = function(a) {
            if (!_.q.IntersectionObserver) return null;
            var b = a.m.offsetWidth * a.m.offsetHeight,
                c = cI(a.B);
            b = [].concat(_.ue(bI), _.ue(dI(c, b)));
            qa(b);
            return new _.q.IntersectionObserver(function(d) {
                return jI(a, d)
            }, {
                threshold: b
            })
        },
        jI = function(a, b) {
            try {
                var c = cI(a.B);
                _.Us(b, function(d) {
                    a.I && hI(a, Math.round(d.time), d.boundingClientRect.width * d.boundingClientRect.height, d.intersectionRect.width * d.intersectionRect.height, c, d.isIntersecting)
                })
            } catch (d) {
                a.H && a.H(d)
            }
        },
        hI = function(a, b, c, d, e, f) {
            if (null == a.o) throw Error("Not Attached.");
            var g = new $H;
            c = _.z(g, 1, c);
            d = _.z(c, 2, d);
            e = _.z(d, 3, e);
            b = _.z(e, 4, b);
            f = _.z(b, 5, f);
            f = Sb(f.m(), 4);
            uB(a.l, "1", 10, f, void 0, a.o)
        };
    var kI = function(a, b) {
            this.j = a;
            this.o = b
        },
        lI = function(a) {
            if (a.j.frames.google_ads_top_frame) return !0;
            var b = Ex(a.j);
            b = b && b.contentWindow;
            if (!b) return !1;
            b.addEventListener("message", function(c) {
                var d = c.ports;
                "__goog_top_url_req" === c.data.msgType && d.length && d[0].postMessage({
                    msgType: "__goog_top_url_resp",
                    topUrl: a.o
                })
            }, !1);
            return !0
        };
    var dk = function(a) {
        _.T.call(this, a)
    };
    _.P(dk, _.T);
    var hk = he(dk),
        fk = [1, 3];
    var Ce = {
        Jj: 0,
        Fj: 1,
        Gj: 9,
        Dj: 2,
        Ej: 3,
        Ij: 5,
        Hj: 7
    };
    var mI = _.R(["https://securepubads.g.doubleclick.net/static/topics/topics_frame.html"]),
        Xj = _.A(mI);
    var Dk = function(a) {
        _.T.call(this, a)
    };
    _.P(Dk, _.T);
    Dk.prototype.getVersion = function() {
        return _.Rf(this, 2)
    };
    var Ck = function(a) {
        _.T.call(this, a, -1, nI)
    };
    _.P(Ck, _.T);
    var wk = function(a, b) {
            return _.z(a, 2, b)
        },
        Bk = function(a, b) {
            return _.z(a, 3, b)
        },
        yk = function(a, b) {
            return _.z(a, 4, b)
        },
        vk = function(a, b) {
            return _.z(a, 5, b)
        },
        Ak = function(a, b) {
            return _.z(a, 9, b)
        },
        uk = function(a, b) {
            return _.yd(a, 10, b)
        },
        tk = function(a, b) {
            return _.z(a, 11, b)
        },
        xk = function(a, b) {
            return _.z(a, 1, b)
        },
        zk = function(a, b) {
            return _.z(a, 7, b)
        },
        nI = [10, 6];
    var rk = "platform platformVersion architecture model uaFullVersion bitness fullVersionList wow64".split(" ");
    var oI = function() {
            this.id = "goog_" + Zw++
        },
        pI = function(a) {
            _.U.call(this);
            this.context = a;
            this.j = new _.v.Map
        };
    _.P(pI, _.U);
    pI.prototype.o = function() {
        _.U.prototype.o.call(this);
        this.j.clear()
    };
    pI.prototype.aa = function(a, b) {
        var c = this;
        if (this.H) return function() {};
        var d = "string" === typeof a ? a : a.id,
            e, f, g = null != (f = null == (e = this.j.get(d)) ? void 0 : e.add(b)) ? f : new _.v.Set([b]);
        this.j.set(d, g);
        return function() {
            return void qI(c, a, b)
        }
    };
    var rI = function(a, b, c) {
            c = void 0 === c ? function() {
                return !0
            } : c;
            return new _.v.Promise(function(d) {
                var e = a.aa(b, function(f) {
                    c(f) && (e(), d(f))
                })
            })
        },
        qI = function(a, b, c) {
            var d;
            return !(null == (d = a.j.get("string" === typeof b ? b : b.id)) || !d.delete(c))
        };
    pI.prototype.dispatchEvent = function(a, b, c) {
        var d = this,
            e, f, g, h, k, l, n, m;
        return _.Ab(function(p) {
            e = "string" === typeof a ? a : a.id;
            f = d.j.get(e);
            if (null == (g = f) || !g.size) return p.return();
            h = "function" === typeof window.CustomEvent ? new CustomEvent(e, {
                detail: c,
                bubbles: !0,
                cancelable: !0
            }) : function() {
                var r = document.createEvent("CustomEvent");
                r.initCustomEvent(e, !0, !0, c);
                return r
            }();
            k = [];
            l = {};
            n = _.x(f);
            for (m = n.next(); !m.done; l = {
                    Uc: l.Uc
                }, m = n.next()) l.Uc = m.value, k.push(new _.v.Promise(function(r) {
                return function(t) {
                    return _.Ab(function(w) {
                        if (1 == w.j) return Bb(w, 0, 2);
                        fi(d.context, b, function() {
                            d.j.has(e) && f.has(r.Uc) && r.Uc(h)
                        }, !0);
                        t();
                        w.j = 0
                    })
                }
            }(l)));
            return Bb(p, _.v.Promise.all(k), 0)
        })
    };
    var sI = new oI,
        tI = new oI,
        Dq = new oI,
        uI = new oI,
        Fq = new oI,
        vI = new oI,
        wI = new oI,
        Lo = new oI,
        xI = new oI,
        yI = new oI;
    var zI = function() {
        this.data = void 0;
        this.status = 0;
        this.j = []
    };
    zI.prototype.ud = function() {
        return this.j
    };
    zI.prototype.Vd = function() {
        this.j = []
    };
    var AI, EI, HI, ur, II, JI, DI, CI, BI, KI;
    AI = function() {
        this.j = new _.v.Map;
        this.B = 0;
        this.o = new _.v.Map;
        this.md = null;
        this.H = this.m = this.A = this.l = 0;
        this.I = new zI
    };
    EI = function(a, b) {
        a.j.get(b) || (a.j.set(b, {
            Kb: !0,
            He: "",
            Pb: "",
            Uf: 0,
            Cf: 0,
            Fe: [],
            Ge: [],
            Cb: !1
        }), _.go(b, function() {
            a.j.delete(b);
            BI(a, b)
        }), b.aa(tI, function(c) {
            c = c.detail;
            var d = (0, B.K)(a.j.get(b));
            d.He = y(c, 33) || "";
            d.Cb = !0;
            CI(a, b, function() {
                return void(d.He = "")
            });
            DI(a, b, function() {
                return void(d.Cb = !1)
            })
        }))
    };
    _.Eq = function(a, b) {
        var c, d;
        return null != (d = null == (c = a.j.get(b)) ? void 0 : c.Kb) ? d : !1
    };
    _.FI = function(a, b) {
        if (a = a.j.get(b)) a.Kb = !1
    };
    _.GI = function(a, b) {
        if (a = a.j.get(b)) a.Kb = !0
    };
    HI = function(a, b) {
        if (!b.length) return [];
        var c = Oh(b[0].getAdUnitPath());
        b.every(function(g) {
            return Oh(g.getAdUnitPath()) === c
        });
        var d = [];
        a = _.x(a.j);
        for (var e = a.next(); !e.done; e = a.next()) {
            var f = _.x(e.value);
            e = f.next().value;
            (f = f.next().value.He) && Oh(e.getAdUnitPath()) === c && !_.u(b, "includes").call(b, e) && d.push(f)
        }
        return d
    };
    ur = function(a, b) {
        var c, d;
        return null != (d = null == (c = a.j.get(b)) ? void 0 : c.Pb) ? d : ""
    };
    II = function(a, b) {
        return (a = a.j.get(b)) ? a.Uf - 1 : 0
    };
    JI = function(a, b) {
        var c = (0, B.K)(a.o.get(b)) - 1;
        0 === c ? a.o.delete(b) : a.o.set(b, c);
        return c
    };
    DI = function(a, b, c) {
        (a = a.j.get(b)) && a.Fe.push(c)
    };
    CI = function(a, b, c) {
        (a = a.j.get(b)) && a.Ge.push(c)
    };
    BI = function(a, b) {
        if (a = a.j.get(b))
            for (b = a.Ge.slice(), a.Ge.length = 0, a = _.x(b), b = a.next(); !b.done; b = a.next()) b = b.value, b()
    };
    KI = function(a, b) {
        if (a = a.j.get(b))
            for (b = a.Fe.slice(), a.Fe.length = 0, a = _.x(b), b = a.next(); !b.done; b = a.next()) b = b.value, b()
    };
    AI.prototype.Cb = function(a) {
        var b, c;
        return null != (c = null == (b = this.j.get(a)) ? void 0 : b.Cb) ? c : !1
    };
    var LI = function(a, b, c) {
            if (a = a.j.get(b)) a.Tf = c
        },
        MI = function(a, b) {
            if (a = a.j.get(b)) {
                var c;
                null == (c = a.Tf) || c.Ha();
                delete a.Tf
            }
        };
    var NI = function() {
        var a = {};
        return a.adsense_channel_ids = "channel", a.adsense_ad_types = "ad_type", a.adsense_ad_format = "format", a.adsense_background_color = "color_bg", a.adsense_border_color = "color_border", a.adsense_link_color = "color_link", a.adsense_text_color = "color_text", a.adsense_url_color = "color_url", a.page_url = "url", a.adsense_allow_expandable_ads = "ea", a.adsense_encoding = "oe", a.adsense_family_safe = "adsafe", a.adsense_flash_version = "flash", a.adsense_font_face = "f", a.adsense_hints = "hints", a.adsense_keyword_type = "kw_type", a.adsense_keywords = "kw", a.adsense_test_mode = "adtest", a.alternate_ad_iframe_color = "alt_color", a.alternate_ad_url = "alternate_ad_url", a.demographic_age = "cust_age", a.demographic_gender = "cust_gender", a.document_language = "hl", a
    };
    var Hk = new _.v.Map,
        Gk = new _.v.Map;
    var Jk = function(a, b) {
        this.push = J(a, 76, b.push.bind(b))
    };
    var Lk = function(a, b) {
        this.messageId = a;
        this.messageArgs = b
    };
    Lk.prototype.getMessageId = function() {
        return this.messageId
    };
    Lk.prototype.getMessageArgs = function() {
        return this.messageArgs
    };
    var OI = M(2),
        PI = M(3),
        QI = M(4),
        RI = M(5),
        SI = M(6),
        TI = M(12),
        UI = M(14),
        VI = M(16),
        WI = M(19),
        XI = M(20),
        YI = M(23),
        ZI = M(26),
        $I = M(28),
        aJ = M(149),
        bJ = M(30),
        cJ = M(31),
        dJ = M(34),
        eJ = M(35),
        fJ = M(36),
        Dp = M(38),
        gJ = M(40),
        hJ = M(48),
        iJ = M(50),
        jJ = M(60),
        kJ = M(63),
        lJ = M(64),
        mJ = M(66),
        nJ = M(68),
        oJ = M(69),
        pJ = M(70),
        qJ = M(71),
        rJ = M(78),
        sJ = M(80),
        tJ = M(82),
        uJ = M(84),
        vJ = M(85),
        wJ = M(87),
        nl = M(88),
        xJ = M(92),
        yJ = M(93),
        zJ = M(99),
        AJ = M(103),
        BJ = M(104),
        CJ = M(105),
        DJ = M(106),
        EJ = M(107),
        FJ = M(108),
        GJ = M(113),
        HJ = M(114),
        IJ = M(115),
        JJ = M(117),
        KJ = M(118),
        LJ = M(119),
        Gl = M(121),
        MJ = M(122),
        NJ = M(123),
        cq = M(125),
        OJ = M(126),
        PJ = M(127),
        QJ = M(144),
        np = M(129),
        pp = M(132),
        RJ = M(134),
        SJ = M(135),
        TJ = M(136),
        UJ = M(137),
        VJ = M(138),
        WJ = M(139),
        XJ = M(140),
        qq = M(142),
        YJ = M(143),
        ZJ = M(145),
        $J = M(147),
        Kp = M(148),
        aK = M(150);
    var bK = function(a, b, c) {
        var d = this;
        this.addEventListener = J(a, 86, function(e, f) {
            if ("function" !== typeof f) return N(b, Nk("Service.addEventListener", [e, f])), d;
            var g = Ok(e);
            if (!g) return N(b, yJ(e)), d;
            c.addEventListener(g, f);
            return d
        });
        this.removeEventListener = J(a, 904, function(e, f) {
            var g = Ok(e);
            "function" === typeof f && g ? c.removeEventListener(g, f) : N(b, Nk("Service.removeEventListener", [e, f]))
        });
        this.getSlots = J(a, 573, function() {
            return c.m.map(function(e) {
                return (0, B.K)(e.pa)
            })
        });
        this.getSlotIdMap = J(a, 574, function() {
            for (var e = {}, f = _.x(c.m), g = f.next(); !g.done; g = f.next()) g = g.value, e[g.toString()] = g.pa;
            return e
        });
        this.getName = J(a, 575, function() {
            return c.getName()
        })
    };
    var Pk = function(a, b, c) {
        bK.call(this, a, b, c);
        this.notifyUnfilledSlots = J(a, 69, function(d) {
            c.Kb && cK(c, dK(c, d))
        });
        this.refreshAllSlots = J(a, 60, function() {
            c.Kb && cK(c)
        });
        this.setVideoSession = J(a, 61, function(d, e, f) {
            c.G = e;
            c.L = f;
            "number" === typeof d && (e = rj().j, _.z(e, 29, d))
        });
        this.getDisplayAdsCorrelator = J(a, 62, function(d) {
            return eK(c, d)
        });
        this.getVideoStreamCorrelator = J(a, 63, function() {
            var d = rj().j;
            d = y(d, 29);
            return null != d ? d : 0
        });
        this.isSlotAPersistentRoadblock = J(a, 64, function(d) {
            var e = _.u(c.m, "find").call(c.m, function(f) {
                return f.pa === d
            });
            return !!e && fK(c, e)
        });
        this.onImplementationLoaded = J(a, 65, function() {
            c.j.info(hJ("GPT CompanionAds"))
        });
        this.slotRenderEnded = J(a, 67, function(d, e, f) {
            var g = _.u(c.m, "find").call(c.m, function(h) {
                return h.pa === d
            });
            return g && gK(c, g, e, f)
        });
        this.setRefreshUnfilledSlots = J(a, 59, function(d) {
            return c.setRefreshUnfilledSlots(d)
        })
    };
    _.P(Pk, bK);
    var Rk = function(a, b, c) {
        bK.call(this, a, b, c);
        this.setContent = J(a, 72, function(d) {
            var e = _.u(c.m, "find").call(c.m, function(f) {
                return f.pa === d
            });
            N(b, QJ(), e)
        })
    };
    _.P(Rk, bK);
    var hK = _.R(["https://console.googletagservices.com/pubconsole/loader.js"]),
        cl = _.A(hK),
        gl, fl = !1,
        Yk = !1,
        $k = !1;
    var Ap = function(a, b) {
        this.getAllEvents = J(a, 563, function() {
            return Yk ? iK(b).slice() : []
        });
        this.getEventsBySlot = J(a, 565, function(c) {
            return Yk ? jK(b, c).slice() : []
        });
        this.getEventsByLevel = J(a, 566, function(c) {
            return Yk ? kK(b, c).slice() : []
        })
    };
    var ql = function(a, b, c, d) {
        var e = this,
            f = c.getSlotId(),
            g = rj().j,
            h = (0, B.K)(Zn(rj(), f.getDomId()));
        this.set = J(a, 83, function(k, l) {
            "page_url" === k && l && (k = [kl(ll(new ml, k), [String(l)])], _.yd(h, 3, k));
            return e
        });
        this.get = J(a, 84, function(k) {
            if ("page_url" !== k) return null;
            var l, n;
            return null != (n = null == (l = (_.C = (0, B.K)(h.xa()), _.u(_.C, "find")).call(_.C, function(m) {
                return y(m, 1) === k
            })) ? void 0 : _.bn(l, 2)[0]) ? n : null
        });
        this.setClickUrl = J(a, 79, function(k) {
            "string" === typeof k ? h.setClickUrl(k) : N(b, Nk("Slot.setClickUrl", [k]), f);
            return e
        });
        this.setTargeting = J(a, 81, function(k, l) {
            ol(f, h, k, l, b);
            return e
        });
        this.updateTargetingFromMap = J(a, 85, function(k) {
            pl(f, h, k, b);
            return e
        });
        this.display = J(a, 78, function() {
            lK(d, f, aj(g, rj().o))
        });
        this.setTagForChildDirectedTreatment = J(a, 80, function(k) {
            if (0 === k || 1 === k) {
                var l = sn(g) || new lH;
                l.setTagForChildDirectedTreatment(k);
                _.Uh(g, 25, l)
            }
            return e
        });
        this.setForceSafeFrame = J(a, 567, function(k) {
            "boolean" === typeof k ? _.z(h, 12, k) : N(b, Nk("PassbackSlot.setForceSafeFrame", [String(k)]), f);
            return e
        });
        this.setTagForUnderAgeOfConsent = J(a, 448, function(k) {
            if (0 === k || 1 === k) {
                var l = sn(g) || new lH;
                l.setTagForUnderAgeOfConsent(k);
                _.Uh(g, 25, l)
            }
            return e
        })
    };
    var Kn = function(a, b) {
        this.push = J(a, 932, function(c) {
            b.push(c)
        })
    };
    var dp = {
        Cj: 0,
        zj: 1,
        Aj: 2,
        Bj: 3
    };
    var tl = {
            REWARDED: 4,
            TOP_ANCHOR: 2,
            BOTTOM_ANCHOR: 3,
            INTERSTITIAL: 5
        },
        vl = {
            IAB_AUDIENCE_1_1: 1,
            IAB_CONTENT_2_1: 2,
            IAB_CONTENT_2_2: 3
        },
        ul = {
            PURCHASED: 1,
            ORGANIC: 2
        };
    var dm = function(a, b, c) {
        pI.call(this, a);
        this.slotId = b;
        this.m = c
    };
    _.P(dm, pI);
    dm.prototype.getSlotId = function() {
        return this.slotId
    };
    var mK = "",
        zl = null,
        Fl = _.Rs(function() {
            var a, b;
            null == (a = window.console) || null == (b = a.warn) || b.call(a, "googletag.pubads().setSafeFrameConfig({useUniqueDomain: ...}) has been removed, and no longer has any effect.")
        });
    var Ee = function(a, b, c, d) {
        pI.call(this, a);
        this.adUnitPath = b;
        this.pb = d;
        this.pa = null;
        this.id = this.adUnitPath + "_" + c
    };
    _.P(Ee, pI);
    _.aa = Ee.prototype;
    _.aa.getId = function() {
        return this.id
    };
    _.aa.getAdUnitPath = function() {
        return this.adUnitPath
    };
    _.aa.getName = function() {
        return this.adUnitPath
    };
    _.aa.toString = function() {
        return this.getId()
    };
    _.aa.getDomId = function() {
        return this.pb
    };
    var nK = function(a, b) {
        a.pa = b
    };
    var Ll = /^(?:https?:)?\/\/(?:www\.googletagservices\.com|securepubads\.g\.doubleclick\.net|(pagead2\.googlesyndication\.com))(\/tag\/js\/gpt(?:_[a-z]+)*\.js|\/pagead\/managed\/js\/gpt\.js)/;
    var oK = _.Rs(function() {
            return void Ix("google_DisableInitialLoad is deprecated and will be removed. Please use googletag.pubads().isInitialLoadDisabled() instead to check if initial load has been disabled.")
        }),
        pK = _.Rs(function() {
            return void Ix("googletag.pubads().setCookieOptions() has been removed, and no longer has any effect. Consider migrating to Limited Ads.")
        }),
        qK = _.Rs(function() {
            return void Ix("The following functions are deprecated: googletag.pubads().setTagForChildDirectedTreatment(), googletag.pubads().clearTagForChildDirectedTreatment(), googletag.pubads().setRequestNonPersonalizedAds(), and googletag.pubads().setTagForUnderAgeOfConsent(). Please use googletag.pubads().setPrivacySettings() instead.")
        }),
        rK = function() {
            Object.defineProperty(window, "google_DisableInitialLoad", {
                get: function() {
                    oK();
                    return !0
                },
                set: function() {
                    oK()
                },
                configurable: !0
            })
        },
        fm = function(a, b, c, d, e) {
            bK.call(this, a, b, c);
            var f = this,
                g = rj().j,
                h = rj().o,
                k = !1;
            this.setTargeting = J(a, 1, function(l, n) {
                var m = null;
                "string" === typeof n ? m = [n] : Array.isArray(n) ? m = n : wa(n) && (m = _.u(Array, "from").call(Array, n));
                var p = "string" === typeof l && !il(l);
                m = m && Ca(m);
                var r, t = null != (r = null == m ? void 0 : m.every(function(w) {
                    return "string" === typeof w
                })) ? r : !1;
                if (!p || !t) return N(b, Nk("PubAdsService.setTargeting", [l, n])), f;
                n = m;
                p = (_.C = Pe(g, ml, 2), _.u(_.C, "find")).call(_.C, function(w) {
                    return y(w, 1) === l
                });
                if ("gpt-beta" === l) {
                    if (c.B) return N(b, DJ(n.join())), f;
                    if (p) return N(b, EJ(n.join())), f;
                    n = bm(n, e)
                }
                p ? kl(p, n) : (p = kl(ll(new ml, l), n), _.Xf(g, 2, ml, p));
                b.info(nl(l, n.join(), c.getName()));
                return f
            });
            this.clearTargeting = J(a, 2, function(l) {
                if (void 0 === l) return _.yd(g, 2), b.info(BJ(c.getName())), f;
                if ("gpt-beta" === l) return N(b, FJ(l)), f;
                var n = Pe(g, ml, 2),
                    m = _.u(n, "findIndex").call(n, function(p) {
                        return y(p, 1) === l
                    });
                if (0 > m) return N(b, uJ(l, c.getName())), f;
                n.splice(m, 1);
                _.yd(g, 2, n);
                b.info(tJ(l, c.getName()));
                return f
            });
            this.getTargeting = J(a, 38, function(l) {
                if ("string" !== typeof l) return N(b, Nk("PubAdsService.getTargeting", [l])), [];
                var n = (_.C = Pe(g, ml, 2), _.u(_.C, "find")).call(_.C, function(m) {
                    return y(m, 1) === l
                });
                return n ? _.bn(n, 2).slice() : []
            });
            this.getTargetingKeys = J(a, 39, function() {
                return Pe(g, ml, 2).map(function(l) {
                    return (0, B.K)(y(l, 1))
                })
            });
            this.setCategoryExclusion = J(a, 3, function(l) {
                if ("string" !== typeof l || il(l)) return N(b, Nk("PubAdsService.setCategoryExclusion", [l])), f;
                (_.C = _.bn(g, 3), _.u(_.C, "includes")).call(_.C, l) || Ku(g, 3, l);
                b.info(vJ(l));
                return f
            });
            this.clearCategoryExclusions = J(a, 4, function() {
                _.z(g, 3, Vc);
                b.info(wJ());
                return f
            });
            this.disableInitialLoad = J(a, 5, function() {
                _.z(g, 4, !0);
                k || (k = !0, rK())
            });
            this.enableSingleRequest = J(a, 6, function() {
                if (c.B && !K(g, 6)) return N(b, jJ("PubAdsService.enableSingleRequest")), !1;
                b.info(kJ("single request"));
                _.z(g, 6, !0);
                return !0
            });
            this.enableAsyncRendering = J(a, 7, function() {
                return !0
            });
            this.enableSyncRendering = J(a, 8, function() {
                Ix("GPT synchronous rendering is no longer supported, ads will be requested and rendered asynchronously. See https://support.google.com/admanager/answer/9212594 for more details.");
                return !1
            });
            this.enableLazyLoad = J(a, 485, function(l) {
                var n = new Tq;
                n = _.z(n, 1, 800);
                n = _.z(n, 2, 400);
                n = hH(n, 3);
                if (_.na(l)) {
                    var m = l.fetchMarginPercent;
                    "number" === typeof m && (0 <= m ? _.z(n, 1, m) : -1 === m && yf(n, 1));
                    m = l.renderMarginPercent;
                    "number" === typeof m && (0 <= m ? _.z(n, 2, m) : -1 === m && yf(n, 2));
                    l = l.mobileScaling;
                    "number" === typeof l && (0 < l ? _.z(n, 3, _.Bc(l)) : -1 === l && _.z(n, 3, _.Bc(1)))
                }
                window.IntersectionObserver || !Un(n, 1) && !Un(n, 2) ? _.Uh(g, 5, n) : N(b, aK())
            });
            this.setCentering = J(a, 9, function(l) {
                l = !!l;
                b.info(lJ("centering", String(l)));
                _.z(g, 15, l)
            });
            this.definePassback = J(a, 10, function(l, n) {
                return (l = em(a, b, c, l, n, d)) && l.Of
            });
            this.refresh = J(a, 11, function() {
                var l = _.wb.apply(0, arguments),
                    n = _.x(l),
                    m = n.next().value;
                n = n.next().value;
                n = void 0 === n ? {} : n;
                m && !Array.isArray(m) || !_.na(n) || n.changeCorrelator && "boolean" !== typeof n.changeCorrelator ? N(b, Nk("PubAdsService.refresh", l)) : (n && !1 === n.changeCorrelator || g.setCorrelator(Mx()), m = m ? $l(m, c) : c.m, c.refresh(aj(g, h), m) || N(b, Nk("PubAdsService.refresh", l)))
            });
            this.enableVideoAds = J(a, 12, function() {
                _.z(g, 21, !0);
                sK(c, g)
            });
            this.setVideoContent = J(a, 13, function(l, n) {
                tK(c, l, n, g)
            });
            this.collapseEmptyDivs = J(a, 14, function(l) {
                l = void 0 === l ? !1 : l;
                _.z(g, 11, !0);
                l = !!l;
                _.z(g, 10, l);
                b.info(rJ(String(l)));
                return !!K(g, 11)
            });
            this.clear = J(a, 15, function(l) {
                if (Array.isArray(l)) return uK(c, g, h, $l(l, c));
                if (void 0 === l) return uK(c, g, h, c.m);
                N(b, Nk("PubAdsService.clear", [l]));
                return !1
            });
            this.setLocation = J(a, 16, function(l) {
                if ("string" !== typeof l) return N(b, Nk("PubAdsService.setLocation", [l])), f;
                _.z(g, 8, l);
                return f
            });
            this.setCookieOptions = J(a, 17, function() {
                pK();
                return f
            });
            this.setTagForChildDirectedTreatment = J(a, 18, function(l) {
                qK();
                if (1 !== l && 0 !== l) return N(b, MJ("PubadsService.setTagForChildDirectedTreatment", Hl(l), "0,1")), f;
                var n = sn(g) || new lH;
                n.setTagForChildDirectedTreatment(l);
                _.Uh(g, 25, n);
                return f
            });
            this.clearTagForChildDirectedTreatment = J(a, 19, function() {
                qK();
                var l = sn(g);
                if (!l) return f;
                l.clearTagForChildDirectedTreatment();
                _.Uh(g, 25, l);
                return f
            });
            this.setPublisherProvidedId = J(a, 20, function(l) {
                l = String(l);
                b.info(lJ("PPID", l));
                _.z(g, 16, l);
                return f
            });
            this.set = J(a, 21, function(l, n) {
                if ("string" !== typeof l || !l.length || void 0 === NI()[l] || "string" !== typeof n) return N(b, Nk("PubAdsService.set", [l, n])), f;
                var m = (_.C = g.xa(), _.u(_.C, "find")).call(_.C, function(p) {
                    return y(p, 1) === l
                });
                m ? kl(m, [n]) : (m = gH(ll(new ml, l), n), _.Xf(g, 14, ml, m));
                b.info(fJ(l, String(n), c.getName()));
                return f
            });
            this.get = J(a, 22, function(l) {
                if ("string" !== typeof l) return N(b, Nk("PubAdsService.get", [l])), null;
                var n = (_.C = g.xa(), _.u(_.C, "find")).call(_.C, function(m) {
                    return y(m, 1) === l
                });
                return (n = n && _.bn(n, 2)) ? n[0] : null
            });
            this.getAttributeKeys = J(a, 23, function() {
                return g.xa().map(function(l) {
                    return (0, B.K)(y(l, 1))
                })
            });
            this.display = J(a, 24, function(l, n, m, p) {
                return void c.display(l, n, d, m, p)
            });
            this.updateCorrelator = J(a, 25, function() {
                Ix(Nl("update"));
                N(b, IJ());
                g.setCorrelator(Mx());
                return f
            });
            this.defineOutOfPagePassback = J(a, 35, function(l) {
                l = em(a, b, c, l, [1, 1], d);
                if (!l) return null;
                _.z(l.nb, 15, 1);
                return l.Of
            });
            this.setForceSafeFrame = J(a, 36, function(l) {
                if ("boolean" !== typeof l) return N(b, Nk("PubAdsService.setForceSafeFrame", [Hl(l)])), f;
                _.z(g, 13, l);
                return f
            });
            this.setSafeFrameConfig = J(a, 37, function(l) {
                var n = Il(b, l);
                if (!n) return N(b, Nk("PubAdsService.setSafeFrameConfig", [l])), f;
                _.Uh(g, 18, n);
                return f
            });
            this.setRequestNonPersonalizedAds = J(a, 445, function(l) {
                qK();
                if (0 !== l && 1 !== l) return N(b, MJ("PubAdsService.setRequestNonPersonalizedAds", Hl(l), "0,1")), f;
                var n = sn(g) || new lH;
                _.z(n, 8, !!l);
                _.Uh(g, 25, n);
                return f
            });
            this.setTagForUnderAgeOfConsent = J(a, 447, function(l) {
                l = void 0 === l ? 2 : l;
                qK();
                if (2 !== l && 0 !== l && 1 !== l) return N(b, MJ("PubadsService.setTagForUnderAgeOfConsent", Hl(l), "2,0,1")), f;
                var n = sn(g) || new lH;
                n.setTagForUnderAgeOfConsent(l);
                _.Uh(g, 25, n);
                return f
            });
            this.getCorrelator = J(a, 27, function() {
                return String(y(g, 26))
            });
            this.getTagSessionCorrelator = J(a, 631, function() {
                return sf(_.q)
            });
            this.getVideoContent = J(a, 30, function() {
                return vK(c, g)
            });
            this.getVersion = J(a, 568, function() {
                return a.Hb ? String(a.Hb) : a.Ta
            });
            this.forceExperiment = J(a, 569, function(l) {
                return void c.forceExperiment(l)
            });
            this.setCorrelator = J(a, 28, function(l) {
                Ix(Nl("set"));
                N(b, HJ());
                if (Si(window)) return f;
                if (!qm(l)) return N(b, Nk("PubadsService.setCorrelator", [Hl(l)])), f;
                l = g.setCorrelator(l);
                _.z(l, 27, !0);
                return f
            });
            this.markAsAmp = J(a, 570, function() {
                window.console && window.console.warn && window.console.warn("googletag.pubads().markAsAmp() is deprecated and ignored.")
            });
            this.isSRA = J(a, 571, function() {
                return !!K(g, 6)
            });
            this.setImaContent = J(a, 328, function(l, n) {
                _.bg(g, 22) ? tK(c, l, n, g) : (_.z(g, 21, !0), sK(c, g), "string" === typeof l && _.z(g, 19, l), "string" === typeof n && _.z(g, 20, n))
            });
            this.getImaContent = J(a, 329, function() {
                return _.bg(g, 22) ? vK(c, g) : c.B ? {
                    vid: y(g, 19) || "",
                    cmsid: y(g, 20) || ""
                } : null
            });
            this.isInitialLoadDisabled = J(a, 572, function() {
                return !!K(g, 4)
            });
            this.setPrivacySettings = J(a, 648, function(l) {
                if (!_.na(l)) return N(b, Nk("PubAdsService.setPrivacySettings", [l])), f;
                var n = l.restrictDataProcessing,
                    m = l.childDirectedTreatment,
                    p = l.underAgeOfConsent,
                    r = l.limitedAds,
                    t = l.nonPersonalizedAds,
                    w = l.userOptedOutOfPersonalization,
                    D = l.trafficSource,
                    G, F = null != (G = sn(g)) ? G : new lH;
                "boolean" === typeof t ? _.z(F, 8, t) : void 0 !== t && N(b, Gl("PubAdsService.setPrivacySettings", Hl(l), "nonPersonalizedAds", Hl(t)));
                "boolean" === typeof w ? _.z(F, 13, w) : void 0 !== w && N(b, Gl("PubAdsService.setPrivacySettings", Hl(l), "userOptedOutOfPersonalization", Hl(w)));
                "boolean" === typeof n ? _.z(F, 1, n) : void 0 !== n && N(b, Gl("PubAdsService.setPrivacySettings", Hl(l), "restrictDataProcessing", Hl(n)));
                "boolean" === typeof r ? (n = Ml(), r && !K(F, 9) && a.Pc && (t = a.Lb, w = Vh(a), G = new fy, G = _.hd(G, 1, !0), G = _.hd(G, 2, n), w = _.Xh(w, 11, Yh, G), we(t, w)), n ? _.z(F, 9, r) : r && N(b, $J())) : void 0 !== r && N(b, Gl("PubAdsService.setPrivacySettings", Hl(l), "limitedAds", Hl(r)));
                void 0 !== p && (null === p ? F.setTagForUnderAgeOfConsent(2) : !1 === p ? F.setTagForUnderAgeOfConsent(0) : !0 === p ? F.setTagForUnderAgeOfConsent(1) : N(b, Gl("PubAdsService.setPrivacySettings", Hl(l), "underAgeOfConsent", Hl(p))));
                void 0 !== m && (null === m ? F.clearTagForChildDirectedTreatment() : !1 === m ? F.setTagForChildDirectedTreatment(0) : !0 === m ? F.setTagForChildDirectedTreatment(1) : N(b, Gl("PubAdsService.setPrivacySettings", Hl(l), "childDirectedTreatment", Hl(m))));
                void 0 !== D && (null === D ? yf(F, 10) : (_.C = _.u(Object, "values").call(Object, ul), _.u(_.C, "includes")).call(_.C, D) ? _.z(F, 10, D) : N(b, Gl("PubAdsService.setPrivacySettings", Hl(l), "trafficSource", Hl(D))));
                _.Uh(g, 25, F);
                return f
            })
        };
    _.P(fm, bK);
    var Bp = function(a, b) {
        var c = this,
            d = [],
            e = [];
        this.addSize = $h(a, 88, function(f, g) {
            var h;
            if (h = jm(f)) h = g, h = im(h) || Array.isArray(h) && h.every(im);
            h ? (_.E(nz) && (h = sm(g), h !== g && (g = Mk([f, g]), g = g.substring(1, g.length - 1), N(b, new Lk(151, ["SizeMappingBuilder.addSize", g])), g = h)), d.push([f, g])) : (e.push([f, g]), N(b, Nk("SizeMappingBuilder.addSize", [f, g])));
            return c
        });
        this.build = $h(a, 89, function() {
            if (e.length) return N(b, dJ(Hl(e))), null;
            va(d);
            return d
        })
    };
    var wK = function(a, b) {
        this.getId = J(a, 593, function() {
            return b.getId()
        });
        this.getAdUnitPath = J(a, 594, function() {
            return b.getAdUnitPath()
        });
        this.getName = J(a, 595, function() {
            return b.getName()
        });
        this.toString = J(a, 596, function() {
            return b.toString()
        });
        this.getDomId = J(a, 597, function() {
            return b.getDomId()
        })
    };
    var Gi = function(a) {
        _.T.call(this, a, -1, xK)
    };
    _.P(Gi, _.T);
    var xK = [2];
    var zK = function(a) {
        _.T.call(this, a, -1, yK)
    };
    _.P(zK, _.T);
    zK.prototype.getAdUnitPath = function() {
        return y(this, 1)
    };
    zK.prototype.getDomId = function() {
        return y(this, 2)
    };
    var AK = function(a, b) {
        _.z(a, 2, b)
    };
    zK.prototype.xa = function() {
        return Pe(this, ml, 3)
    };
    zK.prototype.getServices = function(a) {
        return Ju(this, 4, a)
    };
    var BK = function(a, b) {
        _.yd(a, 5, b)
    };
    zK.prototype.getClickUrl = function() {
        return y(this, 7)
    };
    zK.prototype.setClickUrl = function(a) {
        return _.z(this, 7, a)
    };
    zK.prototype.getCategoryExclusions = function(a) {
        return Ju(this, 8, a)
    };
    var jl = function(a) {
        return Pe(a, ml, 9)
    };
    zK.prototype.gb = function() {
        return Df(this, Dl, 13)
    };
    var Mm = function(a) {
            return _.Re(a, 15, 0)
        },
        $n = function(a, b) {
            _.Xf(a, 27, Ov, b)
        },
        CK = function(a) {
            a = dd(a, y(a, 26), pc(a.ga));
            return null == a ? a : a
        },
        yK = [3, 4, 5, 6, 8, 9, 27];
    var DK = function() {
            this.sourceAgnosticLineItemId = this.sourceAgnosticCreativeId = this.lineItemId = this.creativeId = this.campaignId = this.advertiserId = null;
            this.isBackfill = !1;
            this.encryptedTroubleshootingInfo = this.creativeTemplateId = this.companyIds = this.yieldGroupIds = null
        },
        EK = function(a, b) {
            a.advertiserId = b
        },
        FK = function(a, b) {
            a.campaignId = b
        },
        GK = function(a, b) {
            a.yieldGroupIds = b
        },
        HK = function(a, b) {
            a.companyIds = b
        };
    var IK = function(a, b) {
        this.width = a;
        this.height = b
    };
    IK.prototype.getWidth = function() {
        return this.width
    };
    IK.prototype.getHeight = function() {
        return this.height
    };
    var vm = function(a, b, c) {
        var d = this,
            e = (0, B.K)(Zn(rj(), c.getDomId())),
            f = "",
            g = null,
            h = function() {
                return ""
            },
            k = "",
            l = !1;
        _.go(c, function() {
            e = new zK;
            f = "";
            g = null;
            h = function() {
                return ""
            };
            k = ""
        });
        c.aa(Dq, function(m) {
            var p = m.detail;
            m = p.ef;
            p = p.isBackfill;
            m && (f = m, l = p)
        });
        this.set = J(a, 40, function(m, p) {
            if ("string" !== typeof m || "string" !== typeof p || void 0 === NI()[m]) return N(b, Nk("Slot.set", [m, p]), c), d;
            var r = (_.C = e.xa(), _.u(_.C, "find")).call(_.C, function(t) {
                return y(t, 1) === m
            });
            r ? kl(r, [p]) : (r = ll(new ml, m), gH(r, p), _.Xf(e, 3, ml, r));
            return d
        });
        this.get = J(a, 41, function(m) {
            if ("string" !== typeof m) return N(b, Nk("Slot.get", [m]), c), null;
            var p = (_.C = e.xa(), _.u(_.C, "find")).call(_.C, function(r) {
                return y(r, 1) === m
            });
            return (p = p && _.bn(p, 2)) ? p[0] : null
        });
        this.getAttributeKeys = J(a, 42, function() {
            return e.xa().map(function(m) {
                return (0, B.K)(y(m, 1))
            })
        });
        this.addService = J(a, 43, function(m) {
            m = Hk.get(m);
            if (!m) return N(b, Nk("Slot.addService", [m]), c), d;
            var p = m.getName();
            if ((_.C = _.bn(e, 4), _.u(_.C, "includes")).call(_.C, p)) return b.info(TI(p, c.toString()), c), d;
            m.slotAdded(c, e);
            return d
        });
        this.defineSizeMapping = J(a, 44, function(m) {
            try {
                var p = e;
                if (!Array.isArray(m)) throw new tm("Size mapping must be an array");
                var r = m.map(um);
                _.yd(p, 6, r)
            } catch (t) {
                m = t, di(a, 44, m), Ix("Incorrect usage of googletag.Slot defineSizeMapping: " + m.message)
            }
            return d
        });
        this.setClickUrl = J(a, 45, function(m) {
            if ("string" !== typeof m) return N(b, Nk("Slot.setClickUrl", [m]), c), d;
            e.setClickUrl(m);
            return d
        });
        this.setCategoryExclusion = J(a, 46, function(m) {
            "string" !== typeof m || il(m) ? N(b, Nk("Slot.setCategoryExclusion", [m]), c) : ((_.C = _.bn(e, 8), _.u(_.C, "includes")).call(_.C, m) || Ku(e, 8, m), b.info(UI(m), c));
            return d
        });
        this.clearCategoryExclusions = J(a, 47, function() {
            _.z(e, 8, Vc);
            b.info(VI(), c);
            return d
        });
        this.getCategoryExclusions = J(a, 48, function() {
            return _.bn(e, 8).slice()
        });
        this.setTargeting = J(a, 49, function(m, p) {
            ol(c, e, m, p, b);
            return d
        });
        this.updateTargetingFromMap = J(a, 649, function(m) {
            pl(c, e, m, b);
            return d
        });
        this.clearTargeting = J(a, 50, function(m) {
            if (void 0 === m) return _.yd(e, 9), b.info(WI(c.getAdUnitPath()), c), d;
            var p = jl(e),
                r = _.u(p, "findIndex").call(p, function(t) {
                    return y(t, 1) === m
                });
            if (0 > r) return N(b, uJ(m, c.getAdUnitPath()), c), d;
            p.splice(r, 1);
            _.yd(e, 9, p);
            b.info(AJ(m, c.getAdUnitPath()), c);
            return d
        });
        this.getTargeting = J(a, 51, function(m) {
            if ("string" !== typeof m) return N(b, Nk("Slot.getTargeting", [m]), c), [];
            var p = (_.C = jl(e), _.u(_.C, "find")).call(_.C, function(r) {
                return y(r, 1) === m
            });
            return p ? _.bn(p, 2).slice() : []
        });
        this.getTargetingKeys = J(a, 52, function() {
            return jl(e).map(function(m) {
                return (0, B.K)(y(m, 1))
            })
        });
        this.setCollapseEmptyDiv = J(a, 53, function(m, p) {
            p = void 0 === p ? !1 : p;
            if ("boolean" !== typeof m || "boolean" !== typeof p) return N(b, Nk("Slot.setCollapseEmptyDiv", [m, p]), c), d;
            _.z(e, 10, m);
            _.z(e, 11, m && p);
            p && !m && N(b, XI(c.toString()), c);
            return d
        });
        this.getAdUnitPath = J(a, 54, function() {
            return c.getAdUnitPath()
        });
        this.getSlotElementId = J(a, 598, function() {
            return c.getDomId()
        });
        this.setForceSafeFrame = J(a, 55, function(m) {
            if ("boolean" !== typeof m) return N(b, Nk("Slot.setForceSafeFrame", [String(m)]), c), d;
            _.z(e, 12, m);
            return d
        });
        this.setSafeFrameConfig = J(a, 56, function(m) {
            var p = Il(b, m);
            if (!p) return b.error(Nk("Slot.setSafeFrameConfig", [m]), c), d;
            _.Uh(e, 13, p);
            return d
        });
        c.aa(tI, function(m) {
            m = m.detail;
            if (K(m, 8)) g = null;
            else {
                g = new DK;
                var p = !!K(m, 9);
                g.isBackfill = p;
                var r = Yc(m, 15, Ec),
                    t = Yc(m, 16, Ec);
                r.length && t.length && (g.sourceAgnosticCreativeId = r[0], g.sourceAgnosticLineItemId = t[0], p || (g.creativeId = r[0], g.lineItemId = t[0], (p = Yc(m, 22, Ec)) && p.length && (g.creativeTemplateId = p[0])));
                Yc(m, 17, Ec).length && EK(g, Yc(m, 17, Ec)[0]);
                Yc(m, 18, Ec).length && FK(g, Yc(m, 18, Ec)[0]);
                Yc(m, 19, Ec).length && GK(g, Yc(m, 19, Ec));
                Yc(m, 20, Ec).length && HK(g, Yc(m, 20, Ec));
                m = Yc(m, 45, jc(m.ga) & 18 ? Zc : $c).map(function(w) {
                    return nd(w)
                });
                m.length && (g.encryptedTroubleshootingInfo = m[0])
            }
        });
        this.getResponseInformation = J(a, 355, function() {
            return g
        });
        this.getName = J(a, 170, function() {
            b.error(YJ());
            return c.getAdUnitPath()
        });
        var n = new wK(a, c);
        this.getSlotId = J(a, 579, function() {
            return n
        });
        this.getServices = J(a, 580, function() {
            return _.bn(e, 4).map(function(m) {
                var p = eH[m];
                if (p) {
                    var r, t, w;
                    m = null != (w = null == (t = (r = Tk())[p]) ? void 0 : t.call(r)) ? w : null
                } else m = null;
                return m
            })
        });
        this.getSizes = J(a, 581, function(m, p) {
            var r, t;
            return null != (t = null == (r = Ji(e, m, p)) ? void 0 : r.map(function(w) {
                return K(w, 3) ? "fluid" : new IK(w.getWidth(), w.getHeight())
            })) ? t : null
        });
        this.getClickUrl = J(a, 582, function() {
            var m;
            return null != (m = e.getClickUrl()) ? m : ""
        });
        this.getTargetingMap = J(a, 583, function() {
            for (var m = {}, p = _.x(jl(e)), r = p.next(); !r.done; r = p.next()) r = r.value, y(r, 1) && (m[y(r, 1)] = _.bn(r, 2));
            return m
        });
        this.getOutOfPage = J(a, 584, function(m) {
            return "number" === typeof m ? Mm(e) === m : 0 !== Mm(e)
        });
        this.getCollapseEmptyDiv = J(a, 585, function() {
            return Jl(e, 10) ? K(e, 10) : null
        });
        this.getDivStartsCollapsed = J(a, 586, function() {
            return Jl(e, 11) ? K(e, 11) : null
        });
        c.aa(uI, function(m) {
            h = m.detail.Ig
        });
        this.getContentUrl = J(a, 587, function() {
            return h()
        });
        this.getFirstLook = J(a, 588, function() {
            Ix("The getFirstLook method of SlotInterface is deprecated. Please update your code to no longer call this method.");
            return 0
        });
        c.aa(tI, function(m) {
            var p;
            k = null != (p = m.detail.getEscapedQemQueryId()) ? p : ""
        });
        this.getEscapedQemQueryId = J(a, 591, function() {
            return k
        });
        this.getHtml = J(a, 592, function() {
            return l ? (window.console && console.warn && console.warn("This ad's html cannot be accessed using the getHtml method on googletag.Slot. Returning the empty string instead."), "") : f
        });
        _.E(mz) ? this.setConfig = J(a, 1022, function(m) {
            if (_.na(m)) {
                if (m = m.componentAuction, null != m) {
                    var p = {
                        componentAuction: m
                    };
                    if (_.na(p)) {
                        if (m = CK(e), void 0 !== p.componentAuction) {
                            p = _.x(p.componentAuction);
                            for (var r = p.next(); !r.done; r = p.next()) {
                                var t = r.value;
                                r = t.configKey;
                                t = t.auctionConfig;
                                "string" !== typeof r || il(r) || (null === t ? m.delete(r) : t && m.set(r, JSON.stringify(t)))
                            }
                        }
                    } else N(b, Nk("googletag.Slot.setConfig", [p]))
                }
            } else N(b, Nk("googletag.slot.setConfig", [m]))
        }) : this.setConfig = J(a, 1022, function(m) {
            var p = m.componentAuction;
            if (void 0 !== p) {
                m = CK(e);
                p = _.x(p);
                for (var r = p.next(); !r.done; r = p.next()) {
                    var t = r.value;
                    r = t.configKey;
                    t = t.auctionConfig;
                    "string" !== typeof r || il(r) || (null === t ? m.delete(r) : t && m.set(r, JSON.stringify(t)))
                }
            }
        })
    };
    var JK = null;
    var KK = {},
        Fm = (KK[64] = RJ, KK[134217728] = SJ, KK[32768] = TJ, KK[536870912] = UJ, KK[8] = VJ, KK[512] = WJ, KK[1048576] = XJ, KK[4194304] = ZJ, KK);
    var Nm = function(a) {
        return "22639388115" === Oh(a.getAdUnitPath())
    };
    var Zm = {
        oa: "|"
    };
    var jn = 0,
        LK = new _.Vi(-9, -9);
    var mn = 0;
    var on = new _.v.Set([function(a, b) {
            var c = a.ba.P.U;
            b.set("pvsid", {
                value: a.fa.context.pvsid
            }).set("correlator", {
                value: y(c, 26)
            })
        }, function(a, b) {
            a = a.kg;
            var c = a.vc;
            "wbn" === a.Hc && b.set("wbsu", {
                value: c
            })
        }, function(a, b) {
            var c = a.ba.P.U,
                d = a.Hh;
            a = d.ug;
            var e = d.Zh;
            d = d.Bh;
            _.E(Qy) || (c = 0 === _.Re(c, 24, 0), b.set("adsid", {
                value: c ? a : null
            }).set("pucrd", {
                value: c ? e : null
            }).set("jar", {
                value: d
            }))
        }, function(a, b) {
            var c = a.ba.P.U,
                d = a.Di;
            a = d.kc;
            d = d.jc;
            var e = K(c, 21);
            b = b.set("hxva", {
                value: e ? 1 : null
            }).set("cmsid", {
                value: e ? y(c, 23) : null
            }).set("vid", {
                value: e ? y(c, 22) : null
            }).set("pod", {
                value: d
            }).set("ppos", {
                value: a
            });
            c = y(c, 29);
            b.set.call(b, "scor", {
                value: null == c ? void 0 : c
            })
        }, function(a, b) {
            var c = a.ba,
                d = c.Z,
                e = c.P.V;
            c = a.Xh;
            var f = c.nh,
                g = c.gh;
            b.set("eid", {
                value: a.fa.pe
            }).set("debug_experiment_id", {
                value: oB().split(",")
            }).set("expflags", {
                value: _.Rh(253) ? Jf(Iy) || null : null
            }).set("pied", {
                value: function() {
                    var h = new KG,
                        k = !1,
                        l = !1;
                    f && (k = !0, _.Xf(h, 1, Ov, f));
                    var n = d.map(function(p) {
                        var r = new HG,
                            t;
                        p = null == (t = e[p.getDomId()]) ? void 0 : Pe(t, Ov, 27);
                        if (null == p || !p.length) return r;
                        l = k = !0;
                        t = _.x(p);
                        for (p = t.next(); !p.done; p = t.next()) _.Xf(r, 1, Ov, p.value);
                        return r
                    });
                    l && _.yd(h, 2, n);
                    n = _.x(null != g ? g : []);
                    for (var m = n.next(); !m.done; m = n.next()) _.Xf(h, 1, Ov, m.value), k = !0;
                    return k ? Sb(h.m(), 3) : null
                }()
            })
        }, function(a, b) {
            var c = a.fa,
                d = c.context;
            c = c.Na;
            b.set("output", {
                value: a.kg.Hc
            }).set("gdfp_req", {
                value: 1
            }).set("vrg", {
                value: d.Hb ? String(d.Hb) : d.Ta
            }).set("ptt", {
                value: 17
            }).set("impl", {
                value: c ? "fifs" : "fif"
            })
        }, function(a, b) {
            a = a.ba.P.U;
            b.set("co", {
                value: 0 !== _.Re(a, 24, 0) ? _.Re(a, 24, 0) : null,
                options: {
                    ya: !0
                }
            })
        }, function(a, b) {
            var c = a.fa.X;
            a = sn(a.ba.P.U) || new lH;
            var d = _.Re(a, 6, 2);
            b.set("rdp", {
                value: K(a, 1) ? "1" : null
            }).set("ltd", {
                value: K(a, 9) ? "1" : null
            }).set("gdpr_consent", {
                value: og(c, 2)
            }).set("gdpr", {
                value: Jl(c, 3) ? K(c, 3) ? "1" : "0" : null,
                options: {
                    ya: !0
                }
            }).set("addtl_consent", {
                value: og(c, 4)
            }).set("tcfe", {
                value: Mu(c, 7)
            }).set("us_privacy", {
                value: og(c, 1)
            }).set("npa", {
                value: K(c, 6) || K(a, 8) ? 1 : null
            }).set("puo", {
                value: _.E(cz) && K(a, 13) ? 1 : null
            }).set("tfua", {
                value: 2 !== d ? d : null,
                options: {
                    ya: !0
                }
            }).set("tfcd", {
                value: null != y(a, 5) ? y(a, 5) : null,
                options: {
                    ya: !0
                }
            }).set("trt", {
                value: null != y(a, 10) ? y(a, 10) : null,
                options: {
                    ya: !0
                }
            }).set("tad", {
                value: Jl(c, 8) ? K(c, 8) ? "1" : "0" : null,
                options: {
                    ya: !0
                }
            })
        }, function(a, b) {
            var c = a.ba,
                d = c.P,
                e = c.Z,
                f = c.xe;
            a = a.fa;
            var g = a.F,
                h = a.M,
                k = a.Na;
            a = {
                oa: "~"
            };
            var l = e.map(function(m) {
                    return d.V[m.getDomId()]
                }),
                n = [];
            c = e.map(function(m) {
                return m.getAdUnitPath().replace(/,/g, ":").split("/").map(function(p) {
                    if (!p) return "";
                    var r = _.u(n, "findIndex").call(n, function(t) {
                        return t === p
                    });
                    return 0 <= r ? r : n.push(p) - 1
                }).join("/")
            });
            b.set("iu_parts", {
                value: n
            }).set("enc_prev_ius", {
                value: c
            }).set("prev_iu_szs", {
                value: l.map(function(m) {
                    return Mi(m)
                })
            }).set("fluid", {
                value: function() {
                    var m = !1,
                        p = l.map(function(r) {
                            r = (_.C = Li(r), _.u(_.C, "includes")).call(_.C, "fluid");
                            m || (m = r);
                            return r ? "height" : "0"
                        });
                    return m ? p : null
                }()
            }).set("ifi", {
                value: function() {
                    var m = Fj(g);
                    if (!f) {
                        m += 1;
                        var p = g,
                            r = e.length;
                        r = void 0 === r ? 1 : r;
                        p = Ux(qe(p)) || p;
                        p.google_unique_id = (p.google_unique_id || 0) + r
                    }
                    return m
                }()
            }).set("adks", {
                value: e.map(function(m) {
                    if (k) {
                        var p = d.V[m.getDomId()];
                        p = Oi(p);
                        if (m = h.j.get(m)) m.Pb = p;
                        return p
                    }
                    p = d.U;
                    var r = d.V[m.getDomId()],
                        t;
                    if (!(t = ur(h, m))) {
                        p = Oi(r, K(p, 6) || K(r, 17) ? null : hj(m));
                        if (m = h.j.get(m)) m.Pb = p;
                        t = p
                    }
                    return t
                })
            }).set("didk", {
                value: _.E(kz) ? Em(e, function(m) {
                    return _.Ni(m.getDomId())
                }, a) : null,
                options: _.u(Object, "assign").call(Object, {}, a, {
                    Eb: !0
                })
            })
        }, function(a, b) {
            var c = a.ba;
            a = c.Z;
            c = c.P;
            var d = c.U,
                e = c.V;
            b.set("sfv", {
                value: mK ? mK : mK = yl()
            }).set("fsfs", {
                value: Em(a, function(f) {
                    f = e[f.getDomId()];
                    var g;
                    return Number(null != (g = null == f ? void 0 : Qi(f, 12)) ? g : K(d, 13))
                }, {
                    yc: 0
                }),
                options: {
                    oa: ",",
                    ae: 0,
                    Eb: !0
                }
            }).set("fsbs", {
                value: Em(a, function(f) {
                    f = e[f.getDomId()].gb();
                    var g = d.gb(),
                        h;
                    return (null != (h = null == f ? void 0 : Qi(f, 3)) ? h : null == g ? 0 : K(g, 3)) ? 1 : 0
                }, {
                    yc: 0
                }),
                options: {
                    ae: 0,
                    Eb: !0
                }
            })
        }, function(a, b) {
            var c = a.fa,
                d = c.M,
                e = c.F;
            a = a.ba;
            c = a.Z;
            var f = a.xe;
            b.set("ris", {
                value: Em(c, function(g) {
                    var h, k;
                    g = null != (k = null == (h = d.j.get(g)) ? void 0 : h.Cf) ? k : 0;
                    h = _.jf(e);
                    return g && h ? Math.round(Math.min((h - g) / 1E3, 1800)) : null
                }, {
                    oa: "~"
                }),
                options: {
                    oa: "~",
                    Eb: !0
                }
            }).set("rcs", {
                value: Em(c, function(g) {
                    if (!f) {
                        var h = void 0 === h ? _.q : h;
                        var k = d.j.get(g);
                        k && (k.Cf = _.jf(h) || 0, k.Uf++)
                    }
                    return II(d, g)
                }, {
                    yc: 0
                }),
                options: {
                    ae: 0,
                    Eb: !0
                }
            })
        }, function(a, b) {
            var c = a.ba;
            a = a.fa.Na;
            c = c.P.V[c.Z[0].getDomId()];
            b.set("click", {
                value: !a && c.getClickUrl() ? y(c, 7) : null
            })
        }, function(a, b, c) {
            var d = a.ba,
                e = d.Z,
                f = d.P.V;
            a = a.fa;
            var g = a.X,
                h = a.F;
            c = void 0 === c ? function(k, l) {
                return cf(k, l)
            } : c;
            a = e.map(function(k) {
                return f[k.getDomId()]
            });
            b.set("ists", {
                value: Dm(a, function(k) {
                    return 0 !== Mm(k)
                }) || null
            }).set("fas", {
                value: Em(a, function(k) {
                    return Qm(Mm(k))
                }, {
                    yc: 0
                }),
                options: {
                    ae: 0,
                    Eb: !0
                }
            }).set("itsi", {
                value: e.some(function(k) {
                    var l;
                    return !Nm(k) && 5 === (null == (l = f[k.getDomId()]) ? void 0 : Mm(l))
                }) ? function() {
                    var k = c(g, h);
                    if (!k) return 1;
                    var l;
                    k = Math.max.apply(Math, _.ue(null != (l = _.Km((0, B.K)(k), 604800)) ? l : []));
                    return isFinite(k) ? Math.floor(Math.max((Date.now() - k) / 6E4, 1)) : null
                }() : null
            })
        }, function(a, b) {
            a = a.ba;
            var c = a.P.V;
            a = a.Z.map(function(d) {
                return c[d.getDomId()]
            });
            b.set("rbvs", {
                value: Dm(a, function(d) {
                    return 4 === Mm(d)
                }) || null
            })
        }, function(a, b) {
            var c = a.ba,
                d = c.P,
                e = c.P.U,
                f = c.Z;
            c = c.ub;
            var g = a.fa;
            a = g.isSecureContext;
            g = g.F;
            b = b.set("prev_scp", {
                value: $m(f, d),
                options: {
                    Eb: !0,
                    oa: "|"
                }
            });
            var h = b.set,
                k = d.U,
                l = d.V,
                n = new zj;
            n.set(0, 1 !== c);
            l = l[f[0].getDomId()];
            n.set(1, !!K(l, 17));
            n.set(2, gn(f, d));
            n.set(3, K(k, 27) || !1);
            n.set(4, 3 === c);
            d = Bj(n);
            h.call(b, "eri", {
                value: d
            }).set("cust_params", {
                value: cn(e),
                options: {
                    oa: "&"
                }
            }).set("ppid", {
                value: 1 !== _.Re(e, 24, 0) && _.bg(e, 16) ? y(e, 16) : null,
                options: {
                    ya: !0
                }
            }).set("gct", {
                value: Wm("google_preview", g)
            }).set("sc", {
                value: a ? 1 : 0,
                options: {
                    ya: !0
                }
            })
        }, function(a, b) {
            var c = a.fa,
                d = c.F,
                e = c.X;
            c = c.wa;
            a = a.ba.P.U;
            var f = dn(a.xa());
            if (0 === _.Re(a, 24, 0)) {
                var g = _.mC(c, "__gads", e);
                a = "1" === _.mC(c, "__gpi_opt_out", e) ? "1" : null;
                b = b.set("cookie", {
                    value: g,
                    options: {
                        ya: !0
                    }
                }).set("cookie_enabled", {
                    value: !g && nC(c, e) ? "1" : null
                });
                g = d.document;
                var h = g.domain;
                d = b.set.call(b, "cdm", {
                    value: (f || Ti(d)) === g.URL ? "" : h
                });
                f = d.set;
                e = (e = _.mC(c, "__gpi", e)) && !_.u(e, "includes").call(e, "&") ? e : null;
                f.call(d, "gpic", {
                    value: e
                }).set("gpico", {
                    value: a
                }).set("pdopt", {
                    value: a
                })
            }
        }, function(a, b) {
            a = a.fa.F;
            b.set("arp", {
                value: ym(a) ? 1 : null
            }).set("abxe", {
                value: _.ne(a.top) || Cx(a.IntersectionObserver) ? 1 : null
            })
        }, function(a, b) {
            var c = a.fa.F;
            a = dn(a.ba.P.U.xa());
            b.set("dt", {
                value: (new Date).getTime()
            });
            if (!a) {
                try {
                    var d = Math.round(Date.parse(c.document.lastModified) / 1E3) || null
                } catch (e) {
                    d = null
                }
                b.set("lmt", {
                    value: d
                })
            }
            d = mn;
            c = lf(c);
            0 < c && d >= c && b.set("dlt", {
                value: c
            }).set("idt", {
                value: d - c
            })
        }, function(a, b) {
            var c = a.ba,
                d = c.P,
                e = c.Z,
                f = c.P;
            c = f.U;
            f = f.V;
            var g = a.fa;
            a = g.F;
            var h = g.Na;
            g = Ki(!0, a);
            for (var k = a.document, l = [], n = [], m = _.x(e), p = m.next(); !p.done; p = m.next()) {
                p = p.value;
                var r = f[p.getDomId()];
                p = nj(p, r, k, Ri(c, r));
                r = void 0;
                var t = h ? null != (r = p) ? r : LK : p;
                t && (l.push(Math.round(t.x)), n.push(Math.round(t.y)))
            }
            g && (d.lc = g);
            c = Si(a) ? null : Ki(!1, a);
            try {
                var w = a.top;
                var D = hn(w.document, w)
            } catch (G) {
                D = new _.Vi(-12245933, -12245933)
            }
            b.set("adxs", {
                value: l
            }).set("adys", {
                value: n
            }).set("biw", {
                value: g ? g.width : null
            }).set("bih", {
                value: g ? g.height : null
            }).set("isw", {
                value: g ? null == c ? void 0 : c.width : null
            }).set("ish", {
                value: g ? null == c ? void 0 : c.height : null
            }).set("scr_x", {
                value: Math.round(D.x),
                options: {
                    ya: !0
                }
            }).set("scr_y", {
                value: Math.round(D.y),
                options: {
                    ya: !0
                }
            }).set("btvi", {
                value: kn(e, a, d),
                options: {
                    ya: !0,
                    oa: "|"
                }
            })
        }, function(a, b) {
            var c = a.fa.M;
            b.set("ucis", {
                value: a.ba.Z.map(function(d) {
                    d = (0, B.K)(c.j.get(d));
                    null != d.Sc || (d.Sc = window === window.top ? (++c.A).toString(36) : Yw());
                    return d.Sc
                }),
                options: {
                    oa: "|"
                }
            }).set("oid", {
                value: 2
            })
        }, function(a, b) {
            a = a.ba;
            var c = a.Z,
                d = a.P,
                e = d.V;
            a = new _.v.Map;
            d = _.x(d.U.xa());
            for (var f = d.next(); !f.done; f = d.next()) {
                var g = f.value;
                a.set((0, B.K)(y(g, 1)), [_.bn(g, 2)[0]])
            }
            for (d = 0; d < c.length; d++)
                if (g = e[c[d].getDomId()])
                    for (g = _.x(g.xa()), f = g.next(); !f.done; f = g.next()) {
                        var h = f.value;
                        f = (0, B.K)(y(h, 1));
                        var k = a.get(f) || [];
                        h = _.bn(h, 2)[0];
                        1 === c.length ? k[0] = h : h !== k[0] && (k[d + 1] = h);
                        a.set(f, k)
                    }
            c = [];
            e = _.x(_.u(a, "keys").call(a));
            for (d = e.next(); !d.done; d = e.next()) g = d.value, d = NI()[g], g = a.get(g), d && g && (1 < g.length ? (g = g.map(function(l) {
                return encodeURIComponent(l || "")
            }).join(), c.push(d + "," + g)) : 1 === g.length && "url" !== d && b.set(d, {
                value: g[0]
            }));
            c.length && b.set("sps", {
                value: c,
                options: {
                    oa: "|"
                }
            })
        }, function(a, b) {
            var c = a.ba.P.U,
                d = a.fa;
            a = d.F;
            var e = d.Ai;
            d = d.hb;
            e = e ? Me(e) : _.Rh(251);
            var f, g, h, k, l, n, m;
            var p = a;
            p = void 0 === p ? Qw : p;
            try {
                var r = p.history.length
            } catch ($a) {
                r = 0
            }
            b = b.set("u_his", {
                value: r
            }).set("u_h", {
                value: null == (f = a.screen) ? void 0 : f.height
            }).set("u_w", {
                value: null == (g = a.screen) ? void 0 : g.width
            }).set("u_ah", {
                value: null == (h = a.screen) ? void 0 : h.availHeight
            }).set("u_aw", {
                value: null == (k = a.screen) ? void 0 : k.availWidth
            }).set("u_cd", {
                value: null == (l = a.screen) ? void 0 : l.colorDepth
            });
            f = b.set;
            g = a;
            g = void 0 === g ? _.q : g;
            g = g.devicePixelRatio;
            f = f.call(b, "u_sd", {
                value: "number" === typeof g ? +g.toFixed(3) : null
            }).set("u_tz", {
                value: -(new Date).getTimezoneOffset()
            });
            g = f.set;
            try {
                var t, w, D, G, F = null != (G = null == (t = a.external) ? void 0 : null == (w = t.getHostEnvironmentValue) ? void 0 : null == (D = w.bind(a.external)) ? void 0 : D("os-mode")) ? G : "",
                    O, I = Number(null == (O = JSON.parse(F)) ? void 0 : O["os-mode"]);
                var Q = 0 <= I ? I + 1 : null
            } catch ($a) {
                Q = null
            }
            Q = g.call(f, "wsm", {
                value: Q
            }).set("dmc", {
                value: null != (m = null == (n = a.navigator) ? void 0 : n.deviceMemory) ? m : null
            });
            n = Q.set;
            (c = y(c, 8)) ? (50 < c.length && (c = c.substring(0, 50)), c = "a " + lu('role:1 producer:12 loc:"' + c + '"')) : c = "";
            c = n.call(Q, "uule", {
                value: c
            });
            n = c.set;
            m = a;
            m = void 0 === m ? _.q : m;
            Q = new zj;
            m.SVGElement && m.document.createElementNS && Q.set(0);
            t = Bx();
            t["allow-top-navigation-by-user-activation"] && Q.set(1);
            t["allow-popups-to-escape-sandbox"] && Q.set(2);
            m.crypto && m.crypto.subtle && Q.set(3);
            m.TextDecoder && m.TextEncoder && Q.set(4);
            m = Bj(Q);
            e = n.call(c, "bc", {
                value: m
            }).set("uach", {
                value: e ? lu(e, 3) : null
            });
            c = e.set;
            if (d) var S = null;
            else if (d = null == (S = a.navigator) ? void 0 : S.userActivation) {
                S = 0;
                if (null == d ? 0 : d.hasBeenActive) S |= 1;
                if (null == d ? 0 : d.isActive) S |= 2
            } else S = void 0;
            S = c.call(e, "uas", {
                value: S
            });
            d = S.set;
            a: {
                try {
                    var W, ja, ca = null == (W = a.performance) ? void 0 : null == (ja = W.getEntriesByType("navigation")) ? void 0 : ja[0];
                    if (null == ca ? 0 : ca.type) {
                        var ya;
                        var ua = null != (ya = vG.get(ca.type)) ? ya : null;
                        break a
                    }
                } catch ($a) {}
                var za, ka, Oa;ua = null != (Oa = wG.get(null == (za = a.performance) ? void 0 : null == (ka = za.navigation) ? void 0 : ka.type)) ? Oa : null
            }
            d.call(S, "nvt", {
                value: ua
            })
        }, function(a, b) {
            var c = a.fa,
                d = c.F,
                e = c.M;
            c = c.Na;
            a = a.ba;
            var f = a.Z;
            a = a.P;
            var g = a.U,
                h = a.V;
            a = Xm("google_preview", d);
            var k = d.document,
                l = a ? en(k.URL) : k.URL;
            k = a ? en(k.referrer) : k.referrer;
            a = !1;
            if (c) c = dn(g.xa());
            else {
                var n;
                c = null != (n = dn(h[f[0].getDomId()].xa())) ? n : dn(g.xa())
            }
            if (null != c) {
                var m = l;
                Si(d) || (k = "", a = !0)
            } else c = l;
            n = fn(d);
            b.set("nhd", {
                value: n || null
            }).set("url", {
                value: c
            }).set("loc", {
                value: null !== m && m !== c ? m : null
            }).set("ref", {
                value: k
            });
            if (n) {
                m = b.set;
                var p, r;
                n = _.ne(d.top) && (null == (p = d.top) ? void 0 : null == (r = p.location) ? void 0 : r.href);
                var t;
                p = null == (t = d.location) ? void 0 : t.ancestorOrigins;
                d = ok(d) || "";
                t = (null == p ? void 0 : p[p.length - 1]) || "";
                d = (d = n || d || t) ? a ? qx(d.match(_.px)[3] || null) : d : null;
                m.call(b, "top", {
                    value: d
                }).set("etu", {
                    value: e.md
                })
            }
        }, function(a, b) {
            a = a.fa.context.pvsid;
            b.set("rumc", {
                value: _.E(Fz) || _.nf(bi).j ? a : null
            }).set("rume", {
                value: _.E(Vy) ? 1 : null
            })
        }, function(a, b) {
            a = a.fa.F;
            var c = b.set;
            var d = Ox(a);
            var e = LA(a, a.google_ad_width, a.google_ad_height);
            var f = d.location.href;
            if (d === d.top) f = !0;
            else {
                var g = !1,
                    h = d.document;
                h && h.referrer && (f = h.referrer, d.parent === d.top && (g = !0));
                (d = d.location.ancestorOrigins) && (d = d[d.length - 1]) && -1 === f.indexOf(d) && (g = !1, f = d);
                f = g
            }
            g = a.top == a ? 0 : _.ne(a.top) ? 1 : 2;
            d = 4;
            e || 1 != g ? e || 2 != g ? e && 1 == g ? d = 7 : e && 2 == g && (d = 8) : d = 6 : d = 5;
            f && (d |= 16);
            e = "" + d;
            if (a != a.top)
                for (f = a; f && f != f.top && _.ne(f) && !f.sf_ && !f.$sf && !f.inGptIF && !f.inDapIF; f = f.parent);
            c.call(b, "frm", {
                value: e || null
            }).set("vis", {
                value: AG(a.document)
            })
        }, function(a, b) {
            var c = a.ba.Z;
            a = a.fa.F;
            for (var d = [], e = [], f = _.x(c), g = f.next(); !g.done; g = f.next()) {
                var h = void 0,
                    k = void 0,
                    l = void 0;
                var n = a;
                g = hj(g.value);
                var m = Fx((null == g ? void 0 : g.parentElement) && jj(g.parentElement, n) || null);
                !m || 1 === m[0] && 1 === m[3] ? (m = null != (l = null == g ? void 0 : g.parentElement) ? l : null, l = null != (k = Zi(m)) ? k : new _.Yi(0, 0), Cm(l, m, n, 100), k = null != (h = Zi(g)) ? h : new _.Yi(0, 0), Cm(k, g, n, 1), -1 === l.height && (k.height = -1), n = l, k = h = k, h = n.width + "x" + n.height, n = k.width + "x" + k.height) : n = h = "-1x-1";
                d.push(h);
                e.push(n)
            }
            null == JK && (f = LA(a, 500, 300), n = a.navigator, h = n.userAgent, k = n.platform, n = n.product, !/Win|Mac|Linux|iPad|iPod|iPhone/.test(k) && /^Opera/.test(h) ? h = !1 : /Win/.test(k) && /Trident/.test(h) && 11 <= a.document.documentMode ? h = !0 : (k = (/WebKit\/(\d+)/.exec(h) || [0, 0])[1], g = (/rv:(\d+\.\d+)/.exec(h) || [0, 0])[1], h = !k && "Gecko" === n && 27 <= g && !/ rv: 1\.8([^.] |\.0) /.test(h) || 536 <= k ? !0 : !1), JK = h && !f);
            g = 0 !== (0, _.Tm)();
            f = Ki(!0, a, g).width;
            h = [];
            n = [];
            k = [];
            null !== a && a != a.top && (l = Ki(!1, a).width, (-12245933 === f || -12245933 === l || l < f) && k.push(8)); - 12245933 !== f && (1.5 * f < a.document.documentElement.scrollWidth ? k.push(10) : g && 1.5 * a.outerWidth < f && k.push(10));
            c = _.x(c);
            for (l = c.next(); !l.done; l = c.next()) {
                g = new zj;
                m = hj(l.value);
                l = 0;
                var p = !1,
                    r = !1;
                if (m) {
                    for (var t = 0, w = m; w && 100 > t; t++, w = w.parentElement) {
                        var D = jj(w, a);
                        if (D) {
                            var G = D,
                                F = G.display,
                                O = G.overflowX;
                            if ("visible" !== G.overflowY && (g.set(2), (G = Zi(w)) && (l = l ? Math.min(l, G.width) : G.width), g.get(9))) break;
                            Am(D) && g.set(9);
                            "none" === F && g.set(7);
                            "IFRAME" === w.nodeName && (D = parseInt(D.width, 10), D < f && (g.set(8), l = l ? Math.min(D, l) : D));
                            r || (r = "scroll" === O || "auto" === O);
                            p || (p = "flex" === F)
                        } else g.set(3)
                    }
                    r && p && (m = m.getBoundingClientRect().left, (m > f || 0 > m) && g.set(11))
                } else g.set(1);
                m = _.x(k);
                for (p = m.next(); !p.done; p = m.next()) g.set(p.value);
                h.push(Bj(g));
                n.push(l)
            }
            b.set("psz", {
                value: d,
                options: {
                    oa: "|"
                }
            }).set("msz", {
                value: e,
                options: {
                    oa: "|"
                }
            }).set("fws", {
                value: h
            }).set("ohw", {
                value: n
            }).set("ea", {
                value: JK ? null : "0",
                options: {
                    ya: !0
                }
            })
        }, function(a, b) {
            b.set("psts", {
                value: HI(a.fa.M, a.ba.Z)
            })
        }, function(a, b) {
            var c = a.fa;
            a = c.X;
            c = c.F;
            var d;
            var e = c.document.domain,
                f = null != (d = bf(a) && df(c) ? c.document.cookie : null) ? d : "",
                g = c.history.length,
                h = c.screen,
                k = c.document.referrer;
            if (qe()) var l = window.gaGlobal || {};
            else {
                var n = Math.round((new Date).getTime() / 1E3),
                    m = c.google_analytics_domain_name;
                e = "undefined" == typeof m ? HA("auto", e) : HA(m, e);
                var p = -1 < f.indexOf("__utma=" + e + "."),
                    r = -1 < f.indexOf("__utmb=" + e);
                (d = (Ux() || window).gaGlobal) || (d = {}, (Ux() || window).gaGlobal = d);
                var t = !1;
                if (p) {
                    var w = f.split("__utma=" + e + ".")[1].split(";")[0].split(".");
                    r ? d.sid = w[3] : d.sid || (d.sid = n + "");
                    d.vid = w[0] + "." + w[1];
                    d.from_cookie = !0
                } else {
                    d.sid || (d.sid = n + "");
                    if (!d.vid) {
                        t = !0;
                        r = Math.round(2147483647 * Math.random());
                        p = FA.appName;
                        var D = FA.version,
                            G = FA.language ? FA.language : FA.browserLanguage,
                            F = FA.platform,
                            O = FA.userAgent;
                        try {
                            w = FA.javaEnabled()
                        } catch (I) {
                            w = !1
                        }
                        w = [p, D, G, F, O, w ? 1 : 0].join("");
                        h ? w += h.width + "x" + h.height + h.colorDepth : _.q.java && _.q.java.awt && (h = _.q.java.awt.Toolkit.getDefaultToolkit().getScreenSize(), w += h.screen.width + "x" + h.screen.height);
                        w = w + f + (k || "");
                        for (k = w.length; 0 < g;) w += g-- ^ k++;
                        d.vid = (r ^ GA(w) & 2147483647) + "." + n
                    }
                    d.from_cookie || (d.from_cookie = !1)
                }
                if (!d.cid) {
                    b: for (n = 999, m && (m = 0 == m.indexOf(".") ? m.substr(1) : m, n = m.split(".").length), m = 999, f = f.split(";"), w = 0; w < f.length; w++)
                        if (k = IA.exec(f[w]) || JA.exec(f[w]) || KA.exec(f[w])) {
                            h = k[1] || 0;
                            if (h == n) {
                                l = k[2];
                                break b
                            }
                            h < m && (m = h, l = k[2])
                        }t && l && -1 != l.search(/^\d+\.\d+$/) ? (d.vid = l, d.from_cookie = !0) : l != d.vid && (d.cid = l)
                }
                d.dh = e;
                d.hid || (d.hid = Math.round(2147483647 * Math.random()));
                l = d
            }
            e = l.sid;
            d = l.hid;
            t = l.from_cookie;
            f = l.cid;
            t && !bf(a) || b.set("ga_vid", {
                value: l.vid
            }).set("ga_sid", {
                value: e
            }).set("ga_hid", {
                value: d
            }).set("ga_fc", {
                value: t
            }).set("ga_cid", {
                value: f
            }).set("ga_wpids", {
                value: c.google_analytics_uacct
            })
        }, function(a, b) {
            a = a.fa;
            var c = a.F;
            a = a.context.pvsid;
            b = b.set("js", {
                value: _.E(Ay) ? MA(c) : null
            });
            var d = b.set;
            if (_.E(Ay)) a: {
                var e = c;e = void 0 === e ? window : e;
                if (c = MA(e)) {
                    var f = null;
                    try {
                        "afma-gpt-sdk-a" == c ? f = e._gmptnl.pm("GAM=", a.toString()) || "5" : (f = e.__gmptnl_n || "5", e.webkit.messageHandlers._gmptnl.postMessage("GAM="))
                    } catch (g) {
                        a = "3";
                        break a
                    }
                    a = "string" === typeof f ? f : "3"
                } else a = null
            }
            else a = null;
            d.call(b, "ms", {
                value: a
            })
        }, function(a, b) {
            var c = a.fa.F;
            a = c.navigator;
            c = c.document;
            _.E(Rz) || "runAdAuction" in a && "joinAdInterestGroup" in a && Yg("run-ad-auction", c) && b.set("td", {
                value: 1
            })
        }, function(a, b) {
            var c = a.pi.ri;
            Yg("browsing-topics", a.fa.F.document) && (b.set("topics", {
                value: c instanceof Uint8Array ? Sb(c, 3) : c
            }), !c || c instanceof Uint8Array || b.set("tps", {
                value: c
            }))
        }, function(a, b) {
            var c = a.fa,
                d = c.F;
            c = c.X;
            var e = a.ba.Z,
                f = a.ki;
            a = f.Sh;
            var g = f.Sg,
                h = f.Qh;
            f = f.Ih;
            _.E(Cz) || b.set("a3p", {
                value: Qf(cf(c, d), Oh((0, B.K)(e[0]).getAdUnitPath()), a, g, f, h)
            })
        }, function(a, b) {
            var c = a.bd.cd,
                d = a.ba.Z;
            a = {
                oa: "~"
            };
            var e = function() {
                return c ? d.map(function(f) {
                    return (0, B.K)(c.get(f))
                }) : []
            }();
            b.set("cbidsp", {
                value: Em(e, function(f) {
                    return Sb(f.m(), 3)
                }, a),
                options: _.u(Object, "assign").call(Object, {}, a, {
                    Eb: !0
                })
            })
        }, function(a, b) {
            a = a.ba.P.U;
            to(a.vd(), Jp, 1) && (a = Ip(a.vd(), Jp, 1), b.set("cmrv", {
                value: 1
            }).set("cmrq", {
                value: y(a, 1)
            }).set("cmrc", {
                value: _.bn(a, 2),
                options: {
                    oa: ">"
                }
            }).set("cmrids", {
                value: _.bn(a, 3),
                options: {
                    oa: "!"
                }
            }).set("cmrf", {
                value: y(a, 4)
            }))
        }, function(a, b) {
            var c = [];
            a = _.x(Pe(Ip(a.ba.P.U.vd(), Lp, 2), gp, 1));
            for (var d = a.next(); !d.done; d = a.next()) d = d.value, _.bn(d, 2).length && c.push(_.Re(d, 1, 0) + "=" + _.bn(d, 2).join("|"));
            b.set("pps", {
                value: c,
                options: {
                    oa: "~"
                }
            })
        }, function(a, b) {
            b.set("scar", {
                value: a.Oh.kh
            })
        }, function(a, b) {
            a = a.fa.F.document;
            _.E(Ez) || Yg("attribution-reporting", a) && b.set("nt", {
                value: 1
            })
        }, function(a, b) {
            if (a = a.Vh.Uh) a = lu(Me(a), 3), b.set("psd", {
                value: a
            })
        }]),
        NK = function(a) {
            if (null == a || !a.ba.Z.length) return "";
            for (var b = new _.v.Set(Kf(qn)), c = _.x(ln(a.fa.X)), d = c.next(); !d.done; d = c.next()) b.add(d.value);
            c = new _.v.Map;
            d = _.x(on);
            for (var e = d.next(); !e.done; e = d.next()) e = e.value, e(a, c);
            a = "https://" + (MK(a) ? "pagead2.googlesyndication.com" : "securepubads.g.doubleclick.net") + "/gampad/ads?";
            c = _.x(c);
            for (d = c.next(); !d.done; d = c.next()) {
                e = _.x(d.value);
                d = e.next().value;
                var f = e.next().value;
                e = f.value;
                f = void 0 === f.options ? {} : f.options;
                (new RegExp("[?&]" + d + "=")).test(a);
                if (!b.has(d) && null != e) {
                    var g = f;
                    f = void 0 === g.oa ? "," : g.oa;
                    g = void 0 === g.ya ? !1 : g.ya;
                    if (e = "object" !== typeof e ? null == e || !g && 0 === e ? null : encodeURIComponent(e) : Array.isArray(e) && e.length ? encodeURIComponent(e.join(f)) : null) "?" !== a[a.length - 1] && (a += "&"), a += d + "=" + e
                }
            }
            return a
        },
        MK = function(a) {
            var b = a.fa.X,
                c, d;
            a = null != (d = null == (c = sn(a.ba.P.U)) ? void 0 : K(c, 9)) ? d : !1;
            c = K(b, 8);
            return a || c || !bf(b)
        };
    var RK = function(a, b, c, d) {
            var e = this;
            this.context = a;
            this.M = c;
            this.j = new _.v.Map;
            this.o = new _.v.Map;
            this.wb = _.nf(bi);
            gI() && (_.yb(window, "DOMContentLoaded", $h(a, 334, function() {
                for (var f = _.x(e.j), g = f.next(); !g.done; g = f.next()) {
                    var h = _.x(g.value);
                    g = h.next().value;
                    h = h.next().value;
                    OK(e, g, h) && e.j.delete(g)
                }
            })), b.aa(vI, function(f) {
                f = f.detail;
                var g = f.V;
                return void PK(e, (0, B.K)(QK(d, f.Pe)), (0, B.K)(pi(g, 20)))
            }), b.aa(wI, function(f) {
                f = f.detail;
                var g = f.V;
                f = (0, B.K)(QK(d, f.Pe));
                g = (0, B.K)(pi(g, 20));
                var h = e.o.get(f);
                null != h ? iI(h, g) : PK(e, f, g)
            }))
        },
        PK = function(a, b, c) {
            OK(a, b, c) ? a.j.delete(b) : (a.j.set(b, c), _.go(b, function() {
                return a.j.delete(b)
            }))
        },
        OK = function(a, b, c) {
            var d = hj(b);
            if ("DIV" !== (null == d ? void 0 : d.nodeName)) return !1;
            d = new fI({
                F: window,
                wb: a.wb,
                pb: (0, B.va)(d),
                Sa: function(e) {
                    return void di(a.context, 336, e)
                },
                mi: _.E(Fz)
            });
            if (!d.j) return !1;
            iI(d, c);
            a.o.set(b, d);
            DI(a.M, b, function() {
                return void a.o.delete(b)
            });
            return !0
        };
    var SK = function(a) {
        this.o = a;
        this.m = this.j = 0
    };
    SK.prototype.push = function() {
        for (var a = _.x(_.wb.apply(0, arguments)), b = a.next(); !b.done; b = a.next()) {
            b = b.value;
            try {
                "function" === typeof b && (b.call(_.v.globalThis), this.j++)
            } catch (c) {
                this.m++, b = void 0, null == (b = window.console) || b.error("Exception in queued GPT command", c), this.o.error(bJ(String(c)))
            }
        }
        this.o.info(cJ(String(this.j), String(this.m)));
        return this.j
    };
    var Z = function(a, b, c) {
        WB.call(this, b, c);
        this.context = a
    };
    _.P(Z, WB);
    Z.prototype.R = function(a) {
        di(this.context, this.id, a);
        var b, c;
        null == (b = window.console) || null == (c = b.error) || c.call(b, a)
    };
    var TK = function(a, b, c, d, e) {
        var f = null,
            g = $h(a.context, b, e);
        _.yb(c, d, g) && (f = function() {
            return _.Ae(c, d, g)
        }, _.go(a, f));
        return f
    };
    var UK = function(a, b, c) {
        Z.call(this, a, 937, _.If(Zy));
        this.window = c;
        this.zb = V(this);
        this.l = V(this);
        this.A = V(this);
        this.D = V(this);
        this.Qb = V(this);
        this.uc = V(this);
        this.G = ZB(this, b)
    };
    _.P(UK, Z);
    UK.prototype.j = function() {
        if (this.window.top !== this.window) VK(this);
        else {
            var a = this.G.value;
            if (a) {
                var b = {},
                    c;
                if (null == (c = Df(a, Ev, 2)) ? 0 : _.Sf(c, 2)) b["*"] = {
                    Fc: !0
                };
                c = new _.v.Set;
                for (var d = _.x(Pe(a, Dv, 1)), e = d.next(); !e.done; e = d.next()) {
                    e = e.value;
                    for (var f = _.x([_.Rf(e, 2), _.Rf(e, 1)].filter(function(r) {
                            return !!r
                        })), g = f.next(); !g.done; g = f.next()) b[g.value] = {
                        Fc: _.Sf(e, 3)
                    };
                    e = _.x(Yc(e, 4, Cc));
                    for (f = e.next(); !f.done; f = e.next()) c.add(f.value)
                }
                this.zb.J(b);
                this.l.J([].concat(_.ue(c)));
                var h, k;
                b = null == (h = Df(a, Ev, 2)) ? void 0 : null == (k = Df(h, yv, 1)) ? void 0 : Pe(k, wv, 1);
                KB(this.A, (null == b ? 0 : b.length) ? b : null);
                var l;
                this.Qb.J(!(null == (l = Df(a, Ev, 2)) || !_.Sf(l, 4)));
                var n;
                this.uc.J(!(null == (n = Df(a, Ev, 2)) || !_.Sf(n, 5)));
                var m, p;
                a = null == (m = Df(a, Ev, 2)) ? void 0 : null == (p = Df(m, yv, 3)) ? void 0 : Pe(p, wv, 1);
                KB(this.D, (null == a ? 0 : a.length) ? a : null)
            } else VK(this)
        }
    };
    var VK = function(a) {
        a.zb.J({});
        a.l.J([]);
        LB(a.A);
        a.Qb.J(!1);
        a.uc.J(!1);
        LB(a.D)
    };
    UK.prototype.I = function(a) {
        this.m(a)
    };
    UK.prototype.m = function() {
        VK(this)
    };
    var WK = function(a, b, c, d, e, f) {
        Z.call(this, a, 980);
        this.A = b;
        this.C = new RB;
        this.l = [];
        this.L = X(this, c);
        this.G = X(this, d);
        this.D = X(this, e);
        a = _.x(f);
        for (b = a.next(); !b.done; b = a.next()) this.l.push(X(this, b.value))
    };
    _.P(WK, Z);
    WK.prototype.j = function() {
        (_.C = _.u(Object, "entries").call(Object, this.L.value), _.u(_.C, "find")).call(_.C, function(c) {
            var d = _.x(c);
            c = d.next().value;
            d = d.next().value;
            return "*" !== c && (null == d ? void 0 : d.Fc)
        }) && (this.A.B = !0);
        qf(25);
        for (var a = _.x((_.C = [this.G.value, this.D.value, this.l.map(function(c) {
                return c.value
            })], _.u(_.C, "flat")).call(_.C)), b = a.next(); !b.done; b = a.next()) pf(b.value);
        this.C.notify()
    };
    var XK = function(a, b) {
        Z.call(this, a, 892, _.If(az));
        this.l = V(this);
        this.D = V(this);
        this.A = V(this);
        this.Sb = V(this);
        this.Kc = V(this);
        this.G = V(this);
        this.L = ZB(this, b)
    };
    _.P(XK, Z);
    XK.prototype.j = function() {
        var a = this.L.value;
        if (!a) throw Error("config timeout");
        KB(this.l, Df(a, Gv, 3));
        KB(this.D, Df(a, Jv, 2));
        this.A.J(Yc(a, 4, Cc));
        KB(this.Sb, Pe(a, Bv, 6));
        KB(this.Kc, Pe(a, aw, 5));
        KB(this.G, Df(a, $v, 7))
    };
    XK.prototype.I = function(a) {
        this.m(a)
    };
    XK.prototype.m = function(a) {
        this.l.Ea(a);
        this.D.Ea(a);
        this.A.J([]);
        this.Sb.J([]);
        this.Kc.J([]);
        LB(this.G)
    };
    var YK = [{
            name: "Interstitial",
            oe: 1
        }, {
            name: "TopAnchor",
            oe: 2
        }, {
            name: "BottomAnchor",
            oe: 3
        }],
        ZK = function(a, b) {
            Z.call(this, a, 789);
            this.l = b;
            this.C = V(this)
        };
    _.P(ZK, Z);
    ZK.prototype.j = function() {
        var a = this;
        this.C.J(YK.filter(function(b) {
            return (new RegExp("gam" + b.name + "Demo", "i")).test(a.l)
        }).map(function(b) {
            var c = b.name;
            b = b.oe;
            var d, e;
            null == (d = window.console) || null == (e = d.warn) || e.call(d, "GPT - Demo " + c + " ENABLED");
            d = new aw;
            e = new Qv;
            b = _.z(e, 2, b);
            c = _.z(b, 1, "/22639388115/example/" + c.toLowerCase());
            return _.Xh(d, 5, bw, c)
        }))
    };
    var $K = function(a, b) {
        Z.call(this, a, 891);
        var c = this;
        this.l = V(this);
        this.error = void 0;
        var d = V(this);
        this.A = X(this, d);
        b ? b(function(e, f) {
            if (f) c.error = f, d.J([]);
            else try {
                if ("string" === typeof e) {
                    var g = JSON.parse(e || "[]");
                    Array.isArray(g) && d.J(g)
                }
            } catch (h) {} finally {
                d.mb || (c.error = Error("malformed response"), d.J([]))
            }
        }) : (this.error = Error("missing input"), d.J([]))
    };
    _.P($K, Z);
    $K.prototype.j = function() {
        if (this.error) throw this.error;
        this.l.J(Ed(dw, this.A.value))
    };
    var zn = function(a, b, c, d) {
        Z.call(this, a, 959);
        this.ob = b;
        this.C = V(this);
        this.l = X(this, b);
        $B(this, c);
        $B(this, d)
    };
    _.P(zn, Z);
    zn.prototype.j = function() {
        this.C.J(this.l.value)
    };
    var yn = function(a, b, c, d, e, f, g) {
        Z.call(this, a, 874);
        this.A = b;
        this.M = c;
        this.F = d;
        this.G = e;
        this.l = YB(this);
        $B(this, f);
        this.D = X(this, g)
    };
    _.P(yn, Z);
    yn.prototype.j = function() {
        var a = this,
            b = new lA(this.F, {
                Wa: -1,
                yg: !0
            });
        _.Nn(this, b);
        if (nA(b)) {
            var c = this.M.I,
                d = c.status,
                e = function(f) {
                    var g = a.D.value,
                        h, k, l;
                    if (l = !(null == (h = a.G) ? 0 : K(h, 9))) {
                        var n = void 0 === n ? !1 : n;
                        l = rA(f) ? !1 === f.gdprApplies || "tcunavailable" === f.tcString || void 0 === f.gdprApplies && !n || "string" !== typeof f.tcString || !f.tcString.length ? !0 : pA(f, "1") : !1
                    }
                    h = _.z(g, 5, l);
                    l = !sA(f, ["3", "4"]);
                    h = _.z(h, 9, l);
                    h = _.z(h, 2, f.tcString);
                    l = null != (k = f.addtlConsent) ? k : "";
                    k = _.z(h, 4, l);
                    _.z(k, 7, f.internalErrorState);
                    null != f.gdprApplies && _.z(g, 3, f.gdprApplies);
                    _.E(oz) && !sA(f, ["2", "7", "9", "10"]) && _.z(g, 8, !0);
                    a.l.notify()
                };
            switch (d) {
                case 2:
                    e(c.data);
                    break;
                case 1:
                    c.j.push(e);
                    break;
                case 0:
                    c.data = void 0;
                    c.status = 1;
                    c.j.push(e);
                    this.A.info(KJ());
                    b.addEventListener(function(f) {
                        rA(f) ? ("tcunavailable" === f.tcString ? a.A.info(LJ("failed")) : a.A.info(LJ("succeeded")), c.data = f, c.status = 2, c.ud().forEach(function(g) {
                            g(f)
                        }), c.Vd()) : (c.data = void 0, c.status = 1)
                    });
                    break;
                default:
                    throw Error("Impossible TCDataCacheStatus: " + d);
            }
        } else this.l.notify()
    };
    var xn = function(a, b, c, d, e) {
        Z.call(this, a, 875);
        this.D = b;
        this.F = c;
        this.l = YB(this);
        $B(this, d);
        this.A = X(this, e)
    };
    _.P(xn, Z);
    xn.prototype.j = function() {
        var a = this,
            b = new UA(this.F);
        _.Nn(this, b);
        if (PA(b.caller)) {
            var c = $h(this.context, 660, function(d) {
                d && "string" === typeof d.uspString && _.z(a.A.value, 1, d.uspString);
                a.l.notify()
            });
            this.D.info(JJ());
            VA(b, c)
        } else this.l.notify()
    };
    var vn = function(a, b) {
        Z.call(this, a, 958);
        this.l = b;
        this.ob = V(this)
    };
    _.P(vn, Z);
    vn.prototype.j = function() {
        var a = new kC,
            b, c = null == (b = this.l) ? void 0 : K(b, 9);
        _.z(a, 5, !c);
        this.ob.J(a)
    };
    var wn = function(a, b, c, d) {
        d = void 0 === d ? .001 : d;
        Z.call(this, a, 960);
        this.F = b;
        this.A = d;
        this.l = X(this, c)
    };
    _.P(wn, Z);
    wn.prototype.j = function() {
        var a = this;
        fi(this.context, 894, function() {
            return void yj("cmpMet", function(b) {
                Ej(b, a.context);
                var c = new lA(a.F);
                _.Nn(a, c);
                var d = new UA(a.F);
                _.Nn(a, d);
                L(b, "fc", Number(a.l.value));
                L(b, "tcfv1", Number(!!a.F.__cmp));
                L(b, "tcfv2", Number(nA(c)));
                L(b, "usp", Number(!!PA(d.caller)));
                L(b, "ptt", 17)
            }, a.A)
        })
    };
    var aL = function(a, b) {
        Z.call(this, a, 931);
        this.ac = V(this);
        this.Rb = V(this);
        this.l = Y(this, b)
    };
    _.P(aL, Z);
    aL.prototype.j = function() {
        var a = this.l.value,
            b = new _.v.Map;
        this.ac.J(new _.v.Map);
        if (a) {
            var c;
            a = _.x(null != (c = this.l.value) ? c : []);
            for (c = a.next(); !c.done; c = a.next()) {
                var d = c.value;
                c = Pe(d, uv, 1);
                c = 1 === _.Re(c[0], 1, 0) ? Iu(c[0]) : Lu(c[0], Hu);
                d = _.$e(d, 2);
                var e = void 0;
                b.set(c, Math.min(null != (e = b.get(c)) ? e : Number.MAX_VALUE, d))
            }
        }
        this.Rb.J(b)
    };
    aL.prototype.m = function() {
        this.ac.J(new _.v.Map);
        this.Rb.J(new _.v.Map)
    };
    var bL = function(a, b) {
        Z.call(this, a, 981);
        this.A = V(this);
        this.l = V(this);
        this.D = Y(this, b)
    };
    _.P(bL, Z);
    bL.prototype.j = function() {
        var a = new _.v.Map,
            b, c = _.x(null != (b = this.D.value) ? b : []);
        for (b = c.next(); !b.done; b = c.next()) {
            b = b.value;
            var d = Pe(b, uv, 1);
            d = 1 === _.Re(d[0], 1, 0) ? Iu(d[0]) : Lu(d[0], Hu);
            a.set(d, _.$e(b, 2))
        }
        this.A.J(a);
        this.l.J(new lv)
    };
    bL.prototype.m = function() {
        this.A.J(new _.v.Map);
        var a = this.l,
            b = a.J;
        var c = new lv;
        c = _.z(c, 1, 2);
        b.call(a, c)
    };
    var cL = function(a, b, c, d, e, f) {
        Z.call(this, a, 976);
        this.nextFunction = d;
        this.l = e;
        this.requestBidsConfig = f;
        $B(this, b);
        $B(this, c)
    };
    _.P(cL, Z);
    cL.prototype.j = function() {
        var a;
        null == (a = this.nextFunction) || a.apply(this.l, [this.requestBidsConfig])
    };
    var dL = function(a, b, c, d, e, f) {
        Z.call(this, a, 975);
        this.A = b;
        this.l = c;
        this.D = d;
        this.pbjs = e;
        this.requestBidsConfig = f;
        this.C = new RB
    };
    _.P(dL, Z);
    dL.prototype.j = function() {
        In(this.pbjs, this.A, this.l, this.D, this.requestBidsConfig);
        this.C.notify()
    };
    dL.prototype.m = function() {
        this.C.notify()
    };
    var eL = function(a, b, c, d, e, f) {
        Z.call(this, a, 1100);
        this.pbjs = b;
        this.l = c;
        this.A = d;
        this.D = e;
        this.requestBidsConfig = f;
        this.C = new RB
    };
    _.P(eL, Z);
    eL.prototype.j = function() {
        var a, b, c = null != (b = null == (a = this.l) ? void 0 : a.get("*")) ? b : _.If(yy);
        if (c) this.xb(c);
        else {
            var d, e, f, g;
            a = null != (g = null != (f = null == (d = this.requestBidsConfig) ? void 0 : d.adUnits) ? f : null == (e = this.pbjs) ? void 0 : e.adUnits) ? g : [];
            d = _.x(a);
            for (e = d.next(); !e.done; e = d.next())
                if (e = e.value.code) c = b = a = g = void 0, f = null != (g = null != (a = null == (c = this.l) ? void 0 : c.get(_.E(Cn) ? Bn(e) : e)) ? a : null == (b = this.l) ? void 0 : b.get(_.Ni(e))) ? g : 0, this.xb(f)
        }
        this.C.notify()
    };
    eL.prototype.xb = function(a) {
        var b;
        null != (b = this.A) && _.z(b, 2, this.D);
        if (a) {
            var c;
            null == (c = this.A) || _.z(c, 1, 1);
            if (!this.D) {
                this.requestBidsConfig.timeout = a;
                var d, e, f;
                b = null != (f = null == (e = (d = this.pbjs).getConfig) ? void 0 : e.call(d).s2sConfig) ? f : [];
                if (Array.isArray(b))
                    for (d = _.x(b), e = d.next(); !e.done; e = d.next()) e.value.timeout = a;
                else b.timeout = a;
                var g, h;
                null == (h = (g = this.pbjs).setConfig) || h.call(g, {
                    bidderTimeout: a
                })
            }
        }
    };
    eL.prototype.m = function() {
        this.C.notify()
    };
    var fL = function(a, b, c, d, e, f, g, h) {
        _.U.call(this);
        this.j = a;
        this.B = b;
        this.m = c;
        this.l = d;
        this.A = e;
        this.I = f;
        this.N = g;
        this.pbjs = h
    };
    _.P(fL, _.U);
    fL.prototype.push = function(a) {
        var b = a.context,
            c = a.nextFunction;
        a = a.requestBidsConfig;
        if (this.pbjs) {
            var d = new hg;
            _.Nn(this, d);
            var e = new eL(this.j, this.pbjs, this.A, this.I, this.N, a),
                f = new dL(this.j, this.B, this.m, this.l, this.pbjs, a);
            H(d, e);
            H(d, f);
            H(d, new cL(this.j, f.C, e.C, c, b, a));
            sg(d)
        }
    };
    var gL = function(a, b, c, d, e, f, g, h, k) {
        Z.call(this, a, 951);
        this.F = window;
        this.Gd = V(this);
        this.Hd = V(this);
        this.G = X(this, b);
        this.A = Y(this, d);
        this.D = X(this, e);
        this.O = X(this, f);
        this.l = Y(this, g);
        this.T = Y(this, h);
        this.L = X(this, k);
        $B(this, c)
    };
    _.P(gL, Z);
    gL.prototype.j = function() {
        var a = !!Tk().pbjs_hooks;
        this.Hd.J(a);
        KB(this.Gd, a ? null : _.hf());
        var b, c = null == (b = this.A.value) ? void 0 : b.size,
            d;
        b = (null == (d = this.l.value) ? void 0 : d.size) || _.If(yy);
        d = this.G.value;
        var e, f = null != (e = Tk().pbjs_hooks) ? e : [];
        e = new fL(this.context, this.A.value, this.D.value, this.O.value, this.l.value, this.T.value, this.L.value, d);
        _.Nn(this, e);
        f = _.x(f);
        for (var g = f.next(); !g.done; g = f.next()) e.push(g.value);
        if (c || b || a) Tk().pbjs_hooks = Ln(this.context, e);
        !c && !b || a || Jn(d, this.F)
    };
    var hL = function(a, b, c) {
        Z.call(this, a, 1093);
        this.A = new QB(b);
        this.l = X(this, c)
    };
    _.P(hL, Z);
    hL.prototype.j = function() {
        var a = this.A.value;
        if (a) {
            var b;
            (null == (b = this.l.value["*"]) ? 0 : b.Fc) && Array.isArray(a.installedModules) && (b = new Zk("pbjs_modules"), Ej(b, this.context), L(b, "pbmods", a.installedModules.join("~")), al(b))
        }
    };
    var iL = function(a, b) {
        Z.call(this, a, 966);
        this.F = b;
        this.tb = V(this)
    };
    _.P(iL, Z);
    iL.prototype.j = function() {
        var a = this,
            b = uh(this.F);
        if (b) this.tb.J(b);
        else if ((b = Object.getOwnPropertyDescriptor(this.F, "_pbjsGlobals")) && !b.configurable) yj("pdpg_error", function(d) {
            Ej(d, a.context)
        }, _.If(wy));
        else {
            var c = null;
            Object.defineProperty(this.F, "_pbjsGlobals", {
                set: function(d) {
                    c = d;
                    (d = uh(a.F)) && a.tb.J(d)
                },
                get: function() {
                    return c
                }
            })
        }
    };
    iL.prototype.m = function() {};
    var Pn = function(a, b, c, d) {
        Z.call(this, a, 879);
        this.A = b;
        this.l = V(this);
        c && (this.D = X(this, d))
    };
    _.P(Pn, Z);
    Pn.prototype.j = function() {
        var a, b;
        (null != (b = null == (a = this.D) ? void 0 : a.value) ? b : aB(this.A)) ? (a = bB(this.A), this.l.lb(a)) : LB(this.l)
    };
    var On = function(a, b, c) {
        Z.call(this, a, 896);
        this.l = b;
        this.Ub = V(this);
        c && $B(this, c)
    };
    _.P(On, Z);
    On.prototype.j = function() {
        this.Ub.J(aB(this.l))
    };
    var jL = function(a, b) {
        Z.call(this, a, 1018);
        this.td = YB(this);
        this.l = Y(this, b)
    };
    _.P(jL, Z);
    jL.prototype.j = function() {
        var a, b, c, d = _.x(null != (c = null == (a = this.l.value) ? void 0 : null == (b = Df(a, XA, 5)) ? void 0 : Yc(b, 1, Cc)) ? c : []);
        for (a = d.next(); !a.done; a = d.next()) pf(a.value);
        this.td.notify()
    };
    var kL = function(a, b) {
        Z.call(this, a, 1070);
        this.l = V(this);
        this.A = Y(this, b)
    };
    _.P(kL, Z);
    kL.prototype.j = function() {
        var a, b = null == (a = this.A.value) ? void 0 : Df(a, XA, 5);
        if (b) {
            a = [];
            for (var c = _.x(Yc(b, 2, Fc)), d = c.next(); !d.done; d = c.next()) {
                var e = d.value;
                d = new Ov;
                var f = new Mv;
                e = _.z(f, 1, e);
                d = _.Uh(d, 2, e);
                null != Un(b, 3) && (e = new Kv, e = _.z(e, 1, 1), e = _.z(e, 2, Se(b, 3)), _.Uh(d, 3, e));
                a.push(d)
            }
            this.l.J(a)
        } else this.l.J([])
    };
    var lL = function(a, b, c, d) {
        Z.call(this, a, 1016);
        this.C = V(this);
        this.A = Y(this, b);
        this.l = Y(this, c);
        this.D = bC(this, [b, d])
    };
    _.P(lL, Z);
    lL.prototype.j = function() {
        if (this.l.value) {
            var a = this.A.value || this.D.value;
            a && mL(this, a) ? this.C.J(a) : (LB(this.C), nL(this, a))
        } else LB(this.C)
    };
    lL.prototype.I = function(a) {
        this.m(a)
    };
    lL.prototype.m = function() {
        LB(this.C)
    };
    var mL = function(a, b) {
            return Pe((0, B.K)(a.l.value), Hv, 1).some(function(c) {
                return _.Rf(c, 1) === b
            })
        },
        nL = function(a, b) {
            yj("pp_iris_failure", function(c) {
                L(c, "fnc", b);
                Ej(c, a.context)
            }, _.If(bz))
        };
    var oL = function(a, b) {
        Z.call(this, a, 1015);
        this.l = V(this);
        this.A = Y(this, b)
    };
    _.P(oL, Z);
    oL.prototype.j = function() {
        if (this.A.value)
            if (Pe(this.A.value, Hv, 1).length) {
                var a = Pe(this.A.value, Hv, 1)[0];
                (_.C = [2, 3], _.u(_.C, "includes")).call(_.C, _.Re(a, 3, 0)) ? this.l.J(_.Rf(a, 1)) : LB(this.l)
            } else LB(this.l);
        else LB(this.l)
    };
    oL.prototype.I = function(a) {
        this.m(a)
    };
    oL.prototype.m = function() {
        LB(this.l)
    };
    var pL = function(a, b, c) {
        Z.call(this, a, 1017);
        this.F = c;
        this.C = YB(this);
        this.l = Y(this, b)
    };
    _.P(pL, Z);
    pL.prototype.j = function() {
        var a = this;
        if (this.l.value) {
            var b = uA(this.F, this.l.value, function(c) {
                if (!c) {
                    c = dx(b.j);
                    for (var d = _.x(document.getElementsByName("googlefcPresent")), e = d.next(); !e.done; e = d.next()) c.og(e.value)
                }
                a.C.notify()
            });
            b.start()
        } else this.C.notify()
    };
    pL.prototype.I = function(a) {
        this.m(a)
    };
    pL.prototype.m = function() {
        this.C.notify()
    };
    var qL = function(a, b) {
        Z.call(this, a, 1056);
        this.C = V(this);
        this.l = X(this, b)
    };
    _.P(qL, Z);
    qL.prototype.j = function() {
        var a = Oh((0, B.K)(this.l.value.getAdUnitPath()));
        this.C.J(a)
    };
    qL.prototype.I = function(a) {
        this.m(a)
    };
    qL.prototype.m = function() {
        LB(this.C)
    };
    var rL = function() {
        Z.apply(this, arguments);
        this.value = this.promise = null;
        this.C = V(this)
    };
    _.P(rL, Z);
    rL.prototype.j = function() {
        var a = this;
        this.promise.then(function() {
            return void KB(a.C, a.value)
        })
    };
    var Ko = function(a, b, c, d) {
        rL.call(this, a, 1061);
        var e = this;
        this.promise = rI(b, c, function(f) {
            return null !== (e.value = d(f))
        })
    };
    _.P(Ko, rL);
    var sL = function(a, b, c, d) {
        Z.call(this, a, 906, _.If($y));
        this.l = YB(this);
        if (b === b.top) {
            var e = new hg;
            _.Nn(this, e);
            var f = new oL(a, c);
            H(e, f);
            d = new Ko(a, d, vI, function(g) {
                return g.detail.V
            });
            H(e, d);
            d = new qL(a, d.C);
            H(e, d);
            a = new lL(a, f.l, c, d.C);
            H(e, a);
            b = new pL(this.context, a.C, b);
            H(e, b);
            aC(this, b.C);
            sg(e)
        } else this.l.notify()
    };
    _.P(sL, Z);
    sL.prototype.j = function() {
        this.l.notify()
    };
    sL.prototype.I = function(a) {
        this.m(a)
    };
    sL.prototype.m = function() {
        this.l.notify()
    };
    var tL = function(a, b) {
        Z.call(this, a, 1052);
        this.A = V(this);
        this.l = V(this);
        this.D = Y(this, b)
    };
    _.P(tL, Z);
    tL.prototype.j = function() {
        var a = this.D.value,
            b = new Bv,
            c = new _.v.Map;
        if (a) {
            var d = new _.v.Set;
            a = _.x(a);
            for (var e = a.next(); !e.done; e = a.next()) {
                var f = e.value;
                if (_.bg(f, 1)) {
                    e = new _.v.Set;
                    c.set(_.Rf(f, 1).toString(), e);
                    f = _.x(f.m());
                    for (var g = f.next(); !g.done; g = f.next()) {
                        g = g.value;
                        var h = (0, B.K)(g.m());
                        e.add(h);
                        d.has(h) || _.Xf(b, 2, zv, g);
                        d.add(h)
                    }
                }
            }
        }
        this.A.J(c);
        this.l.J(b)
    };
    var Nq = function(a, b, c, d, e) {
        Z.call(this, a, 813);
        this.D = b;
        this.ke = c;
        this.Gb = e;
        this.A = V(this);
        d && (this.G = Y(this, d));
        this.l = Y(this, e)
    };
    _.P(Nq, Z);
    Nq.prototype.j = function() {
        var a = this,
            b, c, d = null != (c = this.ke) ? c : null == (b = this.G) ? void 0 : b.value;
        if (d && d.length && this.l.value && !_.E(Bz)) {
            b = _.x(d);
            for (c = b.next(); !c.done; c = b.next()) d = c.value, c = d.jd, (d = d.url) && _.Nn(this, Xg(c, d, this.l.value, this.Gb, function(e, f) {
                di(a.context, e, f);
                var g, h;
                null == (g = a.D) || null == (h = g.error) || h.call(g, f)
            }));
            this.A.J(!0)
        } else this.A.J(!1)
    };
    var uL = function(a, b) {
        Z.call(this, a, 1040);
        this.l = V(this);
        this.A = Y(this, b)
    };
    _.P(uL, Z);
    uL.prototype.j = function() {
        var a = this.A.value;
        a ? (a = a.m(), this.l.J(a.map(function(b) {
            var c = b.H();
            b = b.m();
            c = c && (_.u(c, "startsWith").call(c, location.protocol) || _.u(c, "startsWith").call(c, "data:") && 80 >= c.length) ? re(null === c ? "null" : void 0 === c ? "undefined" : c) : void 0;
            return {
                jd: b,
                url: c
            }
        }))) : this.l.J([])
    };
    var vL = function(a, b, c) {
        Z.call(this, a, 1045);
        this.Gb = c;
        this.l = X(this, b)
    };
    _.P(vL, Z);
    vL.prototype.j = function() {
        var a = this.l.value;
        if (a) {
            var b = this.context,
                c = this.Gb;
            if (_.E(hz) || _.bg(a, 1)) {
                var d = new hg,
                    e = new Lq;
                e.J(a);
                a = new uL(b, e);
                H(d, a);
                b = new Nq(b, console, void 0, a.l, c);
                H(d, b);
                sg(d)
            }
        }
    };
    var wL = function(a, b, c) {
        Z.call(this, a, 1051);
        this.A = b;
        this.l = Y(this, c)
    };
    _.P(wL, Z);
    wL.prototype.j = function() {
        var a = this;
        this.l.value && Tg(this.l.value, function(b, c) {
            di(a.context, b, c);
            var d, e;
            null == (d = a.A) || null == (e = d.error) || e.call(d, c)
        })
    };
    var Mq = function(a, b, c) {
        Z.call(this, a, 706);
        this.F = b;
        this.C = V(this);
        this.l = X(this, c)
    };
    _.P(Mq, Z);
    Mq.prototype.j = function() {
        KB(this.C, cf(this.l.value, this.F))
    };
    var xL = function(a, b, c, d, e, f) {
        Z.call(this, a, 1096);
        this.networkCode = b;
        this.F = c;
        this.X = d;
        this.Ga = e;
        this.l = Y(this, f)
    };
    _.P(xL, Z);
    xL.prototype.j = function() {
        var a, b = null == (a = this.l.value) ? void 0 : a.sg;
        b && b(this.Ga, this.X, this.F, this.networkCode)
    };
    var yL = function(a) {
        this.module = a
    };
    yL.prototype.toString = function() {
        return String(this.module)
    };
    _.zL = new yL(2);
    _.AL = new yL(5);
    var BL = function(a, b) {
        Z.call(this, a, 1095);
        this.l = b;
        this.C = V(this)
    };
    _.P(BL, Z);
    BL.prototype.j = function() {
        this.C.lb(this.l.load(_.AL))
    };
    var CL = function(a, b, c, d) {
        Z.call(this, a, 1090);
        this.l = b;
        this.A = X(this, c);
        this.D = Y(this, d)
    };
    _.P(CL, Z);
    CL.prototype.j = function() {
        var a = this.D.value,
            b;
        if (a && null != (b = Df(a, Yv, 1)) && _.Zv(b).length) {
            b = new hg;
            _.Nn(this, b);
            var c = new BL(this.context, this.l);
            H(b, c);
            a = new xL(this.context, "", window, this.A.value, (0, B.K)(Df(a, Yv, 1)), c.C);
            H(b, a);
            sg(b)
        }
    };
    var DL = function(a, b) {
        Z.call(this, a, 1081);
        this.qb = V(this);
        this.l = Y(this, b)
    };
    _.P(DL, Z);
    DL.prototype.j = function() {
        this.l.value ? this.qb.J(this.l.value) : LB(this.qb)
    };
    var EL = function(a, b, c, d, e, f, g) {
        Z.call(this, a, 1080);
        this.W = b;
        this.googletag = c;
        this.U = d;
        this.D = e;
        this.l = f;
        this.G = g;
        this.A = V(this)
    };
    _.P(EL, Z);
    EL.prototype.j = function() {
        var a;
        if (a = to(this.l, Sv, 2)) a = (0, B.K)(Df(this.l, Sv, 2)), a = Vn(a) && Xn(a);
        if (a) {
            var b;
            bo(this.W, this.googletag, this.l, null != (b = this.U) ? b : this.D.j, this.G);
            null != Un(this.l, 1) ? this.A.J(Se(this.l, 1)) : LB(this.A)
        } else LB(this.A)
    };
    var FL = function(a, b, c, d, e, f, g) {
        Z.call(this, a, 1109);
        this.W = c;
        this.U = d;
        this.l = e;
        this.D = f;
        this.A = g;
        this.C = V(this);
        this.G = Y(this, b)
    };
    _.P(FL, Z);
    FL.prototype.j = function() {
        var a = this,
            b = this.G.value;
        b && (this.A.push(function() {
            b.addService(a.l)
        }), ao(this.W, function() {
            a.D(b);
            K(a.U, 4) && a.l.refresh([b])
        }))
    };
    var GL = function(a, b, c, d, e, f) {
        Z.call(this, a, 1108);
        this.adUnitPath = b;
        this.format = c;
        this.La = d;
        this.D = e;
        this.A = f;
        this.C = V(this);
        this.l = V(this)
    };
    _.P(GL, Z);
    GL.prototype.j = function() {
        var a = fo(this.context, this.A, this.D, {
            ge: this.format,
            adUnitPath: this.adUnitPath,
            La: this.La
        });
        KB(this.l, a);
        KB(this.C, a ? (0, B.K)(a.pa) : null)
    };
    var HL = function(a, b, c, d, e, f, g, h, k, l, n) {
        hg.call(this);
        this.context = a;
        this.W = b;
        this.adUnitPath = c;
        this.format = d;
        this.La = e;
        this.G = f;
        this.D = g;
        this.N = h;
        this.U = k;
        this.L = l;
        this.R = n;
        a = H(this, new GL(this.context, this.adUnitPath, this.format, this.La, this.L, this.R));
        H(this, new FL(this.context, a.C, this.W, this.U, this.G, this.D, this.N));
        this.j = {
            pa: a.C,
            hk: a.l
        }
    };
    _.P(HL, hg);
    var IL = new _.v.Map([
            [1, 5],
            [2, 2],
            [3, 3]
        ]),
        JL = function(a, b, c, d, e, f, g, h, k) {
            Z.call(this, a, 1079);
            this.W = b;
            this.googletag = c;
            this.U = d;
            this.G = e;
            this.l = f;
            this.A = g;
            this.L = h;
            this.D = k;
            this.O = V(this)
        };
    _.P(JL, Z);
    JL.prototype.j = function() {
        var a = this,
            b = this.L.getAdUnitPath(),
            c = IL.get(_.Re(this.L, 2, 0));
        if (b && c)
            if (_.E(ez)) {
                var d, e = null != (d = this.U) ? d : this.l.j;
                b = new HL(this.context, this.W, b, c, !0, this.googletag.pubads(), this.googletag.display, this.googletag.cmd, e, this.G, this.A);
                _.Nn(this, b);
                sg(b);
                this.O.lb(b.m.promise)
            } else if (b = fo(this.context, this.A, this.G, {
                ge: c,
                adUnitPath: b,
                La: !0
            })) {
            var f = (0, B.K)(b.pa);
            this.D && $n((0, B.K)(Zn(this.l, f.getSlotElementId())), this.D);
            this.googletag.cmd.push(function() {
                f.addService(a.googletag.pubads())
            });
            ao(this.W, function() {
                a.googletag.display(f);
                var g;
                K(null != (g = a.U) ? g : a.l.j, 4) && a.googletag.pubads().refresh([f])
            })
        }
    };
    var KL = function(a, b, c, d) {
        Z.call(this, a, 1111);
        this.l = c;
        this.A = d;
        this.D = X(this, b)
    };
    _.P(KL, Z);
    KL.prototype.j = function() {
        var a = this.D.value.pa;
        a && $n((0, B.K)(Zn(this.l, a.getSlotElementId())), this.A)
    };
    var yr = function(a, b, c, d, e, f, g) {
        Z.call(this, a, 1082);
        this.googletag = b;
        this.U = c;
        this.T = d;
        this.l = e;
        this.O = f;
        this.L = [];
        this.G = V(this);
        this.D = new DL(this.context, this.G);
        this.A = [];
        this.qb = this.D.qb;
        _.Nn(this, this.D);
        a = _.x(g);
        for (b = a.next(); !b.done; b = a.next()) this.A.push(X(this, b.value))
    };
    _.P(yr, Z);
    yr.prototype.j = function() {
        if (_.E(dz)) {
            var a = LL(this),
                b = a.qg,
                c = a.Yh,
                d;
            KB(this.G, null == (d = a.mh) ? void 0 : Df(d, Ov, 4));
            a = new hg;
            _.Nn(this, a);
            b = _.x(b);
            for (d = b.next(); !d.done; d = b.next()) {
                d = d.value;
                var e = Df(d, Ov, 4),
                    f = void 0,
                    g = H(a, new JL(this.context, document, this.googletag, null != (f = this.U) ? f : this.l.j, this.T, this.l, this.O, (0, B.K)(Df(d, Qv, Tf(d, bw, 5))), e));
                e && _.E(ez) && H(a, new KL(this.context, g.O, rj(), e))
            }
            c = _.x(c);
            for (d = c.next(); !d.done; d = c.next()) b = d.value, b = new EL(this.context, document, this.googletag, this.U, this.l, (0, B.K)(Df(b, Uv, Tf(b, bw, 6))), Df(b, Ov, 4)), H(a, b), this.L.push(b.A);
            H(a, this.D);
            sg(a)
        } else LB(this.qb)
    };
    var LL = function(a) {
        var b = [],
            c = [];
        a = _.x(_.u(a.A, "flatMap").call(a.A, function(f) {
            return f.value
        }));
        for (var d = a.next(); !d.done; d = a.next()) switch (d = d.value, ik(d, bw)) {
            case 5:
                b.push(d);
                break;
            case 6:
                c.push(d);
                break;
            case 8:
                var e = d
        }
        return {
            qg: b,
            Yh: c,
            mh: e
        }
    };
    var ML = function(a, b, c, d, e, f, g, h) {
        _.U.call(this);
        this.context = a;
        this.la = b;
        this.ka = c;
        this.L = d;
        this.M = e;
        this.O = f;
        this.T = g;
        this.Y = h;
        this.G = new $K(this.context, this.O);
        this.m = new XK(this.context, this.G.l);
        this.j = new UK(this.context, this.m.l, window);
        this.B = new aL(this.context, this.j.A);
        this.l = new bL(this.context, this.j.D);
        var k;
        this.R = new ZK(this.context, null != (k = window.location.hash) ? k : "");
        this.D = new yr(this.context, Tk(), null, this.la, this.ka, this.L, [this.R.C, this.m.Kc]);
        this.I = new iL(this.context, window);
        this.A = new WK(this.context, this.T, this.j.zb, this.m.A, this.j.l, this.D.L);
        this.N = new gL(this.context, this.I.tb, this.A.C, this.B.Rb, this.j.Qb, this.B.ac, this.l.A, this.l.l, this.j.uc);
        _.Nn(this, this.I);
        _.Nn(this, this.G);
        _.Nn(this, this.m);
        _.Nn(this, this.B);
        _.Nn(this, this.l);
        _.Nn(this, this.j);
        _.Nn(this, this.R);
        _.Nn(this, this.D);
        _.Nn(this, this.N);
        _.Nn(this, this.A)
    };
    _.P(ML, _.U);
    var NL = function(a, b) {
        var c = new hg;
        _.Nn(a, c);
        H(c, a.I);
        H(c, a.G);
        H(c, a.m);
        H(c, a.j);
        H(c, a.B);
        H(c, a.A);
        H(c, a.l);
        b = new sL(a.context, window, a.m.D, b);
        H(c, b);
        H(c, a.R);
        H(c, a.D);
        H(c, new hL(a.context, a.I.tb, a.j.zb));
        H(c, a.N);
        var d = {
                tb: a.I.tb,
                zb: a.j.zb,
                Rb: a.B.Rb,
                Qb: a.j.Qb,
                ac: a.B.ac,
                Gd: a.N.Gd,
                Hd: a.N.Hd,
                wg: a.l.l,
                uc: a.j.uc
            },
            e = Qn(a.context, a.O, b.l),
            f = e.Ub,
            g = e.pf;
        _.Nn(c, e.zc);
        e = new jL(a.context, g);
        H(c, e);
        var h = new kL(a.context, g);
        H(c, h);
        g = An(a.context, a.L, a.M, void 0, window, f, g);
        f = g.ob;
        _.Nn(a, g.zc);
        if (!_.E(Bz) && !Ml()) {
            var k = a.context;
            Tk();
            var l = a.m.Sb;
            var n = window;
            g = new hg;
            var m = new Mq(k, n, f);
            n = m.C;
            H(g, m);
            l = new tL(k, l);
            H(g, l);
            H(g, new vL(k, l.l, n));
            _.E(Dz) && (k = new wL(k, console, n), H(g, k));
            sg(g);
            k = l.A;
            _.Nn(a, g)
        }
        l = a.context;
        m = a.Y;
        var p = a.m.G;
        g = new hg;
        f = new CL(l, m, f, p);
        H(g, f);
        sg(g);
        _.Nn(a, g);
        sg(c);
        return {
            Ye: d,
            Kh: b.l,
            Gg: a.A.C,
            Jh: k,
            qb: a.D.qb,
            Sb: a.m.Sb,
            td: e.td,
            fh: h.l,
            Gb: n
        }
    };
    var OL = function(a, b, c) {
        Z.call(this, a, 1103);
        this.l = b;
        this.X = c;
        this.C = V(this)
    };
    _.P(OL, Z);
    OL.prototype.j = function() {
        this.C.J(!!bf(this.X) && !K(this.X, 9) && (this.l ? K(this.l, 9) || K(this.l, 8) || K(this.l, 1) || _.E(cz) && K(this.l, 13) || 1 === _.Re(this.l, 6, 2) || 1 === y(this.l, 5) ? !1 : !0 : !0))
    };
    var PL = ["Debug", "Info", "Warning", "Error", "Fatal"],
        QL = function(a, b, c) {
            this.level = a;
            this.message = b;
            this.pa = c;
            this.timestamp = new Date
        };
    _.aa = QL.prototype;
    _.aa.getSlot = function() {
        return this.pa
    };
    _.aa.getLevel = function() {
        return this.level
    };
    _.aa.getTimestamp = function() {
        return this.timestamp
    };
    _.aa.getMessage = function() {
        return this.message
    };
    _.aa.toString = function() {
        return this.timestamp.toTimeString() + ": " + PL[this.level] + ": " + this.message
    };
    var RL = {
            20: function(a) {
                return "Ignoring a call to setCollapseEmptyDiv(false, true). Slots that start out collapsed should also collapse when empty. Slot: " + a[0] + "."
            },
            23: function(a) {
                return 'Error in googletag.display: could not find div with id "' + a[1] + '" in DOM for slot: ' + a[0] + "."
            },
            34: function(a) {
                return "Size mapping is null because invalid mappings were added: " + a[0] + "."
            },
            60: function(a) {
                return "Ignoring the " + a[0] + "(" + (a[1] || "") + ") call since the service is already enabled."
            },
            66: function(a) {
                return "Slot " + a[0] + " cannot be refreshed until PubAdsService is enabled."
            },
            68: function() {
                return "Slots cannot be cleared until service is enabled."
            },
            80: function(a) {
                return "Slot object at position " + a[0] + " is of incorrect type."
            },
            84: function(a) {
                return 'Cannot find targeting attribute "' + a[0] + '" for "' + a[1] + '".'
            },
            93: function(a) {
                return "Failed to register listener. Unknown event type: " + a[0] + "."
            },
            96: function(a) {
                return "Invalid arguments: " + a[0] + "(" + a[1] + ")."
            },
            122: function(a) {
                return "Invalid argument: " + a[0] + "(" + a[1] + "). Valid values: " + a[2] + "."
            },
            121: function(a) {
                return "Invalid object passed to " + a[0] + "(" + a[1] + "), for " + a[2] + ": " + a[3] + "."
            },
            151: function(a) {
                return "Invalid arguments: " + a[0] + "(" + a[1] + "). All zero-area slot sizes were removed."
            },
            105: function(a) {
                return "SRA requests may include a maximum of 30 ad slots. " + a[1] + " were requested, so the last " + a[2] + " were ignored."
            },
            106: function(a) {
                return "Publisher betas " + a[0] + " were declared after enableServices() was called."
            },
            107: function(a) {
                return "Publisher betas may only be declared once. " + a[0] + " were added after betas had already been declared."
            },
            108: function(a) {
                return "Beta keys cannot be cleared. clearTargeting() was called on " + a[0] + "."
            },
            123: function(a) {
                return "Refresh was throttled for slot: " + a[0] + "."
            },
            113: function(a) {
                return a[0] + " ad slot ineligible as page is not mobile optimized: " + a[1] + "."
            },
            116: function(a) {
                return 'The unique SafeFrame domain setting in Google Ad Manager conflicts with the "useUniqueDomain" setting passed to the setSafeFrameConfig API method. GPT will use useUniqueDomain=' + a[0] + " based on the API call."
            },
            114: function() {
                return 'setCorrelator has been deprecated. See the Google Ad Manager help page on "Creative selection for multiple ad slots" for more information: https://support.google.com/admanager/answer/183281.'
            },
            115: function() {
                return 'updateCorrelator has been deprecated. See the Google Ad Manager help page on "Creative selection for multiple ad slots" for more information: https://support.google.com/admanager/answer/183281.'
            },
            132: function(a) {
                return "Taxonomy with id " + a[0] + " has reached the limit of " + a[1] + " values."
            },
            133: function() {
                return "No taxonomy values were cleared, either due to an invalid taxonomy or no values present."
            },
            134: function(a) {
                return ho(a[0]) + " " + a[1] + " not requested: Format already created on the page."
            },
            135: function(a) {
                return ho(a[0]) + " " + a[1] + " not requested: Frequency cap of 1 has been exceeded."
            },
            136: function(a) {
                return ho(a[0]) + " " + a[1] + " not requested: The viewport exceeds the current maximum width of 2500px."
            },
            137: function(a) {
                return ho(a[0]) + " " + a[1] + " not requested: Format currently only supported on mobile."
            },
            138: function(a) {
                return ho(a[0]) + " " + a[1] + " not requested: Format currently only supports portrait orientation."
            },
            139: function(a) {
                return ho(a[0]) + " " + a[1] + " not requested: GPT is not running in the top-level window."
            },
            140: function(a) {
                return ho(a[0]) + " " + a[1] + " not requested: Detected browser is currently unsupported."
            },
            142: function(a) {
                return "A google product ad tag with click url " + a[0] + " does not contain any elements enabled for clicking."
            },
            145: function(a) {
                return ho(a[0]) + " " + a[1] + " not requested: Unable to access local storage to determine if the frequency cap has been exceeded due to insufficient user consent."
            },
            143: function() {
                return "getName on googletag.Slot is deprecated and will be removed. Use getAdUnitPath instead."
            },
            147: function() {
                return "GPT must be loaded from the limited ads URL to enable limited ads functionality."
            },
            148: function() {
                return "CommerceAdsConfig must contain a valid value for either categories or queries."
            },
            150: function() {
                return "Legacy browser does not support intersection observer causing lazy render/fetch as well as viewability events not to work properly."
            }
        },
        SL = {
            26: function(a) {
                return "Div ID passed to googletag.display() does not match any defined slots: " + a[0] + "."
            },
            28: function(a) {
                return "Error in googletag.defineSlot: Cannot create slot " + a[1] + '. Div element "' + a[0] + '" is already associated with another slot: ' + a[2] + "."
            },
            149: function(a) {
                return "Error in googletag.defineSlot: Invalid ad unit path provided " + a[0] + ", see https://support.google.com/admanager/answer/10477476 for more information."
            },
            92: function(a) {
                return "Exception in " + a[1] + ' event listener: "' + a[0] + '".'
            },
            30: function(a) {
                return "Exception in googletag.cmd function: " + a[0] + "."
            },
            125: function(a) {
                return "google-product-ad element is invalid: " + a[0] + "."
            },
            126: function() {
                return "Attempted to collect prebid data but window.pbjs is undefined."
            },
            127: function(a) {
                return "Encountered the following error while attempting to collect prebid metadata: " + a[0] + "."
            },
            144: function() {
                return "ContentService is no longer available. Use the browser's built-in DOM APIs to directly add content to div elements instead."
            }
        };
    var TL = function(a) {
            this.context = a;
            this.m = this.H = this.j = 0;
            this.B = window;
            this.o = [];
            this.o.length = 1E3
        },
        iK = function(a) {
            return [].concat(_.ue(a.o.slice(a.j)), _.ue(a.o.slice(0, a.j))).filter(function(b) {
                return !!b
            })
        },
        jK = function(a, b) {
            return iK(a).filter(function(c) {
                return c.getSlot() === b
            })
        },
        kK = function(a, b) {
            return iK(a).filter(function(c) {
                return c.getLevel() >= b
            })
        };
    TL.prototype.log = function(a, b, c, d) {
        var e = this;
        d = void 0 === d ? !1 : d;
        var f, g;
        c = new QL(a, b, null != (g = null == (f = void 0 === c ? null : c) ? void 0 : f.pa) ? g : null);
        this.o[this.j] = c;
        this.j = (this.j + 1) % 1E3;
        g = _.If(Gy) && 100 > this.H;
        f = 2 === a || 3 === a;
        var h = b.getMessageArgs(),
            k = b.getMessageId(),
            l = RL[k] || SL[k];
        g && f && (b = _.If(Gy), yj("gpt_eventlog_messages", function(n) {
            ++e.H;
            Ej(n, e.context);
            L(n, "level", a);
            L(n, "messageId", k);
            L(n, "args", h.join("|"));
            l || L(n, "noMsg", !0);
            var m = Error(),
                p;
            L(n, "stack", _.vB(null != (p = m.stack) ? p : "", m.message))
        }, b));
        if (l) {
            b = "[GPT] " + l(h);
            if (d) throw new tm(b);
            d = this.m < _.If(Hy) && f && _.q.console;
            if (this.B === top && d || _.u(_.q.navigator.userAgent, "includes").call(_.q.navigator.userAgent, "Lighthouse"))(function(n) {
                var m, p, r, t;
                return void(2 === a ? null == (p = (m = _.q.console).warn) ? void 0 : p.call(m, n) : null == (t = (r = _.q.console).error) ? void 0 : t.call(r, n))
            })(b), this.m++
        }
        return c
    };
    TL.prototype.info = function(a, b) {
        return this.log(1, a, void 0 === b ? null : b)
    };
    var N = function(a, b, c) {
        a.log(2, b, c, !1)
    };
    TL.prototype.error = function(a, b, c) {
        return this.log(3, a, b, void 0 === c ? !1 : c)
    };
    var UL = function() {
            var a = this;
            var b = void 0 === b ? rj().j : b;
            this.H = "";
            this.j = this.storage = null;
            this.B = this.l = this.m = !1;
            this.o = function() {
                return !1
            };
            var c = {},
                d = {},
                e = {};
            this.I = (e[3] = (c[13] = function() {
                return _.wb.apply(0, arguments).some(function(f) {
                    return 0 == a.H.lastIndexOf(f, 0)
                })
            }, c[12] = function() {
                return !!K(b, 6)
            }, c[15] = function(f) {
                return a.o(f)
            }, c[48] = function() {
                return !!a.storage
            }, c[51] = function() {
                return a.m
            }, c[66] = function() {
                try {
                    return !!HTMLScriptElement.supports("webbundle")
                } catch (f) {
                    return !1
                }
            }, c[67] = function() {
                return a.l
            }, c[68] = function() {
                return a.B
            }, c), e[4] = (d[8] = function(f) {
                var g;
                return null != (g = We(a.storage, Number(f))) ? g : void 0
            }, d[10] = function(f) {
                return a.j ? _.Ni(f + a.j) % 1E3 : void 0
            }, d), e[5] = {}, e)
        },
        VL = function(a, b) {
            b && !a.j && (a.j = _.u(b.split(":"), "find").call(b.split(":"), function(c) {
                return 0 === c.indexOf("ID=")
            }) || null)
        };
    var WL = /(<head(\s+[^>]*)?>)/i,
        Qq = function(a, b, c, d, e) {
            Z.call(this, a, 665);
            this.C = V(this);
            this.l = X(this, b);
            this.D = Y(this, c);
            this.G = X(this, d);
            this.A = X(this, e)
        };
    _.P(Qq, Z);
    Qq.prototype.j = function() {
        var a;
        0 === this.l.value.kind && null != (a = this.D.value) && y(a, 1) ? (a = this.l.value.Ya, this.A.value || Va() || (a = a.replace(WL, "$1<meta http-equiv=Content-Security-Policy content=\"script-src https://cdn.ampproject.org/;object-src 'none';child-src blob:;frame-src 'none'\">")), this.G.value && !this.A.value && (a = a.replace(WL, '$1<meta name="referrer" content="origin">')), this.C.J({
            kind: 0,
            Ya: a
        })) : this.C.J(this.l.value)
    };
    var wr = function(a, b, c, d, e, f, g, h) {
        Z.call(this, a, 718);
        this.D = Y(this, c);
        this.l = Y(this, d);
        $B(this, e);
        this.G = X(this, f);
        this.A = X(this, g);
        this.O = X(this, h);
        this.L = rI(b, xI)
    };
    _.P(wr, Z);
    wr.prototype.j = function() {
        var a = this,
            b, c, d;
        return _.Ab(function(e) {
            if (1 == e.j) {
                var f = !a.O.value;
                if (null == a.l.value || "height" !== a.D.value || f) return e.return();
                b = a.G.value;
                c = a.A.value;
                XL(c, !1);
                _.Wx(c, "min-width", "100%");
                _.Wx(b, "min-width", "100%");
                return Bb(e, a.L, 2)
            }
            if (a.H) return e.return();
            d = b.contentDocument;
            if (!d) return e.return();
            f = d.body.offsetWidth;
            b.setAttribute("height", String(d.body.offsetHeight));
            b.setAttribute("width", String(f));
            XL(c, !0);
            e.j = 0
        })
    };
    var XL = function(a, b) {
        _.Wx(a, "visibility", b ? "visible" : "hidden")
    };
    var fr = function(a, b, c, d, e, f, g, h, k, l, n, m, p) {
        Z.call(this, a, 699);
        this.W = b;
        this.slotId = c;
        this.l = d;
        this.lc = e;
        this.C = YB(this);
        this.L = Y(this, f);
        this.T = X(this, g);
        this.D = X(this, h);
        this.O = X(this, k);
        this.A = Y(this, l);
        this.Y = X(this, n);
        this.G = X(this, m);
        p && $B(this, p)
    };
    _.P(fr, Z);
    fr.prototype.j = function() {
        var a = this.T.value,
            b = this.D.value;
        b.style.width = "";
        b.style.height = "";
        if ("height" !== this.L.value) {
            var c, d = null != (c = this.A.value) ? c : 0;
            c = this.O.value;
            var e = this.Y.value,
                f = this.G.value,
                g = !1;
            switch (d) {
                case 1:
                case 2:
                    g = this.context;
                    var h = this.W,
                        k = this.slotId,
                        l = this.l,
                        n = this.lc;
                    var m = c.width,
                        p = c.height,
                        r = 0;
                    var t = 0;
                    var w = Li(l);
                    w = _.x(w);
                    for (var D = w.next(); !D.done; D = w.next()) {
                        var G = D.value;
                        Array.isArray(G) && (D = (0, B.va)(G[0]), G = (0, B.va)(G[1]), r < D && (r = D), t < G && (t = G))
                    }
                    t = [r, t];
                    r = t[0] < m;
                    p = t[1] < p;
                    if (r || p) {
                        t = m + "px";
                        w = {
                            "max-height": "none",
                            "max-width": t,
                            padding: "0px",
                            width: t
                        };
                        p && (w.height = "auto");
                        uj(b, a, w);
                        b = {};
                        r && (r = sj(e.width), m > r && (b.width = t, b["max-width"] = t));
                        p && (b.height = "auto", b["max-height"] = "none");
                        c: {
                            for (F in b)
                                if (Object.prototype.hasOwnProperty.call(b, F)) {
                                    var F = !1;
                                    break c
                                }
                            F = !0
                        }
                        F ? b = !1 : (b["padding-" + ("ltr" === e.direction ? "left" : "right")] = "0px", _.tj(a, b), b = !0)
                    } else b = !1;
                    b: switch (t = c.width, F = h.defaultView || h.parentWindow || _.q, d) {
                        case 2:
                            a = vj(a, F, t, e, n);
                            break b;
                        case 1:
                            if (e = a.parentElement)
                                if (n = Zi(e)) {
                                    D = n.width;
                                    n = hj(k, F.document);
                                    m = (0, B.K)(jj(n, F));
                                    p = m.position;
                                    G = sj(m.width) || 0;
                                    r = jj(e, F);
                                    w = "rtl" === r.direction ? "Right" : "Left";
                                    n = w.toLowerCase();
                                    F = "absolute" === p ? 0 : sj(r["padding" + w]);
                                    r = sj(r["border" + w + "Width"]);
                                    t = Math.max(Math.round((D - Math.max(G, t)) / 2), 0);
                                    D = {};
                                    G = 0;
                                    var O = Fx(m);
                                    O && (G = O[4] * ("Right" === w ? -1 : 1), w = O[3] || 1, 1 !== (O[0] || 1) || 1 !== w) && (O[0] = 1, O[3] = 1, D.transform = "matrix(" + O.join(",") + ")");
                                    w = 0;
                                    switch (p) {
                                        case "fixed":
                                            var I, Q = null != (I = Number(kj(m.getPropertyValue(n)))) ? I : 0,
                                                S;
                                            I = null != (S = e.getBoundingClientRect().left) ? S : 0;
                                            w = Q - I;
                                            break;
                                        case "relative":
                                            w = null != (Q = Number(kj(m.getPropertyValue(n)))) ? Q : 0;
                                            break;
                                        case "absolute":
                                            D[n] = "0"
                                    }
                                    D["margin-" + n] = t - F - r - w - G + "px";
                                    _.tj(a, D);
                                    a = !0
                                } else a = !1;
                            else a = !1;
                            break b;
                        default:
                            a = !1
                    }
                    b || a ? (xj(g, h, k, l, d, c.width, c.height, "gpt_slotexp", f), g = !0) : g = !1;
                    break;
                case 3:
                    d = this.context, g = this.W, h = this.slotId, k = this.l, I = this.lc, l = c.width, S = c.height, Q = sj(e.height) || 0, S >= Q || "none" === e.display || "hidden" === e.visibility || !I || -12245933 === I.width || a.getBoundingClientRect().bottom <= I.height ? g = !1 : (I = {
                        height: S + "px"
                    }, uj(b, a, I), _.tj(a, I), xj(d, g, h, k, 3, l, S, "gpt_slotred", f), g = !0)
            }!g && _.E(ty) && xj(this.context, this.W, this.slotId, this.l, 0, c.width, c.height, "gpt_pgbrk", f)
        }
        this.C.notify()
    };
    var Uq = function(a, b, c, d, e, f, g, h, k, l) {
        Z.call(this, a, 681);
        this.adUnitPath = b;
        this.ca = c;
        this.L = d;
        this.Tb = e;
        this.Qa = V(this);
        this.G = V(this);
        this.dd = V(this);
        this.l = Jf(ry).split(",");
        this.A = Kf(sy);
        this.O = Y(this, f);
        this.da = Y(this, g);
        this.T = Y(this, h);
        this.D = X(this, k);
        this.Y = X(this, l)
    };
    _.P(Uq, Z);
    Uq.prototype.j = function() {
        if (this.Tb) YL(this);
        else {
            var a;
            if (a = this.l.length) {
                this.l.length ? this.A.length ? (a = this.adUnitPath.split("/"), a = _.u(this.A, "includes").call(this.A, a[a.length - 1])) : a = !0 : a = !1;
                var b = a;
                a = b ? ZL(this) : null;
                if (b && a) {
                    b = this.Y.value;
                    var c, d, e = null != (d = null == (c = Zi(b.parentElement)) ? void 0 : c.width) ? d : 0;
                    c = "p" === this.l[0];
                    d = Number(this.l[0]);
                    if (c = "f" === this.l[0] ? this.L : d && 0 < d ? d : c ? Math.min(e, this.L) : null) {
                        d = a.width;
                        var f = a.height,
                            g = this.l[1],
                            h = Number(g);
                        d = "ratio" === g && d ? Math.floor(f / d * c) : h && 0 < h ? f * h : f;
                        $L(this, c, d, {
                            kind: 0,
                            Ya: '<html><body style="height:' + (d - 2 + "px;width:" + (c - 2 + 'px;background-color:#ddd;color:#000;border:1px solid #f00;margin:0;"><p>Requested size:')) + (a.width + "x" + a.height + "</p><p>Rendered size:") + (c + "x" + d + "</p></body></html>")
                        }, c <= e ? 1 : 2, b);
                        a = !0
                    } else a = !1
                } else a = !1
            }
            a || YL(this)
        }
    };
    var ZL = function(a) {
            a = Li(a.ca)[0];
            return Array.isArray(a) && a.every(function(b) {
                return "number" === typeof b
            }) ? new _.Yi(a[0], a[1]) : null
        },
        $L = function(a, b, c, d, e, f) {
            e = void 0 === e ? a.O.value : e;
            a.G.J(new _.Yi(b, c));
            a.Qa.J(d);
            KB(a.dd, e);
            f && _.Wx(f, "opacity", .5)
        },
        YL = function(a) {
            var b = a.da.value,
                c = a.T.value;
            if (a.Tb) $L(a, null != b ? b : 0, null != c ? c : 0, a.D.value);
            else {
                if (null == b) throw new tm("Missing 'width'.");
                if (null == c) throw new tm("Missing 'height'.");
                $L(a, b, c, a.D.value)
            }
        };
    var aM = /^v?\d{1,3}(\.\d{1,3}){0,2}(-pre)?$/,
        bM = function(a, b, c, d, e, f, g, h, k, l, n, m) {
            Z.call(this, a, 920);
            this.L = b;
            this.V = c;
            this.Ib = d;
            this.D = V(this);
            this.G = V(this);
            this.l = V(this);
            this.O = [];
            this.A = new _.v.Map;
            this.ma = X(this, e);
            f && (this.da = new QB(f));
            g && (this.T = X(this, g));
            h && (this.ca = Y(this, h));
            k && (this.Y = X(this, k));
            l && (this.ua = X(this, l));
            n && (this.na = Y(this, n));
            m && (this.ha = Y(this, m))
        };
    _.P(bM, Z);
    bM.prototype.j = function() {
        if (cM(this)) {
            var a, b = null == (a = this.da) ? void 0 : a.value;
            b && b.libLoaded ? "function" !== typeof b.getEvents ? (this.L.error(OJ()), dM(this)) : (a = eM(this, b)) ? (KB(this.l, a), this.D.J(this.A), this.G.J(this.O)) : dM(this) : dM(this)
        } else dM(this)
    };
    bM.prototype.I = function(a) {
        this.m(a)
    };
    bM.prototype.m = function(a) {
        this.L.error(PJ(a.message));
        dM(this)
    };
    var dM = function(a) {
            LB(a.l);
            LB(a.D);
            LB(a.G)
        },
        eM = function(a, b) {
            var c = (0, B.K)(b.getEvents)(),
                d = c.filter(function(g) {
                    var h = g.args;
                    return "auctionEnd" === g.eventType && h.auctionId
                }),
                e = !1,
                f = a.ma.value.map(function(g) {
                    var h = new sv,
                        k = function(ua) {
                            return ua === g.getDomId() || ua === g.getAdUnitPath()
                        },
                        l, n = null != (l = fM.get(g)) ? l : 0,
                        m;
                    l = null != (m = d.filter(function(ua) {
                        var za, ka, Oa;
                        return Number(null == (za = ua.args) ? void 0 : za.timestamp) > n && (null == (ka = ua.args) ? void 0 : null == (Oa = ka.adUnitCodes) ? void 0 : _.u(Oa, "find").call(Oa, k))
                    })) ? m : [];
                    if (!l.length) return a.O.push(g), [g, h];
                    var p;
                    m = null == (p = l.reduce(function(ua, za) {
                        return Number(za.args.timestamp) > Number(ua.args.timestamp) ? za : ua
                    })) ? void 0 : p.args;
                    if (!m) return [g, h];
                    var r = void 0 === m.bidderRequests ? [] : m.bidderRequests;
                    p = void 0 === m.bidsReceived ? [] : m.bidsReceived;
                    var t = m.auctionId;
                    m = m.timestamp;
                    if (!t || null == m || !r.length) return [g, h];
                    fM.has(g) || _.go(g, function() {
                        return fM.delete(g)
                    });
                    fM.set(g, m);
                    m = tv(h);
                    Math.random() < _.If(xy) && b.version && aM.test(b.version) && _.z(m, 6, b.version);
                    var w;
                    pv(m, null == (w = a.na) ? void 0 : w.value);
                    w = ij(function() {
                        return Eo(c, t)
                    });
                    l = jl(a.V[g.getDomId()]);
                    var D = {};
                    r = _.x(r);
                    for (var G = r.next(); !G.done; D = {
                            Tc: D.Tc,
                            Od: D.Od
                        }, G = r.next()) {
                        var F = G.value;
                        D.Tc = F.bidderCode;
                        var O = F.bids;
                        G = F.timeout;
                        D.Od = F.src;
                        F = F.auctionStart;
                        var I = {};
                        O = _.x(O);
                        for (var Q = O.next(); !Q.done; I = {
                                nc: I.nc
                            }, Q = O.next()) {
                            var S = Q.value;
                            I.nc = S.bidId;
                            var W = S.transactionId;
                            Q = S.adUnitCode;
                            var ja = S.getFloor;
                            S = S.mediaTypes;
                            if (I.nc && k(Q)) {
                                e = !0;
                                so(m, g, Q);
                                W && (_.bg(m, 4) || _.z(m, 4, W), a.A.has(W) || a.A.set(W, F));
                                null != Un(m, 8) || _.z(m, 8, G);
                                var ca = _.u(p, "find").call(p, function(ua) {
                                    return function(za) {
                                        return za.requestId === ua.nc
                                    }
                                }(I));
                                W = jo(m, function(ua) {
                                    return function() {
                                        var za = mo(new no, ua.Tc);
                                        _.E(oo) && po(ua.Tc, b, za);
                                        switch (ua.Od) {
                                            case "client":
                                                _.z(za, 7, 1);
                                                break;
                                            case "s2s":
                                                _.z(za, 7, 2)
                                        }
                                        return za
                                    }
                                }(D)());
                                vo(m, W, Q, (0, B.K)(a.ca).value, (0, B.K)(a.Y).value, (0, B.K)(a.ua).value, ja);
                                ca ? (lo(W, 1), "number" === typeof ca.timeToRespond && qo(W, ca.timeToRespond), Q = io(ca, l, S), ko(W, Q)) : (Q = w().get(I.nc)) && !Q.yf ? qo(lo(W, 2), Math.round(Q.latency)) : qo(lo(W, 3), G)
                            }
                        }
                    }
                    var ya;
                    (null == (ya = b.getConfig) ? 0 : ya.call(b).useBidCache) && ro(m, g, t, l, b);
                    return [g, h]
                });
            return e ? new _.v.Map(f) : null
        },
        cM = function(a) {
            var b;
            if (null == (b = a.ha) ? 0 : b.value) return !0;
            var c, d = null == (c = a.T) ? void 0 : c.value;
            if (!d) return !1;
            var e;
            return (null == (e = d["*"]) ? void 0 : e.Fc) || a.Ib.split(",").some(function(f) {
                var g;
                return !(null == (g = d[f]) || !g.Fc)
            })
        },
        fM = new _.v.Map;
    var gM, hM = function(a, b, c, d, e, f, g) {
        Z.call(this, a, 1019);
        this.V = g;
        b && (this.l = new QB(b));
        c && (this.D = new QB(c));
        d && (this.G = new QB(d));
        this.A = Y(this, e);
        this.L = Y(this, f)
    };
    _.P(hM, Z);
    hM.prototype.j = function() {
        iM(this);
        jM(this)
    };
    var jM = function(a) {
            if (!(Math.random() >= _.If(vy))) {
                var b = (a.L.value || []).filter(function(m) {
                    return jl(a.V[m.getDomId()]).some(function(p) {
                        return "hb_pb" === y(p, 1)
                    })
                });
                if (b.length) {
                    var c, d, e, f, g, h, k, l, n = (null == (c = a.l) ? 0 : null == (d = c.value) ? 0 : null == (e = d.adUnits) ? 0 : e.length) ? [].concat(_.ue(new _.v.Set(null == (f = a.l) ? void 0 : null == (g = f.value) ? void 0 : g.adUnits.map(function(m) {
                        return m.code
                    })))) : _.u(Object, "keys").call(Object, (null == (h = a.l) ? void 0 : null == (k = h.value) ? void 0 : null == (l = k.getAdserverTargeting) ? void 0 : l.call(k)) || {});
                    c = new Zk("haux");
                    L(c, "ius", b.map(function(m) {
                        return m.getAdUnitPath()
                    }).join("~"));
                    L(c, "dids", b.map(function(m) {
                        return m.getDomId()
                    }).join("~"));
                    L(c, "paucs", n.join("~"));
                    Ej(c, a.context);
                    al(c)
                }
            }
        },
        iM = function(a) {
            yj("ppc_hrc", function(b) {
                var c;
                null != gM || (gM = (0, B.va)(null == (c = (_.C = window.google_js_reporting_queue = window.google_js_reporting_queue || [], _.u(_.C, "find")).call(_.C, function(k) {
                    return "1" === k.label
                })) ? void 0 : c.value));
                var d = kf("navigationStart", window);
                gM && L(b, "lt", gM);
                var e;
                L(b, "tids", [].concat(_.ue((null == (e = a.A.value) ? void 0 : _.u(e, "keys").call(e)) || [])).join());
                var f;
                L(b, "asts", [].concat(_.ue((null == (f = a.A.value) ? void 0 : _.u(f, "values").call(f)) || [])).map(function(k) {
                    return k - d
                }).join());
                var g;
                if (null == (g = a.D) ? 0 : g.value) L(b, "ht", a.D.value - d);
                else {
                    var h;
                    (null == (h = a.G) ? 0 : h.value) && L(b, "ht", 0)
                }
                Ej(b, a.context)
            }, a.A.value ? _.If(uy) : 0)
        };
    var Kq = function(a, b, c, d, e) {
        Z.call(this, a, 982);
        this.l = Y(this, b);
        c && (this.D = new QB(c));
        this.G = X(this, d);
        this.A = X(this, e)
    };
    _.P(Kq, Z);
    Kq.prototype.j = function() {
        var a = this,
            b, c = null == (b = this.D) ? void 0 : b.value;
        if (this.l.value && null != c && c.onEvent) {
            b = {};
            for (var d = _.x(["bidWon", "staleRender", "adRenderFailed", "adRenderSucceeded"]), e = d.next(); !e.done; b = {
                    oc: b.oc,
                    Vc: b.Vc
                }, e = d.next()) b.oc = e.value, b.Vc = function(f) {
                return function(g) {
                    if (a.l.value === g.adId) {
                        var h = new Zk("hbm_brt");
                        Ej(h, a.context);
                        L(h, "et", f.oc);
                        L(h, "sf", a.G.value);
                        L(h, "qqid", a.A.value);
                        var k, l, n;
                        L(h, "bc", String(null != (n = null != (l = g.bidderCode) ? l : null == (k = g.bid) ? void 0 : k.bidder) ? n : ""));
                        al(h)
                    }
                }
            }(b), c.onEvent(b.oc, b.Vc), _.go(this, function(f) {
                return function() {
                    return void fi(a.context, a.id, function() {
                        var g;
                        return void(null == (g = c.offEvent) ? void 0 : g.call(c, f.oc, f.Vc))
                    }, !0)
                }
            }(b))
        }
    };
    Kq.prototype.m = function() {};
    var Qp = function(a, b) {
        Z.call(this, a, 1110);
        this.F = b;
        this.C = V(this)
    };
    _.P(Qp, Z);
    Qp.prototype.j = function() {
        var a = this.F;
        a = _.E(wz) && void 0 !== a.credentialless && (_.E(xz) || a.crossOriginIsolated);
        this.C.J(a)
    };
    var kM = function(a, b, c, d, e, f) {
        f = void 0 === f ? Ho : f;
        Z.call(this, a, 886);
        this.Z = b;
        this.M = c;
        this.l = d;
        this.W = e;
        this.A = f;
        this.C = YB(this)
    };
    _.P(kM, Z);
    kM.prototype.j = function() {
        var a = this,
            b, c;
        return _.Ab(function(d) {
            if (1 == d.j) return 3 !== AG(a.W) ? (d.j = 2, d = void 0) : d = Bb(d, new _.v.Promise(function(e) {
                return void EG(e, a.W)
            }), 2), d;
            if (4 != d.j) return b = a.l ? Go(a.l) : null, null == b || (c = a.Z.some(function(e) {
                return !lj(hj(e))
            })) ? (a.C.notify(), d.return()) : Bb(d, lM(a, b), 4);
            a.C.notify();
            d.j = 0
        })
    };
    var lM = function(a, b) {
        return new _.v.Promise(function(c) {
            var d = a.A(function(h, k) {
                h.some(function(l) {
                    return 0 < l.intersectionRatio
                }) && (k.disconnect(), c())
            }, b + "%");
            if (d) {
                _.go(a, function() {
                    return void d.disconnect()
                });
                for (var e = {}, f = _.x(a.Z), g = f.next(); !g.done; e = {
                        rc: e.rc
                    }, g = f.next()) {
                    g = g.value;
                    e.rc = hj(g);
                    if (!e.rc) break;
                    d.observe(e.rc);
                    DI(a.M, g, function(h) {
                        return function() {
                            return void d.unobserve(h.rc)
                        }
                    }(e))
                }
            } else c()
        })
    };
    var Sq = function(a, b, c) {
        Z.call(this, a, 666);
        this.A = b;
        this.l = V(this);
        this.D = Y(this, c)
    };
    _.P(Sq, Z);
    Sq.prototype.j = function() {
        var a = new Tq;
        this.D.Ac() && hH(_.z(a, 2, this.D.value), 1);
        if (this.A) {
            a = [this.A, a];
            var b = new Tq;
            a = _.x(a);
            for (var c = a.next(); !c.done; c = a.next()) c = c.value, null != Un(c, 1) && _.z(b, 1, Un(c, 1)), null != Un(c, 2) && _.z(b, 2, Un(c, 2)), null != Fo(c, 3) && hH(b, Fo(c, 3));
            a = b
        }
        b = this.l;
        a = null != Un(a, 2) ? null != Fo(a, 3) && 0 !== (0, _.Tm)() ? (0, B.va)(Un(a, 2)) * (0, B.va)(Fo(a, 3)) : Un(a, 2) : null;
        KB(b, a)
    };
    var er = function(a, b, c, d, e, f, g) {
        f = void 0 === f ? Io : f;
        Z.call(this, a, 666);
        this.A = f;
        this.C = YB(this);
        $B(this, b);
        g && $B(this, g);
        this.l = X(this, c);
        this.G = Y(this, d);
        this.D = Y(this, e)
    };
    _.P(er, Z);
    er.prototype.j = function() {
        var a = this.D.value,
            b = this.G.value,
            c = this.l.value;
        null == a || 0 > a || 0 === b || !lj(c) ? this.C.notify() : mM(this, a, b, c)
    };
    var mM = function(a, b, c, d) {
        var e = a.A(b, $h(a.context, 291, function(f, g) {
            f = _.x(f);
            for (var h = f.next(); !h.done; h = f.next())
                if (h = h.value, !(0 >= h.intersectionRatio)) {
                    g.unobserve(h.target);
                    a.C.notify();
                    break
                }
        }));
        e ? (null != c && setTimeout(function() {
            a.C.notify();
            e.disconnect()
        }, c), e.observe(d), _.go(a, function() {
            e.disconnect()
        })) : (_.E(Cy), a.C.notify())
    };
    var pr = function(a, b, c, d, e, f, g, h, k) {
        Z.call(this, a, 682);
        this.M = b;
        this.format = c;
        this.slotId = d;
        this.F = e;
        this.l = Y(this, f);
        this.A = X(this, g);
        this.G = X(this, h);
        this.D = Y(this, k)
    };
    _.P(pr, Z);
    pr.prototype.j = function() {
        var a = this;
        if ((2 === this.format || 3 === this.format) && this.l.Ac() && _.Sf(this.l.value, 12, !1)) {
            var b = (0, B.K)(this.D.value).Xg,
                c = _.Eq(this.M, this.slotId),
                d = this.G.value,
                e = this.A.value;
            _.tj(e, {
                "max-height": "30vh",
                overflow: "hidden"
            });
            if (nM) nM.Gi(e);
            else {
                nM = new b(this.context, this.format, e, this.F, d, this.M, this.slotId);
                b = {};
                d = _.x(Pe(this.l.value, ew, 13));
                for (var f = d.next(); !f.done; f = d.next()) f = f.value, b[y(f, 1)] = y(f, 2);
                nM.Li(b);
                nM.kd();
                CI(this.M, this.slotId, function() {
                    nM && (nM.Ha(), nM = null);
                    c && _.GI(a.M, a.slotId)
                })
            }
            _.go(this, function() {
                return _.mx(e)
            })
        }
    };
    var nM = null;
    var qr = function(a, b, c, d, e, f, g, h, k, l) {
        Z.call(this, a, 683);
        this.slotId = b;
        this.format = c;
        this.Y = d;
        this.l = Y(this, e);
        this.G = X(this, f);
        this.T = X(this, g);
        this.L = Y(this, h);
        this.O = Y(this, k);
        this.D = X(this, l);
        this.A = rI(b, Lo, function(n) {
            n = n.detail;
            try {
                var m = JSON.parse(n.data);
                return "sth" === m.googMsgType && "i-adframe-load" === m.msg_type
            } catch (p) {
                return !1
            }
        })
    };
    _.P(qr, Z);
    qr.prototype.j = function() {
        var a = this,
            b, c, d, e, f, g, h, k, l, n, m;
        return _.Ab(function(p) {
            if (1 == p.j) {
                b = _.If(Ty);
                c = a.l.value;
                if (!c || 5 !== a.format) return p.return();
                Math.random() < _.If(Uy) && _.v.Promise.race([a.A.then(function() {
                    return !1
                }), new _.v.Promise(function(r) {
                    TK(a, a.id, window, "pagehide", function(t) {
                        t && r(!0)
                    })
                })]).then(function(r) {
                    var t = new Zk("int_pm");
                    L(t, "ts", Date.now());
                    L(t, "flg", b);
                    L(t, "qem", a.D.value);
                    L(t, "ph", Number(r));
                    al(t)
                });
                d = a.T.value;
                e = a.G.value;
                f = (0, B.K)(a.O.value);
                g = f.rh;
                h = new _.cH(a.context);
                n = (null == (k = a.l.value) ? 0 : null != pi(k, 14)) ? 60 * (0, B.K)(null == (l = a.l.value) ? void 0 : zq(l, 14)) : 604800;
                m = new g(window, e, d, h, a.Y, Jo(Pe(c, ew, 13)), Nm(a.slotId), function() {
                    return void a.Ha()
                }, n, a.L.value);
                _.Nn(a, m);
                switch (b) {
                    case 0:
                        m.L();
                        break;
                    case 1:
                        p.j = 2;
                        return
                }
            } else {
                if (4 != p.j) return Bb(p, a.A, 4);
                if (a.H) return p.return();
                m.L(!0)
            }
            p.j = 0
        })
    };
    var kr = function(a, b, c, d, e, f) {
        Z.call(this, a, 846);
        this.D = b;
        this.format = c;
        this.C = V(this);
        this.l = Y(this, d);
        this.A = Y(this, e);
        f && $B(this, f)
    };
    _.P(kr, Z);
    kr.prototype.j = function() {
        var a, b = (2 === this.format || 3 === this.format) && !(null == (a = this.l.value) || !_.Sf(a, 12, !1));
        a = 5 === this.format && this.A.value;
        b || a ? this.C.lb(this.D.load(_.zL)) : LB(this.C)
    };
    var oM = function(a, b) {
            this.serviceName = b;
            this.slot = (0, B.K)(a.pa)
        },
        pM = function(a, b) {
            oM.call(this, a, b);
            this.isEmpty = !1;
            this.slotContentChanged = !0;
            this.sourceAgnosticLineItemId = this.sourceAgnosticCreativeId = this.lineItemId = this.labelIds = this.creativeTemplateId = this.creativeId = this.campaignId = this.advertiserId = this.size = null;
            this.isBackfill = !1;
            this.companyIds = this.yieldGroupIds = null
        };
    _.P(pM, oM);
    var qM = function() {
        oM.apply(this, arguments)
    };
    _.P(qM, oM);
    var rM = function(a, b, c) {
        oM.call(this, a, b);
        this.inViewPercentage = c
    };
    _.P(rM, oM);
    var sM = function() {
        oM.apply(this, arguments)
    };
    _.P(sM, oM);
    var tM = function() {
        oM.apply(this, arguments)
    };
    _.P(tM, oM);
    var uM = function() {
        oM.apply(this, arguments)
    };
    _.P(uM, oM);
    var vM = function() {
        oM.apply(this, arguments)
    };
    _.P(vM, oM);
    var wM = function(a, b, c, d) {
        oM.call(this, a, b);
        this.makeRewardedVisible = c;
        this.payload = d
    };
    _.P(wM, oM);
    var xM = function(a, b, c) {
        oM.call(this, a, b);
        this.payload = c
    };
    _.P(xM, oM);
    var yM = function() {
        oM.apply(this, arguments)
    };
    _.P(yM, oM);
    var zM = function(a, b, c, d, e, f) {
        Z.call(this, a, 696);
        this.slotId = b;
        this.sa = c;
        $B(this, d);
        bC(this, [e, f])
    };
    _.P(zM, Z);
    zM.prototype.j = function() {
        this.sa.dispatchEvent("rewardedSlotClosed", 703, new yM(this.slotId, "publisher_ads"))
    };
    var AM = function(a, b, c, d, e) {
        Z.call(this, a, 694);
        this.slotId = b;
        this.sa = c;
        $B(this, d);
        this.l = Y(this, e)
    };
    _.P(AM, Z);
    AM.prototype.j = function() {
        var a, b = null == (a = this.l.value) ? void 0 : a.payload;
        this.sa.dispatchEvent("rewardedSlotGranted", 702, new xM(this.slotId, "publisher_ads", null != b ? b : null))
    };
    var BM = {
            width: "100%",
            height: "100%",
            left: "0",
            top: "0"
        },
        CM = function(a, b, c, d, e, f) {
            Z.call(this, a, 693);
            this.F = b;
            this.G = f;
            this.C = YB(this);
            this.l = X(this, c);
            this.A = X(this, d);
            $B(this, e);
            this.D = new _.NG(this.F)
        };
    _.P(CM, Z);
    CM.prototype.j = function() {
        var a = this;
        if (!this.G.mb) {
            var b = 0 === (0, _.Tm)() ? "rgba(1,1,1,0.5)" : "white";
            _.tj(this.A.value, _.u(Object, "assign").call(Object, {
                "background-color": b,
                opacity: "1",
                position: "fixed",
                margin: "0",
                padding: "0",
                "z-index": "2147483647",
                display: "block"
            }, BM));
            _.go(this, _.XG(this.F.document, this.F));
            oe(this.l.value).postMessage(JSON.stringify({
                type: "rewarded",
                message: "visible"
            }), "*");
            if (this.F === this.F.top) {
                this.F.location.hash = "goog_rewarded";
                var c = _.PG(this.D, 2147483646);
                _.SG(c);
                _.go(this, function() {
                    _.TG(c);
                    "goog_rewarded" === a.F.location.hash && (a.F.location.hash = "")
                })
            }
            this.C.notify()
        }
    };
    var DM = function(a, b, c, d) {
        Z.call(this, a, 695);
        this.F = b;
        this.l = X(this, c);
        $B(this, d)
    };
    _.P(DM, Z);
    DM.prototype.j = function() {
        if (this.F === this.F.top) var a = (0, B.K)(oe(this.l.value)),
            b = TK(this, 503, this.F, "hashchange", function(c) {
                dt(c.oldURL, "#goog_rewarded") && (a.postMessage(JSON.stringify({
                    type: "rewarded",
                    message: "back_button"
                }), "*"), b())
            })
    };
    var EM = function(a, b, c, d) {
        Z.call(this, a, 692);
        this.slotId = b;
        this.sa = c;
        this.C = YB(this);
        this.l = X(this, d)
    };
    _.P(EM, Z);
    EM.prototype.j = function() {
        var a = this.l.value,
            b = new _.oh,
            c = b.promise,
            d;
        this.sa.dispatchEvent("rewardedSlotReady", 701, new wM(this.slotId, "publisher_ads", b.resolve, null != (d = a.payload) ? d : null));
        SB(this.C, c)
    };
    var FM = {
            width: "100%",
            height: "100%",
            left: "0",
            top: "0"
        },
        GM = {
            width: "60%",
            height: "60%",
            transform: "translate(-50%, -50%)",
            left: "50%",
            top: "50%"
        },
        HM = function(a, b, c, d, e) {
            Z.call(this, a, 691);
            this.D = V(this);
            this.A = YB(this);
            this.G = X(this, c);
            this.l = bC(this, [d, e])
        };
    _.P(HM, Z);
    HM.prototype.j = function() {
        "ha_before_make_visible" === this.l.value.message ? this.A.notify() : (_.tj(this.G.value, _.u(Object, "assign").call(Object, {
            position: "absolute"
        }, 0 === (0, _.Tm)() ? GM : FM)), this.D.J(this.l.value))
    };
    var rr = function(a, b, c, d, e, f) {
        hg.call(this);
        var g = Mo(b, "granted", a);
        H(this, g);
        var h = Mo(b, "prefetched", a);
        H(this, h);
        var k = Mo(b, "closed", a);
        H(this, k);
        var l = Mo(b, "ha_before_make_visible", a);
        H(this, l);
        var n = new HM(a, b, e, h.C, l.C);
        H(this, n);
        h = new EM(a, b, c, n.D);
        H(this, h);
        f = new CM(a, d, e, f, h.C, n.A);
        H(this, f);
        H(this, new DM(a, d, e, f.C));
        H(this, new AM(a, b, c, h.C, g.C));
        H(this, new zM(a, b, c, h.C, k.C, l.C))
    };
    _.P(rr, hg);
    var Up = function(a, b) {
        Z.call(this, a, 1031);
        this.F = b
    };
    _.P(Up, Z);
    Up.prototype.j = function() {
        this.F === this.F.top && nk(this.F)
    };
    var Sp = function(a, b, c) {
        c = void 0 === c ? sh : c;
        Z.call(this, a, 1063);
        this.F = b;
        this.A = c;
        this.l = V(this)
    };
    _.P(Sp, Z);
    Sp.prototype.j = function() {
        var a = this;
        if (_.E(My) && th(this.F)) {
            var b = null,
                c = 0,
                d = $h(this.context, this.id, function() {
                    var f, g, h, k;
                    return _.Ab(function(l) {
                        switch (l.j) {
                            case 1:
                                return f = a.A(a.F), g = "0", l.m = 2, Bb(l, f, 4);
                            case 4:
                                g = null != (h = l.o) ? h : "0";
                                1E4 < g.length && (di(a.context, a.id, new tm("ML:" + g.length)), g = "0");
                                Db(l, 3);
                                break;
                            case 2:
                                k = Eb(l), di(a.context, a.id, k);
                            case 3:
                                b = g, c = _.hf(a.F) + 3E5, l.j = 0
                        }
                    })
                });
            var e = (_.C = d(), _.u(_.C, "finally")).call(_.C, function() {
                e = void 0
            });
            this.l.J(function() {
                var f, g;
                return _.Ab(function(h) {
                    if (1 == h.j) {
                        f = _.hf(a.F) >= c;
                        g = null === b || "0" === b;
                        if (!f && !g) {
                            h.j = 2;
                            return
                        }
                        e || (e = (_.C = d(), _.u(_.C, "finally")).call(_.C, function() {
                            e = void 0
                        }));
                        return Bb(h, e, 2)
                    }
                    return h.return((0, B.K)(b))
                })
            })
        } else this.l.J(function() {
            return _.v.Promise.resolve("")
        })
    };
    Sp.prototype.m = function() {
        this.l.J(function() {
            return _.v.Promise.resolve("")
        })
    };
    var IM = function(a, b) {
        Z.call(this, a, 1091);
        this.C = V(this);
        b && (this.l = Y(this, b))
    };
    _.P(IM, Z);
    IM.prototype.j = function() {
        var a;
        null != (a = this.l) && a.value ? this.C.lb(this.l.value()) : this.C.J("")
    };
    IM.prototype.m = function() {
        this.C.J("")
    };
    var Wp = function(a, b) {
        Z.call(this, a, 1107);
        this.F = b;
        this.C = V(this)
    };
    _.P(Wp, Z);
    Wp.prototype.j = function() {
        if (Wa()) {
            var a = Yg("run-ad-auction", this.F.document),
                b = Yg("browsing-topics", this.F.document),
                c = Yg("shared-storage", this.F.document),
                d = Yg("attribution-reporting", this.F.document),
                e = 0;
            a && (e |= 1);
            b && (e |= 4);
            c && (e |= 8);
            d && (e |= 2);
            0 === e ? LB(this.C) : (a = new FG, e = _.fd(a, 1, e, 0), this.C.J(e))
        } else LB(this.C)
    };
    Wp.prototype.m = function() {
        LB(this.C)
    };
    var Op = function(a) {
        Z.call(this, a, 1104);
        this.C = V(this)
    };
    _.P(Op, Z);
    Op.prototype.j = function() {
        for (var a = [], b = _.x(Kf($f)), c = b.next(); !c.done; c = b.next()) {
            c = c.value;
            try {
                var d = ag(c);
                a.push(d)
            } catch (e) {
                tf(44, "UNKNOWN_ID", e.message)
            }
        }
        this.C.J(a)
    };
    Op.prototype.m = function() {
        this.C.J([])
    };
    var mr = function(a, b, c, d) {
        Z.call(this, a, 1101);
        this.F = b;
        this.A = Y(this, d);
        this.l = Y(this, c)
    };
    _.P(mr, Z);
    mr.prototype.j = function() {
        if (Yg("browsing-topics", this.F.document) && this.A.value && this.l.value) {
            var a = this.l.value,
                b = Yj(this.F);
            b.setTopicsCalled ? _.v.Promise.resolve() : (b.setTopicsCalled = !0, a({
                message: "goog:topics:frame:get:topics",
                skipTopicsObservation: !1
            }))
        }
    };
    var Rp = function(a, b) {
        Z.call(this, a, 979);
        this.F = b;
        this.C = V(this)
    };
    _.P(Rp, Z);
    Rp.prototype.j = function() {
        var a = this,
            b = "function" !== typeof this.F.document.browsingTopics,
            c = !Yg("browsing-topics", this.F.document);
        b = b || c;
        !Yg("shared-storage", this.F.document) && b ? LB(this.C) : ak(this.F).then(function(d) {
            a.C.J(d)
        })
    };
    Rp.prototype.m = function() {
        LB(this.C)
    };
    var JM = function(a, b, c, d, e, f, g) {
        Z.call(this, a, 978);
        this.l = b;
        this.X = c;
        this.F = d;
        this.localStorage = e;
        this.C = V(this);
        f && (this.A = Y(this, f));
        g && (this.D = X(this, g))
    };
    _.P(JM, Z);
    JM.prototype.j = function() {
        var a;
        if (null != (a = this.A) && a.value && Yg("browsing-topics", this.F.document)) {
            var b;
            if (null != (a = null == (b = this.D) ? void 0 : b.value)) b = a;
            else {
                var c, d, e, f, g, h;
                b = !(null == (c = this.l) ? 0 : K(c, 8)) && (!_.E(cz) || !(null == (d = this.l) ? 0 : K(d, 13))) && !(null == (e = this.l) ? 0 : K(e, 1)) && 1 !== (null == (f = this.l) ? void 0 : _.Re(f, 6, 2)) && 1 !== (null == (g = this.l) ? void 0 : y(g, 5)) && !(null == (h = this.l) ? 0 : K(h, 9)) && !!bf(this.X) && !K(this.X, 9)
            }
            b ? (c = gk(this.A.value, this.F, new _.cH(this.context), this.localStorage), this.C.lb(c)) : this.C.J(5)
        } else LB(this.C)
    };
    JM.prototype.m = function() {
        LB(this.C)
    };
    var KM = function() {
            var a = this;
            this.promise = new _.v.Promise(function(b, c) {
                a.reject = c;
                a.resolve = b
            })
        },
        LM = function() {
            this.auctionSignals = new KM;
            this.topLevelSellerSignals = new KM;
            this.j = new KM;
            this.perBuyerSignals = new KM;
            this.perBuyerTimeouts = new KM
        },
        MM = function(a, b, c) {
            this.j = a;
            this.be = b;
            this.Nb = c
        };
    var NM = navigator,
        OM = function(a, b, c, d, e, f) {
            Z.call(this, a, 1089);
            this.l = b;
            this.X = c;
            this.C = V(this);
            this.A = X(this, d);
            e && (this.D = X(this, e));
            f && (this.G = Y(this, f))
        };
    _.P(OM, Z);
    OM.prototype.j = function() {
        var a = _.E(qz),
            b, c, d = null != (c = null == (b = this.D) ? void 0 : b.value) ? c : !bf(this.X) || K(this.X, 9) ? !1 : this.l ? !K(this.l, 8) && (!_.E(cz) || !K(this.l, 13)) && !K(this.l, 1) && 1 !== _.Re(this.l, 6, 2) && 1 !== y(this.l, 5) && !K(this.l, 9) : !0;
        b = _.If(rz);
        c = 0 === b;
        var e = !("runAdAuction" in navigator && Yg("run-ad-auction", document));
        if (a || c || e || !d) LB(this.C);
        else {
            a = {};
            if (1 === b) {
                var f = _.x(this.A.value);
                for (b = f.next(); !b.done; b = f.next()) a[b.value.getId()] = PM()
            } else if (2 === b) {
                d = null == (f = this.G) ? void 0 : f.value;
                if (!d) {
                    LB(this.C);
                    return
                }
                f = _.x(this.A.value);
                for (b = f.next(); !b.done; b = f.next()) b = b.value, c = d.get(b.getId()), e = void 0, null != (e = c) && e.length && (a[b.getId()] = PM(c))
            }
            this.C.J(a)
        }
    };
    var PM = function(a) {
        var b = new LM,
            c = new AbortController;
        a = No({
            be: b,
            Nb: c,
            ig: _.E(tz),
            interestGroupBuyers: a
        });
        a = NM.runAdAuction(a).catch(function(d) {
            return d instanceof DOMException && "TimeoutError" === d.name ? 2 : 3
        });
        return new MM(a, b, c)
    };
    var Vq = function(a, b, c) {
        Z.call(this, a, 881);
        this.nb = b;
        this.C = V(this);
        this.l = Y(this, c)
    };
    _.P(Vq, Z);
    Vq.prototype.j = function() {
        if (_.E(qz) || !this.l.value) LB(this.C);
        else {
            for (var a = this.l.value, b = [], c = _.x((_.C = CK(this.nb), _.u(_.C, "values")).call(_.C)), d = c.next(); !d.done; d = c.next()) {
                d = d.value;
                try {
                    b.push(JSON.parse(d))
                } catch (m) {
                    di(this.context, 1023, m)
                }
            }
            c = this.C;
            d = c.J;
            for (var e = {}, f = _.x(Pe(a, Dw, 7)), g = f.next(); !g.done; g = f.next()) g = g.value, e[_.Rf(g, 1)] = JSON.parse(_.Rf(g, 2));
            if (f = Df(a, Cw, 6)) e["https://googleads.g.doubleclick.net"] = f.toJSON(), e["https://td.doubleclick.net"] = f.toJSON();
            f = {};
            g = _.x(Pe(a, Ew, 11));
            for (var h = g.next(); !h.done; h = g.next()) h = h.value, f[_.Rf(h, 1)] = Se(h, 2);
            var k = {};
            zq(a, 18) && (k["https://googleads.g.doubleclick.net"] = zq(a, 18), k["https://td.doubleclick.net"] = zq(a, 18));
            g = _.Rf(a, 1).split("/td/")[0];
            h = _.Rf(a, 19);
            h = "" !== h ? g + h : void 0;
            var l, n = _.u(Object, "assign").call(Object, {}, {
                seller: g,
                decisionLogicUrl: _.Rf(a, 1),
                trustedScoringSignalsUrl: _.Rf(a, 2),
                interestGroupBuyers: _.bn(a, 3),
                sellerExperimentGroupId: zq(a, 17),
                auctionSignals: JSON.parse(_.Rf(a, 4) || "{}"),
                sellerSignals: (null == (l = Df(a, Gw, 5)) ? void 0 : l.toJSON()) || [],
                sellerTimeout: Se(a, 15) || 50,
                perBuyerExperimentGroupIds: k,
                perBuyerSignals: e,
                perBuyerTimeouts: f
            }, h ? {
                directFromSellerSignals: h
            } : {});
            l = new Gw;
            "0" !== kd(y(Ip(Ip(a, Gw, 5), Fw, 5), 2), "0") && (e = new Fw, f = kd(y(Ip(Ip(a, Gw, 5), Fw, 5), 2), "0"), zc(e), null != f && 0 !== +f ? Wc(e, 2, f) : Wc(e, 2, void 0, !1), _.Uh(l, 5, e));
            a = _.u(Object, "assign").call(Object, {}, {
                seller: g,
                decisionLogicUrl: _.Rf(a, 1),
                sellerExperimentGroupId: zq(a, 17),
                sellerSignals: l.toJSON(),
                sellerTimeout: Se(a, 15) || 50,
                interestGroupBuyers: [],
                auctionSignals: {},
                perBuyerExperimentGroupIds: {},
                perBuyerSignals: {},
                perBuyerTimeouts: {}
            }, h ? {
                directFromSellerSignals: h
            } : {}, {
                componentAuctions: [n].concat(_.ue(null != b ? b : []))
            });
            d.call(c, a)
        }
    };
    Vq.prototype.m = function() {
        LB(this.C)
    };
    var Po = navigator,
        Qo = /(\$\{GDPR})/gi,
        Ro = /(\$\{GDPR_CONSENT_[0-9]+\})/gi,
        So = /(\$\{ADDTL_CONSENT})/gi,
        To = /(\$\{AD_WIDTH})/gi,
        Uo = /(\$\{AD_HEIGHT})/gi;
    var QM = navigator,
        Wq = function(a, b, c, d, e, f, g, h, k, l) {
            Z.call(this, a, 882);
            this.M = b;
            this.X = c;
            this.ha = d;
            this.l = l;
            this.Qa = V(this);
            this.A = V(this);
            this.D = V(this);
            this.O = Y(this, e);
            this.T = Y(this, f);
            this.Y = X(this, g);
            this.da = X(this, h);
            this.ca = X(this, k)
        };
    _.P(Wq, Z);
    Wq.prototype.j = function() {
        var a = this,
            b, c, d, e, f, g, h, k, l, n, m, p, r, t, w, D, G;
        return _.Ab(function(F) {
            switch (F.j) {
                case 1:
                    if (RM(a)) return _.E(sz) && (null == (b = a.l) || b.Nb.abort()), SM(a), F.return();
                    c = (0, B.K)(a.O.value);
                    d = c.getWidth();
                    e = c.getHeight();
                    if (!d || !e) return _.E(sz) && (null == (f = a.l) || f.Nb.abort()), SM(a), F.return();
                    g = Ip(c, Gw, 5);
                    a.G = g.getEscapedQemQueryId();
                    a.L = _.Rf(g, 6);
                    h = _.Sf(g, 9);
                    if (k = _.Sf(g, 10))
                        if (SM(a), _.Sf(g, 17)) return Xo(0, 0, g), _.E(sz) && (null == (l = a.l) || l.Nb.abort()), F.return();
                    yj("pre_run_ad_auction_ping", function(O) {
                        Ej(O, a.context);
                        var I;
                        L(O, "winner_qid", null != (I = a.G) ? I : "");
                        var Q;
                        L(O, "xfpQid", null != (Q = a.L) ? Q : "");
                        L(O, "publisher_tag", "gpt")
                    }, 1);
                    n = performance.now();
                    m = Se(c, 8) || 1E3;
                    return Bb(F, TM(a, (0, B.K)(a.T.value), g, m, n), 2);
                case 2:
                    p = F.o;
                    r = Math.round(performance.now() - n);
                    t = 3 === p;
                    w = 2 === p;
                    D = 1 === p;
                    G = "string" === typeof p;
                    yj("run_ad_auction_stats", function(O) {
                        Ej(O, a.context);
                        L(O, "duration_ms", r);
                        L(O, "applied_timeout_ms", m);
                        L(O, "timed_out", w ? 1 : 0);
                        L(O, "error", t ? 1 : 0);
                        L(O, "auction_skipped", D ? 1 : 0);
                        L(O, "auction_winner", G ? 1 : 0);
                        L(O, "thread_release_only", _.Sf(g, 15) ? 1 : 0);
                        var I;
                        L(O, "winner_qid", null != (I = a.G) ? I : "");
                        var Q;
                        L(O, "xfpQid", null != (Q = a.L) ? Q : "");
                        L(O, "publisher_tag", "gpt");
                        a.l && L(O, "parallel", "1")
                    }, 1);
                    if (!G) return Xo(r, w ? m : 0, g), k || SM(a), F.return();
                    if (k) return Bb(F, QM.deprecatedURNToURL(p, !0), 7);
                    if (!h) {
                        F.j = 4;
                        break
                    }
                    return Bb(F, QM.deprecatedURNToURL(p, !0), 6);
                case 6:
                    return SM(a), F.return();
                case 7:
                    return F.return();
                case 4:
                    return Bb(F, Vo(p, {
                        gdprApplies: Jl(a.X, 3) ? K(a.X, 3) ? "1" : "0" : null,
                        ih: y(a.X, 2),
                        tg: y(a.X, 4),
                        rg: c.getWidth() ? c.getWidth().toString() : null,
                        pg: c.getHeight() ? c.getHeight().toString() : null
                    }), 8);
                case 8:
                    a.ca.value.style.display = "", a.Qa.J({
                        kind: 2,
                        Qe: p
                    }), a.A.J(new _.Yi(d, e)), a.D.J(!1), F.j = 0
            }
        })
    };
    Wq.prototype.m = function() {
        SM(this)
    };
    var TM = function(a, b, c, d, e) {
            var f = Se(c, 14) || -1;
            if (0 < f && a.M.m >= f) return 1;
            f = Se(c, 13) || -1;
            if (0 < f && a.M.H >= f) return 1;
            ++a.M.m;
            ++a.M.H;
            b.signal = AbortSignal.timeout(d);
            b = a.l ? UM(a, b, d, e, a.l, _.Sf(c, 15)) : VM(a, b, d, e, _.Sf(c, 15));
            --a.M.m;
            return b
        },
        VM = function(a, b, c, d, e) {
            if (e) return Yo();
            var f;
            return null == (f = QM.runAdAuction) ? void 0 : f.call(QM, b).then(function(g) {
                WM(a, g, c, d);
                return g
            }).catch(function(g) {
                return g instanceof DOMException && "TimeoutError" === g.name ? 2 : 3
            })
        },
        UM = function(a, b, c, d, e, f) {
            if (f) return Yo();
            Oo(b, e.be);
            setTimeout(function() {
                e.Nb.abort(new DOMException("runAdAuction", "TimeoutError"))
            }, c);
            return e.j.then(function(g) {
                null !== g && "string" !== typeof g || WM(a, g, c, d);
                return g
            })
        },
        WM = function(a, b, c, d) {
            yj("run_ad_auction_complete", function(e) {
                Ej(e, a.context);
                L(e, "duration_ms", Math.round(performance.now() - d));
                L(e, "applied_timeout_ms", c);
                L(e, "auction_has_winner", !!b);
                a.G && L(e, "winner_qid", a.G);
                a.L && L(e, "xfpQid", a.L)
            }, 1)
        },
        RM = function(a) {
            var b = !!QM.runAdAuction && Yg("run-ad-auction", document);
            return _.E(qz) || !b || !a.O.value || !a.T.value
        },
        SM = function(a) {
            a.D.J(a.ha);
            a.Qa.J(a.Y.value);
            a.A.J(a.da.value)
        };
    var Zo = "3rd party ad content";
    var XM = function(a, b, c) {
        _.U.call(this);
        this.context = a;
        this.Ka = b;
        this.m = c;
        a = c.slotId;
        b = c.size;
        this.j = "height" === c.Yg ? "fluid" : [b.width, b.height];
        this.Bc = oj(a);
        this.Cc = Zo
    };
    _.P(XM, _.U);
    XM.prototype.render = function() {
        var a = this.Ka,
            b = this.m,
            c = b.slotId,
            d = b.P.V,
            e = b.W,
            f = b.size,
            g = b.hc,
            h = b.je,
            k = b.isBackfill;
        b = b.Sc;
        g && vh(g, _.jx(e), null != h ? h : "", !1);
        Cq(_.nf(bi), "5", (0, B.K)(pi(d[c.getDomId()], 20)));
        c.dispatchEvent(Dq, 801, {
            ef: 0 === a.kind ? a.Ya : "",
            isBackfill: k
        });
        a = this.l();
        b && a && a.setAttribute("data-google-container-id", b);
        c.dispatchEvent(Fq, 825, {
            size: f,
            isEmpty: !1
        });
        return a
    };
    XM.prototype.loaded = function(a) {
        var b = this.m,
            c = b.slotId,
            d = b.sa;
        b = b.P.V;
        c.dispatchEvent(xI, 844, void 0);
        a && a.setAttribute("data-load-complete", !0);
        d.dispatchEvent("slotOnload", 710, new sM(c, "publisher_ads"));
        Cq(_.nf(bi), "6", (0, B.K)(pi(b[c.getDomId()], 20)))
    };
    var YM = function(a, b) {
        if (b) return null;
        a = a.Ka;
        a = 0 === a.kind ? a.Ya : "";
        b = "";
        var c = !0,
            d = "sf";
        b = void 0 === b ? "" : b;
        c = void 0 === c ? !1 : c;
        d = void 0 === d ? "" : d;
        if (a) {
            var e = a.toLowerCase(); - 1 < e.indexOf("<!doctype") || -1 < e.indexOf("<html") ? c && Nh(d, 2) : (c && Nh(d, 3), a = _.E(Gz) ? a : "<!doctype html><html><head>" + b + "</head><body>" + a + "</body></html>")
        } else c && Nh(d, 1);
        return a
    };
    XM.prototype.o = function() {
        _.U.prototype.o.call(this);
        var a;
        null == (a = this.m.hc) || a.removeAttribute("data-google-query-id")
    };
    XM.prototype.I = function(a, b) {
        var c = this,
            d = ZM(this, function() {
                return void c.loaded((0, B.K)(d.j))
            }, a, b);
        _.go(this, function() {
            100 != d.status && (2 == d.ia && (KH(d.m), d.ia = 0), window.clearTimeout(d.R), d.R = -1, d.A = 3, d.o && (d.o.Ha(), d.o = null), _.Ae(window, "resize", d.D), _.Ae(window, "scroll", d.D), d.l && d.j && d.l == _.nx(d.j) && d.l.removeChild(d.j), d.j = null, d.l = null, d.status = 100)
        });
        return d
    };
    var ZM = function(a, b, c, d) {
        var e = a.m,
            f = e.Yf,
            g = e.isBackfill,
            h = e.sh,
            k = e.Sc,
            l = e.rd,
            n = e.Td,
            m = e.Da,
            p = Array.isArray(a.j) ? new _.Yi(Number(a.j[0]), Number(a.j[1])) : 1;
        return new SH({
            Ie: e.bf,
            Bc: a.Bc,
            Cc: a.Cc,
            content: YM(a, d),
            size: p,
            Qg: !!h,
            Kf: b,
            Zf: null != f ? f : void 0,
            permissions: {
                od: Jl(c, 1) ? !!K(c, 1) : !g,
                pd: Jl(c, 2) ? !!K(c, 2) : !1
            },
            Dc: !!Tk().fifWin,
            hi: mK ? mK : mK = yl(),
            Bg: Cl(),
            hostpageLibraryTokens: m.hostpageLibraryTokens,
            Sa: function(r, t) {
                return void di(a.context, r, t)
            },
            uniqueId: (0, B.K)(k),
            Xf: dj(),
            rd: null != l ? l : void 0,
            xd: null != d ? d : void 0,
            Td: null != n ? n : void 0
        })
    };
    var $M = function() {
        XM.apply(this, arguments)
    };
    _.P($M, XM);
    var aN = function(a, b) {
            var c = _.ze(b ? "fencedframe" : "IFRAME");
            b && (c.mode = "opaque-ads");
            c.id = a.Bc;
            c.name = a.Bc;
            c.title = a.Cc;
            Array.isArray(a.j) ? null != a.j[0] && null != a.j[1] && (c.width = String(a.j[0]), c.height = String(a.j[1])) : (c.width = "100%", c.height = "0");
            c.allowTransparency = "true";
            c.scrolling = "no";
            c.marginWidth = "0";
            c.marginHeight = "0";
            c.frameBorder = "0";
            c.style.border = "0";
            c.style.verticalAlign = "bottom";
            c.setAttribute("role", "region");
            c.setAttribute("aria-label", "Advertisement");
            c.tabIndex = 0;
            return c
        },
        bN = function(a, b) {
            "string" !== typeof a.j && (b.width = String(a.j[0]), b.height = String(a.j[1]));
            var c = $h(a.context, 774, function() {
                a.loaded(b);
                _.Ae(b, "load", c)
            });
            _.yb(b, "load", c);
            _.go(a, function() {
                return _.Ae(b, "load", c)
            });
            a.m.bf.appendChild(b)
        };
    var wq = function() {
        $M.apply(this, arguments)
    };
    _.P(wq, $M);
    wq.prototype.l = function() {
        var a = aN(this, !this.m.wi);
        Rj(a, this.Ka.Qe);
        bN(this, a);
        return a
    };
    wq.prototype.B = function() {
        return !1
    };
    var Yp = function(a) {
        Z.call(this, a, 1083);
        this.C = V(this)
    };
    _.P(Yp, Z);
    Yp.prototype.j = function() {
        var a = Fk();
        a ? this.C.lb(a) : LB(this.C)
    };
    var cN = function(a, b, c, d, e, f, g, h, k, l, n, m, p, r) {
        Z.call(this, a, 866);
        this.G = b;
        this.l = c;
        this.D = d;
        this.Hc = e;
        this.vc = f;
        this.X = g;
        this.W = h;
        this.C = YB(this);
        this.A = X(this, k);
        this.O = Y(this, l);
        this.T = X(this, n);
        this.Y = X(this, m);
        $B(this, p);
        this.L = X(this, r)
    };
    _.P(cN, Z);
    cN.prototype.j = function() {
        var a, b, c, d = this,
            e, f, g, h, k, l, n, m, p, r, t, w, D;
        return _.Ab(function(G) {
            switch (G.j) {
                case 1:
                    e = d.T.value;
                    if (!e) return d.C.notify(), G.return();
                    f = Ib(d.Y.value, {
                        uuid: d.vc
                    });
                    g = document.createElement("script");
                    h = {
                        source: e,
                        credentials: d.L.value ? "include" : "omit",
                        resources: [f.toString()]
                    };
                    g.setAttribute("type", "webbundle");
                    jb(g, new _.qp(JSON.stringify(h).replace(/</g, "\\u003C"), rp));
                    d.W.head.appendChild(g);
                    d.C.notify();
                    G.m = 2;
                    return Bb(G, dN(f), 4);
                case 4:
                    k = G.o;
                    Db(G, 3);
                    break;
                case 2:
                    l = Eb(G);
                    if (l instanceof xB) return d.l(l), G.return();
                    throw l;
                case 3:
                    a = _.bn(k, 1);
                    b = _.bn(k, 2);
                    c = _.bn(k, 3);
                    n = a;
                    m = b;
                    p = c;
                    if (n.length !== m.length) return d.l(new wB("Received " + n.length + " ad URLs but " + m.length + " metadatas")), G.return();
                    h.resources = [].concat(_.ue(n.filter(function(F) {
                        return F
                    })), _.ue(p.map(function(F) {
                        return "https://securepubads.g.doubleclick.net" + F
                    })));
                    h.resources.length ? (r = _.ze("SCRIPT"), r.setAttribute("type", "webbundle"), jb(r, new _.qp(JSON.stringify(h).replace(/</g, "\\u003C"), rp)), d.W.head.removeChild(g), d.W.head.appendChild(r)) : d.W.head.removeChild(g);
                    for (t = 0; t < n.length; t++) w = n[t], D = m[t], d.G(t, D, {
                        kind: 1,
                        url: w
                    }, d.A.value, d.X, d.O.value);
                    d.D(n.length - 1, d.A.value, d.X);
                    G.j = 0
            }
        })
    };
    var dN = function(a) {
        var b, c;
        return _.Ab(function(d) {
            if (1 == d.j) return Bb(d, fetch(a.toString()).catch(function() {
                throw new xB("Failed to fetch bundle index.");
            }), 2);
            if (3 != d.j) return b = d.o, Bb(d, b.text(), 3);
            c = d.o;
            return d.return(Pw(c))
        })
    };
    var Cp = new _.v.Set,
        eN = function(a, b, c) {
            var d = 0,
                e = function() {
                    d = 0
                };
            return function(f) {
                d || (d = _.q.setTimeout(e, b), a.apply(c, arguments))
            }
        }(function() {
            throw new tm("Reached Limit for addEventListener");
        }, 3E5),
        fN = function(a, b) {
            _.U.call(this);
            this.j = a;
            this.l = b;
            this.m = [];
            this.B = !1;
            this.D = 0;
            this.A = new _.v.Map;
            Cp.add(this);
            this.j.info(eJ(this.getName()))
        };
    _.P(fN, _.U);
    var Ep = function(a) {
        a.B || (a.B = !0, qf(6), a.R())
    };
    fN.prototype.slotAdded = function(a, b) {
        this.m.push(a);
        var c = new tM(a, this.getName());
        this.l.dispatchEvent("slotAdded", 818, c);
        this.j.info(gJ(this.getName(), a.getAdUnitPath()), a);
        a = this.getName();
        Ku(b, 4, a)
    };
    fN.prototype.destroySlots = function(a) {
        var b = this;
        return a.filter(function(c) {
            return ia(b.m, c)
        })
    };
    fN.prototype.addEventListener = function(a, b, c) {
        var d = this;
        c = void 0 === c ? window : c;
        if (this.D >= _.If(Fy) && 0 < _.If(Fy)) return eN(), !1;
        if (!c.IntersectionObserver && (_.C = ["impressionViewable", "slotVisibilityChanged"], _.u(_.C, "includes")).call(_.C, a)) return N(this.j, aK()), !1;
        var e;
        if (null == (e = this.A.get(a)) ? 0 : e.has(b)) return !1;
        this.A.has(a) || this.A.set(a, new _.v.Map);
        c = function(f) {
            f = f.detail;
            try {
                b(f)
            } catch (k) {
                d.j.error(xJ(String(k), a));
                var g, h;
                null == (g = window.console) || null == (h = g.error) || h.call(g, k)
            }
        };
        (0, B.K)(this.A.get(a)).set(b, c);
        this.l.aa(a, c);
        this.D++;
        return !0
    };
    fN.prototype.removeEventListener = function(a, b) {
        var c, d = null == (c = this.A.get(a)) ? void 0 : c.get(b);
        if (!d || !qI(this.l, a, d)) return !1;
        this.D--;
        return (0, B.K)(this.A.get(a)).delete(b)
    };
    var up = function(a) {
        for (var b = _.x(Cp), c = b.next(); !c.done; c = b.next()) c.value.destroySlots(a)
    };
    var yp = function(a, b, c, d) {
        fN.call(this, a, c);
        this.I = b;
        this.ads = new _.v.Map;
        this.N = this.Kb = !1;
        d.m = !0
    };
    _.P(yp, fN);
    yp.prototype.slotAdded = function(a, b) {
        var c = this;
        a.aa(tI, function(d) {
            K(d.detail, 11) && (gN(c, a).Ph = !0)
        });
        fN.prototype.slotAdded.call(this, a, b)
    };
    yp.prototype.R = function() {};
    yp.prototype.setRefreshUnfilledSlots = function(a) {
        "boolean" === typeof a && (this.Kb = a)
    };
    var eK = function(a, b) {
            b && !a.N && yj("ima_sdk_v", function(c) {
                a.N = !0;
                L(c, "v", b)
            });
            return String(Gu())
        },
        cK = function(a, b) {
            var c = rj().j,
                d = rj().o;
            if (a.I.B) {
                var e = {
                    ub: 3
                };
                a.G && (e.jc = a.G);
                a.L && (e.kc = a.L);
                b = null != b ? b : a.m;
                c = aj(c, d);
                d = e.jc;
                var f = e.kc;
                d && "number" !== typeof d || f && "number" !== typeof f || a.I.refresh(c, b, e)
            } else(null == b ? 0 : b[0]) && a.j.error(mJ(b[0].getDomId()))
        },
        fK = function(a, b) {
            var c;
            return a.I.B && !(null == (c = a.ads.get(b)) || !c.Ph)
        },
        dK = function(a, b) {
            return a.m.filter(function(c) {
                return _.u(b, "includes").call(b, c.toString())
            })
        };
    yp.prototype.getName = function() {
        return "companion_ads"
    };
    var gK = function(a, b, c, d) {
            b = new pM(b, a.getName());
            null != c && null != d && (b.size = [c, d]);
            a.l.dispatchEvent("slotRenderEnded", 67, b)
        },
        gN = function(a, b) {
            var c = a.ads.get(b);
            c || (c = {}, a.ads.set(b, c), _.go(b, function() {
                return a.ads.delete(b)
            }));
            return c
        };
    var zp = function(a, b) {
        fN.call(this, a, b)
    };
    _.P(zp, fN);
    zp.prototype.getName = function() {
        return "content"
    };
    zp.prototype.R = function() {};
    var hN = function() {
            this.o = [];
            this.hostpageLibraryTokens = [];
            this.j = {}
        },
        iN = function(a, b) {
            if (!_.u(a.o, "includes").call(a.o, b) && (_.C = [1, 2, 3], _.u(_.C, "includes")).call(_.C, b)) {
                var c = rC[b];
                if (c) {
                    var d = b + "_hostpage_library";
                    if (c = bl(document, c)) c.id = d
                }
                a.o.push(b);
                b = new sC(b);
                a.hostpageLibraryTokens.push(b);
                a = Tk();
                a.hostpageLibraryTokens || (a.hostpageLibraryTokens = {});
                a.hostpageLibraryTokens[b.j] = b.o
            }
        },
        jN = function(a, b, c) {
            var d;
            a.j[b] = null != (d = a.j[b]) ? d : new _.v.Set;
            a.j[b].add(c)
        },
        Fp = function(a, b) {
            var c, d;
            a = null != (d = null == (c = a.j[b]) ? void 0 : _.u(c, "values").call(c)) ? d : [];
            return [].concat(_.ue(a))
        };
    var kN = _.R(["https://securepubads.g.doubleclick.net/pagead/managed/js/gpt/", "/pubads_impl_", ".js"]),
        lN = _.R(["https://securepubads.g.doubleclick.net/gpt/pubads_impl_", "_", ".js"]),
        mN = _.R(["https://pagead2.googlesyndication.com/pagead/managed/js/gpt/", "/pubads_impl_", ".js"]),
        nN = _.R(["https://pagead2.googlesyndication.com/gpt/pubads_impl_", "_", ".js"]),
        oN = new _.v.Map([
            [2, {
                Gf: "page_level_ads"
            }],
            [5, {
                Gf: "shoppit"
            }]
        ]),
        pN = function(a) {
            var b = void 0 === b ? oN : b;
            this.context = a;
            this.j = b;
            this.o = new _.v.Map;
            this.loaded = new _.v.Set
        },
        rN;
    pN.prototype.load = function(a) {
        var b = _.qN(this, a),
            c, d = (null != (c = this.j.get(a.module)) ? c : {}).Gf;
        if (!d) throw Error("cannot load invalid module: " + d);
        if (!this.loaded.has(a.module)) {
            d = (c = _.Rh(172)) && "pagead2.googlesyndication.com" === qx((c.src || "").match(_.px)[3] || null) ? this.context.jb ? _.A(mN, this.context.jb, d) : _.A(nN, d, this.context.Ta) : this.context.jb ? _.A(kN, this.context.jb, d) : _.A(lN, d, this.context.Ta);
            c = {};
            var e = _.If(fz),
                f = _.If(Ly);
            e && (c.cb = e);
            f && (c.mcb = f);
            d = _.u(Object, "keys").call(Object, c).length ? at(d, c) : d;
            rN(this, a);
            bl(document, d);
            this.loaded.add(a.module)
        }
        return b.promise
    };
    _.qN = function(a, b) {
        b = b.module;
        a.o.has(b) || a.o.set(b, new _.oh);
        return (0, B.K)(a.o.get(b))
    };
    rN = function(a, b) {
        var c = b.module;
        b = "_gpt_js_load_" + c + "_";
        var d = $h(a.context, 340, function(e) {
            if (a.j.has(c) && "function" === typeof e) {
                var f = (0, B.K)(a.j.get(c));
                f = (void 0 === f.Kg ? [] : f.Kg).map(function(g) {
                    return _.qN(a, g).promise
                });
                _.v.Promise.all(f).then(function() {
                    e.call(window, _, a)
                })
            }
        });
        Object.defineProperty(Tk(), b, {
            value: function(e) {
                if (d) {
                    var f = d;
                    d = null;
                    f(e)
                }
            },
            writable: !1,
            enumerable: !1
        })
    };
    var sN = function() {
        this.resources = {}
    };
    var tq = function() {
        XM.apply(this, arguments)
    };
    _.P(tq, XM);
    tq.prototype.l = function() {
        var a = this.m,
            b = a.P,
            c = b.U;
        a = b.V[a.slotId.getDomId()];
        b = new Dl;
        c = Kl([b, c.gb(), null == a ? void 0 : a.gb()]);
        c = XM.prototype.I.call(this, c);
        return (0, B.K)(c.j)
    };
    tq.prototype.B = function() {
        return !1
    };
    var uq = function() {
        $M.apply(this, arguments)
    };
    _.P(uq, $M);
    uq.prototype.l = function() {
        var a = this,
            b = this.m,
            c = b.Yf;
        b = b.rd;
        var d = aN(this);
        if (null == c ? 0 : c.length)
            if (_.Vt) {
                c = _.x(c);
                for (var e = c.next(); !e.done; e = c.next()) d.sandbox.add(e.value)
            } else d.sandbox.add.apply(d.sandbox, _.ue(c));
        b && (d.allow = b);
        bN(this, d);
        fi(this.context, 653, function() {
            var f;
            if (f = _.Ht(a.Ka.Ya)) {
                var g = f.toString().toLowerCase(); - 1 < g.indexOf("<!doctype") || -1 < g.indexOf("<html") ? sq(2) : (sq(3), f = _.E(Gz) ? f : _.Ht("<!doctype html><html><head><script>var inDapIF=true,inGptIF=true;\x3c/script></head><body>" + f + "</body></html>"))
            } else sq(1);
            var h, k;
            g = null != (k = null == (h = d.contentWindow) ? void 0 : h.document) ? k : d.contentDocument;
            Va() && g.open("text/html", "replace");
            nb(g, f);
            var l, n, m;
            if (dt(null != (m = null == (l = d.contentWindow) ? void 0 : null == (n = l.location) ? void 0 : n.href) ? m : "", "#")) {
                var p, r;
                null == (p = d.contentWindow) || null == (r = p.history) || r.replaceState(null, "", "#" + Math.random())
            }
            g.close()
        }, !0);
        return d
    };
    uq.prototype.B = function() {
        return !0
    };
    var vq = function() {
        $M.apply(this, arguments)
    };
    _.P(vq, $M);
    vq.prototype.l = function() {
        var a = this.Ka.url,
            b = this.m,
            c = b.P,
            d = c.U;
        b = c.V[b.slotId.getDomId()];
        d = Kl([d.gb(), null == b ? void 0 : b.gb()]);
        var e = aN(this);
        Rj(e, a);
        $M.prototype.I.call(this, d, e);
        var f = function() {
            e.removeEventListener("load", f);
            tN(a)
        };
        e.addEventListener("load", f);
        Nx(e, function() {
            return void tN(a)
        });
        return e
    };
    var tN = function(a) {
        var b = document.querySelectorAll("script[type=webbundle]");
        if (b.length) {
            a: {
                for (var c = 0; c < b.length; c++) {
                    var d = void 0;
                    if (null == (d = b[c].textContent) ? 0 : d.match(a)) {
                        b = b[c];
                        break a
                    }
                }
                b = null
            }
            b && b.textContent && (c = JSON.parse(b.textContent)) && "object" === typeof c && (d = c.resources, a = d.indexOf(a, 0), -1 < a && d.splice(a, 1), 0 === d.length ? document.head.removeChild(b) : (a = _.ze("SCRIPT"), a.setAttribute("type", "webbundle"), a.textContent = JSON.stringify(c), document.head.removeChild(b), document.head.appendChild(a)))
        }
    };
    vq.prototype.B = function() {
        return !1
    };
    var nr = function(a, b, c, d, e, f, g, h, k, l, n, m, p, r, t, w, D, G, F, O, I, Q, S, W, ja, ca) {
        Z.call(this, a, 680);
        this.slotId = b;
        this.M = c;
        this.P = d;
        this.sa = e;
        this.Da = f;
        this.F = g;
        this.l = V(this);
        this.D = V(this);
        this.A = YB(this);
        this.L = X(this, h);
        this.Aa = X(this, k);
        $B(this, l);
        this.da = X(this, n);
        this.G = X(this, m);
        this.ca = X(this, p);
        $B(this, O);
        this.O = X(this, r);
        this.T = Y(this, t);
        this.Pa = Y(this, w);
        this.Y = X(this, D);
        this.ua = Y(this, G);
        this.eb = Y(this, F);
        $B(this, I);
        this.na = X(this, Q);
        $B(this, S);
        ca && $B(this, ca);
        this.ha = Y(this, W);
        ja && (this.ma = Y(this, ja))
    };
    _.P(nr, Z);
    nr.prototype.j = function() {
        var a = this,
            b = this.L.value;
        if (0 === b.kind && null == b.Ya) throw new wB("invalid html");
        var c, d;
        b = xq(this.context, b, {
            W: document,
            slotId: this.slotId,
            M: this.M,
            P: this.P,
            sa: this.sa,
            size: this.ca.value,
            hc: this.da.value,
            bf: this.G.value,
            je: this.O.value,
            Yg: this.T.value,
            Yf: this.Pa.value,
            isBackfill: this.Y.value,
            sh: this.ua.value,
            Sc: this.eb.value,
            rd: this.na.value,
            wi: null == (c = this.ha.value) ? void 0 : _.Sf(c, 14),
            Td: null == (d = this.ma) ? void 0 : d.value,
            Da: this.Da
        }, {
            xi: this.Aa.value
        });
        _.Nn(this, b);
        var e = b.render();
        TK(this, this.id, this.F, "message", function(f) {
            e.contentWindow === f.source && a.slotId.dispatchEvent(Lo, 824, f)
        });
        this.A.notify();
        this.l.J(e);
        this.D.J(b.B())
    };
    var vr = function(a, b, c, d, e, f) {
        Z.call(this, a, 863);
        this.l = c;
        this.Pb = Number(b);
        this.D = X(this, d);
        this.G = X(this, e);
        f ? this.A = X(this, f) : this.L = uN(this)
    };
    _.P(vr, Z);
    var uN = function(a) {
        return _.Ab(function(b) {
            return b.return(new _.v.Promise(function(c) {
                try {
                    TK(a, a.id, a.l, "message", function(d) {
                        var e;
                        "asmreq" === (null == (e = d.data) ? void 0 : e.type) && zq(Aq(d.data.payload), 1) === a.Pb && c(d)
                    })
                } catch (d) {}
            }))
        })
    };
    vr.prototype.j = function() {
        var a = this,
            b, c, d, e, f, g, h, k, l;
        return _.Ab(function(n) {
            if (1 == n.j) {
                b = yq(a.l);
                c = a.D.value;
                d = a.G.value;
                e = B;
                f = e.K;
                if (a.A) {
                    g = a.A.value;
                    n.j = 2;
                    return
                }
                return Bb(n, a.L, 3)
            }
            2 != n.j && (g = n.o);
            h = f.call(e, g);
            var m = a.l,
                p = yq(m);
            var r = c.getBoundingClientRect();
            var t = _.ne(m) ? Ui(c, m) : {
                x: 0,
                y: 0
            };
            m = t.x;
            t = t.y;
            r = new _.Px(t, m + r.right, t + r.bottom, m);
            m = new yG;
            m = _.z(m, 1, r.top);
            m = _.z(m, 3, r.bottom);
            m = _.z(m, 2, r.left);
            r = _.z(m, 4, r.right);
            m = new zG;
            m = _.z(m, 1, a.Pb);
            m = _.z(m, 2, !d);
            r = _.Uh(m, 3, r);
            r = _.z(r, 4, b);
            k = _.z(r, 5, p);
            l = {
                type: "asmres",
                payload: Me(k)
            };
            h.ports[0].postMessage(l);
            n.j = 0
        })
    };
    var jr = function(a, b) {
        Z.call(this, a, 1020);
        this.F = b;
        this.C = V(this)
    };
    _.P(jr, Z);
    jr.prototype.j = function() {
        var a = this.F;
        a = _.E(wz) && void 0 !== a.credentialless && (_.E(xz) || a.crossOriginIsolated);
        this.C.J(a)
    };
    var Oq = function(a, b, c, d, e) {
        Z.call(this, a, 720);
        this.format = b;
        this.D = c;
        this.C = V(this);
        this.l = Y(this, d);
        this.A = Y(this, e)
    };
    _.P(Oq, Z);
    Oq.prototype.j = function() {
        var a = this.A.value;
        if (null == a) LB(this.C);
        else {
            var b = Math.round(.3 * this.D),
                c;
            2 !== this.format && 3 !== this.format || null == (c = this.l.value) || !_.Sf(c, 12, !1) || 0 >= b || a <= b ? this.C.J(a) : this.C.J(b)
        }
    };
    var Zq = function(a, b, c) {
        Z.call(this, a, 1054);
        this.l = b;
        this.C = YB(this);
        this.A = X(this, c)
    };
    _.P(Zq, Z);
    Zq.prototype.j = function() {
        this.A.value || this.l();
        this.C.notify()
    };
    var ar = function(a, b, c, d, e, f, g, h, k, l, n, m) {
        Z.call(this, a, 674);
        this.slotId = b;
        this.U = c;
        this.A = d;
        this.W = f;
        this.M = g;
        this.C = V(this);
        this.G = 2 === e || 3 === e;
        this.l = X(this, h);
        this.O = X(this, k);
        this.L = Y(this, l);
        this.D = Y(this, n);
        m && $B(this, m)
    };
    _.P(ar, Z);
    ar.prototype.j = function() {
        var a = Ri(this.U, this.A),
            b = gj(this.slotId, this.W) || zm(this.l.value, pj(this.slotId), a);
        this.O.value && !a && (b.style.display = "inline-block");
        this.G ? CI(this.M, this.slotId, function() {
            return void _.mx(b)
        }) : _.go(this, function() {
            return void _.mx(b)
        });
        a = vN(this);
        0 < a && (b.style.paddingTop = a + "px");
        this.C.J(b)
    };
    var vN = function(a) {
        var b = a.l.value,
            c, d = null == (c = a.L.value) ? void 0 : c.height;
        if (b && !a.D.value && d) {
            var e;
            c = (null != (e = Qi(a.A, 23)) ? e : K(a.U, 31)) ? Math.floor((b.offsetHeight - d) / 2) : 0
        } else c = 0;
        return c
    };
    var Jq = function(a, b) {
        Z.call(this, a, 859);
        this.F = b;
        this.C = V(this)
    };
    _.P(Jq, Z);
    Jq.prototype.j = function() {
        this.C.J(!_.ne(this.F.top))
    };
    var dr = function(a, b, c) {
        Z.call(this, a, 698);
        this.F = b;
        this.C = V(this);
        this.l = X(this, c)
    };
    _.P(dr, Z);
    dr.prototype.j = function() {
        KB(this.C, jj(this.l.value, this.F))
    };
    var ir = function(a, b, c) {
        Z.call(this, a, 840);
        this.format = b;
        this.W = c;
        this.C = V(this)
    };
    _.P(ir, Z);
    ir.prototype.j = function() {
        var a = [],
            b = this.W;
        b = void 0 === b ? document : b;
        var c;
        null != (c = b.featurePolicy) && (_.C = c.features(), _.u(_.C, "includes")).call(_.C, "attribution-reporting") && a.push("attribution-reporting");
        5 !== this.format && 4 !== this.format || !_.E(qy) || a.push("autoplay");
        a.length ? this.C.J(a.join(";")) : this.C.J("")
    };
    var or = function(a, b, c, d, e) {
        Z.call(this, a, 934);
        this.F = b;
        this.slotId = c;
        $B(this, d);
        this.l = X(this, e)
    };
    _.P(or, Z);
    or.prototype.j = function() {
        var a = this;
        this.slotId.aa(Lo, function(b) {
            b = b.detail.data;
            try {
                var c = JSON.parse(b);
                if ("gpi-uoo" === c.googMsgType) {
                    var d = c.userOptOut,
                        e = c.clearAdsData,
                        f = a.l.value,
                        g = new xw;
                    var h = _.z(g, 1, d ? "1" : "0");
                    var k = _.z(h, 2, 2147483647);
                    var l = _.z(k, 3, "/");
                    var n = _.z(l, 4, a.F.location.hostname);
                    var m = new _.lC(a.F);
                    oC(m, "__gpi_opt_out", n, f);
                    if (d || e) pC(m, "__gads", f), pC(m, "__gpi", f)
                }
            } catch (p) {}
        })
    };
    var Yq = function(a, b, c, d, e, f) {
        Z.call(this, a, 1053);
        this.slotId = b;
        this.P = c;
        this.M = d;
        this.l = V(this);
        this.A = X(this, e);
        this.D = X(this, f)
    };
    _.P(Yq, Z);
    Yq.prototype.j = function() {
        this.D.value ? (Gq(this.slotId, this.M, this.P, this.A.value), this.l.J(!1)) : this.l.J(!0)
    };
    var xr = function(a, b, c, d, e, f) {
        Z.call(this, a, 721);
        this.F = b;
        this.G = Y(this, c);
        this.A = X(this, d);
        this.l = X(this, e);
        this.D = X(this, f)
    };
    _.P(xr, Z);
    xr.prototype.j = function() {
        var a = this,
            b = this.G.value,
            c, d = null == b ? void 0 : null == (c = y(b, 1)) ? void 0 : c.toUpperCase(),
            e;
        b = null == b ? void 0 : null == (e = y(b, 2)) ? void 0 : e.toUpperCase();
        if (d && b) {
            e = this.A.value;
            c = this.l.value;
            var f = this.D.value,
                g = f.style.height,
                h = f.style.width,
                k = f.style.display,
                l = f.style.position,
                n = Hq(e.id + "_top", d),
                m = Hq(e.id + "_bottom", b);
            _.tj(m, {
                position: "relative",
                top: "calc(100vh - 48px)"
            });
            f.appendChild(n);
            f.appendChild(m);
            _.tj(c, {
                position: "absolute",
                top: "24px",
                clip: "rect(0, auto, auto, 0)",
                width: "100vw",
                height: "calc(100vh - 48px)"
            });
            _.tj(e, {
                position: "fixed",
                top: "0",
                height: "100vh"
            });
            var p;
            _.tj(f, {
                position: "relative",
                display: (null == (p = this.F.screen.orientation) ? 0 : p.angle) ? "none" : "block",
                width: "100vw",
                height: "100vh"
            });
            TK(this, 722, this.F, "orientationchange", function() {
                var r;
                (null == (r = a.F.screen.orientation) ? 0 : r.angle) ? _.tj(f, {
                    display: "none"
                }): _.tj(f, {
                    display: "block"
                })
            });
            _.go(this, function() {
                _.mx(n);
                _.mx(m);
                f.style.position = l;
                f.style.height = g;
                f.style.width = h;
                f.style.display = k
            })
        }
    };
    var sr = function(a, b, c, d, e, f) {
        f = void 0 === f ? Iq : f;
        Z.call(this, a, 783);
        var g = this;
        this.slotId = b;
        this.W = d;
        this.sa = e;
        this.L = f;
        this.G = !1;
        this.l = null;
        this.D = this.A = -1;
        this.T = _.Rs(function() {
            g.sa.dispatchEvent("impressionViewable", 715, new qM(g.slotId, "publisher_ads"))
        });
        this.Y = Ss(function() {
            g.sa.dispatchEvent("slotVisibilityChanged", 716, new rM(g.slotId, "publisher_ads", g.D))
        });
        this.O = X(this, c);
        var h = new RB;
        rI(this.slotId, xI).then(function() {
            return void h.notify()
        });
        $B(this, h)
    };
    _.P(sr, Z);
    sr.prototype.j = function() {
        var a = this,
            b = this.L($h(this.context, this.id, function(c) {
                c = _.x(c);
                for (var d = c.next(); !d.done; d = c.next()) a.A = 100 * d.value.intersectionRatio, _.u(Number, "isFinite").call(Number, a.A) && wN(a)
            }));
        b && (b.observe(this.O.value), TK(this, this.id, this.W, "visibilitychange", function() {
            wN(a)
        }), _.go(this, function() {
            b.disconnect()
        }))
    };
    var wN = function(a) {
            var b = !CG(a.W);
            xN(a, 50 <= a.A && b);
            b = Math.floor(b ? a.A : 0);
            if (0 > b || 100 < b || b === a.D ? 0 : -1 !== a.D || 0 !== b) a.D = b, a.Y()
        },
        xN = function(a, b) {
            a.G || (b ? null === a.l && (a.l = setTimeout(function() {
                CG(a.W) || (a.T(), a.G = !0);
                a.l = null
            }, 1E3)) : null !== a.l && (clearTimeout(a.l), a.l = null))
        };
    var yN = _.R(["https://td.doubleclick.net/td/kb?kbli=", ""]),
        zN = _.R(["https://googleads.g.doubleclick.net/td/kb?kbli=", ""]),
        lr = function(a, b, c) {
            Z.call(this, a, 1007);
            this.l = Y(this, b);
            c && $B(this, c)
        };
    _.P(lr, Z);
    lr.prototype.j = function() {
        var a = this.l.value;
        if (null != a && a.length && null === document.getElementById("koelBirdIGRegisterIframe")) {
            var b = document.createElement("iframe");
            a = _.E(uz) ? xb(yN, encodeURIComponent(a.join())) : xb(zN, encodeURIComponent(a.join()));
            b.removeAttribute("srcdoc");
            if (a instanceof _.Ys) throw new Rt("TrustedResourceUrl", 2);
            a = _.fb(a);
            void 0 !== a && (b.src = a);
            for (a = "allow-same-origin allow-scripts allow-forms allow-popups allow-popups-to-escape-sandbox allow-storage-access-by-user-activation".split(" "); 0 < b.sandbox.length;) b.sandbox.remove(b.sandbox.item(0));
            for (var c = 0; c < a.length; c++) b.sandbox.supports && !b.sandbox.supports(a[c]) || b.sandbox.add(a[c]);
            b.id = "koelBirdIGRegisterIframe";
            document.head.appendChild(b)
        }
    };
    var cr = function(a, b, c, d, e, f, g) {
        Z.call(this, a, 664);
        this.slotId = b;
        this.lc = c;
        this.M = d;
        this.C = YB(this);
        this.A = X(this, e);
        this.l = Y(this, f);
        g && $B(this, g)
    };
    _.P(cr, Z);
    cr.prototype.j = function() {
        var a = this,
            b, c = null != (b = this.l.value) ? b : 0;
        if (0 !== (0, _.Tm)() || 0 < c) {
            var d = document;
            b = BG(d);
            if (CG(d) && b && (0 < II(this.M, this.slotId) || !AN(this)) && b) {
                var e = TK(this, 324, d, b, function() {
                    CG(d) || (e && e(), a.C.notify())
                });
                if (e) return
            }
        }
        this.C.notify()
    };
    var AN = function(a) {
        var b = a.A.value;
        try {
            var c, d = null != (c = top) ? c : void 0;
            if (void 0 === d) return !0;
            var e = hn(null == d ? void 0 : d.document, d).y,
                f = e + a.lc.height;
            return b.y >= e && b.y <= f
        } catch (g) {
            return !0
        }
    };
    var $q = function(a, b, c) {
        Z.call(this, a, 1055);
        this.C = YB(this);
        $B(this, c);
        this.l = X(this, b)
    };
    _.P($q, Z);
    $q.prototype.j = function() {
        this.l.value && this.C.notify()
    };
    var Rq = function(a, b, c, d, e) {
        Z.call(this, a, 669);
        this.U = b;
        this.V = c;
        this.C = V(this);
        this.A = Y(this, d);
        this.l = X(this, e)
    };
    _.P(Rq, Z);
    Rq.prototype.j = function() {
        if (Jf(ry)) this.C.J(!0);
        else {
            var a, b = !(null == (a = this.A.value) || !y(a, 1)) && (K(this.V, 12) || K(this.U, 13)) || this.l.value;
            this.C.J(!!b)
        }
    };
    var gr = function(a, b, c, d, e, f) {
        Z.call(this, a, 719);
        this.U = b;
        this.A = c;
        this.C = V(this);
        this.l = X(this, d);
        this.D = X(this, e);
        this.G = Y(this, f)
    };
    _.P(gr, Z);
    gr.prototype.j = function() {
        var a = this.l.value.kind;
        switch (a) {
            case 0:
                this.l.value.Ya ? this.D.value ? BN(this) : LB(this.C) : LB(this.C);
                break;
            case 1:
                BN(this);
                break;
            case 2:
                LB(this.C);
                break;
            default:
                gb(a)
        }
    };
    var BN = function(a) {
        var b = a.G.value,
            c = new Dl;
        b = _.z(c, 3, b);
        K(Kl([b, a.U.gb(), a.A.gb()]), 3) ? a.C.J(XH) : LB(a.C)
    };
    var Pq = function(a, b, c, d, e, f, g, h, k) {
        Z.call(this, a, 673);
        this.slotId = b;
        this.hc = c;
        this.D = d;
        this.A = e;
        this.W = f;
        this.l = g;
        this.M = h;
        this.Tb = k;
        this.C = V(this)
    };
    _.P(Pq, Z);
    Pq.prototype.j = function() {
        var a = this,
            b, c;
        return _.Ab(function(d) {
            if (1 == d.j) {
                if (a.hc) {
                    CN(a, a.hc);
                    a.C.J(a.hc);
                    d.j = 0;
                    return
                }
                if (Pi(a.l)) {
                    a.C.J(DN(a));
                    d.j = 0;
                    return
                }
                return Bb(d, rI(a.slotId, sI), 4)
            }
            b = d.o;
            c = b.detail;
            if (a.H) return d.return();
            CN(a, c);
            a.C.J(c);
            d.j = 0
        })
    };
    var DN = function(a) {
            var b = _.ze("INS");
            b.id = a.D;
            _.tj(b, {
                display: "none"
            });
            a.W.documentElement.appendChild(b);
            var c = function() {
                return void _.mx(b)
            };
            2 === a.l || 3 === a.l ? CI(a.M, a.slotId, c) : _.go(a, c);
            return b
        },
        CN = function(a, b) {
            if (2 !== a.l && 3 !== a.l) {
                for (var c = _.x(_.u(Array, "from").call(Array, b.childNodes)), d = c.next(); !d.done; d = c.next()) d = d.value, 1 === d.nodeType && d.id !== a.A && _.mx(d);
                a.Tb || (b.style.display = "")
            }
        };
    var br = function(a, b) {
        Z.call(this, a, 676);
        this.C = V(this);
        this.l = X(this, b)
    };
    _.P(br, Z);
    br.prototype.j = function() {
        var a = Wi(this.l.value);
        this.C.J(a)
    };
    var hr = function(a, b, c, d, e) {
        Z.call(this, a, 807);
        this.F = b;
        this.C = YB(this);
        this.l = Y(this, c);
        this.A = X(this, d);
        e && $B(this, e)
    };
    _.P(hr, Z);
    hr.prototype.j = function() {
        var a = this.l.value;
        if (a && !this.A.value) {
            var b = Ox(this.F);
            lI(new kI(b, a)) || this.R(new tm("Cannot create top window frame"))
        }
        this.C.notify()
    };
    var EN = function(a, b) {
            var c = rj();
            this.context = a;
            this.M = b;
            this.j = c
        },
        FN = function(a, b, c, d, e, f, g, h, k, l, n, m, p, r, t, w, D) {
            var G = document,
                F = window;
            e || f || _.E(Xq) || MI(a.M, d);
            var O = zr(a.context, b, a.j, c, d, e, f, g, h, k, l, n, G, m, p, r, t, function() {
                MI(a.M, d);
                LI(a.M, d, O)
            }, w, D);
            f || _.E(Xq) || LI(a.M, d, O);
            _.go(d, function() {
                MI(a.M, d)
            });
            F.top !== F && F.addEventListener("pagehide", function(I) {
                I.persisted || MI(a.M, d)
            });
            sg(O)
        };
    var GN = function(a, b, c) {
        Z.call(this, a, 944);
        this.F = b;
        this.l = new _.lC(this.F);
        this.A = X(this, c)
    };
    _.P(GN, Z);
    GN.prototype.j = function() {
        var a = this.A.value;
        if (nC(this.l, a)) {
            var b = _.mC(this.l, "__gpi_opt_out", a);
            if (b) {
                var c = new xw;
                b = _.z(c, 1, b);
                b = _.z(b, 2, 2147483647);
                b = _.z(b, 3, "/");
                b = _.z(b, 4, this.F.location.hostname);
                oC(this.l, "__gpi_opt_out", b, a)
            }
        }
    };
    var HN = function(a, b, c, d) {
        d = void 0 === d ? Cr : d;
        Z.call(this, a, 883);
        this.Bb = b;
        this.D = d;
        this.l = YB(this);
        this.A = X(this, c)
    };
    _.P(HN, Z);
    HN.prototype.j = function() {
        !bf(this.A.value) || _.E(Qy) ? this.l.notify() : (_.E(Py) || pG(this.Bb), this.D() ? SB(this.l, new _.v.Promise(function(a) {
            return void qG(a)
        })) : (qG(null), this.l.notify()))
    };
    var IN = function(a, b, c, d, e) {
        Z.call(this, a, 884);
        this.wa = b;
        this.l = c;
        this.A = V(this);
        this.G = Y(this, d);
        this.D = X(this, e)
    };
    _.P(IN, Z);
    IN.prototype.j = function() {
        this.l.storage = this.G.value;
        VL(this.l, _.mC(this.wa, "__gads", this.D.value));
        qf(20);
        qf(2);
        this.A.J(_.nf( of ).j())
    };
    var JN = function(a, b, c) {
        Z.call(this, a, 873);
        this.F = b;
        this.l = X(this, c)
    };
    _.P(JN, Z);
    JN.prototype.j = function() {
        var a = this.context,
            b = this.l.value,
            c = this.F;
        !Tk()._pubconsole_disable_ && (b = ff("google_pubconsole", b, c)) && (b = b.split("|"), "1" !== b[0] && "0" !== b[0] || Wk(a, c))
    };
    var KN = function(a, b, c, d, e) {
        Z.call(this, a, 1058);
        this.F = b;
        this.X = c;
        d && (this.l = Y(this, d));
        $B(this, e)
    };
    _.P(KN, Z);
    KN.prototype.j = function() {
        var a;
        if (Yg("shared-storage", this.F.document) && (null == (a = this.l) ? 0 : a.value) && bf(this.X)) {
            a = {
                message: "goog:spam:client_age",
                pvsid: this.context.pvsid,
                clientAgeIframe: _.E(Dy)
            };
            var b = this.l.value;
            b(a)
        }
    };
    var LN = function(a, b, c) {
        Z.call(this, a, 798);
        this.C = V(this);
        this.l = Y(this, b);
        this.A = X(this, c)
    };
    _.P(LN, Z);
    LN.prototype.j = function() {
        var a = this,
            b = new _.v.Map;
        if (this.l.value) {
            var c = this.l.value,
                d = c.fa.Na,
                e = c.bd.cd;
            c = _.x(c.ba.Z);
            for (var f = c.next(); !f.done; f = c.next()) {
                f = f.value;
                var g = void 0,
                    h = null == (g = e) ? void 0 : g.get(f);
                b.set(f, d ? MN(this, f, h) : function() {
                    return a.A.value
                })
            }
        }
        this.C.J(b)
    };
    var MN = function(a, b, c) {
        return ij(function() {
            var d = _.u(Object, "assign").call(Object, {}, a.l.value);
            d.ba.xe = !0;
            d.ba.Z = [b];
            c && (d.bd.cd = new _.v.Map, d.bd.cd.set(b, c));
            return Vm(_.E(zy) ? rn(d) : NK(d)).url
        })
    };
    var NN = function(a, b, c, d, e, f, g) {
        Z.call(this, a, 810);
        this.D = b;
        this.Na = c;
        this.P = d;
        this.A = e;
        this.F = f;
        this.X = g;
        this.l = V(this)
    };
    _.P(NN, Z);
    NN.prototype.j = function() {
        var a = this,
            b = this.D;
        !this.Na && 1 < this.D.length && (b = [b[0]]);
        b = b.filter(function(c) {
            if (c.H) return !1;
            var d = a.P.V[c.getDomId()],
                e;
            if (e = !(co(Mm(d)) && (_.C = Kf(Xy), _.u(_.C, "includes")).call(_.C, String(Mm(d))))) yh(a.F) && 4 === Mm(d) ? (N(a.A, GJ("googletag.enums.OutOfPageFormat.REWARDED", String(c.getAdUnitPath()))), e = !0) : e = !1, e = !e;
            return e && !Pm(a.context, a.A, c, d, a.F, a.X)
        });
        30 < b.length && (N(this.A, CJ("30", String(b.length), String(b.length - 30))), b = b.slice(0, 30));
        this.l.J(b)
    };
    var ON = function(a, b, c) {
        Z.call(this, a, 919);
        this.l = b;
        this.X = c;
        this.C = V(this)
    };
    _.P(ON, Z);
    ON.prototype.j = function() {
        var a, b = !(null == (a = this.l) ? 0 : K(a, 9)) && !!bf(this.X);
        this.C.J(b)
    };
    var PN = function(a, b, c, d, e, f) {
        Z.call(this, a, 935);
        this.M = b;
        this.P = c;
        this.W = d;
        this.C = YB(this);
        this.l = X(this, e);
        $B(this, f)
    };
    _.P(PN, Z);
    PN.prototype.j = function() {
        var a = this.P,
            b = a.U;
        a = a.V;
        for (var c = _.x(this.l.value), d = c.next(); !d.done; d = c.next()) {
            d = d.value;
            var e = a[d.getDomId()],
                f = this.W;
            tn(e, b) && !this.M.Cb(d) && un(d, f, e, b)
        }
        this.C.notify()
    };
    var QN = function(a, b, c, d, e, f) {
        f = void 0 === f ? Tj : f;
        Z.call(this, a, 939);
        this.A = b;
        this.F = c;
        this.X = d;
        this.l = f;
        $B(this, e)
    };
    _.P(QN, Z);
    QN.prototype.j = function() {
        var a = this.l,
            b = this.F,
            c = new gq;
        var d = new fq;
        d = _.jd(d, 1, String(this.A));
        c = _.Uh(c, 5, d);
        c = _.fd(c, 4, 1, 0);
        c = _.fd(c, 2, 2, 0);
        c = _.jd(c, 3, this.context.jb || this.context.Ta);
        c = _.hd(c, 6, bf(this.X));
        a.call(this, b, c)
    };
    var RN = function(a, b, c, d, e) {
        Z.call(this, a, 905);
        this.P = b;
        this.l = c;
        this.C = YB(this);
        this.A = X(this, d);
        $B(this, e)
    };
    _.P(RN, Z);
    RN.prototype.j = function() {
        for (var a = _.x(this.A.value), b = a.next(); !b.done; b = a.next()) {
            var c = void 0;
            switch (null == (c = this.P.V[b.value.getDomId()]) ? void 0 : Mm(c)) {
                case 2:
                case 3:
                case 5:
                    this.l.load(_.zL);
                    return
            }
        }
        this.C.notify()
    };
    var SN = function(a, b, c, d) {
        Z.call(this, a, 833);
        this.l = b;
        this.F = c;
        this.C = YB(this);
        $B(this, d)
    };
    _.P(SN, Z);
    SN.prototype.j = function() {
        if (!_.E(gz)) {
            var a = this.l,
                b = this.F,
                c = dj();
            c = {
                version: mK ? mK : mK = yl(),
                Kd: c
            };
            c = ZH.Ah(c);
            var d = GH(b);
            c = d ? se(c, new _.v.Map([
                ["n", String(d)]
            ])) : c;
            d = Kf(Al);
            for (var e = new _.v.Map, f = 0; f < d.length; f += 2) e.set(d[f], d[f + 1]);
            c = se(c, e);
            var g;
            a.resources[c.toString()] || (null == (g = Tk()) ? 0 : g.fifWin) || (a.resources[c.toString()] = 1, b = b.document, a = _.ze("IFRAME"), a.src = _.kb(c).toString(), a.style.visibility = "hidden", a.style.display = "none", b = b.getElementsByTagName("script"), b.length && (b = b[b.length - 1], b.parentNode && b.parentNode.insertBefore(a, b.nextSibling)))
        }
        this.C.notify()
    };
    var TN = function(a, b, c, d) {
        Z.call(this, a, 928);
        this.requestId = b;
        this.C = YB(this);
        this.l = X(this, c);
        $B(this, d)
    };
    _.P(TN, Z);
    TN.prototype.j = function() {
        var a = this.context,
            b = this.requestId,
            c = this.l.value.length;
        if (a.Pc) {
            var d = a.Lb;
            a = Vh(a);
            var e = new dy;
            b = _.id(e, 2, b);
            c = _.fd(b, 1, c, 0);
            c = _.Xh(a, 7, Yh, c);
            we(d, c)
        }
        this.C.notify()
    };
    var UN = function(a, b, c, d) {
        Z.call(this, a, 867);
        this.sa = b;
        this.P = c;
        this.C = YB(this);
        this.l = X(this, d)
    };
    _.P(UN, Z);
    UN.prototype.j = function() {
        for (var a = _.x(this.l.value), b = a.next(); !b.done; b = a.next()) {
            var c = _.x(b.value);
            b = c.next().value;
            c = c.next().value;
            var d = pi(this.P.V[b.getDomId()], 20);
            b.dispatchEvent(uI, 808, {
                Ig: c,
                gi: d
            });
            this.sa.dispatchEvent("slotRequested", 705, new uM(b, "publisher_ads"))
        }
        this.C.notify()
    };
    var VN = function(a, b, c, d, e, f, g, h, k, l, n, m, p, r, t, w, D, G, F, O, I, Q, S, W, ja, ca, ya, ua, za, ka, Oa, $a, Jb) {
        Z.call(this, a, 785, _.If(lz));
        this.Na = b;
        this.M = c;
        this.wa = d;
        this.P = e;
        this.Hc = f;
        this.ub = g;
        this.kc = h;
        this.jc = k;
        this.pe = l;
        this.vc = n;
        this.wb = m;
        this.X = p;
        this.isSecureContext = r;
        this.hb = t;
        this.F = w;
        this.l = V(this);
        this.D = V(this);
        this.A = V(this);
        $B(this, S);
        this.ma = ZB(this, D);
        this.G = ZB(this, G);
        this.L = X(this, F);
        this.T = ZB(this, I);
        this.O = ZB(this, Q);
        $B(this, S);
        $B(this, W);
        ja && (this.ua = X(this, ja));
        ca && (this.Y = new QB(ca));
        ya && (this.na = Y(this, ya));
        ua && (this.da = X(this, ua));
        za && $B(this, za);
        ka && (this.ha = X(this, ka));
        $a && (this.Aa = X(this, $a));
        Oa && (this.eb = ZB(this, Oa));
        this.ca = Y(this, O);
        Jb && (this.Pa = Y(this, Jb))
    };
    _.P(VN, Z);
    VN.prototype.j = function() {
        if (this.L.value.length) {
            var a = !_.E(Qy);
            if (a) {
                jh();
                var b = lh[1]
            } else b = "";
            if (a) {
                jh();
                var c = lh[4]
            } else c = "";
            a ? (jh(), a = lh[6]) : a = "";
            var d = a;
            var e = (a = this.T.value) ? a : this.O && !this.O.mb() ? 9 : this.T.mb() ? null : 1;
            this.G.value && (this.M.md = this.G.value);
            var f, g, h, k, l, n, m, p, r, t;
            a = {
                fa: {
                    F: this.F,
                    context: this.context,
                    M: this.M,
                    wa: this.wa,
                    X: this.X,
                    Na: this.Na,
                    pe: this.pe,
                    isSecureContext: this.isSecureContext,
                    Ai: null == (f = this.eb) ? void 0 : f.value,
                    hb: this.hb
                },
                ba: {
                    Z: this.L.value,
                    P: this.P,
                    ub: this.ub,
                    xe: !1
                },
                Di: {
                    kc: this.kc,
                    jc: this.jc
                },
                Hh: {
                    ug: b,
                    Bh: c,
                    Zh: d
                },
                Oh: {
                    kh: null != (r = this.ma.value) ? r : "0"
                },
                kg: {
                    Hc: this.Hc,
                    vc: this.vc
                },
                bd: {
                    cd: this.ca.value
                },
                pi: {
                    ri: e
                },
                ki: {
                    Ih: null != (t = null == (g = this.ua) ? void 0 : g.value) ? t : void 0,
                    Sh: null == (h = this.Y) ? void 0 : h.value,
                    Sg: null == (k = this.da) ? void 0 : k.value,
                    Qh: null == (l = this.Aa) ? void 0 : l.value
                },
                Xh: {
                    nh: null == (n = this.na) ? void 0 : n.value,
                    gh: null == (m = this.ha) ? void 0 : m.value
                },
                Vh: {
                    Uh: null == (p = this.Pa) ? void 0 : p.value
                }
            };
            this.D.J(a);
            _.E(zy) ? (f = Vm(rn(a)), g = f.url, uB(this.wb, (9).toString(), 9, f.Ud), this.l.J(g), this.A.J(pn(a) ? Ks("https://pagead2.googlesyndication.com/gampad/ads/%{uuid}") : Ks("https://securepubads.g.doubleclick.net/gampad/ads/%{uuid}"))) : (f = Vm(NK(a)), g = f.url, uB(this.wb, (9).toString(), 9, f.Ud), this.l.J(g), this.A.J(MK(a) ? Ks("https://pagead2.googlesyndication.com/gampad/ads/%{uuid}") : Ks("https://securepubads.g.doubleclick.net/gampad/ads/%{uuid}")))
        } else this.l.J(""), LB(this.D)
    };
    var WN = function(a, b, c, d, e, f) {
        Z.call(this, a, 878);
        this.l = b;
        this.W = c;
        this.P = d;
        this.F = e;
        this.C = YB(this);
        $B(this, f)
    };
    _.P(WN, Z);
    WN.prototype.j = function() {
        for (var a = _.x(this.l), b = a.next(); !b.done; b = a.next()) {
            b = b.value;
            var c = hj(b, this.W);
            if (!gj(b, this.W) && c) {
                a: {
                    var d = c;
                    var e = this.P.V[b.getDomId()],
                        f = 0,
                        g = 0;e = _.x(Li(e));
                    for (var h = e.next(); !h.done; h = e.next())
                        if (h = h.value, Array.isArray(h)) {
                            var k = _.x(h);
                            h = k.next().value;
                            k = k.next().value;
                            if (!("number" !== typeof h || "number" !== typeof k || 1 >= h || 1 >= k || (f = f || h, g = Math.min(g || Infinity, k), Am(jj(d, this.F)) || !d.parentElement || Am(jj(d.parentElement, this.F))))) {
                                d = [f, 0];
                                break a
                            }
                        }
                    d = f || g ? [f, g] : null
                }
                g = this.P;f = g.U;g = g.V[b.getDomId()];zm(c, pj(b), Ri(f, g), d)
            }
        }
        this.C.notify()
    };
    var XN = function(a, b, c, d, e, f) {
            this.l = a;
            this.I = b;
            this.B = c;
            this.Z = d;
            this.X = e;
            this.A = f;
            this.H = "";
            this.m = -1;
            this.j = 1;
            this.o = ""
        },
        ZN = function(a, b) {
            if (b)
                if (1 !== a.j && 2 !== a.j) YN(a, new wB("state err: (" + ([a.j, a.o.length].join() + ")")));
                else {
                    a.o && (b = a.o + b);
                    var c = 0;
                    do {
                        var d = b.indexOf("\n", c);
                        var e = -1 !== d;
                        if (!e) break;
                        var f = a;
                        c = b.substr(c, d - c);
                        if (1 === f.j) f.H = c, ++f.m, f.j = 2;
                        else {
                            try {
                                f.l(f.m, f.H, {
                                    kind: 0,
                                    Ya: Lx(c)
                                }, f.Z, f.X, f.A), f.H = ""
                            } catch (g) {}
                            f.j = 1
                        }
                        c = d + 1
                    } while (e && c < b.length);
                    a.o = b.substr(c)
                }
        },
        YN = function(a, b) {
            a.j = 4;
            try {
                a.I(b)
            } catch (c) {}
        },
        $N = function(a) {
            1 !== a.j || a.o ? YN(a, new wB("state err (" + ([a.j, a.o.length].join() + ")"))) : (a.j = 3, a.B(a.m, a.Z, a.X))
        };
    var aO = function(a, b, c, d, e, f, g, h, k, l, n) {
        Z.call(this, a, 788);
        this.O = b;
        this.L = c;
        this.G = d;
        this.X = e;
        this.C = YB(this);
        this.D = 0;
        this.A = !1;
        this.l = null != n ? n : new XMLHttpRequest;
        this.Y = X(this, f);
        this.ca = Y(this, g);
        this.da = X(this, h);
        $B(this, k);
        this.T = X(this, l)
    };
    _.P(aO, Z);
    aO.prototype.j = function() {
        var a = this,
            b = this.da.value;
        if (b) {
            var c = new XN(this.O, this.L, this.G, this.Y.value, this.X, this.ca.value);
            this.l.open("GET", b);
            this.l.withCredentials = this.T.value;
            this.l.onreadystatechange = function() {
                bO(a, c, !1)
            };
            this.l.onload = function() {
                bO(a, c, !0)
            };
            this.l.onerror = function() {
                YN(c, new xB("XHR error"))
            };
            this.l.send()
        }
        this.C.notify()
    };
    var bO = function(a, b, c) {
        try {
            if (3 === a.l.readyState || 4 === a.l.readyState)
                if (300 <= a.l.status) a.A || (YN(b, new xB("xhr_err-" + a.l.status)), a.A = !0);
                else {
                    var d = a.l.responseText.substr(a.D);
                    d && ZN(b, d);
                    a.D = a.l.responseText.length;
                    c && 4 === a.l.readyState && $N(b)
                }
        } catch (e) {
            YN(b, e)
        }
    };
    var cO = function(a, b, c, d, e, f, g, h, k, l) {
        Z.call(this, a, 1078);
        this.D = b;
        this.A = c;
        this.l = d;
        this.X = e;
        this.C = YB(this);
        this.L = X(this, f);
        this.O = Y(this, g);
        this.T = X(this, h);
        $B(this, k);
        this.G = X(this, l)
    };
    _.P(cO, Z);
    cO.prototype.j = function() {
        var a = this.T.value;
        a && dO(this, a);
        this.C.notify()
    };
    var dO = function(a, b) {
        var c, d, e, f, g, h, k, l, n, m, p, r, t;
        _.Ab(function(w) {
            switch (w.j) {
                case 1:
                    return c = new XN(a.D, a.A, a.l, a.L.value, a.X, a.O.value), e = a.G.value ? "include" : "same-origin", w.m = 2, Bb(w, fetch(b, {
                        credentials: e
                    }), 4);
                case 4:
                    d = w.o;
                    Db(w, 3);
                    break;
                case 2:
                    f = Eb(w), YN(c, new xB("fetch error: " + (f instanceof Error ? f.message : void 0)));
                case 3:
                    if (!d) return w.return();
                    if (300 <= d.status) return YN(c, new xB("fetch_status-" + d.status)), w.return();
                    h = null == (g = d.body) ? void 0 : g.getReader();
                    if (!h) return w.return();
                    k = new TextDecoder;
                    l = !1;
                case 5:
                    if (l) {
                        w.j = 6;
                        break
                    }
                    w.m = 7;
                    return Bb(w, h.read(), 9);
                case 9:
                    p = w.o;
                    m = p.value;
                    l = p.done;
                    Db(w, 8);
                    break;
                case 7:
                    n = r = Eb(w), l = !0;
                case 8:
                    t = k.decode(m, {
                        stream: !l
                    });
                    ZN(c, t);
                    w.j = 5;
                    break;
                case 6:
                    n && YN(c, new xB("fetch read error: " + (n instanceof Error ? n.message : void 0))), $N(c), w.j = 0
            }
        })
    };
    var eO = function(a, b, c, d, e) {
        Z.call(this, a, 918);
        this.P = b;
        this.wb = c;
        this.C = YB(this);
        this.l = X(this, e);
        $B(this, d)
    };
    _.P(eO, Z);
    eO.prototype.j = function() {
        var a = this.l.value;
        a.length && Cq(this.wb, "3", (0, B.K)(pi(this.P.V[a[0].getDomId()], 20)));
        this.C.notify()
    };
    var fO = function(a, b) {
        Z.call(this, a, 820);
        this.F = b;
        this.C = V(this)
    };
    _.P(fO, Z);
    fO.prototype.j = function() {
        var a = this,
            b, c, d, e;
        return _.Ab(function(f) {
            if (1 == f.j) return Bb(f, Wj(a.F), 2);
            b = f.o;
            c = b.md;
            d = b.status;
            c || yj("gpt_etu", function(g) {
                Ej(g, a.context);
                L(g, "rsn", d)
            });
            a.C.J(null != (e = c) ? e : "");
            f.j = 0
        })
    };
    var hO = function(a, b, c) {
        Z.call(this, a, 804);
        this.Ka = c;
        this.C = XB(this);
        this.A = [];
        this.Yb = {
            oh: gO(this, function(d) {
                return Un(d, 6)
            }),
            Hi: gO(this, function(d) {
                return Un(d, 7)
            }),
            vh: gO(this, function(d) {
                return !!K(d, 8)
            }),
            Zg: gO(this, function(d) {
                return y(d, 10)
            }),
            lf: gO(this, function(d) {
                var e;
                return null != (e = d.getEscapedQemQueryId()) ? e : ""
            }),
            vg: gO(this, function(d) {
                return Df(d, yw, 43)
            }),
            uh: gO(this, function(d) {
                return !!K(d, 9)
            }),
            yi: gO(this, function(d) {
                return !!K(d, 12)
            }),
            hh: gO(this, function(d) {
                return Df(d, iw, Tf(d, Lw, 48))
            }),
            Wg: gO(this, function(d) {
                return Df(d, gw, Tf(d, Lw, 39))
            }),
            dd: gO(this, function(d) {
                return y(d, 36)
            }),
            zi: gO(this, function(d) {
                return K(d, 13)
            }),
            th: gO(this, function(d) {
                return K(d, 3)
            }),
            vi: gO(this, function(d) {
                return y(d, 49)
            }),
            Ei: gO(this, function(d) {
                return Un(d, 29)
            }),
            Fi: gO(this, function(d) {
                return Un(d, 30)
            }),
            qh: gO(this, function(d) {
                return Df(d, Aw, 51)
            }),
            Rg: gO(this, function(d) {
                return y(d, 61)
            }),
            Qa: V(this),
            gg: gO(this, function(d) {
                return Df(d, Iw, 58)
            }),
            Ii: gO(this, function(d) {
                var e, f;
                return null != (f = null == (e = Df(d, zw, 56)) ? void 0 : og(e, 1)) ? f : null
            }),
            Kc: gO(this, function(d) {
                return Pe(d, aw, 62)
            }),
            Ch: gO(this, function(d) {
                return Yc(d, 63, Fc)
            }),
            Cg: gO(this, function(d) {
                return K(d, 64)
            })
        };
        this.l = X(this, b)
    };
    _.P(hO, Z);
    var gO = function(a, b) {
        var c = V(a);
        a.A.push({
            C: c,
            Tg: b
        });
        return c
    };
    hO.prototype.j = function() {
        for (var a = _.x(this.A), b = a.next(); !b.done; b = a.next()) {
            b = b.value;
            var c = b.Tg;
            KB(b.C, c(this.l.value))
        }
        0 === this.Ka.kind || 1 === this.Ka.kind && this.Ka.url ? this.Yb.Qa.J(this.Ka) : this.Yb.Qa.J({
            kind: 0,
            Ya: y(this.l.value, 4) || ""
        });
        this.C.J(this.Yb)
    };
    var iO = function(a, b, c, d) {
        Z.call(this, a, 822);
        this.slotId = b;
        this.Da = c;
        this.l = YB(this);
        this.A = X(this, d)
    };
    _.P(iO, Z);
    iO.prototype.j = function() {
        for (var a = this, b = Wn(this.A.value, 23), c = _.x(b), d = c.next(); !d.done; d = c.next()) d = d.value, iN(this.Da, d), jN(this.Da, d, this.slotId);
        this.l.notify();
        b.length && yj("gpt_hp", function(e) {
            Ej(e, a.context);
            L(e, "ls", b.join())
        }, _.If(Ey))
    };
    var jO = function(a, b, c) {
        Z.call(this, a, 803);
        this.l = b;
        this.slotId = c;
        this.C = V(this);
        this.A = V(this)
    };
    _.P(jO, Z);
    jO.prototype.j = function() {
        var a = JSON.parse(this.l),
            b = xm(a, Ms);
        if (!b) throw Error("missing ad unit path");
        if (null == a || !a[b]) throw Error("invalid ad unit path: " + b);
        a = a[b];
        if (!Array.isArray(a)) throw Error("dictionary not an array: " + this.l);
        a = Ed(Kw, a);
        var c;
        b = _.x(null != (c = Yc(a, 27, Cc)) ? c : []);
        for (c = b.next(); !c.done; c = b.next()) c = c.value, _.nf( of ).o(c);
        qf(4);
        this.slotId.dispatchEvent(tI, 800, a);
        this.C.J(a);
        var d;
        KB(this.A, null != (d = Df(a, ww, 54)) ? d : null)
    };
    var kO = function(a, b, c, d) {
        Z.call(this, a, 823);
        this.slotId = b;
        this.M = c;
        this.l = YB(this);
        this.A = X(this, d)
    };
    _.P(kO, Z);
    kO.prototype.j = function() {
        var a = this;
        K(this.A.value, 11) && (_.FI(this.M, this.slotId), CI(this.M, this.slotId, function() {
            _.GI(a.M, a.slotId)
        }));
        this.l.notify()
    };
    var lO = function(a, b, c, d) {
        Z.call(this, a, 821);
        this.X = b;
        this.wa = c;
        this.l = YB(this);
        this.A = X(this, d)
    };
    _.P(lO, Z);
    lO.prototype.j = function() {
        if (bf(this.X))
            for (var a = new _.v.Set, b = _.x(Pe(this.A.value, xw, 14)), c = b.next(); !c.done; c = b.next()) {
                c = c.value;
                var d = void 0,
                    e = null != (d = Mu(c, 5)) ? d : 1;
                a.has(e) || (oC(this.wa, 2 === e ? "__gpi" : "__gads", c, this.X), a.add(e))
            }
        this.l.notify()
    };
    var mO = function(a, b, c, d) {
        hg.call(this);
        this.context = a;
        this.slotId = b;
        a = d.M;
        var e = d.X;
        b = d.Da;
        var f = d.wa;
        d = d.Ka;
        var g = new jO(this.context, c, this.slotId);
        H(this, g);
        c = new uL(this.context, g.A);
        H(this, c);
        e = new lO(this.context, e, f, g.C);
        H(this, e);
        b = new iO(this.context, this.slotId, b, g.C);
        H(this, b);
        a = new kO(this.context, this.slotId, a, g.C);
        H(this, a);
        a = new hO(this.context, g.C, d);
        H(this, a);
        d = a.Yb;
        this.j = {
            Tb: d.vh,
            je: d.lf,
            si: d.gg,
            ke: c.l,
            Yb: a.C
        }
    };
    _.P(mO, hg);
    /* 
     
    Math.uuid.js (v1.4) 
    http://www.broofa.com 
    mailto:robert@broofa.com 
    Copyright (c) 2010 Robert Kieffer 
    Dual licensed under the MIT and GPL licenses. 
    */
    var nO = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz".split(""),
        oO = function() {
            for (var a = Array(36), b = 0, c, d = 0; 36 > d; d++) 8 == d || 13 == d || 18 == d || 23 == d ? a[d] = "-" : 14 == d ? a[d] = "4" : (2 >= b && (b = 33554432 + 16777216 * Math.random() | 0), c = b & 15, b >>= 4, a[d] = nO[19 == d ? c & 3 | 8 : c]);
            return a.join("")
        };
    var pO = function(a, b, c, d, e, f, g, h, k, l, n, m, p, r, t, w, D, G, F, O, I, Q, S, W, ja, ca) {
        Z.call(this, a, 973);
        this.ma = b;
        this.G = c;
        this.O = d;
        this.D = e;
        this.P = f;
        this.M = g;
        this.wa = h;
        this.da = k;
        this.T = l;
        this.A = n;
        this.Lc = m;
        this.ha = p;
        this.Ib = r;
        this.isSecureContext = t;
        this.hb = w;
        this.Da = D;
        this.F = G;
        this.W = F;
        this.Gb = O;
        this.ua = S;
        this.l = W;
        this.Y = ja;
        this.na = ca;
        this.L = Y(this, O);
        this.ca = X(this, I);
        this.Aa = X(this, Q);
        this.l && $B(this, this.l.Gg)
    };
    _.P(pO, Z);
    pO.prototype.j = function() {
        var a = this,
            b = new hg;
        _.Nn(this, b);
        var c = this.ca.value,
            d = sn(this.P.U);
        this.L.value && this.na.J(this.L.value);
        _.E(Dz) || H(b, new wL(this.context, console, this.Gb));
        var e = new kM(this.context, this.O, this.M, Df(this.P.U, Tq, 5), this.W);
        H(b, e);
        var f = new WN(this.context, this.O, this.W, this.P, this.F, e.C);
        H(b, f);
        var g = !!K(this.P.U, 6),
            h = new NN(this.context, this.O, g, this.P, this.G, this.F, c);
        H(b, h);
        if (_.E(pz)) {
            e = new OL(this.context, d, c);
            H(b, e);
            var k = e.C
        }
        var l = new OM(this.context, d, c, h.l, k);
        H(b, l);
        var n = new fO(this.context, this.F);
        H(b, n);
        var m = this.Y,
            p = m.lh;
        e = m.fg;
        var r = m.Bi,
            t = m.Rh;
        m = m.Wh;
        var w, D = null != (w = this.l) ? w : {};
        w = D.Jh;
        var G = D.qb,
            F = D.Sb,
            O = D.td,
            I = D.fh,
            Q, S = null != (Q = D.Ye) ? Q : {};
        Q = S.tb;
        var W = S.zb,
            ja = S.Rb,
            ca = S.Qb,
            ya = S.ac;
        D = S.Gd;
        var ua = S.Hd;
        S = S.wg;
        p = new IM(this.context, p);
        H(b, p);
        W = new bM(this.context, this.G, this.P.V, this.Ib, h.l, Q, W, ja, ca, ya, S, G);
        H(b, W);
        H(b, new hM(this.context, Q, D, ua, W.D, W.G, this.P.V));
        ua = new JM(this.context, d, c, this.F, this.L.value, e, k);
        H(b, ua);
        k = window.isSecureContext && _.E(vz) ? "wbn" : "ldjh";
        var za = ++this.M.l;
        D = "wbn" === k ? oO().toLowerCase() : void 0;
        ja = this.Lc;
        f = new VN(this.context, g, this.M, this.wa, this.P, k, ja.ub, ja.kc, ja.jc, this.Aa.value, D, _.nf(bi), c, this.isSecureContext, this.hb, this.F, p.C, n.C, h.l, W.l, ua.C, e, f.C, this.ua, w, Q, G, F, O, I, r, t, m);
        H(b, f);
        g = new eO(this.context, this.P, _.nf(bi), f.l, h.l);
        H(b, g);
        d = new ON(this.context, d, c);
        H(b, d);
        n = $h(this.context, 646, function(Oa, $a, Jb, Gb, $b, Da) {
            var ob = function() {
                return void qO(a, $b, Oa, $a, Jb, Gb, Da)
            };
            Oa && _.E(By) ? setTimeout($h(a.context, 646, ob), 0) : ob()
        });
        r = $h(this.context, 647, function(Oa, $a, Jb) {
            var Gb = function() {
                return void rO(a, za, Jb, $a, Oa)
            };
            _.E(By) ? setTimeout($h(a.context, 646, Gb), 0) : Gb()
        });
        var ka;
        "ldjh" === k ? (t = sO(this, 289, "strm_err"), _.E(Jy) && window.fetch || _.E(Ky) && Cx(window.fetch) ? ka = new cO(this.context, n, t, r, c, h.l, l.C, f.l, g.C, d.C) : ka = new aO(this.context, n, t, r, c, h.l, l.C, f.l, g.C, d.C)) : ka = new cN(this.context, n, sO(this, 1042, "Unknown web bundle error."), r, k, (0, B.K)(D), c, this.W, h.l, l.C, f.l, f.A, g.C, d.C);
        H(b, ka);
        l = new TN(this.context, za, h.l, ka.C);
        H(b, l);
        l = new LN(this.context, f.D, f.l);
        H(b, l);
        l = new UN(this.context, this.A.sa, this.P, l.C);
        H(b, l);
        l = new SN(this.context, this.da, this.F, l.C);
        H(b, l);
        l = new RN(this.context, this.P, this.T, h.l, l.C);
        H(b, l);
        h = new PN(this.context, this.M, this.P, this.W, h.l, l.C);
        H(b, h);
        h = new QN(this.context, sf(this.F), this.F, c, ka.C);
        H(b, h);
        1 === za && (c = new KN(this.context, this.F, c, e, ka.C), H(b, c));
        sg(b)
    };
    var qO = function(a, b, c, d, e, f, g) {
            var h, k, l;
            return _.Ab(function(n) {
                h = f[c];
                if (!h) return di(a.context, 646, Error("missing slot")), n.return();
                0 === c && (k = (0, B.K)(pi(a.P.V[h.getDomId()], 20)), Cq(_.nf(bi), "4", k));
                return Bb(n, tO(a, h, d, e, b, null == (l = g) ? void 0 : l[h.getId()]), 0)
            })
        },
        rO = function(a, b, c, d, e) {
            var f, g, h;
            return _.Ab(function(k) {
                switch (k.j) {
                    case 1:
                        var l = a.context,
                            n = e + 1,
                            m = d.length;
                        if (l.Pc) {
                            var p = l.Lb;
                            l = Vh(l);
                            var r = new ey;
                            r = _.id(r, 3, b);
                            n = _.fd(r, 1, n, 0);
                            m = _.fd(n, 2, m, 0);
                            m = _.Xh(l, 8, Yh, m);
                            we(p, m)
                        }
                        f = e + 1;
                    case 2:
                        if (!(f < d.length)) {
                            k.j = 4;
                            break
                        }
                        if (!d[f]) {
                            k.j = 3;
                            break
                        }
                        p = new Kw;
                        p = _.z(p, 8, !0);
                        g = Me(p);
                        h = '{"empty":' + g + "}";
                        return Bb(k, qO(a, c, f, h, {
                            kind: 0,
                            Ya: ""
                        }, d, null), 3);
                    case 3:
                        ++f;
                        k.j = 2;
                        break;
                    case 4:
                        JI(a.M, a.D) || a.A.se.dispatchEvent(yI, 965, a.D), k.j = 0
                }
            })
        },
        tO = function(a, b, c, d, e, f) {
            var g, h, k, l, n, m, p, r, t, w, D, G, F;
            return _.Ab(function(O) {
                if (1 == O.j) return g = {
                    X: e,
                    Da: a.Da,
                    M: a.M,
                    wa: a.wa,
                    Ka: d
                }, h = new mO(a.context, b, c, g), Bb(O, sg(h), 2);
                k = O.o;
                l = k.Tb;
                n = k.je;
                m = k.si;
                p = k.ke;
                r = k.Yb;
                if (b.H) return O.return();
                t = !!m;
                D = null == (w = m) ? void 0 : Df(w, Gw, 5);
                t && yj("gpt_td_init", function(I) {
                    Ej(I, a.context);
                    var Q, S;
                    L(I, "winner_qid", null != (S = null == (Q = D) ? void 0 : Q.getEscapedQemQueryId()) ? S : "");
                    var W, ja;
                    L(I, "xfpQid", null != (ja = null == (W = D) ? void 0 : _.Rf(W, 6)) ? ja : "");
                    L(I, "noFill", l ? "1" : "0");
                    L(I, "publisher_tag", "gpt")
                }, 1);
                G = Mm(a.P.V[b.getDomId()]);
                ((F = Xm("google_norender") || 5 === G && _.E(Yy)) || l && !t) && !_.E(Xq) ? Gq(b, a.M, a.P, (0, B.K)(n)) : FN(a.ha, a.ma, a.G, b, l || F, t, a.M, a.P, a.Da, r, (0, B.K)(p), e, f, a.A.sa, a.T, a.l, a.Y);
                h.Ha();
                O.j = 0
            })
        },
        sO = function(a, b, c) {
            return $h(a.context, b, function(d) {
                d = d instanceof Error ? d : Error();
                d.message = d.message || c;
                di(a.context, b, d);
                JI(a.M, a.D) || a.A.se.dispatchEvent(yI, 965, a.D)
            })
        };
    var uO = function(a, b, c, d, e, f, g, h, k, l, n, m, p, r, t, w, D, G, F, O, I, Q, S, W, ja) {
        Z.call(this, a, 885);
        this.ha = b;
        this.D = c;
        this.P = d;
        this.M = e;
        this.wa = f;
        this.Lc = g;
        this.ca = h;
        this.O = k;
        this.l = l;
        this.G = n;
        this.da = m;
        this.isSecureContext = p;
        this.L = r;
        this.Y = t;
        this.hb = w;
        this.Da = D;
        this.Bb = G;
        this.F = F;
        this.W = O;
        this.A = S;
        this.T = W;
        this.ma = ja;
        this.na = X(this, I);
        $B(this, Q)
    };
    _.P(uO, Z);
    uO.prototype.j = function() {
        var a = this.na.value;
        if (a.length) {
            var b = this.M,
                c = this.l,
                d = a.length;
            b.o.has(c);
            b.o.set(c, d);
            a = _.x(a);
            for (b = a.next(); !b.done; b = a.next()) {
                c = b.value;
                var e = void 0,
                    f = void 0;
                b = c.Ib;
                d = c.Z;
                c = new hg;
                _.Nn(this, c);
                var g = Qn(this.context, this.Y, null == (f = this.A) ? void 0 : f.Kh);
                f = g.Ub;
                var h = g.pf;
                _.Nn(c, g.zc);
                f = An(this.context, this.D, this.M, sn(this.P.U), this.F, f, h);
                g = f.ob;
                _.Nn(c, f.zc);
                f = new JN(this.context, this.F, g);
                H(c, f);
                f = new GN(this.context, this.F, g);
                H(c, f);
                f = new HN(this.context, null != (e = this.Bb) ? e : _.Rh(150), g);
                H(c, f);
                e = new Mq(this.context, this.F, g);
                H(c, e);
                h = new IN(this.context, this.wa, this.L, e.C, g);
                H(c, h);
                b = new pO(this.context, this.ha, this.D, d, this.l, this.P, this.M, this.wa, this.ca, this.O, this.G, this.Lc, this.da, b, this.isSecureContext, this.hb, this.Da, this.F, this.W, e.C, g, h.A, f.l, this.A, this.T, this.ma);
                H(c, b);
                sg(c)
            }
        } else this.G.se.dispatchEvent(yI, 965, this.l)
    };
    var vO = new _.v.Map,
        wO = function(a, b, c, d) {
            d = void 0 === d ? vO : d;
            Z.call(this, a, 834);
            this.D = b;
            this.Z = c;
            this.l = d;
            this.A = V(this);
            this.G = _.v.Promise.all(this.Z.map(this.L, this))
        };
    _.P(wO, Z);
    wO.prototype.j = function() {
        var a = this,
            b;
        return _.Ab(function(c) {
            if (1 == c.j) return Bb(c, a.G, 2);
            b = c.o;
            a.A.J(b.filter(function(d) {
                return null != d && !d.H
            }));
            c.j = 0
        })
    };
    wO.prototype.L = function(a) {
        var b = this,
            c, d;
        return _.Ab(function(e) {
            if (1 == e.j) {
                if (a.H) return e.return();
                b.l.has(a) || (b.l.set(a, Dr(a)), _.go(a, function() {
                    return void b.l.delete(a)
                }));
                c = (0, B.K)(b.l.get(a));
                return Bb(e, c(), 2)
            }
            d = e.o;
            if (b.H) return e.return();
            if (d) return e.return(a);
            N(b.D, NJ(a.getAdUnitPath()));
            return e.return()
        })
    };
    var xO = function(a, b, c, d, e) {
        Z.call(this, a, 847);
        this.M = b;
        this.Na = c;
        this.A = d;
        this.l = V(this);
        this.D = X(this, e)
    };
    _.P(xO, Z);
    xO.prototype.j = function() {
        var a = this.D.value;
        if (a.length) {
            for (var b = _.x(a), c = b.next(); !c.done; c = b.next()) KI(this.M, c.value);
            this.A ? this.l.J([]) : this.Na ? (b = Oh(a[0].getAdUnitPath()), a = yO(a, b), this.l.J(a)) : (a = a.map(function(d) {
                return {
                    Ib: Oh(d.getAdUnitPath()),
                    Z: [d]
                }
            }), this.l.J(a))
        } else this.l.J([])
    };
    var yO = function(a, b) {
        var c = [];
        a = Ba(a, function(f) {
            return Oh(f.getAdUnitPath())
        });
        a = _.x(_.u(Object, "entries").call(Object, a));
        for (var d = a.next(); !d.done; d = a.next()) {
            var e = _.x(d.value);
            d = e.next().value;
            e = e.next().value;
            d === b ? c.unshift({
                Ib: d,
                Z: e
            }) : c.push({
                Ib: d,
                Z: e
            })
        }
        return c
    };
    var zO = function(a, b, c) {
        Z.call(this, a, 845);
        this.V = b;
        this.l = V(this);
        this.A = V(this);
        this.D = X(this, c)
    };
    _.P(zO, Z);
    zO.prototype.j = function() {
        var a = this,
            b = function(d) {
                return !!Li(a.V[d.getDomId()]).length
            },
            c = this.D.value;
        this.l.J(c.filter(b));
        this.A.J(c.filter(Qs(b)))
    };
    var AO = function(a, b, c, d, e) {
        Z.call(this, a, 864);
        this.M = b;
        this.P = c;
        this.W = d;
        this.l = YB(this);
        this.A = X(this, e)
    };
    _.P(AO, Z);
    AO.prototype.j = function() {
        for (var a = _.x(this.A.value), b = a.next(); !b.done; b = a.next())
            if (b = b.value, _.Eq(this.M, b)) {
                var c = this.P,
                    d = c.U;
                c = c.V[b.getDomId()];
                tn(c, d) && un(b, this.W, c, d);
                KI(this.M, b);
                var e = void 0,
                    f = void 0;
                null != (e = null != (f = Qi(c, 10)) ? f : K(d, 11)) && e && un(b, this.W, c, d)
            }
        this.l.notify()
    };
    var BO = function(a, b, c, d, e, f, g, h, k, l, n, m, p, r, t, w, D, G, F, O) {
        _.U.call(this);
        var I = this;
        this.context = a;
        this.L = b;
        this.B = c;
        this.M = d;
        this.wa = e;
        this.sa = f;
        this.R = g;
        this.A = h;
        this.G = k;
        this.isSecureContext = l;
        this.I = n;
        this.D = m;
        this.hb = p;
        this.Da = r;
        this.Bb = t;
        this.W = w;
        this.F = D;
        this.l = G;
        this.N = F;
        this.O = O;
        this.j = new _.v.Map;
        this.m = new pI(a);
        _.Nn(this, this.m);
        this.m.aa(yI, function(Q) {
            Q = Q.detail;
            var S = I.j.get(Q);
            S && (I.j.delete(Q), S.Ha())
        })
    };
    _.P(BO, _.U);
    var CO = function(a, b, c, d) {
        var e = ++a.M.B;
        a.j.has(e);
        var f = new hg;
        a.j.set(e, f);
        b = new wO(a.context, a.B, b);
        H(f, b);
        var g = new zO(a.context, d.V, b.A);
        H(f, g);
        b = new xO(a.context, a.M, !!K(d.U, 6), Xm("google_nofetch"), g.l);
        H(f, b);
        g = new AO(a.context, a.M, d, document, g.A);
        H(f, g);
        a = new uO(a.context, a.L, a.B, d, a.M, a.wa, c, a.R, a.A, e, {
            se: a.m,
            sa: a.sa
        }, a.G, a.isSecureContext, a.I, a.D, a.hb, a.Da, a.Bb, a.F, a.W, b.l, g.l, a.l, a.N, a.O);
        H(f, a);
        sg(f)
    };
    var DO = function(a, b, c, d, e, f, g, h, k, l, n, m, p, r, t, w) {
        fN.call(this, c, h);
        this.context = a;
        this.M = d;
        this.I = new _.v.Set;
        this.N = {};
        this.G = new EN(a, d);
        this.L = new BO(a, b, c, d, new _.lC(window), this.l, n, e, this.G, f, g, k, l, m, p, document, window, r, t, w);
        _.Nn(this, this.L)
    };
    _.P(DO, fN);
    DO.prototype.getName = function() {
        return "publisher_ads"
    };
    DO.prototype.display = function(a, b, c, d, e) {
        d = void 0 === d ? "" : d;
        e = void 0 === e ? "" : e;
        var f = "";
        if (d)
            if (_.na(d) && 1 == d.nodeType) {
                var g = d;
                f = g.id
            } else f = d;
        Ep(this);
        var h = cm(c, this.context, this.j, a, b, f),
            k = h.slotId;
        h = h.nb;
        if (k && h) {
            g && !f && (g.id = k.getDomId());
            this.slotAdded(k, h);
            h.setClickUrl(e);
            var l;
            xp(this, null != (l = g) ? l : k.getDomId(), c)
        } else N(this.j, Nk("PubAdsService.display", [a, b, d]))
    };
    var xp = function(a, b, c) {
            var d = EO(b, c);
            c = d.slotId;
            var e = d.Lg;
            d = d.Mg;
            if (c) {
                if (b = rj(), (d = Zn(b, c.getDomId())) && !K(d, 19))
                    if (e && b.m.set(c, e), hj(c) || Pi(Mm(d))) {
                        if (_.z(d, 19, !0), e = aj(b.j, b.o), a.B) {
                            Ep(a);
                            a.B && EI(a.M, c);
                            a.j.info(iJ());
                            b = e.U;
                            d = e.V;
                            var f = K(b, 6);
                            if (f || !a.M.Cb(c)) f && (f = hj(c)) && c.dispatchEvent(sI, 778, f), K(b, 4) && (d = d[c.getDomId()], tn(d, b) && !a.M.Cb(c) && un(c, document, d, b)), FO(a, e, c)
                        }
                    } else N(a.j, YI(String(y(d, 1)), String(y(d, 2))), c)
            } else d ? a.j.error(ZI(d)) : a.j.error(Nk("googletag.display", [String(b)]))
        },
        lK = function(a, b, c) {
            var d = void 0 === d ? document : d;
            var e;
            null != (e = c.V[b.getDomId()]) && _.z(e, 19, !0);
            e = {
                id: Xw(b.getDomId())
            };
            nb(d, ih(e));
            hj(b, d) ? (Ep(a), EI(a.M, b), FO(a, c, b)) : yj("gpt_pb_write", function(f) {
                Ej(f, a.context)
            })
        };
    DO.prototype.slotAdded = function(a, b) {
        var c = this;
        K(b, 17) || this.B && EI(this.M, a);
        this.l.dispatchEvent(vI, 724, {
            Pe: a.getDomId(),
            V: b
        });
        var d = 0;
        a.aa(Fq, function(e) {
            var f = e.detail;
            e = f.size;
            f = f.isEmpty;
            var g = new pM(a, "publisher_ads");
            f && (g.isEmpty = !0);
            var h = a.pa.getResponseInformation();
            e && h && (g.size = [e.width, e.height], g.sourceAgnosticCreativeId = h.sourceAgnosticCreativeId, g.sourceAgnosticLineItemId = h.sourceAgnosticLineItemId, g.isBackfill = h.isBackfill, g.creativeId = h.creativeId, g.lineItemId = h.lineItemId, g.creativeTemplateId = h.creativeTemplateId, g.advertiserId = h.advertiserId, g.campaignId = h.campaignId, g.yieldGroupIds = h.yieldGroupIds, g.companyIds = h.companyIds);
            _.E(Ny) && (e = new Zk("gpt_sree"), Ej(e, c.context), L(e, "sid", c.context.pvsid), L(e, "adk", ur(c.M, a)), L(e, "nf", f), L(e, "rc", II(c.M, a)), L(e, "sret", ((_.jf(_.q) || 0) - d).toFixed(3)), al(e));
            c.l.dispatchEvent("slotRenderEnded", 708, g)
        });
        a.aa(tI, function(e) {
            var f, g;
            d = null != (g = null != (f = e.timeStamp) ? f : _.jf(_.q)) ? g : 0;
            c.l.dispatchEvent("slotResponseReceived", 709, new vM(a, c.getName()))
        });
        fN.prototype.slotAdded.call(this, a, b)
    };
    var FO = function(a, b, c) {
            var d = GO(a, b, c);
            HO(a, d, b, {
                ub: 1
            });
            b = c.getAdUnitPath();
            if (c = a.N[b]) {
                c = _.x(c);
                for (d = c.next(); !d.done; d = c.next()) d = d.value, HO(a, d.Z, d.P, d.Lc);
                delete a.N[b]
            }
        },
        GO = function(a, b, c) {
            var d = b.U;
            b = b.V;
            if (K(d, 4)) return [];
            var e;
            return !K(d, 6) || (null == (e = b[c.getDomId()]) ? 0 : K(e, 17)) ? (a.I.add(c), _.go(c, function() {
                return void a.I.delete(c)
            }), [c]) : a.m.filter(function(f) {
                if (a.I.has(f)) return !1;
                a.I.add(f);
                _.go(f, function() {
                    return void a.I.delete(f)
                });
                return !0
            })
        },
        HO = function(a, b, c, d) {
            a.j.info(pJ());
            if (IO(a, b, d, c) && 1 !== d.ub)
                for (b = _.x(b), d = b.next(); !d.done; d = b.next()) d = d.value.getDomId(), a.l.dispatchEvent(wI, 725, {
                    Pe: d,
                    V: c.V[d]
                })
        },
        IO = function(a, b, c, d) {
            b = b.filter(function(e) {
                if (!_.Eq(a.M, e)) return !1;
                var f = d.V[e.getDomId()];
                5 !== Mm(f) && 4 !== Mm(f) || _.FI(a.M, e);
                return !0
            });
            if (!b.length) return null;
            CO(a.L, b, c, d);
            return b
        };
    DO.prototype.refresh = function(a, b, c) {
        b = JO(this, b);
        if (!b.length) return !1;
        KO(this, a, b, null != c ? c : {
            ub: 2
        });
        return !0
    };
    var JO = function(a, b) {
            return b.filter(function(c, d) {
                if (!c.H) return !0;
                N(a.j, sJ(String(d)));
                return !1
            })
        },
        KO = function(a, b, c, d) {
            var e = c[0],
                f, g = null != (f = null == e ? void 0 : e.getDomId()) ? f : "";
            if (a.B) {
                var h = {};
                e = _.x(c);
                for (f = e.next(); !f.done; h = {
                        tc: h.tc
                    }, f = e.next()) h.tc = f.value, a.I.add(h.tc), _.go(h.tc, function(k) {
                    return function() {
                        return void a.I.delete(k.tc)
                    }
                }(h));
                HO(a, c, b, d)
            } else c.length && K(b.U, 6) ? (N(a.j, oJ(g), e), e = e.getAdUnitPath(), f = null != (h = a.N[e]) ? h : [], f.push({
                Z: c,
                P: b,
                Lc: d
            }), a.N[e] = f) : N(a.j, mJ(g), e)
        };
    DO.prototype.R = function() {
        var a = this,
            b = rj().j;
        if (K(b, 6))
            for (var c = _.x(this.m), d = c.next(); !d.done; d = c.next()) this.B && EI(this.M, d.value);
        sK(this, b);
        this.l.aa("rewardedSlotClosed", function(e) {
            var f = e.detail.slot;
            e = _.u(a.m, "find").call(a.m, function(g) {
                return f === g.pa
            });
            LO(a, [e], rj().j, rj().o, a.M)
        });
        Uk()
    };
    DO.prototype.destroySlots = function(a) {
        a = fN.prototype.destroySlots.call(this, a);
        if (a.length && this.B) {
            var b = rj();
            MO(this, a, b.j, b.o)
        }
        return a
    };
    var uK = function(a, b, c, d) {
            if (!a.B) return N(a.j, nJ(), d[0]), !1;
            var e = JO(a, d);
            if (!e.length) return N(a.j, Nk("PubAdsService.clear", [d].filter(function(f) {
                return void 0 !== f
            }))), !1;
            a.j.info(qJ());
            MO(a, e, b, c);
            return !0
        },
        MO = function(a, b, c, d) {
            for (var e = _.x(b), f = e.next(); !f.done; f = e.next()) BI(a.M, f.value);
            LO(a, b, c, d, a.M)
        };
    DO.prototype.forceExperiment = function(a) {
        a = Number(a);
        0 < a && _.nf( of ).o(a)
    };
    var LO = function(a, b, c, d, e) {
            var f = void 0 === f ? window : f;
            b = _.x(b);
            for (var g = b.next(); !g.done; g = b.next()) {
                g = g.value;
                MI(a.G.M, g);
                var h = d[g.getDomId()];
                tn(h, c) && un(g, f.document, h, c);
                KI(e, g)
            }
        },
        tK = function(a, b, c, d) {
            if ("string" !== typeof b || "string" !== typeof c) N(a.j, Nk("PubAdsService.setVideoContent", [b, c]));
            else {
                var e = _.z(d, 21, !0);
                b = _.z(e, 22, b);
                _.z(b, 23, c);
                sK(a, d)
            }
        },
        vK = function(a, b) {
            if (!a.B) return null;
            var c, d;
            return {
                vid: null != (c = y(b, 22)) ? c : "",
                cmsid: null != (d = y(b, 23)) ? d : ""
            }
        },
        sK = function(a, b) {
            K(b, 21) && a.B && _.z(b, 29, Mx())
        },
        EO = function(a, b) {
            var c = "";
            if ("string" === typeof a) c = a, b = QK(b, c);
            else if (_.na(a) && 1 == a.nodeType) {
                var d = a;
                c = d.id;
                b = QK(b, c)
            } else b = (_.C = [].concat(_.ue(b.Z)), _.u(_.C, "find")).call(_.C, function(e) {
                return e.pa === a
            });
            return {
                slotId: b,
                Lg: d,
                Mg: c
            }
        };
    var NO = _.R(["https://securepubads.g.doubleclick.net/pagead/js/rum_debug.js"]),
        OO = _.R(["https://securepubads.g.doubleclick.net/pagead/js/rum.js"]);
    var PO = as(["^[-p{L}p{M}p{N}_,.!*<>():/]*$"], ["^[-\\p{L}\\p{M}\\p{N}_,\\.!*<>():/]*$"]),
        QO = _.Rs(function() {
            Ix("The googletag.pubads().definePassback function has been deprecated. The function may break in certain contexts, see https://developers.google.com/publisher-tag/guides/passback-tags#construct_passback_tags for how to correctly create a passback.")
        }),
        SO = function(a, b) {
            var c = this;
            var d = void 0 === d ? _.u(String, "raw").call(String, PO) : d;
            this.M = a;
            this.o = d;
            this.j = new _.v.Map;
            this.Z = new _.v.Set;
            b.o = function(e) {
                return RO(c, e)
            }
        };
    SO.prototype.defineSlot = function(a, b, c, d, e) {
        a = cm(this, a, b, c, d, e);
        var f = a.slotId;
        if (f) return f.pa;
        a.nd || b.error(Nk("googletag.defineSlot", [c, d, e]));
        return null
    };
    var cm = function(a, b, c, d, e, f, g) {
        return "string" === typeof d && 0 < d.length && e && (void 0 === f || "string" === typeof f) ? a.add(b, c, d, e, {
            pb: f,
            Nf: void 0 === g ? !1 : g
        }) : {}
    };
    SO.prototype.add = function(a, b, c, d, e) {
        var f = this,
            g = void 0 === e ? {} : e;
        e = g.pb;
        var h = void 0 === g.format ? 0 : g.format,
            k = void 0 === g.Nf ? !1 : g.Nf;
        g = void 0 === g.La ? !1 : g.La;
        try {
            var l = new RegExp(this.o, "u");
            if (l.test("/1") && !l.test(c)) return b.error(aJ(c)), {
                nd: !0
            }
        } catch (m) {}
        if (l = Um(h, g)) return Gm(b, l, h, c), {};
        k && QO();
        h = this.j.get(c) || Number(k);
        b = TO(this, a, b, c, h, d, e || "gpt_unit_" + c + "_" + h);
        a = b.nb;
        var n = b.slotId;
        b = b.nd;
        if (!n) return {
            nd: b
        };
        this.j.set(c, h + 1);
        this.Z.add(n);
        _.go(n, function() {
            return void f.Z.delete(n)
        });
        ZG(c);
        return {
            slotId: n,
            nb: a
        }
    };
    var QK = function(a, b) {
            a = _.x(a.Z);
            for (var c = a.next(); !c.done; c = a.next())
                if (c = c.value, c.getDomId() === b) return c
        },
        vp = function(a) {
            a = _.x(a);
            for (var b = a.next(); !b.done; b = a.next()) b.value.Ha()
        },
        TO = function(a, b, c, d, e, f, g) {
            var h = QK(a, g);
            if (h) return c.error($I(g, d, h.getAdUnitPath())), {
                nd: !0
            };
            var k = new zK;
            AK(_.z(k, 1, d), g);
            BK(k, om(f));
            pH(k);
            var l = new Ee(b, d, e, g);
            nK(l, wm(b, c, l));
            _.go(l, function() {
                var n = rj(),
                    m = l.getDomId();
                delete n.o[m];
                n.m.delete(l);
                n = l.getAdUnitPath();
                n = Oh(n);
                var p;
                m = (null != (p = mi.get(n)) ? p : 0) - 1;
                0 >= m ? mi.delete(n) : mi.set(n, m);
                c.info(zJ(l.toString()), l);
                (p = Gk.get(l)) && Hk.delete(p);
                Gk.delete(l)
            });
            c.info(OI(l.toString()), l);
            l.aa(uI, function(n) {
                n = n.detail.gi;
                c.info(PI(l.getAdUnitPath()), l);
                uB(_.nf(bi), "7", 9, II(a.M, l), 0, n)
            });
            l.aa(tI, function(n) {
                var m = n.detail;
                c.info(QI(l.getAdUnitPath()), l);
                var p;
                n = _.nf(bi);
                var r = pi(k, 20);
                m = null != (p = m.getEscapedQemQueryId()) ? p : "";
                n.j && (_.q.google_timing_params = _.q.google_timing_params || {}, _.q.google_timing_params["qqid." + r] = m)
            });
            l.aa(Dq, function() {
                return void c.info(RI(l.getAdUnitPath()), l)
            });
            l.aa(Fq, function() {
                return void c.info(SI(l.getAdUnitPath()), l)
            });
            return {
                nb: k,
                slotId: l
            }
        },
        RO = function(a, b) {
            var c = new RegExp("(^|,|/)" + b + "($|,|/)");
            return [].concat(_.ue(a.Z)).some(function(d) {
                return c.test(Oh(d.getAdUnitPath()))
            })
        };
    var Mr = "1";
    (function(a, b) {
        var c = null != a ? a : {
            Ta: Nr(),
            jb: "m202304030101",
            Lb: new _.Rr(0),
            bg: !0,
            jf: 1
        };
        try {
            var d = Tk();
            (0, B.Pf)(!_.nf(Ph).j);
            _.u(Object, "assign").call(Object, Qh, d._vars_);
            d._vars_ = Qh;
            if (d.evalScripts) d.evalScripts();
            else {
                MH();
                try {
                    dh()
                } catch (ka) {
                    di(c, 408, ka)
                }
                nn();
                var e = new UL;
                try {
                    $g(e.I), qf(13), qf(3)
                } catch (ka) {
                    di(c, 408, ka)
                }
                var f = Pr(e),
                    g = null != a ? a : Sr(f),
                    h = null != b ? b : new TL(g);
                Zh(g);
                yj("gpt_fifwin", function(ka) {
                    Ej(ka, g)
                }, d.fifWin ? .01 : 0);
                var k = new AI,
                    l = new SO(k, e),
                    n = new pN(g),
                    m = _.Rh(260),
                    p = new ML(g, l, rj(), h, k, m, e, n),
                    r = wx(),
                    t = Zp(g),
                    w = new pI(g),
                    D = new pI(g),
                    G = new pI(g),
                    F;
                m && (F = NL(p, w));
                var O = _.Rh(221),
                    I = new sN,
                    Q = new hN,
                    S, W, ja = null != (W = null == (S = F) ? void 0 : S.Gb) ? W : new Lq,
                    ca;
                _.E(Sy) && (ca = _.Rh(150));
                var ya = new DO(g, l, h, k, n, r, e, w, m, O, I, Q, ca, F, t, ja);
                _.E(Fz) && new RK(g, w, k, l);
                var ua = rj().j;
                Mp(g, h, ya, ua, l, D, G, e, Q, ja);
                var za = $h(g, 77, function() {
                    var ka = d.cmd;
                    if (!ka || Array.isArray(ka)) {
                        var Oa = new SK(h);
                        d.cmd = Kk(g, Oa);
                        null != ka && ka.length && Oa.push.apply(Oa, ka)
                    }
                });
                d.fifWin && "complete" !== document.readyState ? _.yb(window, "load", function() {
                    return window.setTimeout(za, 0)
                }) : za();
                sp();
                if (_.E(Fz) || _.nf(bi).j) Lr(), bl(document, _.E(Hz) ? _.A(NO) : _.A(OO));
                rq(g, h);
                Xk(g)
            }
        } catch (ka) {
            di(c, 106, ka)
        }
    })();
    var WO = function(a, b) {
        var c = this;
        this.m = a;
        this.j = !1;
        this.H = b;
        this.o = this.H.ra(264, function(d) {
            c.j && (UO || (d = Date.now()), c.m(d), UO ? VO.call(_.q, c.o) : _.q.setTimeout(c.o, 17))
        })
    };
    WO.prototype.start = function() {
        this.j || (this.j = !0, UO ? VO.call(_.q, this.o) : this.o(0))
    };
    WO.prototype.stop = function() {
        this.j = !1
    };
    var VO = _.q.requestAnimationFrame || _.q.webkitRequestAnimationFrame,
        UO = !!VO && !/'iPhone'/.test(_.q.navigator.userAgent);
    var XO = function(a, b, c, d) {
        this.o = a;
        this.ia = b;
        this.L = c;
        this.progress = 0;
        this.H = null;
        this.B = !1;
        this.j = [];
        this.m = null;
        this.l = new WO((0, _.ys)(this.D, this), d)
    };
    XO.prototype.D = function(a) {
        if (this.B) this.l.stop();
        else {
            null === this.H && (this.H = a);
            this.progress = (a - this.H) / this.L;
            1 <= this.progress && (this.progress = 1);
            a = this.m ? this.m(this.progress) : this.progress;
            this.j = [];
            for (var b = 0; b < this.o.length; b++) this.j.push((this.ia[b] - this.o[b]) * a + this.o[b]);
            this.N();
            1 == this.progress && (this.l.stop(), this.I())
        }
    };
    XO.prototype.I = function() {};
    XO.prototype.N = function() {};
    _.YO = function(a) {
        a.B = !1;
        a.l.start()
    };
    XO.prototype.stop = function() {
        this.B = !0
    };
    _.ZO = function(a) {
        return a * a * a
    };
    _.$O = function(a) {
        a = 1 - a;
        return 1 - a * a * a
    };
    _.aP = function(a, b, c, d, e, f, g, h) {
        XO.call(this, [b], [c], d, f);
        this.R = a;
        this.G = e;
        this.A = g ? g : null;
        this.m = h || null
    };
    _.P(_.aP, XO);
    _.aP.prototype.N = function() {
        var a = {};
        a[this.G] = this.j[0] + "px";
        _.Wx(this.R, a)
    };
    _.aP.prototype.I = function() {
        this.A && this.A()
    };
}).call(this, {});